# Skibidi Debug (merged)

## Build
    gradlew build        ->  build/libs/skibidi-debug-1.0.0.jar   (single jar, drop into mods/)
(gradle.properties still points at G:/JDK21 – change org.gradle.java.home if your JDK lives elsewhere.)

## How the merge works
* Main addon (ex "P3nis Debug V5"): full source, package com.skibidi.debug (renamed, no "p3nis" left anywhere).
* Skibidi Debug   : only .class files were provided (no source), so it is bundled as
                    libs/skibididebug-classes.jar and booted from P3nisDebugAddon.onInitialize()
                    inside a try/catch (if that half ever fails, the other modules still load).
* One fabric.mod.json / one Meteor entrypoint / one jar.

## Rename (p3nis -> skibidi)
* Entry class SkibidiDebugAddon, mod id skibidi-debug, jar skibidi-debug-1.0.0.jar, package com.skibidi.debug
  (deliberately NOT under dev.skibididebug: Orbit matches lambda factories by package prefix and an overlap could mix them up).
* Categories: "Astrix Finder", "Astrix Extra", "Astrix Music" (+ the original "Skibididebug" category from the classes half).
* Module p3nis-finder -> skibidi-finder. Config folder is now config/skibididebug/ (old config/p3nis/ is simply ignored).

## Changes
* Module-name collision: both halves had a module called "region-map". The Skibidi one is now
  "skibidi-region-map" (patched in the class constant pool).
* Removed SpawnerRendererMixin (empty mixin targeting class_839, did nothing, only a startup-crash risk).
* AutoRTPHome: /sethome now sends the slot (/sethome <n>, like HomeSeter); rtp regions are sent as
  "/rtp eu central" (space) instead of "eu-central"; log text no longer claims it disables itself.

## Not done / needs input
* Skibidi Debug classes could not be edited at source level (no source). Bug fixes there need a decompile.
* Head textures for the Admin list: assets/skibididebug/textures/admin/<name>.png are NOT in the zip you sent.
* Nothing here could be compiled or run on my side (no Minecraft/Meteor jars, no network).

## FIX (debug pass)
* ROOT CAUSE module "skibidi-debug" không hiện: Meteor gọi onRegisterCategories() trước onInitialize();
  bản cũ chỉ tạo `skibidi` trong onInitialize() => category của nửa Skibididebug không bao giờ được đăng ký.
  Giờ đăng ký bằng `Skibididebug.CATEGORY` (static) ngay trong onRegisterCategories().
* gradle.properties: bỏ `org.gradle.java.home=G:/JDK21` (làm build lỗi trên mọi máy khác).
* gradlew: dùng GradleWrapperMain chuẩn.
* Mixin defaultRequire 1 -> 0: nếu signature Camera/ClientPlayNetworkHandler lệch bản MC thì chỉ tắt tính năng, không crash game.

## Custom Models merge
* custom-models-addon is in subproject custom-models/ (package dev.custommodels.addon, source untouched), nested into the main jar
  via `include project(':custom-models')` -> still ONE jar: build/libs/skibidi-debug-1.0.0.jar. Module "custom-models" is in the Render tab.
* Reason for a subproject: custom-models uses YARN names, this project uses INTERMEDIARY (class_XXXX).
* build.gradle: added the missing fabric-loader modImplementation line. Removed missing icon reference from fabric.mod.json.
* yarn_mappings=1.21.11+build.4 in gradle.properties is a guess - verify at fabricmc.net/develop.
* Not compiled here.

## FIX v4 (code pass)
* ChunkFinder: airPocket no longer inflated (run counter reset per run); hidden-ore now counts only player filler
  (cobble / cobbled deepslate / obsidian, >=4 faces) instead of natural stone; chunk marked scanned only once it is
  really loaded; vertical-vein uses longest ore run per column; queue rebuilt every 60 ticks (was 200).
* SusChunkFinder: new setting cocoa-min (default 10) – natural jungle cocoa no longer flags every chunk.
* TuffChunkFinder: no more worker thread; scans on the client thread, 4 chunks/tick (same detection rules/cooldown).
* custom-models: mixin config required=false, defaultRequire=0; no hard (CustomModelState) casts.
* skibidi-debug.mixins.json: required=false (a bad @Shadow/@Inject target now only disables that feature).
* BaseCalc is inside libs/skibididebug-classes.jar (no source) -> NOT changed.
* Still not compiled/run here.

## FIX v5 (finder bug pass)
* TuffChunkFinder: bo "Base chance: 40-100%" (la so random). Thong bao nay hien ly do that (Beehive / Cobbled deepslate / Dense vines / Dense seagrass / Repeaters) + toa do chunk. Hang doi quet chunk gan nguoi choi truoc, nen candidate la chunk gan nhat (truoc day la chunk dau hang = goc tay-bac).
* AmethystESP: chi bao chat 1 lan cho moi geode moi (truoc day lap lai moi 5 giay vi quet lai); bo qua chunk rong; xoa geode khi khong con du bud.
* SpawnerChunk: quet moi 20 tick thay vi moi tick; xoa danh sach khi doi world/dimension; xoa spawner da bi pha.
* StorageDensityScanner: diem chunk duoc cap nhat/xoa khi tuot duoi nguong hoac chunk ra xa; o ve nam o do cao trung binh cua cac ruong (truoc day nhay theo Y nguoi choi).
* Van chua compile/chay (khong co jar Minecraft/Meteor).

* libs/skibididebug-classes.jar da duoc dat lai dung cho (khong xoa/khong sua thu muc libs).

## FIX v5.1
* fabric.mod.json: them lai "icon": "assets/skibididebug/icon.png" (file icon.png van nam trong assets, truoc do bi bo nham).

## FIX v6
* Category cua nua Skibididebug doi ten: "Skibidi Debug Sourced by kydufi" -> "Astrix debug+" (patch constant pool trong libs/skibididebug-classes.jar).

## FIX v7 (custom-models)
* LivingEntityRendererMixin: @At target cua submitModel thieu descriptor nen Loom khong remap sang intermediary => mixin khong gan duoc, model khong doi. Da them descriptor day du (Model, Object, MatrixStack, RenderLayer, int x3, Sprite, int, CrumblingOverlayCommand)V.
* Chua compile/chay thu local; kiem tra bang cach build lai va xem custom-models co doi model trong game.

## FIX v8
* SusChunkFinder: them "render-filled-chunk" (mac dinh bat) + "chunk-fill-color" / "chunk-line-color" (do). Chunk bi flag duoc to day ca cot tu day world den tran (giong SpawnerChunk); tam phang o Y=63 cu van giu.
* Astrix Finder: bo module skibidi-finder (xoa SkibidiFinder.java + bo dang ky trong SkibidiDebugAddon).
* Chua compile/chay (khong co jar Minecraft/Meteor).

## v9 - Sus Chunk Finder V2
* Moi subproject `sus-chunk-v2/` (yarn, giong custom-models, nested vao jar chinh bang `include project(':sus-chunk-v2')`).
* Module `sus-chunk-finder-v2` = SusChunkFinder cua chukl-addon (heatmap theo cay/amethyst chua moc xong, smart-adjustment, rotated-deepslate...). Dat trong category "Astrix Finder".
* Entry `dev.suschunkv2.SusChunkV2Addon` tim category "Astrix Finder" qua Modules.loopCategories() trong onInitialize (categories luon duoc dang ky truoc). Neu khong thay thi chi log loi, khong crash.
* Module cu `sus-chunk-finder` giu nguyen. Mac dinh V2 chi bat amethyst; render la tam do phang Y=63 (chinh chunk-thickness de thanh cot).
* Chua compile/chay (khong co jar Minecraft/Meteor). Neu yarn_mappings build.4 sai thi sua trong gradle.properties.

## v10 - BugPet / BugPet+
* Subproject `bugpet/` (yarn, nested vao jar chinh bang `include project(':bugpet')`), package dev.bugpet.
* Module `bugpet` = Chunk Finder cu (geode light anomaly); module `bugpet+` = Chunk Finder v2 cu (vein cot kep trong stone).
* Dat trong category "Astrix Finder" (tim qua Modules.loopCategories(), giong sus-chunk-v2).
* yarn_mappings doi build.4 -> build.5 (build.5 la ban client goc dung). Neu sai thi sua gradle.properties.
* Them .github/workflows/build.yml de build bang GitHub Actions ra 1 jar skibidi-debug-1.0.0.jar.
* Chua compile/chay.

## v11 - BugKrispy+
* Module `bug-krispy+` (class BugKrispyPlus, trong subproject bugpet, category "Astrix Finder") = KrispyChunkFinder cu.
* Logic giu nguyen: >= 55 vine (Y16-60) va >= 1 deepslate nam ngang (Y0-60). Cac nguong, ban kinh, tan suat quet, mau, Y ve deu la setting.
* Them thong bao (chuong + chat) cho moi chunk moi; khong con GL11/RenderUtils cua client Krispy, ve bang renderer cua Meteor.
* Chua compile/chay.

## v12 - bo tien to "skibidi-" khoi ten module (category "Astrix debug+")
* Patch constant pool trong libs/skibididebug-classes.jar (khong xoa module nao):
  skibidi-block-anomaly-debug -> block-anomaly-debug, skibidi-debug -> debug,
  skibidi-player-esp -> player-esp, skibidi-suspicious-esp -> suspicious-esp.
* 4 module bi TRUNG ten neu bo tien to (Meteor se xoa module cu cung ten khi add), nen them "+":
  skibidi-hole-esp -> hole-esp+ (trung hole-esp cua Meteor), skibidi-storage-esp -> storage-esp+ (trung storage-esp cua Meteor),
  skibidi-region-map -> region-map+ (trung region-map Astrix Music), skibidi-sus-chunk-finder -> sus-chunk-finder+ (trung sus-chunk-finder Astrix Finder).
* Setting da luu cua cac module nay se mat (doi ten = module moi).

## v13
* Astrix Finder: xoa 3 module chunk-finder, tuff-chunk-finder, player-chunk-finder (xoa file source + bo dang ky trong SkibidiDebugAddon). Cac module khac giu nguyen.

## v14 - SusChunkFinder v3
* Subproject `sus-chunk-v3/` (yarn, nested vao jar chinh bang `include project(':sus-chunk-v3')`), package dev.suschunkv3.
* = SusChunkAddon (amethyst light-5 + kelp/bamboo/berries/vines/dripstone, zone + centroid marker) doi ten thanh SusChunkFinder v3.
* Module `sus-chunk-finder-v3` trong category "Astrix Finder" (tim qua Modules.loopCategories(), giong sus-chunk-v2). Khong trung ten voi sus-chunk-finder / sus-chunk-finder-v2 / sus-chunk-finder+.
* Mixin ClientPlayNetworkHandlerMixin (onLightUpdate/onChunkData) required=false, defaultRequire=0. Debug log: -Dsuschunkv3.debug=true.
* Chua compile/chay (khong co mang / jar Minecraft + Meteor).

## v15 (module cleanup)
* Removed modules: Amethyst Esp, Fake Pay, Custom Freecam, Storage Density Scanner (source + FakePayMixin/FreecamCameraMixin deleted, unregistered in SkibidiDebugAddon, mixins json updated).
* Removed from the precompiled half: Base Calculator, Block Anomaly Debug, Sus Chunk Finder+ -> their 3 `modules.add(new ...)` calls in
  Skibididebug.onInitialize() were NOP'd in libs/skibididebug-classes.jar (classes stay in the jar but are never registered; BlockCache/PacketListener null-check them).
* BugPet module renamed: id "bugpet" -> "chunk-debug" (shows as "Chunk Debug"). Bugpet+ and Bug Krispy+ unchanged.
* Not compiled/run here.

## v16 - Spo Debug (thay SusChunkFinder v3)
* Go bo hoan toan `sus-chunk-v3/` (thu muc, `include 'sus-chunk-v3'` trong settings.gradle, `include project(':sus-chunk-v3')` trong build.gradle).
* Them subproject `spo-debug/` (yarn, nested bang `include project(':spo-debug')`), package dev.spodebug.
* Module `spo-debug` trong category "Astrix Finder" (viet lai Spooky Chunk): dem mob theo chunk + gom cum (union-find theo ban kinh), box chunk, tracer toi tam cum, loc theo loai mob, cooldown theo chunk, log toi `<game dir>/spo-debug-log.txt`.
* Chua build duoc trong sandbox (khong co mang) -> build bang `./gradlew build` hoac GitHub Actions.

## v17 - port tu Mental Debug (viet lai tu bytecode, khong co source goc)
* Them vao subproject `spo-debug` (category "Astrix Finder"): `chunk-finder`, `penny-finder`, `player-debug`.
* chunk-finder: flag chunk khi player khac o Y<8 hoac block update Y<0; chi giu neu < max-neighbors chunk flag trong +-4 chunk. Khong luu hits qua NBT nhu ban goc.
* penny-finder: moi tick quet 1 chunk gan nhat, dem amethyst (block/budding/cluster), het luot thi tinh % base chance + marker tai centroid.
* player-debug: overlay 2D (world vs tab list, nearby players, chunks, top packets). Ban goc la HUD element, o day la module ve overlay rieng.
* Chua build trong sandbox -> build bang ./gradlew build / GitHub Actions.

## v18 - remove bug-krispy+
* Deleted BugKrispyPlus.java and unregistered it in BugPetAddon. bugpet+ and chunk-debug stay.

## v19 - Sus Chunk Finder V3 + Vulxts Sus Chunk
* New subproject `sus-chunk-v3/` (yarn, nested via `include project(:sus-chunk-v3)`), package dev.suschunkv3, taken from chukl-addon 1.13.0.
* Module `sus-chunk-finder-v3` = chukl SusChunkFinder (plant/amethyst growth + rotated deepslate), renamed to V3. Module `vulxts-suschunk` = Vulxts Sus Chunk Finder (weighted growth signals + zone merging). Both in category "Astrix Finder" (found via Modules.loopCategories(), like sus-chunk-v2).
* Names do not clash with sus-chunk-finder / sus-chunk-finder-v2 / sus-chunk-finder+. Not compiled here (no network / no Minecraft+Meteor jars).

## v20 - remove Spotify HUD
* Deleted SpotifyHUD.java, spotify/SpotifyState.java, spotify/SpotifyService.java, spotify_bridge.ps1 and unregistered it in SkibidiDebugAddon. RegionMap description no longer mentions SpotifyHUD.

## v21 - remove category "Astrix Music"
* Deleted category HUD_V1 ("Astrix Music"). Its two modules (staff-list, region-map) moved to "Astrix Extra". Nothing was deleted from them.

## v22 - module "debug" (class Bypass in libs/skibididebug-classes.jar)
* No source for this half, so patched the bytecode: setting `pillar` default false -> true. The flat slab was hardcoded at Y64-65 (LightInspectorRenderer), so it was only easy to see from some heights; the pillar spans Y-60..164 and is visible from any Y.
* Saved configs keep their old value: if you already used the module, turn `pillar` on in the module settings.
* Not changed: LightCache.onTickPre discards light packets while the player is below Y0 (could be why nothing shows when deep).


## v24 - module rename "astrix-" + name
* Every registered module name now starts with "astrix-" (Meteor shows it as "Astrix <Name>"). Changed in each class' super(...) call
  constant pool of libs/skibididebug-classes.jar (staff-notifier, auto-rtp, hole-esp+, region-map+, debug, storage-esp+, target-hud, player-esp, suspicious-esp).
* Saved module settings under the old names are lost (renamed = new module). Not compiled here.

## v24b - "skibidi" -> "astrix" everywhere (file names too)
* Files/folders: com/skibidi -> com/astrix, SkibidiDebugAddon -> AstrixDebugAddon, SkibidiCategory -> AstrixCategory,
  skibidi-debug.mixins.json -> astrix-debug.mixins.json, assets/skibididebug -> assets/astrixdebug,
  libs/skibididebug-classes.jar -> libs/astrixdebug-classes.jar. Mod id/rootProject/jar: astrix-debug (build/libs/astrix-debug-1.0.0.jar).
* Precompiled half: package dev.skibididebug -> dev.astrixdebug, class Skibididebug -> AstrixDebug, Skibidi* classes -> Astrix* (constant pool + file names patched).
* Config folder is now config/astrixdebug/. Older notes above keep the old names for history.

## v25 - remove the skid+ half, add Astrix HUD
* Deleted the whole skid+ subproject (its source, category and fabric.mod.json) and its `include` lines in settings.gradle / build.gradle.
* New yarn subproject `astrix-hud/` (jar-in-jar, same as the other subprojects), package dev.astrixhud, Minecraft 1.21.11 / Meteor 0.5.9.
  Written from scratch as Meteor HudElements (not copied code). Group "Astrix" in the HUD editor with 5 elements:
  astrix-watermark, astrix-info (FPS / ping / server), astrix-time, astrix-coords, astrix-modules (sort: Length / Alphabetical / Category).
  Every element has: opacity, corner-radius, rainbow, rainbow-speed, primary-color, secondary-color.
* Use: Right Shift -> HUD tab -> Edit HUD -> right click / + -> group "Astrix" -> pick an element and drag it.
* Not compiled here (no network / no Minecraft + Meteor jars). Build: ./gradlew build -> build/libs/astrix-debug-1.0.0.jar

## v26 - BugPet / BugPet+ fewer and more accurate alerts
* BugPet (module astrix-chunk-debug):
  - Same base no longer alerts again: the old code picked a slightly different chunk every time more chunks loaded, so each shift was a "new" find.
    Now detections within `merge-radius` chunks (default 3) are one base: one alert, the strongest chunk is kept.
  - `confirm-delay` (default 100 ticks): a hit is rescanned later and only reported if it still holds at least half of its hits
    (stale / half-received light data goes away). Max 3 tries per chunk. 0 = old behaviour.
  - `settle-delay` (default 40 ticks): a chunk is not scanned until its light packets had time to arrive.
  - `min-geode-blocks` (default 10): chunks with only a few amethyst blocks (geode slivers) are skipped; they gave a bad centre and wrong chunk.
  - State is cleared on world/dimension change, and the module only scans in the overworld.
* BugPet+ (module astrix-bugpet+):
  - `require-caps` (default on): the column must be sealed by stone on top and stone/deepslate/bedrock under it. Natural ore blobs continue past their ends.
  - One alert per chunk (reloading a chunk no longer alerts again) and none for a chunk touching one already alerted.
  - State is cleared on world/dimension change, and the module only scans in the overworld.
* Saved settings stay; the new settings use the defaults above. Not compiled here (no Minecraft + Meteor jars).


## v15 - Peace Debug V2 (money, chrome, arox)
* Chi co file .class (khong source) -> dong goi nhu nua Astrix: libs/peace-debug-classes.jar (dev.bypass.*), gop vao jar chinh trong build.gradle (jar { from zipTree(...) }).
* Entry them vao fabric.mod.json: meteor = [AstrixDebugAddon, dev.bypass.BypassAddon]. Meteor tu goi onRegisterCategories/onInitialize + dang ky Orbit factory cho package dev.bypass (khong can boot tay).
* Category moi \"Peace Debug V2 by Kumt!!\" gom module `peace-debug-v2` (flag chunk: plate animation, tracers, kick-on-flag, toast + am thanh flag_found) va `auto-rtp`.
* bypass.mixins.json dat trong src/main/resources, required=false + defaultRequire=0 (giong cac mixin khac: lech signature thi chi tat tinh nang, khong crash). Da dang ky trong fabric.mod.json.
* Assets: assets/peace-debug-v2/sounds.json + sounds/flag_found.ogg.
* Ten module khong trung nhau: peace-debug-v2, auto-rtp (rieng voi astrix-auto-rtp). BlockAnomalyDebug cua Peace chi la lop phu, khong dang ky module nen khong dung voi block-anomaly-debug cua Astrix.
* Package dev.bypass khong trung prefix voi com.astrix.debug / dev.astrixdebug / dev.suschunk* (Orbit lambda factory an toan).
* Chua compile/chay (khong co jar Minecraft/Meteor, khong co mang).

## v27 - Kripsy Chunk (ex KrispyChunkFinder)
* New module `astrix-kripsy-chunk` (class KripsyChunk, src/main/java/com/astrix/debug/modules/, category "Astrix Finder", registered in AstrixDebugAddon). Ported from the Krispy client (Module/RenderUtils/GL11) to Meteor + intermediary names.
* Logic unchanged: >= 55 vines (Y16-60) and >= 1 sideways deepslate (Y0-60); vines checked first, main-thread scan with time budget, per-chunk cache, reset on world change.
* Thresholds, Y ranges, radius, rescan time, budget, chat notify and colours are now settings. Render: flat plane at Y=63 (optional full-height fill).
* Not compiled here (no Minecraft/Meteor jars, no network).

## v28 - Astrix Finder bug pass (code review of every finder module)
* astrix-sus-chunk-finder (SusChunkFinder): scanChunk now walks chunk SECTIONS and skips every section whose palette has none of the
  scanned blocks (was ~98k getBlockState calls per chunk, 3 chunks/tick on the client thread = lag spikes). Same detection rules otherwise.
  Unloaded positions no longer eat the 3-scans-per-tick budget. A budding amethyst whose neighbour face lies in an unloaded chunk is no
  longer counted as "stripped" (unloaded = air = fake hit at the edge of the loaded area).
  New settings: cave-vines-min (default 21, was hard-coded 7: natural lush-cave vines reach ~20) and berries-min (default 40, was
  "3..50 ripe bushes": natural berry patches are generated ripe, so almost every taiga patch was flagged).
* astrix-chunk-finder (spo-debug): packets are handled on the NETWORK thread but hits/told are plain HashSets read by render/tick
  (ConcurrentModificationException risk). Packet handler now only collects and flags on the client thread. Flags are cleared when the
  world/dimension/server changes and on activate (old flags used to stay on screen).
* astrix-player-debug: packet stats map was written on the network thread and read/sorted on the render thread -> now locked.
* astrix-vulxts-suschunk: scan tasks still queued after a world change / restart wrote scores for the OLD world into the new one
  (ghost flags). Added a generation guard.
* astrix-bugpet+: same generation guard (stale detections after world change, activeScans counter could go negative and disable throttling).
* astrix-sus-chunk-finder-v3: back-ported the V2 fixes (scan first then swap = no flicker, stale-result guard, bud parent in an unloaded
  chunk no longer counts as "not grown", far chunks skipped when building the flag list).
* Second pass: astrix-sus-chunk-finder never reset on world/dimension/server change (old hits stayed drawn and chunks at the same
  coordinates in the new world were never scanned because they were still marked "scanned") -> now resets. Same reset added to
  astrix-spawner-notifier and astrix-penny-finder. SusChunkFinder queues nearest chunks first (was row by row from the NW corner) and
  only re-queues every 5 ticks. astrix-spawner-chunk draws the chunk column with the real world height instead of -64..320.
* Not changed (design, needs a decision): natural amethyst geodes score as "base" in astrix-vulxts-suschunk and astrix-penny-finder
  (every geode has far more amethyst blocks than the thresholds), and 13 overlapping modules live in this category.
* Not compiled against Minecraft/Meteor here (no network). Syntax of the whole tree was checked with javac and SusChunkFinder was
  type-checked against stubs; build with ./gradlew build.

## v29 - Kripsy Debug+ (from chunk_finder_meteor_addon)
* New yarn subproject `kripsy-debug/` (jar-in-jar via `include project(':kripsy-debug')`), package dev.kripsydebug.
* Module `kripsy-debug+` (shows as "Kripsy Debug+", class KripsyDebugPlus) = old ChunkFinder: flags chunks whose underground light packets
  are zeroed / uniform-max (carved-out areas). Placed in category "Astrix Finder" (found via Modules.loopCategories(), like bugpet).
* Logic unchanged. Only renamed: package com.krispy.addon -> dev.kripsydebug, constructor takes the category, own addon class replaces ChunkFinderAddon
  (its separate "Chunk Finder" category is dropped). No name clash with chunk-finder / astrix-kripsy-chunk.
* Not compiled here (no Minecraft/Meteor jars). If the compiler complains about LightData getters / SoundEvents...value(), see chunkfinder README notes.
