package dev.spodebug;

import com.mojang.logging.LogUtils;
import dev.spodebug.modules.ChunkFinder;
import dev.spodebug.modules.PennyFinder;
import dev.spodebug.modules.PlayerDebug;
import dev.spodebug.modules.SpoDebug;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

/**
 * Spo Debug (Spooky Chunk rewrite). Nested inside the Astrix jar.
 * The module goes into the existing "Astrix Finder" category, which the main addon
 * registers in onRegisterCategories() (always before any onInitialize()).
 */
public class SpoDebugAddon extends MeteorAddon {
    private static final Logger LOG = LogUtils.getLogger();
    private static final String TARGET_CATEGORY = "Astrix Finder";

    @Override
    public void onInitialize() {
        try {
            Category target = null;
            for (Category c : Modules.loopCategories()) {
                if (TARGET_CATEGORY.equals(c.name)) {
                    target = c;
                    break;
                }
            }
            if (target == null) {
                LOG.error("Spo Debug: category '{}' not found, module not added", TARGET_CATEGORY);
                return;
            }
            Modules.get().add(new SpoDebug(target));
            Modules.get().add(new ChunkFinder(target));
            Modules.get().add(new PennyFinder(target));
            Modules.get().add(new PlayerDebug(target));
        } catch (Throwable t) {
            LOG.error("Spo Debug failed to initialise", t);
        }
    }

    @Override
    public String getPackage() {
        return "dev.spodebug";
    }
}
