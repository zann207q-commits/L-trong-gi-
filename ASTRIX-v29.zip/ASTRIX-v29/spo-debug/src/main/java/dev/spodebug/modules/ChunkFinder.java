package dev.spodebug.modules;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.util.math.ChunkPos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Port of Mental Debug "chunk-finder" (activity based).
 * Flags chunks from (a) other players below Y=8, (b) block updates below Y=0.
 * A flag is only kept when fewer than 5 other flagged chunks are within 4 chunks
 * (isolated activity = likely base, big clusters = noise).
 */
public class ChunkFinder extends Module {
    private static final int Y_MARK = 60;

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<SettingColor> color = sgGeneral.add(new ColorSetting.Builder()
            .name("color").description("Chunk highlight color.")
            .defaultValue(new SettingColor(255, 220, 0, 255)).build());
    private final Setting<Integer> alpha = sgGeneral.add(new IntSetting.Builder()
            .name("alpha").description("Fill alpha.")
            .defaultValue(200).min(0).max(255).sliderRange(0, 255).build());
    private final Setting<Integer> maxNeighbors = sgGeneral.add(new IntSetting.Builder()
            .name("max-neighbors").description("Ignore a flag if this many other flagged chunks are within 4 chunks.")
            .defaultValue(5).min(1).sliderRange(1, 20).build());
    private final Setting<Boolean> chat = sgGeneral.add(new BoolSetting.Builder()
            .name("chat-notify").description("Chat message for each new chunk.")
            .defaultValue(true).build());

    private final Set<ChunkPos> hits = new HashSet<>();
    private final Set<ChunkPos> told = new HashSet<>();
    private int tick;
    private Object lastWorld;

    public ChunkFinder(Category category) {
        super(category, "astrix-chunk-finder", "Activity debug. Flags chunks from player movement and block updates.");
    }

    @Override
    public void onActivate() {
        tick = 0;
        lastWorld = null;
        hits.clear();
        told.clear();
    }

    @Override
    public void onDeactivate() {
        hits.clear();
        told.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;
        // New world / dimension / server: flags from the old one must not stay on screen.
        if (mc.world != lastWorld) {
            hits.clear();
            told.clear();
            lastWorld = mc.world;
        }
        if (++tick % 5 != 0) return;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (p.getY() < 8.0) flag(p.getChunkPos(), "player under deepslate");
        }
    }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (mc.world == null) return;
        // Packets are handled on the network thread, but hits/told are plain HashSets that the render and
        // tick code read. Only collect here and do the actual flagging on the client thread
        // (before this, rendering could crash with ConcurrentModificationException).
        if (event.packet instanceof BlockUpdateS2CPacket p) {
            if (p.getPos().getY() < 0) {
                ChunkPos c = new ChunkPos(p.getPos());
                mc.execute(() -> flag(c, "deep update"));
            }
        } else if (event.packet instanceof ChunkDeltaUpdateS2CPacket p) {
            List<ChunkPos> deep = new ArrayList<>();
            p.visitUpdates((pos, state) -> {
                if (pos.getY() < 0) deep.add(new ChunkPos(pos)); // pos is a reused mutable BlockPos: copy now
            });
            if (!deep.isEmpty()) {
                mc.execute(() -> {
                    for (ChunkPos c : deep) flag(c, "deep chunk update");
                });
            }
        }
    }

    /** True when the chunk is isolated: fewer than max-neighbors flagged chunks within +-4 chunks. */
    private boolean room(ChunkPos c) {
        int n = 0;
        for (ChunkPos h : hits) {
            if (Math.abs(h.x - c.x) <= 4 && Math.abs(h.z - c.z) <= 4) n++;
        }
        return n < maxNeighbors.get();
    }

    private void flag(ChunkPos c, String why) {
        if (mc.world == null || mc.world != lastWorld) return; // queued from an old world
        if (!room(c)) return;
        if (hits.add(c) && told.add(c) && chat.get()) {
            info("Chunk Finder: %s at %d %d", why, c.getCenterX(), c.getCenterZ());
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (hits.isEmpty()) return;
        SettingColor c = color.get();
        Color line = new Color(c.r, c.g, c.b, 255);
        Color fill = new Color(c.r, c.g, c.b, alpha.get());
        for (ChunkPos p : Collections.unmodifiableSet(new HashSet<>(hits))) {
            double x = p.getStartX(), z = p.getStartZ();
            event.renderer.box(x, Y_MARK, z, x + 16.0, Y_MARK + 0.04, z + 16.0, fill, line, ShapeMode.Both, 0);
        }
    }

    @Override
    public String getInfoString() {
        return hits.isEmpty() ? null : String.valueOf(hits.size());
    }
}
