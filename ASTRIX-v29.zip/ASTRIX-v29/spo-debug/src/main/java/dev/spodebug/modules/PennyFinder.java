package dev.spodebug.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;

/**
 * Port of Mental Debug "penny-finder".
 * Walks the nearest loaded chunks one per tick, counts amethyst blocks (block, budding, cluster),
 * and once a full pass is done turns the total into a "base chance" % and marks the centroid.
 */
public class PennyFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<SettingColor> color = sgGeneral.add(new ColorSetting.Builder()
            .name("color").description("Marker color.")
            .defaultValue(new SettingColor(255, 196, 48, 170)).build());
    private final Setting<Integer> simDistance = sgGeneral.add(new IntSetting.Builder()
            .name("simulation-distance").description("Only scan chunks within this many chunks of you.")
            .defaultValue(10).min(2).sliderRange(2, 32).build());
    private final Setting<Integer> sensitivity = sgGeneral.add(new IntSetting.Builder()
            .name("sensitivity").description("Higher = flags with fewer amethyst blocks.")
            .defaultValue(10).min(1).max(20).sliderRange(1, 20).build());
    private final Setting<Integer> alpha = sgGeneral.add(new IntSetting.Builder()
            .name("alpha").defaultValue(200).min(0).max(255).sliderRange(0, 255).build());
    private final Setting<Integer> chunks = sgGeneral.add(new IntSetting.Builder()
            .name("chunks").description("Chunks per pass.")
            .defaultValue(32).min(8).sliderRange(8, 64).build());
    private final Setting<Integer> threshold = sgGeneral.add(new IntSetting.Builder()
            .name("cluster-threshold").description("Amethyst blocks that count as ~100% base.")
            .defaultValue(100).min(20).sliderRange(20, 400).build());
    private final Setting<Integer> yLevel = sgGeneral.add(new IntSetting.Builder()
            .name("y-level").description("Y of the marker.")
            .defaultValue(60).sliderRange(-64, 320).build());
    private final Setting<Integer> markerSize = sgGeneral.add(new IntSetting.Builder()
            .name("marker-size").defaultValue(12).min(2).sliderRange(2, 16).build());
    private final Setting<Boolean> chatFlag = sgGeneral.add(new BoolSetting.Builder()
            .name("chat-flag").description("Chat message when a new likely base is found.")
            .defaultValue(true).build());

    private final List<ChunkPos> queue = new ArrayList<>();
    private final Map<ChunkPos, Integer> counts = new HashMap<>();
    private final List<ChunkPos> flagged = new ArrayList<>();
    private int cursor;
    private BlockPos lastFlag;
    private BlockPos spot;
    private int chance;
    private Object lastWorld;

    public PennyFinder(Category category) {
        super(category, "astrix-penny-finder", "Flags amethyst chunks and a likely base.");
    }

    @Override
    public void onActivate() {
        queue.clear();
        counts.clear();
        flagged.clear();
        cursor = 0;
        spot = null;
        lastFlag = null;
    }

    @Override
    public void onDeactivate() {
        onActivate();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;

        // New world / dimension / server: drop the old pass, flags and marker
        if (mc.world != lastWorld) {
            onActivate();
            lastWorld = mc.world;
        }

        if (queue.isEmpty() || cursor >= queue.size()) {
            if (cursor > 0) publish();
            queue.clear();
            queue.addAll(nearestLoaded(chunks.get(), simDistance.get()));
            cursor = 0;
            counts.clear();
        }
        if (queue.isEmpty()) return;

        ChunkPos cp = queue.get(cursor++);
        WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
        if (wc == null) return;
        counts.put(cp, countAmethyst(wc));
    }

    /** Nearest loaded chunks (by distance to the player), at most {@code max}, within {@code dist} chunks. */
    private List<ChunkPos> nearestLoaded(int max, int dist) {
        List<ChunkPos> list = new ArrayList<>();
        ChunkPos me = mc.player.getChunkPos();
        for (int dx = -dist; dx <= dist; dx++) {
            for (int dz = -dist; dz <= dist; dz++) {
                WorldChunk wc = mc.world.getChunkManager().getWorldChunk(me.x + dx, me.z + dz, false);
                if (wc != null && !wc.isEmpty()) list.add(new ChunkPos(me.x + dx, me.z + dz));
            }
        }
        list.sort(Comparator.comparingInt(c -> (c.x - me.x) * (c.x - me.x) + (c.z - me.z) * (c.z - me.z)));
        return list.size() > max ? new ArrayList<>(list.subList(0, max)) : list;
    }

    private int countAmethyst(WorldChunk chunk) {
        int count = 0;
        ChunkSection[] sections = chunk.getSectionArray();
        for (ChunkSection section : sections) {
            if (section == null || section.isEmpty()) continue;
            if (!section.hasAny(PennyFinder::isAmethyst)) continue;
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        if (isAmethyst(section.getBlockState(x, y, z))) count++;
                    }
                }
            }
        }
        return count;
    }

    private static boolean isAmethyst(BlockState s) {
        return s.isOf(Blocks.AMETHYST_CLUSTER) || s.isOf(Blocks.AMETHYST_BLOCK) || s.isOf(Blocks.BUDDING_AMETHYST);
    }

    /** End of a pass: total -> chance %, centroid -> marker. */
    private void publish() {
        int total = 0, n = 0;
        long sx = 0, sz = 0;
        List<ChunkPos> pos = new ArrayList<>();
        for (Map.Entry<ChunkPos, Integer> e : counts.entrySet()) {
            if (e.getValue() <= 0) continue;
            total += e.getValue();
            pos.add(e.getKey());
            sx += e.getKey().getCenterX();
            sz += e.getKey().getCenterZ();
            n++;
        }
        int need = Math.max(1, threshold.get() * (21 - sensitivity.get()) / 20);
        if (total < need || n == 0) {
            flagged.clear();
            spot = null;
            return;
        }
        flagged.clear();
        flagged.addAll(pos);
        chance = baseChance(total);
        spot = new BlockPos((int) (sx / n), yLevel.get(), (int) (sz / n));

        if (chatFlag.get() && (lastFlag == null || lastFlag.getSquaredDistance(spot) > 256.0)) {
            lastFlag = spot;
            info("Penny Finder: %d%% base chance at %d %d %d (%d clusters)",
                    chance, spot.getX(), spot.getY(), spot.getZ(), total);
        }
    }

    private int baseChance(int total) {
        int t = threshold.get();
        int top = Math.max(t * 5, t + 1);
        int mid = Math.min(12, top);
        if (total >= top) return 100;
        if (total <= mid) return 50;
        return 50 + 50 * (total - mid) / (top - mid);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (flagged.isEmpty()) return;
        SettingColor c = color.get();
        Color line = new Color(c.r, c.g, c.b, 255);
        Color fill = new Color(c.r, c.g, c.b, Math.min(c.a, alpha.get()));
        for (ChunkPos p : new ArrayList<>(flagged)) {
            double x = p.getStartX(), z = p.getStartZ();
            event.renderer.box(x, yLevel.get(), z, x + 16.0, yLevel.get() + 0.02, z + 16.0, fill, line, ShapeMode.Both, 0);
        }
        if (spot != null) {
            double s = markerSize.get() / 2.0;
            double x = spot.getX() + 0.5, y = spot.getY(), z = spot.getZ() + 0.5;
            event.renderer.box(x - s, y, z - s, x + s, y + 0.2, z + s, fill, line, ShapeMode.Both, 0);
        }
    }

    @Override
    public String getInfoString() {
        return spot == null ? null : chance + "%";
    }
}
