package dev.suschunkv3;

import com.mojang.logging.LogUtils;
import dev.suschunkv3.modules.SusChunkFinderV3;
import dev.suschunkv3.modules.VulxtsSusChunk;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

/**
 * Sus Chunk Finder V3 + Vulxts Sus Chunk (ported from chukl-addon 1.13.0). Nested inside the Astrix jar.
 * Modules go into the existing "Astrix Finder" category, which the main addon registers
 * in onRegisterCategories() (always before any onInitialize()).
 */
public class SusChunkV3Addon extends MeteorAddon {
    public static final Logger LOG = LogUtils.getLogger();
    private static final String TARGET_CATEGORY = "Astrix Finder";

    @Override
    public void onInitialize() {
        try {
            Category target = null;
            for (Category c : Modules.loopCategories()) {
                if (TARGET_CATEGORY.equals(c.name)) {
                    target = c;
                    break;
                }
            }
            if (target == null) {
                LOG.error("SusChunkV3: category '{}' not found, modules not added", TARGET_CATEGORY);
                return;
            }
            Modules.get().add(new SusChunkFinderV3(target));
            Modules.get().add(new VulxtsSusChunk(target));
        } catch (Throwable t) {
            LOG.error("SusChunkV3 failed to initialise", t);
        }
    }

    @Override
    public String getPackage() {
        return "dev.suschunkv3";
    }
}
