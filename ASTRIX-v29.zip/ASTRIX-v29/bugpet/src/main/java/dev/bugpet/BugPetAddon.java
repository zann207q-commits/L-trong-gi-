package dev.bugpet;

import com.mojang.logging.LogUtils;
import dev.bugpet.modules.BugPet;
import dev.bugpet.modules.BugPetPlus;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

/**
 * BugPet / BugPet+ (ex Chunk Finder / Chunk Finder v2). Nested inside the Astrix jar.
 * Modules go into the existing "Astrix Finder" category, which the main addon registers
 * in onRegisterCategories() (always before any onInitialize()).
 */
public class BugPetAddon extends MeteorAddon {
    private static final Logger LOG = LogUtils.getLogger();
    private static final String TARGET_CATEGORY = "Astrix Finder";

    @Override
    public void onInitialize() {
        try {
            Category target = null;
            for (Category c : Modules.loopCategories()) {
                if (TARGET_CATEGORY.equals(c.name)) {
                    target = c;
                    break;
                }
            }
            if (target == null) {
                LOG.error("BugPet: category '{}' not found, modules not added", TARGET_CATEGORY);
                return;
            }
            Modules.get().add(new BugPet(target));
            Modules.get().add(new BugPetPlus(target));
        } catch (Throwable t) {
            LOG.error("BugPet failed to initialise", t);
        }
    }

    @Override
    public String getPackage() {
        return "dev.bugpet";
    }
}
