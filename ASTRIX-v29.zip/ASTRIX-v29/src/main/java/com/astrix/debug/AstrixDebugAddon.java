package com.astrix.debug;

import com.astrix.debug.modules.AFKFly;
import com.astrix.debug.modules.AutoRTPHome;
import com.astrix.debug.modules.AutoRelog;
import com.astrix.debug.modules.FakeScoreboard;
import com.astrix.debug.modules.FakeSpawner;
import com.astrix.debug.modules.HomeSeter;
import com.astrix.debug.modules.KripsyChunk;
import com.astrix.debug.modules.RegionMap;
import com.astrix.debug.modules.RelogHelper;
import com.astrix.debug.modules.RenderDistanceBypass;
import com.astrix.debug.modules.SpawnerChunk;
import com.astrix.debug.modules.SpawnerNotifier;
import com.astrix.debug.modules.SpawnerTags;
import com.astrix.debug.modules.StaffDetector;
import com.astrix.debug.modules.StaffList;
import com.astrix.debug.modules.SusChunkFinder;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AstrixDebugAddon extends MeteorAddon {
    private static final Logger LOG = LoggerFactory.getLogger("astrix-debug");

    /** Nửa thứ hai của addon (precompiled, libs/astrixdebug-classes.jar). */
    private dev.astrixdebug.AstrixDebug astrix;
    /** Đảm bảo nửa AstrixDebug chỉ được khởi tạo 1 lần. */
    private boolean astrixInitDone;
    private boolean categoriesRegistered;

    /**
     * Meteor gọi onRegisterCategories() TRƯỚC onInitialize().
     * Bản cũ chỉ tạo this.astrix trong onInitialize() nên lúc đăng ký category nó vẫn là null
     * => category "Astrix debug+" không bao giờ được đăng ký
     * => module "astrix-debug" (Bypass) và các module cùng category không hiện trong GUI.
     * Ở đây ta đăng ký category bằng trường static, không phụ thuộc thứ tự gọi.
     */
    @Override
    public void onRegisterCategories() {
        if (categoriesRegistered) return;
        categoriesRegistered = true;

        Modules.registerCategory((Category) AstrixCategory.CATEGORY);
        Modules.registerCategory((Category) AstrixCategory.MISC_V2);

        try {
            Modules.registerCategory(dev.astrixdebug.AstrixDebug.CATEGORY);
        } catch (Throwable t) {
            LOG.error("AstrixDebug category failed to register", t);
        }
    }

    @Override
    public void onInitialize() {
        Modules modules = Modules.get();
        modules.add((Module) new SpawnerChunk());
        modules.add((Module) new SpawnerNotifier());
        modules.add((Module) new SusChunkFinder());
        modules.add((Module) new KripsyChunk());
        modules.add((Module) new SpawnerTags());
        modules.add((Module) new StaffDetector());
        modules.add((Module) new RelogHelper());
        modules.add((Module) new AutoRelog());
        modules.add((Module) new HomeSeter());
        modules.add((Module) new AFKFly());
        modules.add((Module) new AutoRTPHome());
        modules.add((Module) new RenderDistanceBypass());
        modules.add((Module) new StaffList());
        modules.add((Module) new FakeScoreboard());
        modules.add((Module) new FakeSpawner());
        modules.add((Module) new RegionMap());

        initAstrixHalf();
    }

    /** Cô lập nửa AstrixDebug: lỗi bên đó không được làm hỏng các module còn lại. */
    private void initAstrixHalf() {
        if (astrixInitDone) return;
        astrixInitDone = true;
        try {
            this.astrix = new dev.astrixdebug.AstrixDebug();
            this.astrix.onInitialize();
            LOG.info("AstrixDebug half initialised");
        } catch (Throwable t) {
            LOG.error("AstrixDebug half failed to initialise", t);
            this.astrix = null;
        }
    }

    @Override
    public String getPackage() {
        return "com.astrix.debug";
    }
}
