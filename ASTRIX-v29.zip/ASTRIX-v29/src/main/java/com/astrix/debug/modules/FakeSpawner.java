package com.astrix.debug.modules;

import com.astrix.debug.AstrixCategory;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class FakeSpawner
extends Module {
    public static volatile boolean ENABLED = false;
    private final SettingGroup sg;
    public static volatile boolean useYellowGlass = true;
    public static volatile boolean useOrangeGlass = false;
    public static volatile boolean useBrownGlass = false;
    private final Setting<Boolean> yellow;
    private final Setting<Boolean> orange;
    private final Setting<Boolean> brown;

    public FakeSpawner() {
        super(AstrixCategory.MISC_V2, "astrix-fake-spawner", "Makes Yellow Stained Glass (client-side only) look like a Mob Spawner.");
        this.sg = this.settings.getDefaultGroup();
        this.yellow = this.sg.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("yellow-glass")).description("Make Yellow Stained Glass look like a Spawner.")).defaultValue(true)).onChanged(v -> {
            useYellowGlass = v;
            this.reload();
        })).build());
        this.orange = this.sg.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("orange-glass")).description("Make Orange Stained Glass look like a Spawner.")).defaultValue(false)).onChanged(v -> {
            useOrangeGlass = v;
            this.reload();
        })).build());
        this.brown = this.sg.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("brown-glass")).description("Make Brown Stained Glass look like a Spawner.")).defaultValue(false)).onChanged(v -> {
            useBrownGlass = v;
            this.reload();
        })).build());
    }

    public void onActivate() {
        ENABLED = true;
        useYellowGlass = (Boolean)this.yellow.get();
        useOrangeGlass = (Boolean)this.orange.get();
        useBrownGlass = (Boolean)this.brown.get();
        this.reload();
    }

    public void onDeactivate() {
        ENABLED = false;
        this.reload();
    }

    private void reload() {
        if (this.mc.field_1769 != null) {
            this.mc.field_1769.method_3279();
        }
    }

    public static boolean shouldSwap(class_2248 block) {
        if (!ENABLED) {
            return false;
        }
        if (useYellowGlass && block == class_2246.field_10049) {
            return true;
        }
        if (useOrangeGlass && block == class_2246.field_10227) {
            return true;
        }
        return useBrownGlass && block == class_2246.field_10073;
    }
}

