package dev.custommodels.addon;

import dev.custommodels.addon.modules.CustomModelsModule;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class CustomModelsAddon extends MeteorAddon {
    @Override
    public void onInitialize() {
        Modules.get().add(new CustomModelsModule());
    }

    @Override
    public String getPackage() {
        return "dev.custommodels.addon";
    }
}
