package dev.custommodels.addon.mixin;

import dev.custommodels.addon.CustomModelState;
import dev.custommodels.addon.modules.CustomModelsModule;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.network.ClientPlayerLikeEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin<AvatarlikeEntity extends PlayerLikeEntity & ClientPlayerLikeEntity> {
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void custommodels$updateState(
            AvatarlikeEntity entity, PlayerEntityRenderState state, float tickDelta, CallbackInfo ci) {
        CustomModelsModule module = Modules.get() == null ? null : Modules.get().get(CustomModelsModule.class);
        boolean use = module != null && module.shouldUseCustomModel(entity);
        if (state instanceof CustomModelState custom) {
            custom.goobaa$setCustomModel(use, use ? module.selectedModel() : "");
        }
    }
}
