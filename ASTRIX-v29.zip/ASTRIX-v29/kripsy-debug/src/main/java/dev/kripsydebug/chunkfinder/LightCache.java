package dev.kripsydebug.chunkfinder;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.network.packet.s2c.play.LightData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * offer() may be called from the network thread; drain()/clear() must be called from the client thread.
 */
public final class LightCache {
    private static final Logger LOG = LoggerFactory.getLogger("kripsy-debug+");

    private static final int MAX_PER_DRAIN = 4096;
    private static final int MAX_SNAPSHOTS = 8192;
    /** Only sections whose lowest block Y is <= this are inspected (underground). */
    private static final int MAX_SECTION_BLOCK_Y = 0;

    private final Queue<PendingLightUpdate> queue = new ConcurrentLinkedQueue<>();
    private final Map<Long, LightSnapshot> snapshots = new LinkedHashMap<>(256, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Long, LightSnapshot> eldest) {
            return size() > MAX_SNAPSHOTS;
        }
    };
    private final Set<Long> alertedChunks = new HashSet<>();
    private final Set<AlertedSection> alertedSections = new HashSet<>();
    private final ChunkFoundListener listener;
    private long stamp;

    public LightCache(ChunkFoundListener listener) {
        this.listener = listener;
    }

    public void offer(int chunkX, int chunkZ, LightData data) {
        if (data != null) queue.offer(new PendingLightUpdate(chunkX, chunkZ, data));
    }

    public void clear() {
        queue.clear();
        snapshots.clear();
        alertedChunks.clear();
        alertedSections.clear();
    }

    public void drain(int sectionCount, int bottomSectionY) {
        int processed = 0;
        PendingLightUpdate update;
        while ((update = queue.poll()) != null) {
            process(update, sectionCount, bottomSectionY);
            if (++processed >= MAX_PER_DRAIN) break;
        }
    }

    private void process(PendingLightUpdate update, int sectionCount, int bottomSectionY) {
        long key = chunkKey(update.chunkX(), update.chunkZ());
        LightSnapshot snapshot = snapshots.get(key);
        if (snapshot == null || snapshot.sectionCount != sectionCount || snapshot.bottomSectionY != bottomSectionY) {
            snapshot = new LightSnapshot(sectionCount, bottomSectionY);
            snapshots.put(key, snapshot);
        }

        long now = ++stamp;
        try {
            LightClassifier.apply(update.data(), snapshot, now);
        } catch (Throwable t) {
            LOG.error("[Kripsy Debug+] Light classifier crashed on chunk " + update.chunkX() + "," + update.chunkZ(), t);
            return;
        }
        scan(update.chunkX(), update.chunkZ(), key, snapshot, now);
    }

    private void scan(int chunkX, int chunkZ, long key, LightSnapshot s, long now) {
        for (int i = 1; i <= s.sectionCount; i++) {
            int blockY = (s.bottomSectionY + i - 1) * 16;
            if (blockY > MAX_SECTION_BLOCK_Y) break;

            if (s.skyUpdated[i] == now) check(LightType.SKY, chunkX, chunkZ, key, blockY, s.sky[i]);
            if (s.blockUpdated[i] == now) check(LightType.BLOCK, chunkX, chunkZ, key, blockY, s.block[i]);
        }
    }

    private void check(LightType type, int chunkX, int chunkZ, long key, int blockY, LightPayloadType payload) {
        if ((payload == LightPayloadType.ZEROED_PRESENT || payload == LightPayloadType.UNIFORM_MAX)
            && alertedSections.add(new AlertedSection(key, blockY, type))
            && alertedChunks.add(key)) {
            listener.onChunkFound(chunkX, chunkZ, blockY);
        }
    }

    private static long chunkKey(int x, int z) {
        return (long) x & 0xFFFFFFFFL | ((long) z & 0xFFFFFFFFL) << 32;
    }
}
