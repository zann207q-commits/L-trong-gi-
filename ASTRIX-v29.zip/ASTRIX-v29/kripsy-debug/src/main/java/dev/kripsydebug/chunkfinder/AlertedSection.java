package dev.kripsydebug.chunkfinder;

record AlertedSection(long chunkKey, int blockY, LightType type) {
}
