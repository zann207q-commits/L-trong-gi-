package dev.kripsydebug.chunkfinder;

enum LightType {
    SKY,
    BLOCK
}
