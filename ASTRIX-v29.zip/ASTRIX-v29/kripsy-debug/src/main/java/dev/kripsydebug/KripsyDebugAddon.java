package dev.kripsydebug;

import com.mojang.logging.LogUtils;
import dev.kripsydebug.modules.KripsyDebugPlus;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

/**
 * Kripsy Debug+ (ex Krispy Chunk Finder, light-data chunk finder). Nested inside the Astrix jar.
 * The module goes into the existing "Astrix Finder" category, which the main addon registers
 * in onRegisterCategories() (always before any onInitialize()).
 */
public class KripsyDebugAddon extends MeteorAddon {
    private static final Logger LOG = LogUtils.getLogger();
    private static final String TARGET_CATEGORY = "Astrix Finder";

    @Override
    public void onInitialize() {
        try {
            Category target = null;
            for (Category c : Modules.loopCategories()) {
                if (TARGET_CATEGORY.equals(c.name)) {
                    target = c;
                    break;
                }
            }
            if (target == null) {
                LOG.error("Kripsy Debug+: category '{}' not found, module not added", TARGET_CATEGORY);
                return;
            }
            Modules.get().add(new KripsyDebugPlus(target));
        } catch (Throwable t) {
            LOG.error("Kripsy Debug+ failed to initialise", t);
        }
    }

    @Override
    public String getPackage() {
        return "dev.kripsydebug";
    }
}
