package dev.kripsydebug.chunkfinder;

import net.minecraft.network.packet.s2c.play.LightData;

record PendingLightUpdate(int chunkX, int chunkZ, LightData data) {
}
