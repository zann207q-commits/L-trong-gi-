package dev.kripsydebug.chunkfinder;

public enum LightPayloadType {
    NORMAL,
    EMPTY_MASK,
    ZEROED_PRESENT,
    UNIFORM_MAX,
    UNKNOWN
}
