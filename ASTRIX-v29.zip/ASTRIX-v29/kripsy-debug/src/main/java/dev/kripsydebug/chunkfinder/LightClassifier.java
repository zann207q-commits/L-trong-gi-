package dev.kripsydebug.chunkfinder;

import java.util.BitSet;
import java.util.List;
import net.minecraft.network.packet.s2c.play.LightData;

public final class LightClassifier {
    /** A light nibble array: 16*16*16 blocks / 2 = 2048 bytes. */
    private static final int PAYLOAD_SIZE = 2048;

    private LightClassifier() {
    }

    public static LightPayloadType classifyPayload(byte[] payload) {
        if (payload == null || payload.length != PAYLOAD_SIZE) return LightPayloadType.UNKNOWN;

        boolean allZero = true;
        boolean allMax = true;
        for (byte b : payload) {
            if (b != 0) allZero = false;
            if (b != (byte) 0xFF) allMax = false;
            if (!allZero && !allMax) return LightPayloadType.NORMAL;
        }
        return allZero ? LightPayloadType.ZEROED_PRESENT : LightPayloadType.UNIFORM_MAX;
    }

    public static void apply(LightData data, LightSnapshot snapshot, long stamp) {
        // Original intermediary: block = method_38608/38609/38610, sky = method_38601/38604/38606.
        // If your Yarn version names them differently, adjust these six getters.
        update(data.getInitedBlock(), data.getUninitedBlock(), data.getBlockNibbles(), snapshot.block, snapshot.blockUpdated, stamp);
        update(data.getInitedSky(), data.getUninitedSky(), data.getSkyNibbles(), snapshot.sky, snapshot.skyUpdated, stamp);
    }

    private static void update(BitSet inited, BitSet uninited, List<byte[]> nibbles,
                               LightPayloadType[] types, long[] updated, long stamp) {
        int next = 0;
        for (int i = 0; i < types.length; i++) {
            if (inited.get(i)) {
                byte[] payload = next < nibbles.size() ? nibbles.get(next) : null;
                next++;
                types[i] = classifyPayload(payload);
                updated[i] = stamp;
            } else if (uninited.get(i)) {
                types[i] = LightPayloadType.EMPTY_MASK;
                updated[i] = stamp;
            }
        }
    }
}
