package dev.kripsydebug.chunkfinder;

import java.util.Arrays;

/** Last known light classification per section of one chunk (index 0 and sectionCount+1 are the border sections). */
public final class LightSnapshot {
    public final int sectionCount;
    public final int bottomSectionY;
    public final LightPayloadType[] block;
    public final LightPayloadType[] sky;
    public final long[] blockUpdated;
    public final long[] skyUpdated;

    public LightSnapshot(int sectionCount, int bottomSectionY) {
        this.sectionCount = sectionCount;
        this.bottomSectionY = bottomSectionY;
        int size = sectionCount + 2;
        this.block = new LightPayloadType[size];
        this.sky = new LightPayloadType[size];
        this.blockUpdated = new long[size];
        this.skyUpdated = new long[size];
        Arrays.fill(block, LightPayloadType.UNKNOWN);
        Arrays.fill(sky, LightPayloadType.UNKNOWN);
    }
}
