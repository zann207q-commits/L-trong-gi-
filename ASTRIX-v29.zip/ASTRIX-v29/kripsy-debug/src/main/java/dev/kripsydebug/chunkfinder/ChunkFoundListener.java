package dev.kripsydebug.chunkfinder;

public interface ChunkFoundListener {
    void onChunkFound(int chunkX, int chunkZ, int blockY);
}
