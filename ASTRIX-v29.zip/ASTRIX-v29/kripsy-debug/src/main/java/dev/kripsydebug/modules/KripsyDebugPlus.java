package dev.kripsydebug.modules;

import meteordevelopment.meteorclient.systems.modules.Category;
import dev.kripsydebug.chunkfinder.LightCache;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

public class KripsyDebugPlus extends Module {
    private static final int MAX_FLAGS = 512;
    private static final long DIG_MEMORY_MS = 4000L;
    /** Original code compares SQUARED distance with 64.0, i.e. ~8 blocks. */
    private static final double DIG_RADIUS_SQ = 64.0;
    private static final int MIN_FLAG_Y = 21;
    private static final int RENDER_RANGE_CHUNKS = 24;
    private static final double RENDER_Y_OFFSET = 1.002;

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAlerts = settings.createGroup("Alerts");
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Boolean> chatNotify = sgAlerts.add(new BoolSetting.Builder()
        .name("chat-notifications").description("Print a chat message when a chunk is flagged.")
        .defaultValue(true).build());

    private final Setting<Boolean> soundPing = sgAlerts.add(new BoolSetting.Builder()
        .name("sound-ping").description("Play a sound when a chunk is flagged.")
        .defaultValue(true).build());

    private final Setting<Integer> soundVolume = sgAlerts.add(new IntSetting.Builder()
        .name("sound-volume").description("Ping volume in percent.")
        .defaultValue(100).range(0, 100).sliderRange(0, 100).visible(soundPing::get).build());

    private final Setting<Boolean> kickOnFlag = sgAlerts.add(new BoolSetting.Builder()
        .name("kick-on-flag").description("Disconnect when a chunk is flagged. Turns itself off afterwards.")
        .defaultValue(false).build());

    private final Setting<Double> plateSize = sgRender.add(new DoubleSetting.Builder()
        .name("plate-size").description("Width of the highlight plate in blocks.")
        .defaultValue(16).min(1).sliderRange(1, 64).build());

    private final Setting<Double> plateThickness = sgRender.add(new DoubleSetting.Builder()
        .name("plate-thickness").description("Height of the highlight plate.")
        .defaultValue(0.1).min(0.01).sliderRange(0.01, 4).build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color").defaultValue(new SettingColor(0, 255, 70, 75)).build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").defaultValue(new SettingColor(0, 255, 70, 220)).build());

    private record Flag(ChunkPos chunk, int y, int x, int z) {
    }

    private final LightCache lightCache = new LightCache(this::onChunkFound);
    private final Map<Long, Flag> flags = new LinkedHashMap<>();
    private final Map<Long, Long> recentDigs = new HashMap<>();
    private Object trackedWorld;

    public KripsyDebugPlus(Category category) {
        super(category, "kripsy-debug+",
            "Flags chunks whose light data looks like it was carved out underground.");
    }

    @Override
    public void onActivate() {
        reset();
        trackedWorld = mc.world;
    }

    @Override
    public void onDeactivate() {
        reset();
    }

    private void reset() {
        lightCache.clear();
        flags.clear();
        recentDigs.clear();
        trackedWorld = null;
    }

    private void checkWorld() {
        if (trackedWorld != mc.world) {
            reset();
            trackedWorld = mc.world;
        }
    }

    // Runs on the network thread: only touch the thread-safe queue here.
    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (mc.world == null) return;

        if (event.packet instanceof ChunkDataS2CPacket p) {
            lightCache.offer(p.getChunkX(), p.getChunkZ(), p.getLightData());
        } else if (event.packet instanceof LightUpdateS2CPacket p) {
            lightCache.offer(p.getChunkX(), p.getChunkZ(), p.getData());
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        checkWorld();
        if (mc.world == null || mc.player == null) return;
        lightCache.drain(mc.world.countVerticalSections(), mc.world.getBottomSectionCoord());
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        if (mc.player == null || event.pos == null) return;
        if (mc.player.squaredDistanceTo(Vec3d.ofCenter(event.pos)) <= DIG_RADIUS_SQ) {
            recentDigs.put(ChunkPos.toLong(event.pos.getX() >> 4, event.pos.getZ() >> 4), System.currentTimeMillis());
        }
    }

    private boolean nearRecentDig(int chunkX, int chunkZ) {
        long now = System.currentTimeMillis();
        recentDigs.values().removeIf(t -> now - t > DIG_MEMORY_MS);
        for (long key : recentDigs.keySet()) {
            if (Math.abs(ChunkPos.getPackedX(key) - chunkX) <= 1 && Math.abs(ChunkPos.getPackedZ(key) - chunkZ) <= 1) {
                return true;
            }
        }
        return false;
    }

    // Called from LightCache.drain(), i.e. on the client thread.
    private void onChunkFound(int chunkX, int chunkZ, int sectionBlockY) {
        if (nearRecentDig(chunkX, chunkZ)) return;

        int x = (chunkX << 4) + 8;
        int z = (chunkZ << 4) + 8;
        // Original code ignores the section Y and uses the surface height of the chunk instead.
        int y = mc.world != null && mc.world.isChunkLoaded(chunkX, chunkZ)
            ? Math.max(MIN_FLAG_Y, mc.world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z))
            : MIN_FLAG_Y;

        addFlag(new BlockPos(x, y, z));
    }

    private void addFlag(BlockPos pos) {
        ChunkPos chunk = new ChunkPos(pos);
        Flag flag = new Flag(chunk, Math.max(MIN_FLAG_Y, pos.getY()), pos.getX(), pos.getZ());
        if (flags.putIfAbsent(chunk.toLong(), flag) != null) return;

        if (flags.size() > MAX_FLAGS) flags.remove(flags.keySet().iterator().next());

        if (chatNotify.get()) info("Flagged chunk X: %d Z: %d", flag.x(), flag.z());

        if (soundPing.get()) {
            float volume = soundVolume.get() / 100f;
            mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_PLING, 1.0f, volume));
        }

        if (kickOnFlag.get() && mc.getNetworkHandler() != null) {
            kickOnFlag.set(false);
            AutoReconnect autoReconnect = Modules.get().get(AutoReconnect.class);
            if (autoReconnect != null && autoReconnect.isActive()) autoReconnect.toggle();
            Systems.save();
            mc.getNetworkHandler().getConnection().disconnect(Text.literal(
                "Kicked - Kripsy Debug+ flagged X: " + flag.x() + " Z: " + flag.z()
                    + "\nKick On Flag was automatically turned OFF."));
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (flags.isEmpty() || mc.player == null) return;

        ChunkPos player = mc.player.getChunkPos();
        double half = plateSize.get() / 2.0;
        double thickness = plateThickness.get();

        for (Flag f : flags.values()) {
            if (Math.abs(f.chunk().x - player.x) > RENDER_RANGE_CHUNKS
                || Math.abs(f.chunk().z - player.z) > RENDER_RANGE_CHUNKS) continue;

            double cx = f.chunk().getCenterX();
            double cz = f.chunk().getCenterZ();
            double y = f.y() + RENDER_Y_OFFSET;
            event.renderer.box(cx - half, y, cz - half, cx + half, y + thickness, cz + half,
                sideColor.get(), lineColor.get(), ShapeMode.Both, 0);
        }
    }
}
