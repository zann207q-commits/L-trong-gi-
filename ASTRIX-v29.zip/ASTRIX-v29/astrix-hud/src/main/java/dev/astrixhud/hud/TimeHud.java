package dev.astrixhud.hud;

import dev.astrixhud.AstrixHudAddon;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeHud extends BaseHud {
    public static final HudElementInfo<TimeHud> INFO = new HudElementInfo<>(
        AstrixHudAddon.GROUP, "astrix-time", "Shows the current time.", TimeHud::new);

    private final Setting<String> pattern = sgGeneral.add(new StringSetting.Builder()
        .name("format")
        .description("Time format (Java SimpleDateFormat).")
        .defaultValue("HH:mm:ss")
        .build());

    private SimpleDateFormat fmt;
    private String lastPattern;

    public TimeHud() {
        super(INFO);
    }

    @Override
    public void render(HudRenderer renderer) {
        String s = format();
        double w = renderer.textWidth(s, true) + PAD * 2;
        double h = renderer.textHeight(true) + PAD * 2;
        setSize(w, h);
        panel(renderer, x, y, w, h);
        renderer.text(s, x + PAD, y + PAD, secondaryColor.get(), true);
    }

    private String format() {
        String p = pattern.get();
        if (fmt == null || !p.equals(lastPattern)) {
            try {
                fmt = new SimpleDateFormat(p);
            } catch (IllegalArgumentException e) {
                fmt = new SimpleDateFormat("HH:mm:ss");
            }
            lastPattern = p;
        }
        return fmt.format(new Date());
    }
}
