package dev.astrixhud.hud;

import dev.astrixhud.AstrixHudAddon;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import net.minecraft.client.network.PlayerListEntry;

import java.util.ArrayList;
import java.util.List;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class InfoHud extends BaseHud {
    public static final HudElementInfo<InfoHud> INFO = new HudElementInfo<>(
        AstrixHudAddon.GROUP, "astrix-info", "Shows FPS, ping and the current server.", InfoHud::new);

    private final Setting<Boolean> showFps = sgGeneral.add(new BoolSetting.Builder().name("fps").defaultValue(true).build());
    private final Setting<Boolean> showPing = sgGeneral.add(new BoolSetting.Builder().name("ping").defaultValue(true).build());
    private final Setting<Boolean> showServer = sgGeneral.add(new BoolSetting.Builder().name("server").defaultValue(true).build());

    public InfoHud() {
        super(INFO);
    }

    @Override
    public void render(HudRenderer renderer) {
        List<String> lines = new ArrayList<>();
        if (showFps.get()) lines.add("FPS: " + mc.getCurrentFps());
        if (showPing.get()) lines.add("Ping: " + ping() + "ms");
        if (showServer.get()) lines.add(server());
        if (lines.isEmpty()) lines.add("Info");

        double lineH = renderer.textHeight(true) + 2;
        double maxW = 0;
        for (String l : lines) maxW = Math.max(maxW, renderer.textWidth(l, true));
        double w = maxW + PAD * 2;
        double h = lines.size() * lineH - 2 + PAD * 2;
        setSize(w, h);
        panel(renderer, x, y, w, h);
        for (int i = 0; i < lines.size(); i++) {
            renderer.text(lines.get(i), x + PAD, y + PAD + i * lineH, secondaryColor.get(), true);
        }
    }

    private int ping() {
        if (mc.player == null || mc.getNetworkHandler() == null) return 0;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e != null ? e.getLatency() : 0;
    }

    private String server() {
        if (mc.isInSingleplayer()) return "Single Player";
        if (mc.getCurrentServerEntry() != null) return mc.getCurrentServerEntry().address;
        return "Not connected";
    }
}
