package skid.kaze.module.modules.donutfinding;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

/** Kaze-native suspicious chunk v2 scanner; scans loaded chunks on the client thread. */
public final class SusChunkV2 extends ChunkScanModule {
    public SusChunkV2() {
        super("Sus Chunk V2", "Flags underground chunks containing repeated non-natural blocks", 5);
    }

    @Override protected boolean matches(BlockState state) {
        return state.isOf(Blocks.COBBLED_DEEPSLATE)
            || state.isOf(Blocks.PISTON)
            || state.isOf(Blocks.STICKY_PISTON)
            || state.isOf(Blocks.TNT)
            || state.isOf(Blocks.SPAWNER)
            || state.isOf(Blocks.OBSIDIAN)
            || state.isOf(Blocks.CHEST)
            || state.isOf(Blocks.TRAPPED_CHEST)
            || state.isOf(Blocks.BARREL);
    }
}
