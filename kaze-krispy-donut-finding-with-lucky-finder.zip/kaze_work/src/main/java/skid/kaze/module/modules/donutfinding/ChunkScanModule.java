package skid.kaze.module.modules.donutfinding;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.utils.EncryptedString;

/**
 * Client-thread-only base for the Krispy-inspired Donut Finding modules.
 * It deliberately scans a bounded vertical range and at most one chunk per interval
 * to avoid the unsafe background access used by the source framework.
 */
public abstract class ChunkScanModule extends Module {
    private final NumberSetting threshold;
    private final BooleanSetting chatNotify;
    private final Set<Long> examined = new HashSet<>();
    private int cursor;
    private int tickCounter;

    protected ChunkScanModule(String name, String description, int defaultThreshold) {
        super(EncryptedString.of(name), EncryptedString.of(description), -1, Category.DONUT_FINDING);
        threshold = new NumberSetting(EncryptedString.of("Minimum Hits"), 1, 100, defaultThreshold, 1);
        chatNotify = new BooleanSetting(EncryptedString.of("Chat Notification"), true);
        addSettings(threshold, chatNotify);
    }

    @Override public void onEnable() {
        examined.clear();
        cursor = 0;
        tickCounter = 0;
    }

    @Override public void onDisable() {
        examined.clear();
    }

    @EventListener
    public final void onTick(TickEvent event) {
        if (mc.player == null || mc.world == null || ++tickCounter < 10) return;
        tickCounter = 0;
        ClientWorld world = mc.world;
        ChunkPos center = mc.player.getChunkPos();
        // 7x7 bounded spiral-like order. Only loaded chunks are read; no chunk loads are requested.
        for (int tries = 0; tries < 49; tries++) {
            int index = (cursor++ % 49);
            int dx = index % 7 - 3;
            int dz = index / 7 - 3;
            WorldChunk chunk = world.getChunkManager().getWorldChunk(center.x + dx, center.z + dz);
            if (chunk == null || chunk.isEmpty() || !examined.add(chunk.getPos().toLong())) continue;
            int hits = countHits(chunk);
            if (hits >= threshold.getIntValue() && chatNotify.getValue()) {
                mc.player.sendMessage(Text.literal("[" + getName() + "] Suspicious chunk at X="
                    + chunk.getPos().getStartX() + " Z=" + chunk.getPos().getStartZ()
                    + " (hits=" + hits + ")"), false);
            }
            return;
        }
        // The loaded region can change as the player moves. Revisit it periodically.
        examined.clear();
    }

    private int countHits(WorldChunk chunk) {
        int count = 0;
        int bottom = chunk.getBottomY();
        int minY = Math.max(bottom, -32);
        int maxY = Math.min(bottom + chunk.getHeight() - 1, 48);
        ChunkSection[] sections = chunk.getSectionArray();
        for (int i = 0; i < sections.length; i++) {
            ChunkSection section = sections[i];
            if (section == null || section.isEmpty()) continue;
            int sectionY = bottom + i * 16;
            int fromY = Math.max(0, minY - sectionY);
            int toY = Math.min(15, maxY - sectionY);
            if (fromY > 15 || toY < 0 || fromY > toY) continue;
            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    for (int y = fromY; y <= toY; y++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (matches(state)) count++;
                    }
                }
            }
        }
        return count;
    }

    protected abstract boolean matches(BlockState state);

    protected static boolean isKrispySuspiciousBlock(BlockState state) {
        return state.isOf(Blocks.COBBLED_DEEPSLATE)
            || state.isOf(Blocks.PISTON)
            || state.isOf(Blocks.STICKY_PISTON)
            || state.isOf(Blocks.TNT)
            || state.isOf(Blocks.SPAWNER);
    }
}
