package skid.kaze.module.modules.donutfinding;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.Direction;

/** Kaze-native, bounded adaptation of Krispy's chunk finder. */
public final class ChunkFinderKrispy extends ChunkScanModule {
    public ChunkFinderKrispy() {
        super("Chunk Finder Krispy", "Kaze-native scan for suspicious underground block patterns", 4);
    }

    @Override protected boolean matches(BlockState state) {
        if (state.isOf(Blocks.COBBLED_DEEPSLATE)) return true;
        return state.isOf(Blocks.DEEPSLATE)
            && state.contains(Properties.AXIS)
            && state.get(Properties.AXIS) != Direction.Axis.Y;
    }
}
