package dev.ollie;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import dev.ollie.modules.ACCollectorModule;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.*;

public class ACAddon extends MeteorAddon {
    public static final Category CATEGORY = new Category("ACCollector");
    public static ACCollectorModule collectorModule;

    @Override
    public void onInitialize() {
        collectorModule = new ACCollectorModule();
        Modules.get().add(collectorModule);

        // /pen — client-side only, server không thấy
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(literal("pen")
                .executes(ctx -> {
                    collectorModule.onPenCommand();
                    return 1;
                })
            )
        );
    }

    @Override
    public String getPackage() { return "dev.ollie"; }
}
