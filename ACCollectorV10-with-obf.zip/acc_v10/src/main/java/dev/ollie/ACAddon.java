package dev.ollie;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import dev.ollie.modules.ACCollectorModule;
import dev.ollie.modules.RaidBaseModule;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.*;
import com.mojang.brigadier.arguments.StringArgumentType;

public class ACAddon extends MeteorAddon {
    public static final Category CATEGORY = new Category("ACCollector");
    public static ACCollectorModule collectorModule;
    public static RaidBaseModule    raidBaseModule;

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public void onInitialize() {
        collectorModule = new ACCollectorModule();
        raidBaseModule  = new RaidBaseModule();

        Modules.get().add(collectorModule);
        Modules.get().add(raidBaseModule);

        // /pen — export ACCollector snapshot
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("pen")
                .executes(ctx -> {
                    collectorModule.onPenCommand();
                    return 1;
                })
            );

            // /raidbase [subcommand]
            dispatcher.register(literal("raidbase")
                .executes(ctx -> {
                    raidBaseModule.onCommand(new String[0]);
                    return 1;
                })
                .then(argument("cmd", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        String raw = StringArgumentType.getString(ctx, "cmd");
                        raidBaseModule.onCommand(raw.trim().split("\\s+"));
                        return 1;
                    })
                )
            );
        });
    }

    @Override
    public String getPackage() { return "dev.ollie"; }
}
