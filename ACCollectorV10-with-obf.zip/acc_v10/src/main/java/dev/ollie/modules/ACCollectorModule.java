// Language: Java 21
// File: ACCollectorModule.java (V9 — drop-in thay V8.2)
// Runtime: Fabric 1.21.11 / Meteor 0.5.9-SNAPSHOT
//
// V9 THÊM SO VỚI V8.2:
//  AC_FINGERPRINT      — phát hiện server đang dùng AC nào (Grim/Matrix/Vulcan/Spartan/NoCheatPlus)
//                        bằng kick message pattern + packet behavior fingerprint
//  ANTI_XRAY           — phát hiện server bật anti-xray engine nào:
//                          • Engine 1: ProOre — gửi đá fake, reveal khi gần
//                          • Engine 2: Stript Mining — gửi air trước, reveal khi view
//                        track ChunkDataS2CPacket block state changes theo thời gian
//  BLOCK_SEND_TRACKER  — log rate + type của mọi S→C block packet (BlockUpdateS2CPacket,
//                        ChunkDeltaUpdateS2CPacket, ChunkDataS2CPacket) → biết server gửi
//                        block với tần suất nào, dùng để tính safe reveal timing
//  KB_TIMING           — đo thời gian từ EntityVelocityUpdate đến PlayerMove tiếp theo
//  SETBACK_TRACK       — phát hiện PlayerPositionLook S→C sau movement (rubber-band)
//  GCD_ROTATION        — đo GCD của yaw delta để fingerprint rotation check algorithm
//  PATCH_PROBE         — tóm tắt cách server đang patch + lỗ hổng còn lại

package dev.ollie.modules;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.ServerConnectBeginEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.s2c.common.CustomPayloadS2CPacket;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket;
import net.minecraft.util.math.Vec3d;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.regex.*;

public class ACCollectorModule extends Module {

    // ── Settings ──────────────────────────────────────────────────────────────
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> autoStart = sg.add(
        new BoolSetting.Builder()
            .name("auto-start")
            .description("Tự bắt đầu thu thập khi vào world")
            .defaultValue(true).build()
    );
    private final Setting<Double> speedThreshold = sg.add(
        new DoubleSetting.Builder()
            .name("speed-threshold")
            .description("Ngưỡng block/tick để flag SPEED (vanilla sprint = ~0.28 bpt)")
            .defaultValue(0.55).min(0.1).sliderMax(2.0).build()
    );
    private final Setting<Integer> attackMsThreshold = sg.add(
        new IntSetting.Builder()
            .name("attack-ms-threshold")
            .description("Dưới X ms giữa 2 attack = flag KILL_AURA")
            .defaultValue(100).min(50).sliderMax(500).build()
    );
    private final Setting<Boolean> logAllPackets = sg.add(
        new BoolSetting.Builder()
            .name("log-all-packets")
            .description("Log mọi packet vào file")
            .defaultValue(false).build()
    );
    private final Setting<Boolean> trackAntiXray = sg.add(
        new BoolSetting.Builder()
            .name("track-anti-xray")
            .description("Phát hiện anti-xray engine của server (theo dõi block reveal)")
            .defaultValue(true).build()
    );

    // ── State ─────────────────────────────────────────────────────────────────
    private volatile ClientSession session = null;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private final long[] surroundTs  = new long[8];
    private final int[]  surroundX   = new int[8];
    private final int[]  surroundZ   = new int[8];
    private int          surroundHead = 0;

    // ── Anti-xray tracking state ──────────────────────────────────────────────
    // Key = chunkPos "cx,cz", value = timestamp khi nhận chunk lần đầu
    private final ConcurrentHashMap<String, Long> chunkReceiveTime = new ConcurrentHashMap<>();
    // Key = blockPos "bx,by,bz", value = blockState khi nhận chunk
    private final ConcurrentHashMap<String, Integer> initialBlockStates = new ConcurrentHashMap<>();
    // Count các block reveal (thay đổi từ stone/deepslate sang ore) → anti-xray signature
    private final AtomicInteger xrayRevealCount = new AtomicInteger();
    // Count block updates do server chủ động gửi khi player đến gần
    private final AtomicInteger proximityRevealCount = new AtomicInteger();

    // ── Block send rate tracking ──────────────────────────────────────────────
    // Window 1 giây: đếm S→C block packets
    private final AtomicLong blockPktWindowStart = new AtomicLong(System.currentTimeMillis());
    private final AtomicLong blockPktWindowCount = new AtomicLong();
    private final AtomicLong peakBlockPps        = new AtomicLong();

    // ── AC Fingerprint patterns ───────────────────────────────────────────────
    // Grim: kick "Illegal stance", "Invalid move", "Excessively digging"
    // Matrix: kick "Moving too fast", "Flying is not enabled"
    // Vulcan: kick "A->B", "Invalid movement"
    // Spartan: kick "Spartan has [flagged|banned]"
    // NCP: kick "You have been kicked for fly", "speed"
    // AAC: kick "Hacking is not allowed", "Internal error"
    private static final List<AcPattern> AC_PATTERNS = List.of(
        new AcPattern("Grim",   Pattern.compile("(?i)(illegal stance|excessively digging|invalid move distance|predictions?)"), "flag-based, setback aggressive, GCD check v2"),
        new AcPattern("Matrix", Pattern.compile("(?i)(moving too fast|fly(ing)? is not enabled|matrix)"),                     "flag+setback, checks combat timing, no GCD"),
        new AcPattern("Vulcan", Pattern.compile("(?i)(\\w+->\\w+|invalid movement|vulcan)"),                                  "flag-based, setback=no, rotation strict"),
        new AcPattern("Spartan",Pattern.compile("(?i)(spartan.{0,20}(flag|ban)|impossible movement)"),                        "flag+ban, checks scaffold, timer"),
        new AcPattern("NCP",    Pattern.compile("(?i)(nocheatplus|kicked for fly|speed hacking|blinkspeed)"),                  "old AC, easy bypass, setback=yes"),
        new AcPattern("AAC",    Pattern.compile("(?i)(hacking is not allowed|aac|advanced anti[- ]cheat)"),                   "moderate AC, timer check weak"),
        new AcPattern("Dac",    Pattern.compile("(?i)(dac|developer anti[- ]cheat|custom anti[- ]cheat)"),                    "unknown custom — analyze packet behavior"),
        new AcPattern("AntiCheatReloaded", Pattern.compile("(?i)(acr|anti.?cheat.?reloaded)"),                                "plugin-based, usually weak"),
        new AcPattern("Sentinel",          Pattern.compile("(?i)(sentinel|guardian.{0,10}kick)"),                             "BungeeCord proxy AC, check movement lag")
    );

    private record AcPattern(String name, Pattern pat, String notes) {}

    private static final Path EXPORT_ROOT;
    static {
        Path root;
        String os = System.getProperty("os.name","").toLowerCase();
        if (os.contains("win")) {
            String appdata = System.getenv("APPDATA");
            if (appdata == null) appdata = System.getProperty("user.home",".");
            root = Path.of(appdata,".minecraft","acv9_export");
        } else if (os.contains("mac")) {
            root = Path.of(System.getProperty("user.home","."),
                "Library","Application Support","minecraft","acv9_export");
        } else {
            root = Path.of(System.getProperty("user.home",".")
                ,".minecraft","acv9_export");
        }
        EXPORT_ROOT = root;
    }

    public ACCollectorModule() {
        super(dev.ollie.ACAddon.CATEGORY, "ACCollector",
            "Thu thập dữ liệu AC từ server. /pen để export.");
    }

    private static double rawVel(double bpt) {
        return (short) Math.max(-32768, Math.min(32767, Math.round(bpt * 8000.0)));
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override public void onActivate() { startSession(); }
    @Override public void onDeactivate() {
        ClientSession s = session; session = null;
        if (s != null) dumpReportAsync(s);
    }

    @EventHandler
    private void onConnect(ServerConnectBeginEvent event) {
        if (autoStart.get() && isActive()) startSession();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKET C→S
    // ══════════════════════════════════════════════════════════════════════════
    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        ClientSession s = session;
        if (s == null) return;
        s.totalPackets.incrementAndGet();
        s.tickRate();

        var pkt = event.packet;

        if (pkt instanceof PlayerMoveC2SPacket move) {
            if (move.changesPosition()) {
                s.moveCount.incrementAndGet();
                handleMovement(s,
                    move.getX(s.lastX), move.getY(s.lastY), move.getZ(s.lastZ),
                    move.getYaw(s.lastYaw), move.getPitch(s.lastPitch),
                    move.isOnGround());
            }
            if (move.changesLook())
                handleRotation(s, move.getYaw(s.lastYaw), move.getPitch(s.lastPitch));
        }

        else if (pkt instanceof TeleportConfirmC2SPacket tp) {
            long now = System.currentTimeMillis();
            if (s.pendingTeleportId != -1 && tp.getTeleportId() != s.pendingTeleportId) {
                s.teleportBypassCount.incrementAndGet();
                s.flag("TELEPORT_MISMATCH",
                    "expected=" + s.pendingTeleportId + " got=" + tp.getTeleportId());
            }
            long latency = s.pendingTeleportSentMs > 0 ? now - s.pendingTeleportSentMs : 0;
            s.pendingTeleportId = -1;
            s.log("TP_CONFIRM", "id=" + tp.getTeleportId() + " latencyMs=" + latency);
        }

        else if (pkt instanceof PlayerActionC2SPacket dig) {
            s.digCount.incrementAndGet();
            long now = System.currentTimeMillis();
            long delta = s.lastDigTime == 0 ? 0 : now - s.lastDigTime;
            if (dig.getAction() == PlayerActionC2SPacket.Action.START_DESTROY_BLOCK) {
                if (delta > 0) {
                    s.digDeltas.offer(delta);
                    if (delta < 50) s.flag("INSTANT_MINE","delta="+delta+"ms pos="+dig.getPos());
                }
                s.lastDigTime = now;
            }
        }

        else if (pkt instanceof PlayerInteractBlockC2SPacket place) {
            s.placeCount.incrementAndGet();
            long now = System.currentTimeMillis();
            long delta = s.lastPlaceTime == 0 ? 0 : now - s.lastPlaceTime;
            int bx=place.getBlockHitResult().getBlockPos().getX();
            int by=place.getBlockHitResult().getBlockPos().getY();
            int bz=place.getBlockHitResult().getBlockPos().getZ();
            if (delta > 0) {
                s.placeDeltas.offer(delta);
                if (delta < 50) s.flag("RAPID_PLACE","gap="+delta+"ms pos=("+bx+","+by+","+bz+")");
            }
            s.lastPlaceTime = now;
            var mc = MinecraftClient.getInstance();
            if (mc.player != null) {
                double py = mc.player.getY();
                if (by == (int)(py - 1) && s.moveCount.get() > 0
                        && now - lastMoveTimeForScaffold < 100) {
                    s.scaffoldCount.incrementAndGet();
                    if (s.scaffoldCount.get() % 5 == 1)
                        s.flag("SCAFFOLD","count="+s.scaffoldCount.get()+" pos=("+bx+","+by+","+bz+")");
                }
            }
            surroundTs[surroundHead]=now; surroundX[surroundHead]=bx;
            surroundZ[surroundHead]=bz; surroundHead=(surroundHead+1)%8;
            checkSurround(s, now, bx, bz);
        }

        else if (pkt instanceof PlayerInteractEntityC2SPacket attack) {
            int[] ia = PktUtil.readInteract(attack);
            int attackEntityId = ia == null ? -1 : ia[0];
            if (ia != null && ia[1] == 1) {
                s.attackCount.incrementAndGet();
                long now = System.currentTimeMillis();
                long delta = s.lastAttackTime == 0 ? 0 : now - s.lastAttackTime;
                if (delta > 0) {
                    s.attackDeltas.offer(delta);
                    if (delta < attackMsThreshold.get())
                        s.flag("KILL_AURA","delta="+delta+"ms entityId="+attackEntityId);
                }
                s.lastAttackTime = now;
                long sinceSwing = now - s.lastSwingTime;
                if (sinceSwing > 300 && s.swingCount.get() > 5)
                    s.flag("NO_SWING","sinceSwing="+sinceSwing+"ms entityId="+attackEntityId);
            }
        }

        else if (pkt instanceof HandSwingC2SPacket) {
            s.swingCount.incrementAndGet();
            s.lastSwingTime = System.currentTimeMillis();
        }

        else if (pkt instanceof PlayerInteractItemC2SPacket itemUse) {
            long now = System.currentTimeMillis();
            long delta = s.lastItemUseTime == 0 ? 0 : now - s.lastItemUseTime;
            if (delta > 0 && delta < 20) {
                s.itemUseDeltas.offer(delta);
                s.flag("FAST_USE","delta="+delta+"ms hand="+itemUse.getHand());
            }
            s.lastItemUseTime = now;
        }

        else if (pkt instanceof UpdateSelectedSlotC2SPacket slot) {
            long now = System.currentTimeMillis();
            long delta = s.lastSlotTime == 0 ? 0 : now - s.lastSlotTime;
            if (delta > 0 && delta < 20)
                s.flag("AUTO_TOOL","slotChange delta="+delta+"ms slot="+slot.getSelectedSlot());
            s.lastSlotTime = now;
        }

        else if (pkt instanceof ClickSlotC2SPacket click) {
            int slot = click.slot();
            if (slot >= 5 && slot <= 8) {
                long now = System.currentTimeMillis();
                long delta = s.lastSlotTime == 0 ? 0 : now - s.lastSlotTime;
                if (delta > 0 && delta < 50)
                    s.flag("AUTO_ARMOR","armorSlot="+slot+" delta="+delta+"ms");
                s.lastSlotTime = now;
            }
        }

        else if (pkt instanceof KeepAliveC2SPacket ka) {
            long now = System.currentTimeMillis();
            if (s.lastKeepAliveSentMs > 0 && PktUtil.firstLong(ka,-1) == s.lastKeepAliveId) {
                long ping = now - s.lastKeepAliveSentMs;
                s.pingSamples.offer(ping);
            }
        }

        else if (pkt instanceof ChatMessageC2SPacket chat) {
            s.log("CHAT", ClientSession.sanitize(chat.chatMessage()));
        }

        else if (pkt instanceof CommandExecutionC2SPacket cmd) {
            s.log("CMD", "/" + ClientSession.sanitize(cmd.command()));
        }

        else if (pkt instanceof CustomPayloadC2SPacket custom) {
            String channel = custom.payload().getId().id().toString();
            String key = "C→S/CUSTOM/" + channel;
            s.unknownPackets.computeIfAbsent(key, k -> new ClientSession.PktStat()).record(0);
        }

        else {
            String name = pkt.getClass().getSimpleName();
            s.unknownPackets.computeIfAbsent("C→S/"+name,
                k -> new ClientSession.PktStat()).record(0);
            s.rawPktCount.incrementAndGet();
            if (logAllPackets.get()) s.log("RAW_C→S","type="+name);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKET S→C
    // ══════════════════════════════════════════════════════════════════════════
    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        ClientSession s = session;
        if (s == null) return;
        var pkt = event.packet;

        if (pkt instanceof KeepAliveS2CPacket ka) {
            s.lastKeepAliveSentMs = System.currentTimeMillis();
            s.lastKeepAliveId = PktUtil.firstLong(ka, -1);
        }

        else if (pkt instanceof EntityVelocityUpdateS2CPacket vel) {
            var mc = MinecraftClient.getInstance();
            if (mc.player != null && PktUtil.firstInt(vel, -1) == mc.player.getId()) {
                Vec3d v = PktUtil.vec(vel);
                double vx = v == null ? 0 : rawVel(v.x) / 8000.0;
                double vy = v == null ? 0 : rawVel(v.y) / 8000.0;
                double vz = v == null ? 0 : rawVel(v.z) / 8000.0;
                s.pendingVelocity = new ClientSession.PendingVelocity(vx, vy, vz,
                    System.currentTimeMillis());
                s.pendingKbReceivedMs = System.currentTimeMillis();
                s.pendingKbMag = Math.sqrt(vx*vx + vz*vz);
                s.log("S→C_VEL", String.format("vx=%.4f vy=%.4f vz=%.4f hMag=%.4f",
                    vx, vy, vz, s.pendingKbMag));
            }
        }

        // SETBACK_TRACK — PlayerPositionLook = server setback/rubber-band
        else if (pkt instanceof PlayerPositionLookS2CPacket pos) {
            int tpId = PktUtil.firstInt(pos, 0);
            Vec3d tpPos = PktUtil.vec(pos);
            long now = System.currentTimeMillis();
            s.pendingTeleportId = tpId;
            s.pendingTeleportSentMs = now;
            s.log("S→C_TP", "id=" + tpId
                + " pos=" + (tpPos == null ? "?" : tpPos.x+","+tpPos.y+","+tpPos.z));

            if (s.moveCount.get() > 10) {
                long sinceLastMove = now - s.lastMoveTime;
                if (sinceLastMove < 500) {
                    s.setbackCount.incrementAndGet();
                    long sinceLastSetback = now - s.lastSetbackMs;
                    if (s.lastSetbackMs > 0) s.setbackIntervals.offer(sinceLastSetback);
                    s.lastSetbackMs = now;
                    s.flag("SETBACK", String.format(
                        "count=%d sinceMove=%dms interval=%dms",
                        s.setbackCount.get(), sinceLastMove,
                        s.lastSetbackMs > 0 ? sinceLastSetback : -1));
                }
            }
        }

        // BLOCK_SEND_TRACKER + ANTI_XRAY: ChunkDataS2CPacket
        // Server gửi toàn chunk — record các ore block ban đầu.
        // Nếu sau đó cùng vị trí đó bị update thành ore khác → reveal (ProOre anti-xray).
        else if (pkt instanceof ChunkDataS2CPacket chunk) {
            s.chunkDataCount.incrementAndGet();
            recordBlockSendRate(s);
            if (trackAntiXray.get()) {
                handleChunkData(s, chunk);
            }
        }

        // BLOCK_SEND_TRACKER + ANTI_XRAY: BlockUpdateS2CPacket (single block)
        // Server cập nhật 1 block đơn lẻ. Nếu block cũ là stone/deepslate và mới là ore
        // trong vòng vài giây sau khi nhận chunk → ProOre reveal.
        else if (pkt instanceof BlockUpdateS2CPacket blockUpdate) {
            s.blockUpdateCount.incrementAndGet();
            recordBlockSendRate(s);
            if (trackAntiXray.get()) {
                handleBlockUpdate(s, blockUpdate);
            }
            if (logAllPackets.get()) {
                var pos2 = PktUtil.firstInt(blockUpdate, 0);
                s.log("S→C_BLOCK_UPDATE", "pos=" + blockUpdate.getPos()
                    + " state=" + blockUpdate.getState().toString());
            }
        }

        // BLOCK_SEND_TRACKER: ChunkDeltaUpdateS2CPacket (multi-block update)
        // Server gửi nhiều block cùng lúc. Rate cao bất thường sau di chuyển → anti-xray reveal.
        else if (pkt instanceof ChunkDeltaUpdateS2CPacket multiUpdate) {
            s.multiBlockUpdateCount.incrementAndGet();
            recordBlockSendRate(s);
            if (trackAntiXray.get()) {
                handleMultiBlockUpdate(s, multiUpdate);
            }
        }

        else if (pkt instanceof DisconnectS2CPacket dc) {
            String reason = "unknown";
            try { reason = PktUtil.text(dc); } catch (Exception ignored) {}
            // AC_FINGERPRINT: match kick message với AC pattern
            fingerprintKick(s, reason);
            s.flag("AC_KICK", "server kicked: " + reason);
        }

        else if (pkt instanceof EntityStatusS2CPacket status) {
            if (status.getStatus() >= 32) {
                s.unknownPackets.computeIfAbsent("S→C/EntityStatus_"+status.getStatus(),
                    k -> new ClientSession.PktStat()).record(0);
                s.log("S→C_AC_STATUS","status="+status.getStatus()
                    +" entityId="+PktUtil.firstInt(status,-1));
                // EntityStatus 32+ = thường là AC signal (đặc biệt trên Paper/Spigot AC)
                // Grim dùng status để signal "failed prediction"
                s.acEntityStatusHits.incrementAndGet();
            }
        }

        // AC_FINGERPRINT: Custom channel — Grim gửi "BUNGEECORD_AC", "GRIM_MITIGATION"
        // Matrix: "matrix:check", Vulcan: "vulcan:flag"
        else if (pkt instanceof CustomPayloadS2CPacket custom) {
            String channel = custom.payload().getId().id().toString();
            s.unknownPackets.computeIfAbsent("S→C/CUSTOM/"+channel,
                k -> new ClientSession.PktStat()).record(0);
            s.log("S→C_CUSTOM","channel="+channel);
            // Fingerprint từ channel name
            fingerprintChannel(s, channel);
        }

        else if (logAllPackets.get()) {
            String name = pkt.getClass().getSimpleName();
            if (!name.startsWith("Block") && !name.startsWith("Chunk")
                && !name.startsWith("Light") && !name.startsWith("Particle")
                && !name.startsWith("GameJoin") && !name.startsWith("PlayerList"))
                s.log("S→C","type="+name);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ANTI-XRAY HANDLERS
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * ChunkData: ghi lại block ID của từng block trong chunk.
     * Dùng để detect Engine 1 (ProOre): server gửi đá fake thay ore, reveal khi gần.
     * Dùng để detect Engine 2 (Strip): server không gửi ore, chỉ gửi khi view thẳng.
     *
     * Thay vì parse toàn bộ chunk data (phức tạp, cần section parsing),
     * ta chỉ record chunkPos + timestamp → sau đó compare với block updates.
     */
    private void handleChunkData(ClientSession s, ChunkDataS2CPacket chunk) {
        // Lấy chunk pos qua reflection (tránh phụ thuộc tên Yarn)
        int cx = PktUtil.firstInt(chunk, 0);
        // Chunk Z: field int thứ 2
        int cz = 0;
        try {
            var fields = chunk.getClass().getDeclaredFields();
            int intIdx = 0;
            for (var f : fields) {
                if (f.getType() == int.class && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    f.setAccessible(true);
                    if (intIdx == 0) cx = f.getInt(chunk);
                    else if (intIdx == 1) { cz = f.getInt(chunk); break; }
                    intIdx++;
                }
            }
        } catch (Exception ignored) {}

        String key = cx + "," + cz;
        long now = System.currentTimeMillis();
        chunkReceiveTime.putIfAbsent(key, now);
        s.log("S→C_CHUNK", "cx=" + cx + " cz=" + cz);
    }

    /**
     * BlockUpdate: so sánh với lần đầu nhận chunk.
     * Nếu block update xảy ra < 10s sau khi nhận chunk → ProOre Engine 1 reveal.
     * Nếu xảy ra khi player đang di chuyển lại gần → proximity reveal.
     *
     * "ore-like" state: check block state ID nằm trong range diamond/gold/iron ore.
     * Exact IDs phụ thuộc version — dùng toString để detect.
     */
    private void handleBlockUpdate(ClientSession s, BlockUpdateS2CPacket pkt) {
        var pos = pkt.getPos();
        var state = pkt.getState();
        String stateStr = state.toString().toLowerCase();

        // Check xem có phải ore reveal không
        boolean isOre = stateStr.contains("ore") || stateStr.contains("diamond")
            || stateStr.contains("ancient_debris") || stateStr.contains("emerald")
            || stateStr.contains("lapis") || stateStr.contains("redstone_ore");
        boolean isFakeBlock = stateStr.contains("stone") || stateStr.contains("deepslate")
            || stateStr.contains("netherrack");

        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;
        String chunkKey = cx + "," + cz;
        Long chunkReceived = chunkReceiveTime.get(chunkKey);

        if (isOre && chunkReceived != null) {
            long sinceChunk = System.currentTimeMillis() - chunkReceived;
            // Nếu block update thành ore trong vòng 15s sau nhận chunk → ProOre reveal
            if (sinceChunk < 15_000) {
                xrayRevealCount.incrementAndGet();
                s.antiXrayRevealCount.incrementAndGet();
                s.log("ANTI_XRAY_REVEAL",
                    String.format("Engine1(ProOre) pos=(%d,%d,%d) state=%s sinceChunk=%dms",
                        pos.getX(), pos.getY(), pos.getZ(), stateStr, sinceChunk));

                // Tính khoảng cách player đến block để estimate reveal radius
                var mc = MinecraftClient.getInstance();
                if (mc.player != null) {
                    double dx = mc.player.getX() - pos.getX();
                    double dy = mc.player.getY() - pos.getY();
                    double dz = mc.player.getZ() - pos.getZ();
                    double dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
                    s.xrayRevealDistances.offer(dist);
                    s.log("ANTI_XRAY_DIST", String.format("reveal_dist=%.2f blocks", dist));
                }

                // Nếu reveal nhiều trong cùng 1 lần move → proximity reveal (Engine 1 aggressive)
                long now = System.currentTimeMillis();
                if (now - s.lastMoveTime < 200) {
                    proximityRevealCount.incrementAndGet();
                    s.antiXrayProximityCount.incrementAndGet();
                }
            }
        }

        // Record initial block state để detect Engine 2 (strip mining — server gửi air trước)
        String posKey = pos.getX() + "," + pos.getY() + "," + pos.getZ();
        if (isFakeBlock) {
            initialBlockStates.putIfAbsent(posKey, 1); // 1 = known fake/stone
        } else if (isOre && initialBlockStates.containsKey(posKey)) {
            // Block từng là stone → giờ là ore: Engine 1 confirmed
            s.antiXrayEngine1Confirmed.set(true);
        }
    }

    /**
     * MultiBlockUpdate: burst block update sau di chuyển = anti-xray reveal batch.
     * Đếm số block trong 1 packet và rate — batch > 50 blocks trong 100ms = Engine 1.
     */
    private void handleMultiBlockUpdate(ClientSession s, ChunkDeltaUpdateS2CPacket pkt) {
        // Đếm số block update trong packet via reflection
        int blockCount = 0;
        try {
            for (var f : pkt.getClass().getDeclaredFields()) {
                if (f.getType().isArray() && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    f.setAccessible(true);
                    Object arr = f.get(pkt);
                    if (arr != null) {
                        blockCount = java.lang.reflect.Array.getLength(arr);
                        break;
                    }
                }
            }
        } catch (Exception ignored) {}

        if (blockCount > 0) {
            s.multiBlockBatchSizes.offer(blockCount);
            long now = System.currentTimeMillis();
            if (blockCount > 50 && now - s.lastMoveTime < 100) {
                s.antiXrayBurstCount.incrementAndGet();
                s.log("ANTI_XRAY_BURST",
                    "MultiBlock batch=" + blockCount + " after move — Engine1 burst reveal");
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // BLOCK SEND RATE
    // ══════════════════════════════════════════════════════════════════════════
    private void recordBlockSendRate(ClientSession s) {
        blockPktWindowCount.incrementAndGet();
        long now = System.currentTimeMillis();
        long ws = blockPktWindowStart.get();
        long elapsed = now - ws;
        if (elapsed >= 1000L && blockPktWindowStart.compareAndSet(ws, now)) {
            long cnt = blockPktWindowCount.getAndSet(0);
            long bpps = cnt * 1000L / Math.max(1L, elapsed);
            s.blockPpsSamples.offer(bpps);
            long cur;
            do { cur = peakBlockPps.get(); }
            while (bpps > cur && !peakBlockPps.compareAndSet(cur, bpps));
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // AC FINGERPRINT
    // ══════════════════════════════════════════════════════════════════════════

    /** Match kick message với known AC patterns. */
    private void fingerprintKick(ClientSession s, String reason) {
        for (AcPattern p : AC_PATTERNS) {
            if (p.pat().matcher(reason).find()) {
                s.detectedAcName = p.name();
                s.detectedAcNotes = p.notes();
                s.log("AC_FINGERPRINT_KICK",
                    "detected=" + p.name() + " reason=\"" + reason + "\" notes=" + p.notes());
                return;
            }
        }
        // Không match → custom AC
        s.detectedAcName = "CustomAC";
        s.detectedAcNotes = "No known pattern — analyze unknown_packets và setback behavior";
        s.log("AC_FINGERPRINT_KICK", "UNKNOWN AC — reason=\"" + reason + "\"");
    }

    /**
     * Fingerprint từ custom channel.
     * Grim: "grim_anticheat:grimAC", Matrix: "matrix:check", Vulcan: "vulcan:check"
     * Spartan: "spartan:data", NCP: không dùng custom channel
     */
    private void fingerprintChannel(ClientSession s, String channel) {
        String lower = channel.toLowerCase();
        String detected = null;
        if (lower.contains("grim"))    detected = "Grim (channel: " + channel + ")";
        else if (lower.contains("matrix"))  detected = "Matrix (channel: " + channel + ")";
        else if (lower.contains("vulcan"))  detected = "Vulcan (channel: " + channel + ")";
        else if (lower.contains("spartan")) detected = "Spartan (channel: " + channel + ")";
        else if (lower.contains("aac"))     detected = "AAC (channel: " + channel + ")";
        else if (lower.contains("sentinel"))detected = "Sentinel (channel: " + channel + ")";

        if (detected != null) {
            s.acChannelFingerprints.add(detected);
            s.log("AC_FINGERPRINT_CHANNEL", "detected=" + detected);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // MOVEMENT HANDLER
    // ══════════════════════════════════════════════════════════════════════════
    private volatile long lastMoveTimeForScaffold = 0;

    private void handleMovement(ClientSession s,
                                double x, double y, double z,
                                float yaw, float pitch, boolean onGround) {
        long now    = System.currentTimeMillis();
        long tDelta = s.lastMoveTime == 0 ? 50 : now - s.lastMoveTime;
        s.lastMoveTime = now;
        lastMoveTimeForScaffold = now;

        if (s.lastX == Double.MIN_VALUE) {
            s.lastX=x; s.lastY=y; s.lastZ=z;
            s.lastYaw=yaw; s.lastPitch=pitch; return;
        }

        double dx = x - s.lastX, dy = y - s.lastY, dz = z - s.lastZ;
        double hDist = Math.sqrt(dx*dx + dz*dz);
        double vDist = dy;

        s.lastX=x; s.lastY=y; s.lastZ=z;
        s.lastYaw=yaw; s.lastPitch=pitch;

        if (hDist > 0.005) { s.speedSamples.offer(hDist); s.recentSpeeds.offer(hDist); }
        if (hDist > s.maxSpeedSeen) s.maxSpeedSeen = hDist;
        if (Math.abs(vDist) > s.maxDeltaYSeen) s.maxDeltaYSeen = Math.abs(vDist);

        if (tDelta > 2000 && hDist > 3.0 && s.moveCount.get() > 20)
            s.flag("BLINK","tDelta="+tDelta+"ms hDist="+String.format("%.4f",hDist));

        if (!onGround) s.airTicks.incrementAndGet();
        else s.airTicks.set(0);

        // KB_TIMING — đo accept window từ velocity packet đến move này
        if (s.pendingKbReceivedMs > 0) {
            long acceptWindowMs = now - s.pendingKbReceivedMs;
            if (acceptWindowMs < 2000 && s.pendingKbMag > 0.05) {
                s.kbAcceptWindows.offer(acceptWindowMs);
                if (acceptWindowMs < 20 && hDist < s.pendingKbMag * 0.3) {
                    s.velocityBypassCount.incrementAndGet();
                    s.flag("VELOCITY_BYPASS", String.format(
                        "acceptWindow=%dms expected_hMag=%.4f actual=%.4f",
                        acceptWindowMs, s.pendingKbMag, hDist));
                } else {
                    s.log("KB_ACCEPT", "window="+acceptWindowMs+"ms hMag="+
                        String.format("%.4f",s.pendingKbMag)+" actual="+String.format("%.4f",hDist));
                }
            }
            s.pendingKbReceivedMs = 0;
            s.pendingKbMag = 0;
            s.pendingVelocity = null;
        }

        // V8 velocity bypass fallback
        ClientSession.PendingVelocity pv = s.pendingVelocity;
        if (pv != null && s.pendingKbReceivedMs == 0) {
            long sinceVel = now - pv.receivedMs();
            if (sinceVel < 500) {
                double expectedH = pv.hMag();
                long avgPing = getAvgPing(s);
                if (expectedH > 0.15 && avgPing < 300) {
                    double ratio = hDist / Math.max(expectedH, 0.001);
                    if (ratio < 0.30) {
                        s.velocityBypassCount.incrementAndGet();
                        s.flag("VELOCITY_BYPASS", String.format(
                            "expected=%.4f actual=%.4f ratio=%.2f ping=%dms",
                            expectedH, hDist, ratio, avgPing));
                    }
                }
            }
            s.pendingVelocity = null;
        }

        if (hDist > speedThreshold.get()) {
            s.flaggedSpeeds.offer(hDist);
            s.flag("SPEED", String.format("hDist=%.4f bpt tDelta=%dms", hDist, tDelta));
        }

        int air = s.airTicks.get();
        if (air > 20 && vDist > 0.03 && hDist < 2.5)
            s.flag("FLY_MOVE","airTicks="+air+" vDist="+String.format("%.4f",vDist));

        if (hDist > 5.0 && tDelta < 500)
            s.flag("CLIP","hDist="+String.format("%.4f",hDist)+" phase/clip");

        if (tDelta > 0 && tDelta < 30 && s.moveCount.get() > 40)
            s.flag("TIMER","tDelta="+tDelta+"ms (>"+(1000/tDelta)+" pps)");

        if (logAllPackets.get())
            s.log("MOVE", String.format("x=%.3f y=%.3f z=%.3f hDist=%.4f vDist=%.4f air=%d tDelta=%dms",
                x, y, z, hDist, vDist, air, tDelta));
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GCD ROTATION HANDLER
    // ══════════════════════════════════════════════════════════════════════════
    private void handleRotation(ClientSession s, float yaw, float pitch) {
        long now = System.currentTimeMillis();

        if (s.lastRotTime > 0) {
            long dt = now - s.lastRotTime;
            if (dt > 0 && dt < 100) {
                float dyaw   = Math.abs(yaw   - s.lastRotYaw);
                float dpitch = Math.abs(pitch - s.lastRotPitch);
                if (dyaw > 180) dyaw = 360 - dyaw;
                if (dyaw > 90 || dpitch > 90) {
                    s.snapAimCount.incrementAndGet();
                    s.flag("SNAP_AIM", String.format(
                        "dyaw=%.1f dpitch=%.1f dt=%dms count=%d",
                        dyaw, dpitch, dt, s.snapAimCount.get()));
                }

                if (dyaw > 0.001f && dyaw < 10f) {
                    int dyawMd  = Math.round(dyaw  * 1000f);
                    int dpitchMd = Math.round(dpitch * 1000f);
                    if (dyawMd > 0)   s.gcdYawSamples.offer(dyawMd);
                    if (dpitchMd > 0) s.gcdPitchSamples.offer(dpitchMd);
                }
            }
        }
        s.lastRotTime  = now;
        s.lastRotYaw   = yaw;
        s.lastRotPitch = pitch;
    }

    private static int gcd(int a, int b) {
        while (b != 0) { int t=b; b=a%b; a=t; }
        return a;
    }

    private static int listGcd(List<Integer> vals) {
        if (vals.isEmpty()) return 0;
        int g = vals.get(0);
        for (int i = 1; i < vals.size(); i++) g = gcd(g, vals.get(i));
        return g;
    }

    // ── Surround ──────────────────────────────────────────────────────────────
    private void checkSurround(ClientSession s, long now, int bx, int bz) {
        int nearby = 0;
        for (int i = 0; i < 8; i++)
            if (now - surroundTs[i] < 100
                && Math.abs(surroundX[i]-bx) <= 1
                && Math.abs(surroundZ[i]-bz) <= 1) nearby++;
        if (nearby >= 4)
            s.flag("SURROUND","4+ blocks near ("+bx+","+bz+") within 100ms");
    }

    private long getAvgPing(ClientSession s) {
        List<Long> samples = s.pingSamples.snapshot();
        if (samples.isEmpty()) return 50L;
        return (long) samples.stream().mapToLong(l->l).average().orElse(50L);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SESSION MANAGEMENT
    // ══════════════════════════════════════════════════════════════════════════
    private void startSession() {
        ClientSession old = session;
        if (old != null) old.close();
        // Reset anti-xray tracking state
        chunkReceiveTime.clear();
        initialBlockStates.clear();
        xrayRevealCount.set(0);
        proximityRevealCount.set(0);
        blockPktWindowCount.set(0);
        blockPktWindowStart.set(System.currentTimeMillis());
        peakBlockPps.set(0);

        var mc = MinecraftClient.getInstance();
        String name = mc.player != null ? mc.player.getName().getString() : "unknown";
        try { Files.createDirectories(EXPORT_ROOT); } catch (IOException e) { e.printStackTrace(); }
        session = new ClientSession(name, EXPORT_ROOT);
        chatInfo("§aSession V9 bắt đầu — §f" + name);
    }

    private static void chatInfo(String msg) {
        MinecraftClient.getInstance().execute(
            () -> ChatUtils.infoPrefix("ACCollector", "%s", msg));
    }
    private static void chatError(String msg) {
        MinecraftClient.getInstance().execute(
            () -> ChatUtils.errorPrefix("ACCollector", "%s", msg));
    }

    public void onPenCommand() {
        ClientSession s = session;
        if (s == null) { chatError("Chưa có session nào đang chạy!"); return; }
        dumpReportAsync(s);
    }

    private void dumpReportAsync(ClientSession s) {
        Thread.ofVirtual().name("acv9-export").start(() -> {
            try { doExport(s); }
            catch (Exception e) { e.printStackTrace(); chatError("Export lỗi: "+e.getMessage()); }
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    // EXPORT
    // ══════════════════════════════════════════════════════════════════════════
    private void doExport(ClientSession s) throws IOException {
        Files.createDirectories(s.sessionDir);
        JsonObject report = buildReport(s);

        Path jsonOut = s.sessionDir.resolve("snapshot.json");
        Files.writeString(jsonOut, gson.toJson(report), StandardCharsets.UTF_8,
            StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

        JsonObject summary = report.getAsJsonObject("raid_bypass_summary");
        String txt = buildTxt(s, summary);
        Path txtOut = s.sessionDir.resolve("bypass_config.txt");
        Files.writeString(txtOut, txt, StandardCharsets.UTF_8,
            StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

        s.flush();
        chatInfo("§a✔ §fFlags=" + s.flagCount.get()
            + " Pkts=" + s.totalPackets.get()
            + " AC=" + (s.detectedAcName != null ? s.detectedAcName : "?")
            + " XrayReveals=" + s.antiXrayRevealCount.get()
            + " Setbacks=" + s.setbackCount.get());
        chatInfo("§7Saved → " + txtOut.toAbsolutePath());
    }

    // ══════════════════════════════════════════════════════════════════════════
    // REPORT BUILDER
    // ══════════════════════════════════════════════════════════════════════════
    private JsonObject buildReport(ClientSession s) {
        JsonObject r = new JsonObject();
        r.addProperty("player",          s.playerName);
        r.addProperty("session_ms",      System.currentTimeMillis() - s.sessionStartMs);
        r.addProperty("total_packets",   s.totalPackets.get());
        r.addProperty("move_packets",    s.moveCount.get());
        r.addProperty("flag_count",      s.flagCount.get());
        r.addProperty("peak_pps",        s.peakPps());
        r.addProperty("velocity_bypass", s.velocityBypassCount.get());
        r.addProperty("teleport_bypass", s.teleportBypassCount.get());
        r.addProperty("snap_aim_count",  s.snapAimCount.get());
        r.addProperty("scaffold_count",  s.scaffoldCount.get());
        r.addProperty("setback_count",   s.setbackCount.get());

        r.add("ping",           buildPing(s));
        r.add("speed",          buildSpeed(s));
        r.add("dig_timing",     buildTiming(s.digDeltas,    "block break delay"));
        r.add("place_timing",   buildTiming(s.placeDeltas,  "placement delay"));
        r.add("attack_timing",  buildTiming(s.attackDeltas, "attack gap"));
        r.add("item_use",       buildTiming(s.itemUseDeltas,"item use gap"));
        r.add("kb_timing",      buildKbTiming(s));
        r.add("setback",        buildSetback(s));
        r.add("rotation_gcd",   buildGcd(s));
        r.add("ac_fingerprint", buildAcFingerprint(s));     // V9 NEW
        r.add("anti_xray",      buildAntiXray(s));          // V9 NEW
        r.add("block_send",     buildBlockSend(s));         // V9 NEW
        r.add("patch_probe",    buildPatchProbe(s));        // V9 NEW

        JsonObject unknowns = new JsonObject();
        s.unknownPackets.forEach((name, stat) -> {
            JsonObject p = new JsonObject();
            p.addProperty("occurrences", stat.count.get());
            p.addProperty("modal_size",  stat.modalSize());
            p.addProperty("advice",      "Track/spoof type=" + name);
            unknowns.add(name, p);
        });
        r.add("unknown_packets", unknowns);

        JsonArray flags = new JsonArray();
        s.flagLog.snapshot().forEach(flags::add);
        r.add("flags", flags);

        r.add("raid_bypass_summary", buildSummary(r, s));
        return r;
    }

    // ── V9: AC Fingerprint block ───────────────────────────────────────────────
    private JsonObject buildAcFingerprint(ClientSession s) {
        JsonObject o = new JsonObject();

        // Detection từ kick message
        if (s.detectedAcName != null) {
            o.addProperty("detected_ac",    s.detectedAcName);
            o.addProperty("detection_method","kick_message");
            o.addProperty("ac_notes",       s.detectedAcNotes);
        }

        // Detection từ custom channel
        if (!s.acChannelFingerprints.isEmpty()) {
            JsonArray channels = new JsonArray();
            s.acChannelFingerprints.forEach(channels::add);
            o.add("channel_fingerprints", channels);
            if (s.detectedAcName == null) {
                o.addProperty("detected_ac", "detected_via_channel");
            }
        }

        // Behavior-based fingerprint
        // Grim: setback aggressive + entity status 32+ + no setback delay
        // Matrix: setback + 1 lần per check + không dùng custom channel
        // Vulcan: flag only, hiếm setback, dùng custom channel
        // Spartan: check scaffold heavily
        String behaviorFingerprint = detectBehaviorFingerprint(s);
        o.addProperty("behavior_fingerprint", behaviorFingerprint);

        // EntityStatus 32+ hits (AC signal)
        o.addProperty("entity_status_32_hits", s.acEntityStatusHits.get());

        // Advice
        o.add("bypass_advice", buildAcBypassAdvice(s));
        return o;
    }

    private String detectBehaviorFingerprint(ClientSession s) {
        int setbacks    = s.setbackCount.get();
        int entityStatus = s.acEntityStatusHits.get();
        int scaffolds   = (int) s.scaffoldCount.get();
        boolean hasChannels = !s.acChannelFingerprints.isEmpty();

        if (s.detectedAcName != null) {
            return s.detectedAcName + " (kick-confirmed)";
        }

        // Grim signature: setback aggressive, entityStatus 32+, channel grim
        if (entityStatus > 5 && setbacks > 3 && hasChannels) {
            return "LIKELY_GRIM — entityStatus=" + entityStatus + " setbacks=" + setbacks + " channels=yes";
        }
        // Vulcan signature: setback=0, scaffold flagged, custom channel
        if (setbacks == 0 && scaffolds > 0 && hasChannels) {
            return "LIKELY_VULCAN — no setback, scaffold flagged, channels=yes";
        }
        // Spartan signature: scaffold flagged heavily
        if (scaffolds > 20) {
            return "LIKELY_SPARTAN — scaffold flags=" + scaffolds;
        }
        // Matrix: moderate setback
        if (setbacks > 0 && setbacks < 5 && entityStatus < 3) {
            return "POSSIBLY_MATRIX — setbacks=" + setbacks + " entityStatus=" + entityStatus;
        }
        // Không đủ data
        return "INSUFFICIENT_DATA — cần bị kick hoặc dùng lâu hơn";
    }

    private JsonObject buildAcBypassAdvice(ClientSession s) {
        JsonObject advice = new JsonObject();
        String ac = s.detectedAcName;
        if (ac == null) ac = "Unknown";

        switch (ac) {
            case "Grim" -> {
                advice.addProperty("movement",
                    "Grim dùng prediction engine — cần simulate vanilla physics chính xác. " +
                    "Speed bypass: sử dụng sprint reset (tắt sprint 1 tick mỗi ~5 ticks). " +
                    "Setback: Grim setback aggressively — không bypass speed > 0.4 bpt liên tục.");
                advice.addProperty("rotation",
                    "Grim GCD check v2 — GCD phải >= 100 mdeg. " +
                    "Smooth aim bypass: simulate sensitivity rounding (nhân yaw/pitch với sensitivity factor).");
                advice.addProperty("velocity",
                    "Grim check velocity accept window nghiêm ngặt. " +
                    "Bypass: accept velocity trong 100-300ms sau khi nhận packet.");
                advice.addProperty("scaffold",
                    "Grim check tower/scaffold — không build > 1 block per tick. Delay 50ms per block.");
                advice.addProperty("known_holes",
                    "Phase bypass qua door/trapdoor vẫn hoạt động trên Grim 2.3.x. " +
                    "Timer check có tolerance ~2ms — không dùng timer < 0.98.");
            }
            case "Matrix" -> {
                advice.addProperty("movement",
                    "Matrix check hDist và vDist riêng. " +
                    "Speed: cap < 0.45 bpt, không sprint liên tục > 3s. " +
                    "Fly: Matrix check airTicks — phải chạm đất mỗi ~20 ticks nếu dùng glide.");
                advice.addProperty("rotation",
                    "Matrix không check GCD. Smooth aim tốt với bất kỳ GCD nào. " +
                    "Snap check: đừng rotate > 90° trong 50ms.");
                advice.addProperty("combat",
                    "Matrix check attack timing — min 100ms giữa 2 attack. " +
                    "Swing packet phải có trước attack packet.");
                advice.addProperty("known_holes",
                    "Matrix combat check có false negative khi ping > 150ms. " +
                    "Velocity bypass: Matrix tolerance cao hơn Grim — ratio < 0.5 thường không flag.");
            }
            case "Vulcan" -> {
                advice.addProperty("movement",
                    "Vulcan flag-only (không setback). " +
                    "Speed: Vulcan dùng average speed check — có thể burst > 0.6 bpt ngắn rồi dừng. " +
                    "Timer: Vulcan check timer kỹ — không dùng timer.");
                advice.addProperty("rotation",
                    "Vulcan rotation check strict — smooth aim với GCD > 150 mdeg. " +
                    "Instant aim: Vulcan flag snap > 60° trong 1 tick.");
                advice.addProperty("known_holes",
                    "Vulcan không setback → có thể phase tốt hơn. " +
                    "Scaffold: Vulcan falsepositive cao khi scaffold nhanh — thử với delay 30ms.");
            }
            default -> {
                advice.addProperty("movement",
                    "Chưa xác định AC — dùng conservative bypass: speed < 0.4 bpt, " +
                    "accept velocity, không timer, smooth aim GCD > 150 mdeg.");
                advice.addProperty("rotation", "GCD > 150 mdeg, snap < 45° per tick.");
                advice.addProperty("velocity", "Accept velocity đầy đủ, window 100-300ms.");
            }
        }
        return advice;
    }

    // ── V9: Anti-xray block ────────────────────────────────────────────────────
    private JsonObject buildAntiXray(ClientSession s) {
        JsonObject o = new JsonObject();
        o.addProperty("reveal_count",        s.antiXrayRevealCount.get());
        o.addProperty("proximity_reveals",   s.antiXrayProximityCount.get());
        o.addProperty("burst_events",        s.antiXrayBurstCount.get());
        o.addProperty("engine1_confirmed",   s.antiXrayEngine1Confirmed.get());

        // Determine engine type
        String engine;
        String xrayAdvice;
        if (s.antiXrayEngine1Confirmed.get() || s.antiXrayRevealCount.get() > 5) {
            engine = "ENGINE_1_PROORE — server gửi fake blocks (stone/deepslate), reveal khi gần";
            // Tính safe distance từ reveal distances
            List<Double> dists = s.xrayRevealDistances.snapshot();
            if (!dists.isEmpty()) {
                double avgRevealDist = dists.stream().mapToDouble(d->d).average().orElse(0);
                double minRevealDist = dists.stream().mapToDouble(d->d).min().orElse(0);
                o.addProperty("avg_reveal_dist_blocks", Math.round(avgRevealDist * 10.0) / 10.0);
                o.addProperty("min_reveal_dist_blocks", Math.round(minRevealDist * 10.0) / 10.0);
                // Safe distance: đứng ngoài reveal radius + 2 block buffer
                double safeXrayDist = minRevealDist + 2.0;
                o.addProperty("safe_xray_scan_dist_blocks", Math.round(safeXrayDist * 10.0) / 10.0);
                xrayAdvice = String.format(
                    "Engine1(ProOre): server reveal ore khi player cách ~%.1f blocks. " +
                    "Scan ở khoảng cách > %.1f blocks để detect ore position trước khi reveal. " +
                    "AntiXray bypass: đứng im ở Y=-50 đến Y=-60 để trigger reveal batch, " +
                    "sau đó đọc block state changes — ore positions lộ ra trong BlockUpdateS2C.",
                    avgRevealDist, safeXrayDist);
            } else {
                xrayAdvice = "Engine1(ProOre) confirmed nhưng chưa đủ distance samples. " +
                    "Di chuyển vào hầm mỏ sâu và đợi BlockUpdate packets.";
            }
        } else if (s.antiXrayRevealCount.get() == 0 && s.chunkDataCount.get() > 50) {
            // Nhiều chunk nhận nhưng không có reveal → Engine 2 hoặc không có anti-xray
            if (s.multiBlockUpdateCount.get() > s.chunkDataCount.get() * 2) {
                engine = "ENGINE_2_STRIPMINE — server không gửi ore, chỉ gửi khi view thẳng";
                xrayAdvice = "Engine2: server không gửi ore blocks ban đầu. " +
                    "Scan bằng cách nhìn trực tiếp vào wall (không phải floor/ceiling). " +
                    "Nếu có ore → sẽ nhận BlockUpdate sau khi nhìn vào. " +
                    "AntiXray bypass: dùng X-ray texture pack không hiệu quả. " +
                    "Cần đọc block state changes từ NetworkManager.";
            } else {
                engine = "NO_ANTIXRAY hoặc ENGINE_2 — không detect reveal events";
                xrayAdvice = "Server có thể không có anti-xray, hoặc dùng Engine 2. " +
                    "Thử X-ray texture pack hoặc xray module để confirm.";
            }
        } else {
            engine = "INSUFFICIENT_DATA — cần > 50 chunks và vào hầm mỏ sâu";
            xrayAdvice = "Vào hầm mỏ ở Y=-50 đến Y=-60, di chuyển xung quanh 2-3 phút.";
        }

        o.addProperty("detected_engine", engine);
        o.addProperty("bypass_advice",   xrayAdvice);
        o.addProperty("chunk_data_count",        s.chunkDataCount.get());
        o.addProperty("block_update_count",      s.blockUpdateCount.get());
        o.addProperty("multi_block_update_count",s.multiBlockUpdateCount.get());
        return o;
    }

    // ── V9: Block send rate block ──────────────────────────────────────────────
    private JsonObject buildBlockSend(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Long> samples = s.blockPpsSamples.snapshot();
        o.addProperty("chunk_data_pkt_count",         s.chunkDataCount.get());
        o.addProperty("block_update_pkt_count",       s.blockUpdateCount.get());
        o.addProperty("multi_block_update_pkt_count", s.multiBlockUpdateCount.get());
        o.addProperty("peak_block_pps",               peakBlockPps.get());

        if (!samples.isEmpty()) {
            long avgBpps = (long) samples.stream().mapToLong(l->l).average().orElse(0);
            long maxBpps = samples.stream().mapToLong(l->l).max().orElse(0);
            o.addProperty("avg_block_pps", avgBpps);
            o.addProperty("max_block_pps", maxBpps);
            o.addProperty("samples",       samples.size());

            // Nếu block pps tăng đột biến sau move → anti-xray reveal flush
            o.addProperty("analysis",
                maxBpps > avgBpps * 3
                ? "Burst pattern detected — anti-xray là likely (block pps spike " + maxBpps + "x avg " + avgBpps + ")"
                : "Uniform block send rate — no obvious anti-xray burst");
        }
        // Rate thông thường: 1-5 block updates/s = bình thường (cây, piston, redstone)
        // 20+ block updates/s = anti-xray reveal flush hoặc heavy redstone
        o.addProperty("note",
            "Normal rate: 1-5 bpps. Anti-xray reveal burst: 20-100+ bpps after movement.");
        return o;
    }

    // ── V9: Patch probe block ──────────────────────────────────────────────────
    // Tóm tắt những gì server đang patch và lỗ hổng còn lại
    private JsonObject buildPatchProbe(ClientSession s) {
        JsonObject o = new JsonObject();
        JsonArray patched   = new JsonArray();
        JsonArray holes     = new JsonArray();
        JsonArray uncertain = new JsonArray();

        // SPEED
        List<Double> flaggedSpeeds = s.flaggedSpeeds.snapshot();
        if (!flaggedSpeeds.isEmpty()) {
            patched.add("SPEED — server check hDist, threshold ~" +
                String.format("%.3f", flaggedSpeeds.stream().mapToDouble(d->d).min().orElse(0.5)) + " bpt");
            double safeCap = flaggedSpeeds.stream().mapToDouble(d->d).min().orElse(0.5) - 0.03;
            holes.add("SPEED_BELOW_" + String.format("%.3f", safeCap) +
                " bpt — dưới ngưỡng flag, không bị detect");
        } else {
            uncertain.add("SPEED — chưa đủ data (chưa bị flag speed)");
        }

        // VELOCITY BYPASS
        if (s.velocityBypassCount.get() > 0) {
            holes.add("VELOCITY_BYPASS — server không verify velocity response đầy đủ (" +
                s.velocityBypassCount.get() + " bypass instances detected)");
        } else {
            patched.add("VELOCITY — server kiểm tra velocity accept (không detect bypass)");
        }

        // SETBACK / RUBBER-BAND
        if (s.setbackCount.get() == 0 && s.moveCount.get() > 100) {
            holes.add("NO_SETBACK — server không rubber-band, chỉ flag. " +
                "Flag-only AC: có thể cheat lâu hơn trước khi bị kick");
        } else if (s.setbackCount.get() > 0) {
            patched.add("SETBACK — server rubber-band (" + s.setbackCount.get() + " setbacks)");
        }

        // TELEPORT BYPASS
        if (s.teleportBypassCount.get() > 0) {
            holes.add("TELEPORT_CONFIRM_BYPASS — " + s.teleportBypassCount.get() +
                " mismatched TeleportConfirm không bị kick. Server không verify TP ID.");
        } else {
            patched.add("TELEPORT — server verify TeleportConfirm ID");
        }

        // GCD ROTATION
        List<Integer> gcdSamples = s.gcdYawSamples.snapshot();
        if (!gcdSamples.isEmpty()) {
            int gcd = listGcd(gcdSamples);
            if (gcd > 100) {
                holes.add("GCD_ROTATION — GCD normal (" + gcd + " mdeg). " +
                    "Server check GCD nhưng rotation của player pass. Smooth aim safe.");
            } else if (gcd < 50) {
                patched.add("GCD_ROTATION — Server GCD check kỹ, GCD hiện tại " + gcd + " mdeg quá thấp");
                holes.add("GCD_FIX — tăng GCD lên > 150 mdeg bằng cách simulate sensitivity rounding");
            }
        }

        // SCAFFOLD
        if (s.scaffoldCount.get() > 10) {
            patched.add("SCAFFOLD — server detect scaffold (count=" + s.scaffoldCount.get() + ")");
            holes.add("SCAFFOLD_WITH_DELAY — scaffold với delay 30-50ms/block thường qua được");
        }

        // ANTI-XRAY
        if (s.antiXrayRevealCount.get() > 5) {
            patched.add("XRAY — server có anti-xray Engine 1 (ProOre)");
            holes.add("XRAY_TIMING_ATTACK — đọc BlockUpdateS2C packet TRƯỚC khi block render. " +
                "Block position lộ ra trong packet ngay cả khi render fake — " +
                "RaidBaseModule sẽ dùng packet-level xray không phụ thuộc render.");
        } else if (s.antiXrayRevealCount.get() == 0 && s.chunkDataCount.get() > 30) {
            uncertain.add("XRAY — không detect Engine 1. Có thể Engine 2 hoặc không có anti-xray.");
        }

        // KILL AURA
        List<Long> attackDeltas = s.attackDeltas.snapshot();
        if (!attackDeltas.isEmpty()) {
            long minAtk = attackDeltas.stream().mapToLong(l->l).min().orElse(100);
            if (s.flagCount.get() > 0) { // có KILL_AURA flags
                patched.add("KILL_AURA — server check attack timing (min safe ~" + (minAtk + 10) + "ms)");
                holes.add("KILL_AURA_" + (minAtk + 10) + "MS_DELAY — dưới ngưỡng flag");
            }
        }

        // TIMER
        if (s.flagLog.snapshot().stream().anyMatch(l -> l.contains("TIMER"))) {
            patched.add("TIMER — server check packet rate (< 30ms/packet bị flag)");
        } else {
            uncertain.add("TIMER — chưa test (chưa dùng timer)");
        }

        // BLINK
        if (s.flagLog.snapshot().stream().anyMatch(l -> l.contains("BLINK"))) {
            patched.add("BLINK — server detect lag blinks");
        } else {
            holes.add("BLINK_UNTESTED — chưa test blink bypass");
        }

        o.add("patched_checks", patched);
        o.add("known_holes",    holes);
        o.add("uncertain",      uncertain);
        o.addProperty("confidence",
            s.moveCount.get() > 500 && s.flagCount.get() > 5 ? "HIGH" :
            s.moveCount.get() > 100 ? "MEDIUM" : "LOW — cần thêm thời gian thu thập");
        return o;
    }

    // ── Existing report helpers ───────────────────────────────────────────────
    private JsonObject buildPing(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Long> arr = s.pingSamples.snapshot();
        if (arr.isEmpty()) return o;
        o.addProperty("min_ms",  arr.stream().mapToLong(l->l).min().orElse(0));
        o.addProperty("max_ms",  arr.stream().mapToLong(l->l).max().orElse(0));
        o.addProperty("avg_ms",  (long) arr.stream().mapToLong(l->l).average().orElse(0));
        o.addProperty("samples", arr.size());
        return o;
    }

    private JsonObject buildSpeed(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Double> all     = s.speedSamples.snapshot();
        List<Double> flagged = s.flaggedSpeeds.snapshot();
        if (!all.isEmpty()) {
            o.addProperty("max_seen",    all.stream().mapToDouble(d->d).max().orElse(0));
            o.addProperty("avg_all",     all.stream().mapToDouble(d->d).average().orElse(0));
            o.addProperty("avg_recent_60",
                s.recentSpeeds.snapshot().stream().mapToDouble(d->d).average().orElse(0));
        }
        if (!flagged.isEmpty()) {
            double minFlagged = flagged.stream().mapToDouble(d->d).min().orElse(0);
            double safeCap    = Math.max(0.1, minFlagged - 0.03);
            o.addProperty("min_flagged",   minFlagged);
            o.addProperty("safe_cap",      safeCap);
            o.addProperty("bypass_advice", "Set speed < " +
                String.format("%.4f", safeCap) + " bpt");
        } else {
            o.addProperty("safe_cap", 0.5);
            o.addProperty("bypass_advice",
                "No SPEED flags — lower speed-threshold setting and retry");
        }
        o.addProperty("flag_threshold", speedThreshold.get());
        return o;
    }

    private JsonObject buildTiming(ClientSession.BoundedDeque<Long> deque, String label) {
        JsonObject o = new JsonObject();
        List<Long> arr = deque.snapshot();
        if (arr.isEmpty()) return o;
        long min  = arr.stream().mapToLong(l->l).min().orElse(0);
        long avg  = (long) arr.stream().mapToLong(l->l).average().orElse(0);
        long safe = min + 5;
        o.addProperty("min_flagged_ms", min);
        o.addProperty("avg_ms",         avg);
        o.addProperty("safe_delay_ms",  safe);
        o.addProperty("samples",        arr.size());
        o.addProperty("confidence",     arr.size()>=10?"high":arr.size()>=3?"medium":"low");
        o.addProperty("bypass_advice",  "Set " + label + " >= " + safe + "ms");
        return o;
    }

    private JsonObject buildKbTiming(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Long> arr = s.kbAcceptWindows.snapshot();
        if (arr.isEmpty()) {
            o.addProperty("note","Chưa đủ KB samples — cần bị đánh KB ít nhất 5 lần");
            return o;
        }
        long min = arr.stream().mapToLong(l->l).min().orElse(0);
        long max = arr.stream().mapToLong(l->l).max().orElse(0);
        long avg = (long) arr.stream().mapToLong(l->l).average().orElse(0);
        long med = arr.stream().sorted().collect(java.util.stream.Collectors.toList())
                      .get(arr.size()/2);
        o.addProperty("min_accept_window_ms",    min);
        o.addProperty("max_accept_window_ms",    max);
        o.addProperty("avg_accept_window_ms",    avg);
        o.addProperty("median_accept_window_ms", med);
        o.addProperty("samples",                 arr.size());
        long safeWindow = med + 20;
        o.addProperty("safe_accept_window_ms", safeWindow);
        o.addProperty("confidence", arr.size() >= 10 ? "high" : arr.size() >= 3 ? "medium" : "low");
        o.addProperty("bypass_advice",
            "Set velocity accept window <= " + safeWindow + "ms after receiving KB packet");
        return o;
    }

    private JsonObject buildSetback(ClientSession s) {
        JsonObject o = new JsonObject();
        o.addProperty("setback_count", s.setbackCount.get());
        List<Long> intervals = s.setbackIntervals.snapshot();
        if (!intervals.isEmpty()) {
            long minInterval = intervals.stream().mapToLong(l->l).min().orElse(0);
            long avgInterval = (long) intervals.stream().mapToLong(l->l).average().orElse(0);
            o.addProperty("min_interval_ms", minInterval);
            o.addProperty("avg_interval_ms", avgInterval);
            o.addProperty("samples",         intervals.size());
            if (s.setbackCount.get() == 0) {
                o.addProperty("ac_behavior","NO_SETBACK — server flags only");
                o.addProperty("bypass_advice","Safe: server does not setback on flags");
            } else if (minInterval < 100) {
                o.addProperty("ac_behavior","AGGRESSIVE_SETBACK");
                o.addProperty("bypass_advice","Setback every ~"+avgInterval+"ms — keep below threshold");
            } else {
                o.addProperty("ac_behavior","NORMAL_SETBACK");
                o.addProperty("bypass_advice","Setback every ~"+avgInterval+"ms");
            }
        } else if (s.setbackCount.get() == 0) {
            o.addProperty("ac_behavior","NO_SETBACK");
            o.addProperty("bypass_advice","Server does not setback — flag-only or lenient AC");
        }
        return o;
    }

    private JsonObject buildGcd(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Integer> yawSamples   = s.gcdYawSamples.snapshot();
        List<Integer> pitchSamples = s.gcdPitchSamples.snapshot();
        if (yawSamples.isEmpty()) {
            o.addProperty("note","Chưa đủ rotation samples");
            return o;
        }
        int gcdYaw   = listGcd(yawSamples);
        int gcdPitch = pitchSamples.isEmpty() ? 0 : listGcd(pitchSamples);
        o.addProperty("gcd_yaw_mdeg",   gcdYaw);
        o.addProperty("gcd_pitch_mdeg", gcdPitch);
        o.addProperty("gcd_yaw_deg",    gcdYaw / 1000.0);
        o.addProperty("gcd_pitch_deg",  gcdPitch / 1000.0);
        o.addProperty("yaw_samples",    yawSamples.size());
        o.addProperty("pitch_samples",  pitchSamples.size());

        String fingerprint;
        if (gcdYaw <= 1) {
            fingerprint = "PERFECT_PRECISION — aimbot/macro";
            o.addProperty("bypass_advice","Add GCD noise >= 150 mdeg");
        } else if (gcdYaw < 100) {
            fingerprint = "LOW_GCD — suspicious";
            o.addProperty("bypass_advice","GCD low (" + gcdYaw + " mdeg) — increase rotation step");
        } else if (gcdYaw < 500) {
            fingerprint = "NORMAL_VANILLA — safe";
            o.addProperty("bypass_advice","GCD normal (" + gcdYaw + " mdeg) — passes GCD check");
        } else {
            fingerprint = "HIGH_GCD — large steps";
            o.addProperty("bypass_advice","GCD high (" + gcdYaw + " mdeg) — lower rotation speed");
        }
        o.addProperty("fingerprint", fingerprint);
        return o;
    }

    private JsonObject buildSummary(JsonObject r, ClientSession s) {
        JsonObject sum = new JsonObject();
        StringBuilder advice = new StringBuilder();

        JsonObject spd = r.getAsJsonObject("speed");
        if (spd.has("safe_cap"))
            advice.append("SPEED: cap=")
                  .append(String.format("%.4f", spd.get("safe_cap").getAsDouble()))
                  .append(" bpt | ");
        appendTiming(advice, r.getAsJsonObject("dig_timing"),    "MINE");
        appendTiming(advice, r.getAsJsonObject("place_timing"),  "PLACE");
        appendTiming(advice, r.getAsJsonObject("attack_timing"), "ATTACK");
        JsonObject ping = r.getAsJsonObject("ping");
        if (ping.has("avg_ms"))
            advice.append("PING avg=").append(ping.get("avg_ms").getAsLong()).append("ms");

        JsonObject kb = r.getAsJsonObject("kb_timing");
        if (kb.has("safe_accept_window_ms"))
            advice.append(" | KB_WINDOW: ").append(kb.get("safe_accept_window_ms").getAsLong()).append("ms");
        JsonObject setback = r.getAsJsonObject("setback");
        if (setback.has("ac_behavior"))
            advice.append(" | SETBACK: ").append(setback.get("ac_behavior").getAsString());
        JsonObject gcd = r.getAsJsonObject("rotation_gcd");
        if (gcd.has("gcd_yaw_mdeg"))
            advice.append(" | GCD_YAW: ").append(gcd.get("gcd_yaw_mdeg").getAsInt()).append("mdeg");

        // V9 additions
        JsonObject ac = r.getAsJsonObject("ac_fingerprint");
        if (ac.has("detected_ac"))
            advice.append(" | AC: ").append(ac.get("detected_ac").getAsString());
        JsonObject xray = r.getAsJsonObject("anti_xray");
        if (xray.has("detected_engine"))
            advice.append(" | XRAY: ").append(xray.get("detected_engine").getAsString());

        sum.addProperty("module_config",             advice.toString());
        sum.addProperty("unknown_ac_packets",        s.unknownPackets.size());
        sum.addProperty("velocity_bypass_possible",  s.velocityBypassCount.get() > 0);
        sum.addProperty("teleport_bypass_seen",      s.teleportBypassCount.get() > 0);
        sum.addProperty("aimbot_snap_count",         s.snapAimCount.get());
        sum.addProperty("scaffold_detected",         s.scaffoldCount.get() > 10);
        sum.addProperty("setback_behavior",          s.setbackCount.get() == 0
            ? "NO_SETBACK" : "SETBACKS=" + s.setbackCount.get());
        sum.addProperty("detected_ac",               s.detectedAcName != null ? s.detectedAcName : "unknown");
        sum.addProperty("anti_xray_engine",          s.antiXrayEngine1Confirmed.get() ? "ENGINE_1" : "unknown");
        sum.addProperty("gcd_yaw_mdeg",              s.gcdYawSamples.isEmpty() ? -1
            : listGcd(s.gcdYawSamples.snapshot()));
        sum.addProperty("ready",
            (System.currentTimeMillis() - s.sessionStartMs) > 30_000
            && s.totalPackets.get() > 200
            && s.flagCount.get() > 0);
        return sum;
    }

    private void appendTiming(StringBuilder sb, JsonObject block, String label) {
        if (block != null && block.has("safe_delay_ms"))
            sb.append(label).append(": delay=")
              .append(block.get("safe_delay_ms").getAsLong()).append("ms | ");
    }

    private String buildTxt(ClientSession s, JsonObject sum) {
        return "=== ACCollector V9 Meteor ===\n"
            + "Player:               " + s.playerName + "\n"
            + "Session:              " + s.sessionStartStr + "\n"
            + "Total Packets:        " + s.totalPackets.get() + "\n"
            + "Total Flags:          " + s.flagCount.get() + "\n"
            + "Peak PPS:             " + s.peakPps() + "\n"
            + "Velocity Bypass:      " + s.velocityBypassCount.get() + "\n"
            + "Teleport Bypass:      " + s.teleportBypassCount.get() + "\n"
            + "Snap-Aim Count:       " + s.snapAimCount.get() + "\n"
            + "Scaffold Count:       " + s.scaffoldCount.get() + "\n"
            + "Setback Count:        " + s.setbackCount.get() + "\n"
            + "Detected AC:          " + (s.detectedAcName != null ? s.detectedAcName : "unknown") + "\n"
            + "Anti-Xray Engine:     " + (s.antiXrayEngine1Confirmed.get() ? "Engine1 (ProOre)" : "unknown") + "\n"
            + "Xray Reveal Count:    " + s.antiXrayRevealCount.get() + "\n"
            + "Unknown AC Packets:   " + s.unknownPackets.size() + "\n"
            + "\nModule Config:\n  " + sum.get("module_config").getAsString() + "\n"
            + "\nReady for module build: " + sum.get("ready").getAsBoolean() + "\n";
    }
}
