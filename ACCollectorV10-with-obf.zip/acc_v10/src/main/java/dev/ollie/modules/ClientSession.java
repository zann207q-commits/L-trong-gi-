package dev.ollie.modules;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * V9 ClientSession — thêm state cho:
 *   AC_FINGERPRINT  — detectedAcName, detectedAcNotes, acChannelFingerprints, acEntityStatusHits
 *   ANTI_XRAY       — antiXrayRevealCount, antiXrayProximityCount, antiXrayBurstCount,
 *                     antiXrayEngine1Confirmed, xrayRevealDistances
 *   BLOCK_SEND      — chunkDataCount, blockUpdateCount, multiBlockUpdateCount,
 *                     multiBlockBatchSizes, blockPpsSamples
 *   KB_TIMING       — pendingKbReceivedMs, pendingKbMag, kbAcceptWindows  (retained from V8.2)
 *   SETBACK_TRACK   — setbackCount, lastSetbackMs, setbackIntervals        (retained)
 *   GCD_ROTATION    — gcdYawSamples, gcdPitchSamples                       (retained)
 */
public class ClientSession {

    // ── Bounds ────────────────────────────────────────────────────────────────
    public static final int MAX_SAMPLES  = 8_000;
    public static final int MAX_FLAG_LOG = 15_000;

    // ── Identity ──────────────────────────────────────────────────────────────
    public final String playerName;
    public final Path   sessionDir;
    public final long   sessionStartMs;
    public final String sessionStartStr;

    private static final DateTimeFormatter FILE_FMT =
        DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
    private static final DateTimeFormatter TS_FMT =
        DateTimeFormatter.ofPattern("HH:mm:ss.SSS");

    // ── Counters ──────────────────────────────────────────────────────────────
    public final AtomicLong totalPackets        = new AtomicLong();
    public final AtomicLong digCount            = new AtomicLong();
    public final AtomicLong attackCount         = new AtomicLong();
    public final AtomicLong placeCount          = new AtomicLong();
    public final AtomicLong flagCount           = new AtomicLong();
    public final AtomicLong rawPktCount         = new AtomicLong();
    public final AtomicLong velocityBypassCount = new AtomicLong();
    public final AtomicLong moveCount           = new AtomicLong();
    public final AtomicLong swingCount          = new AtomicLong();
    public final AtomicLong scaffoldCount       = new AtomicLong();

    // Peak PPS — atomic window swap
    private final AtomicLong peakPpsValue = new AtomicLong();
    private final AtomicLong windowStart  = new AtomicLong(System.currentTimeMillis());
    private final LongAdder  windowCount  = new LongAdder();

    // ── Movement state ────────────────────────────────────────────────────────
    public volatile double lastX         = Double.MIN_VALUE;
    public volatile double lastY         = Double.MIN_VALUE;
    public volatile double lastZ         = Double.MIN_VALUE;
    public volatile float  lastYaw       = 0;
    public volatile float  lastPitch     = 0;
    public final    AtomicInteger airTicks = new AtomicInteger();
    public volatile double maxSpeedSeen  = 0;
    public volatile double maxDeltaYSeen = 0;
    public final BoundedDeque<Double> recentSpeeds = new BoundedDeque<>(60);

    // ── Timing state ──────────────────────────────────────────────────────────
    public volatile long lastDigTime     = 0;
    public volatile long lastPlaceTime   = 0;
    public volatile long lastAttackTime  = 0;
    public volatile long lastMoveTime    = 0;
    public volatile long lastSwingTime   = 0;
    public volatile long lastSlotTime    = 0;
    public volatile long lastItemUseTime = 0;

    // ── Rotation state ────────────────────────────────────────────────────────
    public volatile long  lastRotTime  = 0;
    public volatile float lastRotYaw   = 0;
    public volatile float lastRotPitch = 0;
    public final AtomicInteger snapAimCount = new AtomicInteger();

    // ── Ping ──────────────────────────────────────────────────────────────────
    public volatile long lastKeepAliveSentMs = 0;
    public volatile long lastKeepAliveId     = 0;
    public final BoundedDeque<Long> pingSamples = new BoundedDeque<>(200);

    // ── Velocity bypass ───────────────────────────────────────────────────────
    public volatile PendingVelocity pendingVelocity = null;

    // ── Teleport tracking ─────────────────────────────────────────────────────
    public volatile int  pendingTeleportId     = -1;
    public volatile long pendingTeleportSentMs = 0;
    public final AtomicInteger teleportBypassCount = new AtomicInteger();

    // ── KB timing ─────────────────────────────────────────────────────────────
    public volatile long   pendingKbReceivedMs = 0;
    public volatile double pendingKbMag        = 0;
    public final BoundedDeque<Long> kbAcceptWindows = new BoundedDeque<>(MAX_SAMPLES);

    // ── Setback tracking ──────────────────────────────────────────────────────
    public final AtomicInteger setbackCount = new AtomicInteger();
    public volatile long lastSetbackMs = 0;
    public final BoundedDeque<Long> setbackIntervals = new BoundedDeque<>(MAX_SAMPLES);

    // ── GCD rotation samples ──────────────────────────────────────────────────
    public final BoundedDeque<Integer> gcdYawSamples   = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Integer> gcdPitchSamples = new BoundedDeque<>(MAX_SAMPLES);

    // ── Scaffold state ────────────────────────────────────────────────────────
    public volatile long lastScaffoldMs = 0;

    // ── Sample buffers ────────────────────────────────────────────────────────
    public final BoundedDeque<Double> speedSamples    = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Double> flaggedSpeeds   = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Long>   digDeltas       = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Long>   placeDeltas     = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Long>   attackDeltas    = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Long>   itemUseDeltas   = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<String> flagLog         = new BoundedDeque<>(MAX_FLAG_LOG);

    // ── Unknown packet fingerprints ───────────────────────────────────────────
    public final ConcurrentHashMap<String, PktStat> unknownPackets = new ConcurrentHashMap<>();

    // ── V9: AC Fingerprint ────────────────────────────────────────────────────
    /** Tên AC detect được từ kick message hoặc channel (Grim, Matrix, Vulcan...) */
    public volatile String detectedAcName  = null;
    public volatile String detectedAcNotes = null;
    /** Set custom channels đã thấy từ S→C CustomPayload */
    public final Set<String> acChannelFingerprints = ConcurrentHashMap.newKeySet();
    /** Số lần nhận EntityStatus >= 32 (AC signal packets) */
    public final AtomicInteger acEntityStatusHits = new AtomicInteger();

    // ── V9: Anti-Xray ─────────────────────────────────────────────────────────
    /** Số lần block update từ stone/air → ore (Engine 1 reveal) */
    public final AtomicInteger antiXrayRevealCount    = new AtomicInteger();
    /** Số lần block reveal xảy ra ngay sau di chuyển (proximity trigger) */
    public final AtomicInteger antiXrayProximityCount = new AtomicInteger();
    /** Số lần nhận MultiBlockUpdate lớn sau di chuyển (burst reveal) */
    public final AtomicInteger antiXrayBurstCount     = new AtomicInteger();
    /** True nếu Engine 1 (ProOre) xác nhận bằng stone→ore transition */
    public final AtomicBoolean antiXrayEngine1Confirmed = new AtomicBoolean(false);
    /** Khoảng cách player đến ore khi reveal (để estimate reveal radius) */
    public final BoundedDeque<Double> xrayRevealDistances = new BoundedDeque<>(500);

    // ── V9: Block send tracking ───────────────────────────────────────────────
    /** Số lượng ChunkDataS2CPacket nhận được */
    public final AtomicLong chunkDataCount         = new AtomicLong();
    /** Số lượng BlockUpdateS2CPacket nhận được */
    public final AtomicLong blockUpdateCount        = new AtomicLong();
    /** Số lượng ChunkDeltaUpdateS2CPacket nhận được */
    public final AtomicLong multiBlockUpdateCount   = new AtomicLong();
    /** Kích thước của từng batch multi-block update (số blocks trong 1 packet) */
    public final BoundedDeque<Integer> multiBlockBatchSizes = new BoundedDeque<>(2000);
    /** Block packets per second samples (1s window) */
    public final BoundedDeque<Long> blockPpsSamples = new BoundedDeque<>(3600); // 1h data

    // ── Writer ────────────────────────────────────────────────────────────────
    private volatile BufferedWriter writer;
    private volatile boolean        writerDead = false;
    private final Object            writeLock  = new Object();

    // ── Constructor ───────────────────────────────────────────────────────────
    public ClientSession(String playerName, Path exportRoot) {
        this.playerName      = playerName;
        this.sessionStartMs  = System.currentTimeMillis();
        this.sessionStartStr = FILE_FMT.format(LocalDateTime.now());
        this.sessionDir      = exportRoot.resolve(sanitize(playerName) + "_" + sessionStartStr);

        try {
            Files.createDirectories(sessionDir);
            Path logFile = sessionDir.resolve("bypass.log");
            this.writer  = Files.newBufferedWriter(logFile,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            writerDead = true;
            e.printStackTrace();
        }
        log("INIT", "ACCollector V9 session opened — player=" + playerName);
    }

    // ── Logging ───────────────────────────────────────────────────────────────
    public void log(String tag, String data) {
        if (writerDead) return;
        synchronized (writeLock) {
            if (writer == null) return;
            try {
                writer.write("[" + TS_FMT.format(LocalDateTime.now())
                    + "][" + tag + "] " + data);
                writer.newLine();
            } catch (IOException e) {
                writerDead = true;
            }
        }
    }

    public void flag(String type, String detail) {
        String line = "[" + TS_FMT.format(LocalDateTime.now())
            + "][FLAG:" + type + "] " + detail;
        flagLog.offer(line);
        flagCount.incrementAndGet();
        log("FLAG", type + " | " + detail);
        synchronized (writeLock) {
            try { if (writer != null) writer.flush(); } catch (IOException ignored) {}
        }
    }

    // ── PPS tracking ──────────────────────────────────────────────────────────
    public long tickRate() {
        windowCount.increment();
        long now = System.currentTimeMillis();
        long ws  = windowStart.get();
        long elapsed = now - ws;
        if (elapsed >= 1000L && windowStart.compareAndSet(ws, now)) {
            long sum = windowCount.sumThenReset();
            long pps = sum * 1000L / Math.max(1L, elapsed);
            long cur;
            do { cur = peakPpsValue.get(); }
            while (pps > cur && !peakPpsValue.compareAndSet(cur, pps));
            return pps;
        }
        return 0L;
    }

    public long peakPps() { return peakPpsValue.get(); }

    // ── Flush / close ─────────────────────────────────────────────────────────
    public void flush() {
        if (writerDead) return;
        synchronized (writeLock) {
            try { if (writer != null) writer.flush(); } catch (IOException ignored) {}
        }
    }

    public void close() {
        synchronized (writeLock) {
            try {
                if (writer != null) { writer.flush(); writer.close(); }
            } catch (IOException ignored) {
            } finally { writer = null; }
        }
    }

    // ── Sanitize ──────────────────────────────────────────────────────────────
    public static String sanitize(String s) {
        if (s == null) return "unknown";
        return s.replaceAll("[/\\\\:*?\"<>|]", "_")
                .replace("\n", "").replace("\r", "").replace("\t", "");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Inner types
    // ══════════════════════════════════════════════════════════════════════════

    /** Lock-free bounded FIFO — drops oldest when at cap. */
    public static final class BoundedDeque<T> {
        private final int cap;
        private final ConcurrentLinkedDeque<T> q = new ConcurrentLinkedDeque<>();
        private final AtomicInteger sz = new AtomicInteger();

        public BoundedDeque(int cap) { this.cap = cap; }

        public void offer(T val) {
            q.addLast(val);
            if (sz.incrementAndGet() > cap) {
                q.pollFirst();
                sz.decrementAndGet();
            }
        }

        public List<T> snapshot() { return new ArrayList<>(q); }
        public int     size()     { return sz.get(); }
        public boolean isEmpty()  { return sz.get() == 0; }
    }

    /** Pending velocity from server. */
    public record PendingVelocity(double vx, double vy, double vz, long receivedMs) {
        public double hMag() { return Math.sqrt(vx * vx + vz * vz); }
    }

    /** Per-type unknown packet stats. */
    public static final class PktStat {
        public final AtomicInteger count = new AtomicInteger();
        public final ConcurrentHashMap<Integer, AtomicInteger> sizeDist = new ConcurrentHashMap<>();

        public void record(int bytes) {
            count.incrementAndGet();
            sizeDist.computeIfAbsent(bytes, k -> new AtomicInteger()).incrementAndGet();
        }

        public int modalSize() {
            return sizeDist.entrySet().stream()
                .max(java.util.Comparator.comparingInt(e -> e.getValue().get()))
                .map(java.util.Map.Entry::getKey).orElse(0);
        }
    }
}
