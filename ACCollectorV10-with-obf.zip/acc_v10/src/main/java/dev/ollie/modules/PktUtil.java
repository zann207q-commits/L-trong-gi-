package dev.ollie.modules;

import io.netty.buffer.Unpooled;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.Packet;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Helper đọc dữ liệu packet theo KIỂU field (không theo tên) nên không phụ thuộc
 * tên method/field của từng bản Yarn / Minecraft — tránh lỗi "cannot find symbol".
 */
public final class PktUtil {
    private PktUtil() {}

    private static Method interactWriter;

    /** Field int đầu tiên (vd entityId, teleportId). */
    public static int firstInt(Object o, int def) {
        if (o == null) return def;
        for (Field f : o.getClass().getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers()) || f.getType() != int.class) continue;
            try { f.setAccessible(true); return f.getInt(o); } catch (Throwable ignored) {}
        }
        return def;
    }

    /** Field long đầu tiên (vd keepAlive id). */
    public static long firstLong(Object o, long def) {
        if (o == null) return def;
        for (Field f : o.getClass().getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers()) || f.getType() != long.class) continue;
            try { f.setAccessible(true); return f.getLong(o); } catch (Throwable ignored) {}
        }
        return def;
    }

    /** Tìm object kiểu `type` trong field của o, đi sâu tối đa 3 tầng. */
    public static <T> T find(Object o, Class<T> type) { return find(o, type, 0); }

    private static <T> T find(Object o, Class<T> type, int depth) {
        if (o == null || depth > 3) return null;
        for (Field f : o.getClass().getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) continue;
            try {
                f.setAccessible(true);
                Object v = f.get(o);
                if (v == null) continue;
                if (type.isInstance(v)) return type.cast(v);
                String n = v.getClass().getName();
                if (n.startsWith("net.minecraft.") && !(v instanceof Text)) {
                    T r = find(v, type, depth + 1);
                    if (r != null) return r;
                }
            } catch (Throwable ignored) {}
        }
        return null;
    }

    public static Vec3d vec(Object o) { return find(o, Vec3d.class); }

    public static String text(Object o) {
        Text t = find(o, Text.class);
        return t == null ? "unknown" : t.getString();
    }

    /**
     * Đọc {entityId, typeId} của PlayerInteractEntityC2SPacket bằng cách serialize packet.
     * Wire format: VarInt entityId, VarInt type (0=interact, 1=attack, 2=interact_at).
     * @return int[]{entityId, typeId} hoặc null nếu lỗi
     */
    public static int[] readInteract(Packet<?> pkt) {
        try {
            if (interactWriter == null) {
                for (Method m : pkt.getClass().getDeclaredMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (!Modifier.isStatic(m.getModifiers()) && p.length == 1
                            && p[0] == PacketByteBuf.class && m.getReturnType() == void.class) {
                        m.setAccessible(true);
                        interactWriter = m;
                        break;
                    }
                }
            }
            if (interactWriter == null) return null;
            PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
            interactWriter.invoke(pkt, buf);
            int id   = buf.readVarInt();
            int type = buf.readVarInt();
            return new int[]{id, type};
        } catch (Throwable t) {
            return null;
        }
    }
}
