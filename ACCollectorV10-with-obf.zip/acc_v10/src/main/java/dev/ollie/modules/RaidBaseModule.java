// Language: Java 21
// File: RaidBaseModule.java (V1 — standalone Meteor module)
// Runtime: Fabric 1.21.11 / Meteor 0.5.9-SNAPSHOT
//
// Module raid base tự động dựa trên dữ liệu từ ACCollector V9.
// Đọc snapshot.json từ session gần nhất, áp dụng bypass config đã thu thập:
//   • Speed cap tự động (không vượt ngưỡng flag của server)
//   • Velocity accept window (nhận KB đúng thời điểm)
//   • X-ray packet-level (đọc BlockUpdate S→C để detect ore dù anti-xray)
//   • Timer safe range (không flag timer check)
//   • Fly safe height + air tick limit
//   • Scaffold bypass delay (auto-calibrate từ place timing)
//   • GCD-safe rotation khi không muốn flag rotation check
//   • Setback handler (predict setback để không desync)
//
// CÁCH DÙNG:
//   1. Vào server, bật ACCollector ít nhất 2 phút, /pen để export
//   2. Bật RaidBaseModule → tự đọc config từ file mới nhất
//   3. Module tự set speed, velocity, timer, scaffold delay phù hợp
//   4. Dùng /raidbase reload để load lại config sau khi ACCollector export mới
//   5. /raidbase xray để bật packet-level xray (đọc BlockUpdate S→C)
//   6. /raidbase status để xem config hiện tại

package dev.ollie.modules;

import com.google.gson.*;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.*;

// V10: Y-reveal mapper + chunk section parser
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;

public class RaidBaseModule extends Module {

    // ── Settings ──────────────────────────────────────────────────────────────
    private final SettingGroup sg      = settings.getDefaultGroup();
    private final SettingGroup sgXray  = settings.createGroup("Packet X-Ray");
    private final SettingGroup sgMove  = settings.createGroup("Movement");
    private final SettingGroup sgCombat= settings.createGroup("Combat");

    // Core settings
    private final Setting<Boolean> autoLoadConfig = sg.add(
        new BoolSetting.Builder()
            .name("auto-load-config")
            .description("Tự đọc config từ ACCollector session mới nhất khi bật")
            .defaultValue(true).build()
    );
    private final Setting<Boolean> showStatus = sg.add(
        new BoolSetting.Builder()
            .name("show-status")
            .description("Hiện config đã load khi bật module")
            .defaultValue(true).build()
    );

    // Packet X-ray settings
    private final Setting<Boolean> packetXray = sgXray.add(
        new BoolSetting.Builder()
            .name("packet-xray")
            .description("Đọc BlockUpdate S→C để detect ore position (bypass anti-xray Engine 1)")
            .defaultValue(false).build()
    );
    private final Setting<Boolean> xrayLogToChat = sgXray.add(
        new BoolSetting.Builder()
            .name("xray-log-chat")
            .description("Log ore positions vào chat")
            .defaultValue(true).build()
    );
    private final Setting<Integer> xrayMinY = sgXray.add(
        new IntSetting.Builder()
            .name("xray-min-y")
            .description("Chỉ log ore ở Y <= giá trị này (diamond ở Y=-64 đến Y=16)")
            .defaultValue(16).min(-64).sliderMax(64).build()
    );
    private final Setting<Boolean> xrayDiamond = sgXray.add(
        new BoolSetting.Builder()
            .name("xray-diamond").description("Log diamond ore").defaultValue(true).build()
    );
    private final Setting<Boolean> xrayAncientDebris = sgXray.add(
        new BoolSetting.Builder()
            .name("xray-ancient-debris").description("Log ancient debris").defaultValue(true).build()
    );
    private final Setting<Boolean> xrayGold = sgXray.add(
        new BoolSetting.Builder()
            .name("xray-gold").description("Log gold ore").defaultValue(false).build()
    );
    private final Setting<Boolean> xrayIron = sgXray.add(
        new BoolSetting.Builder()
            .name("xray-iron").description("Log iron ore").defaultValue(false).build()
    );

    // ── Y-Reveal Mapper settings ──────────────────────────────────────────────
    private final SettingGroup sgYMapper = settings.createGroup("Y-Reveal Mapper");

    private final Setting<Boolean> yMapperEnabled = sgYMapper.add(new BoolSetting.Builder()
        .name("y-mapper-enabled")
        .description("Track BlockUpdate reveals theo chunk+Y để estimate độ sâu của base.")
        .defaultValue(true).build()
    );
    private final Setting<Double> yMapperMinConfidence = sgYMapper.add(new DoubleSetting.Builder()
        .name("min-confidence")
        .description("Chỉ hiện chunks có confidence >= giá trị này (0.0-1.0)")
        .defaultValue(0.4).min(0.0).sliderMax(1.0).build()
    );
    private final Setting<Boolean> yMapperChat = sgYMapper.add(new BoolSetting.Builder()
        .name("y-mapper-chat")
        .description("Log khi tìm được chunk có confidence cao")
        .defaultValue(true).build()
    );

    // ── Chunk Section Parser settings ─────────────────────────────────────────
    private final SettingGroup sgParser = settings.createGroup("Section Parser");

    private final Setting<Boolean> sectionParserEnabled = sgParser.add(new BoolSetting.Builder()
        .name("section-parser-enabled")
        .description("Scan ChunkData palette + block entities khi chunk load. Hoạt động ở mọi Y.")
        .defaultValue(true).build()
    );
    private final Setting<Integer> parserTickBudget = sgParser.add(new IntSetting.Builder()
        .name("parser-tick-budget")
        .description("Số chunks scan mỗi tick (cao hơn = nhanh hơn nhưng có thể lag)")
        .defaultValue(4).min(1).sliderMax(16).build()
    );
    private final Setting<Integer> parserMinBlockEntities = sgParser.add(new IntSetting.Builder()
        .name("min-block-entities")
        .description("Chỉ alert khi chunk có >= N block entities (chest, furnace...). 1 = mọi hit.")
        .defaultValue(1).min(1).sliderMax(10).build()
    );
    private final Setting<Boolean> parserChatAlert = sgParser.add(new BoolSetting.Builder()
        .name("parser-chat-alert")
        .description("Alert khi section parser tìm được block entities underground")
        .defaultValue(true).build()
    );

    // Movement settings — override nếu không có ACCollector data
    private final Setting<Double> manualSpeedCap = sgMove.add(
        new DoubleSetting.Builder()
            .name("manual-speed-cap")
            .description("Speed cap thủ công (bpt). Bị override bởi ACCollector data nếu có.")
            .defaultValue(0.45).min(0.1).sliderMax(1.0).build()
    );
    private final Setting<Boolean> velocityBypass = sgMove.add(
        new BoolSetting.Builder()
            .name("velocity-bypass")
            .description("Bypass velocity check (giảm KB nhận). Chỉ bật nếu ACCollector detect bypass hole.")
            .defaultValue(false).build()
    );
    private final Setting<Double> velocityMultiplier = sgMove.add(
        new DoubleSetting.Builder()
            .name("velocity-multiplier")
            .description("Hệ số nhân velocity (1.0 = full, 0.0 = no KB)")
            .defaultValue(0.8).min(0.0).sliderMax(1.0).build()
    );
    private final Setting<Boolean> scaffoldBypass = sgMove.add(
        new BoolSetting.Builder()
            .name("scaffold-bypass")
            .description("Thêm delay vào scaffold để bypass AC")
            .defaultValue(false).build()
    );
    private final Setting<Integer> scaffoldDelay = sgMove.add(
        new IntSetting.Builder()
            .name("scaffold-delay-ms")
            .description("Delay giữa 2 block đặt (ms). Auto-set từ ACCollector nếu có.")
            .defaultValue(50).min(0).sliderMax(200).build()
    );

    // Combat settings
    private final Setting<Boolean> attackDelay = sgCombat.add(
        new BoolSetting.Builder()
            .name("attack-delay")
            .description("Thêm delay vào attack để bypass kill aura check")
            .defaultValue(false).build()
    );
    private final Setting<Integer> attackDelayMs = sgCombat.add(
        new IntSetting.Builder()
            .name("attack-delay-ms")
            .description("Min delay giữa 2 attack (ms). Auto-set từ ACCollector nếu có.")
            .defaultValue(100).min(50).sliderMax(500).build()
    );

    // ── Loaded config state ───────────────────────────────────────────────────
    private volatile RaidConfig loadedConfig = null;

    // ── Packet-xray state ─────────────────────────────────────────────────────
    // Queue của ore positions nhận được qua packet (kể cả khi anti-xray Engine 1 che)
    private final ConcurrentLinkedQueue<OreFind> oreFinds = new ConcurrentLinkedQueue<>();
    // Track pending block updates (block đang chờ reveal)
    private final Map<BlockPos, Long> pendingReveal = new LinkedHashMap<>() {
        @Override protected boolean removeEldestEntry(Map.Entry<BlockPos, Long> eldest) {
            return size() > 10_000; // cap 10k entries
        }
    };
    private long lastOreChatMs = 0;

    // ── Scaffold throttle ─────────────────────────────────────────────────────
    private volatile long lastScaffoldPlaceMs = 0;

    // ── Attack throttle ───────────────────────────────────────────────────────
    private final AtomicLong lastAttackMs = new AtomicLong();

    // ── Velocity bypass state ─────────────────────────────────────────────────
    private volatile boolean pendingVelocityBypass = false;
    private volatile long    velocityBypassUntilMs  = 0;

    // ── V10: Y-reveal mapper + chunk section parser ───────────────────────────
    private final YRevealMapper      yRevealMapper  = new YRevealMapper();
    private final ChunkSectionParser sectionParser  = new ChunkSectionParser();
    // Track chunk keys đã alert (tránh spam)
    private final Set<Long>          parserAlerted  = ConcurrentHashMap.newKeySet();
    private long lastParserPurgeMs = 0L;

    // ── Export path ───────────────────────────────────────────────────────────
    private static final Path EXPORT_ROOT;
    static {
        Path root;
        String os = System.getProperty("os.name","").toLowerCase();
        if (os.contains("win")) {
            String appdata = System.getenv("APPDATA");
            if (appdata == null) appdata = System.getProperty("user.home",".");
            root = Path.of(appdata,".minecraft","acv9_export");
        } else if (os.contains("mac")) {
            root = Path.of(System.getProperty("user.home","."),
                "Library","Application Support","minecraft","acv9_export");
        } else {
            root = Path.of(System.getProperty("user.home",".")
                ,".minecraft","acv9_export");
        }
        EXPORT_ROOT = root;
    }

    private record OreFind(BlockPos pos, String type, long receivedMs) {}

    // ── Loaded config record ──────────────────────────────────────────────────
    private record RaidConfig(
        double speedCap,
        long   attackDelayMs,
        long   scaffoldDelayMs,
        long   kbAcceptWindowMs,
        int    gcdYawMdeg,
        String detectedAc,
        String antiXrayEngine,
        boolean velocityBypassHole,
        boolean teleportBypassHole,
        boolean noSetback,
        String  acNotes,
        String  patchProbeConfidence
    ) {}

    // ── Constructor ───────────────────────────────────────────────────────────
    public RaidBaseModule() {
        super(dev.ollie.ACAddon.CATEGORY, "RaidBase",
            "Raid base module dùng config từ ACCollector V9. /raidbase để xem lệnh.");
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override
    public void onActivate() {
        if (autoLoadConfig.get()) {
            boolean loaded = loadLatestConfig();
            if (!loaded) {
                chatInfo("§eKhông tìm thấy ACCollector snapshot. Dùng manual config.");
                chatInfo("§7Chạy ACCollector trước, /pen để export, rồi /raidbase reload");
            }
        }
        oreFinds.clear();
        pendingReveal.clear();
        yRevealMapper.clear();
        sectionParser.clear();
        parserAlerted.clear();
        chatInfo("§aRaidBase V2 bật — YMapper + SectionParser ON. /raidbase help để xem lệnh");
    }

    @Override
    public void onDeactivate() {
        oreFinds.clear();
        pendingReveal.clear();
        yRevealMapper.clear();
        sectionParser.clear();
        parserAlerted.clear();
    }

    // ── Command handler (gọi từ ACAddon khi nhận /raidbase) ──────────────────
    public void onCommand(String[] args) {
        if (args.length == 0) { showHelp(); return; }
        switch (args[0].toLowerCase()) {
            case "reload"  -> { boolean ok = loadLatestConfig(); chatInfo(ok ? "§aConfig reloaded!" : "§cKhông tìm thấy snapshot."); }
            case "xray"    -> { packetXray.set(!packetXray.get()); chatInfo("Packet X-Ray: " + (packetXray.get() ? "§aBẬT" : "§cTẮT")); }
            case "status"  -> showStatus();
            case "ore"     -> showOreFinds();
            case "ymapper" -> showYMapper();
            case "parser"  -> showParserFinds();
            case "help"    -> showHelp();
            default        -> chatInfo("§cUnknown: " + args[0] + " — dùng /raidbase help");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // CONFIG LOADER
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Tìm snapshot.json mới nhất trong EXPORT_ROOT và load config từ đó.
     * File structure: EXPORT_ROOT / {player}_{timestamp} / snapshot.json
     */
    private boolean loadLatestConfig() {
        if (!Files.exists(EXPORT_ROOT)) return false;
        try {
            // Tìm snapshot.json mới nhất
            Optional<Path> latest = Files.walk(EXPORT_ROOT, 2)
                .filter(p -> p.getFileName().toString().equals("snapshot.json"))
                .max((a, b) -> {
                    try { return Files.getLastModifiedTime(a).compareTo(Files.getLastModifiedTime(b)); }
                    catch (IOException e) { return 0; }
                });

            if (latest.isEmpty()) return false;
            Path snapshotPath = latest.get();
            String json = Files.readString(snapshotPath, StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();

            // Parse các giá trị cần thiết
            double speedCap       = 0.45;
            long   atkDelay       = 100;
            long   scafDelay      = 50;
            long   kbWindow       = 200;
            int    gcdYaw         = 300;
            String detectedAc     = "unknown";
            String antiXrayEngine = "unknown";
            boolean velBypassHole = false;
            boolean tpBypassHole  = false;
            boolean noSetback     = false;
            String  acNotes       = "";
            String  confidence    = "LOW";

            // Speed
            if (root.has("speed")) {
                JsonObject spd = root.getAsJsonObject("speed");
                if (spd.has("safe_cap")) speedCap = spd.get("safe_cap").getAsDouble();
            }

            // Attack timing
            if (root.has("attack_timing")) {
                JsonObject atk = root.getAsJsonObject("attack_timing");
                if (atk.has("safe_delay_ms")) atkDelay = atk.get("safe_delay_ms").getAsLong();
            }

            // Place/scaffold timing
            if (root.has("place_timing")) {
                JsonObject place = root.getAsJsonObject("place_timing");
                if (place.has("safe_delay_ms")) scafDelay = place.get("safe_delay_ms").getAsLong();
            }

            // KB window
            if (root.has("kb_timing")) {
                JsonObject kb = root.getAsJsonObject("kb_timing");
                if (kb.has("safe_accept_window_ms")) kbWindow = kb.get("safe_accept_window_ms").getAsLong();
            }

            // GCD
            if (root.has("rotation_gcd")) {
                JsonObject gcd = root.getAsJsonObject("rotation_gcd");
                if (gcd.has("gcd_yaw_mdeg")) gcdYaw = gcd.get("gcd_yaw_mdeg").getAsInt();
            }

            // AC fingerprint
            if (root.has("ac_fingerprint")) {
                JsonObject ac = root.getAsJsonObject("ac_fingerprint");
                if (ac.has("detected_ac"))  detectedAc = ac.get("detected_ac").getAsString();
                if (ac.has("ac_notes"))     acNotes    = ac.get("ac_notes").getAsString();
            }

            // Anti-xray
            if (root.has("anti_xray")) {
                JsonObject xray = root.getAsJsonObject("anti_xray");
                if (xray.has("detected_engine")) antiXrayEngine = xray.get("detected_engine").getAsString();
            }

            // Summary
            if (root.has("raid_bypass_summary")) {
                JsonObject sum = root.getAsJsonObject("raid_bypass_summary");
                if (sum.has("velocity_bypass_possible")) velBypassHole = sum.get("velocity_bypass_possible").getAsBoolean();
                if (sum.has("teleport_bypass_seen"))     tpBypassHole  = sum.get("teleport_bypass_seen").getAsBoolean();
                if (sum.has("setback_behavior")) {
                    noSetback = sum.get("setback_behavior").getAsString().equals("NO_SETBACK");
                }
                if (sum.has("ready") && !sum.get("ready").getAsBoolean()) {
                    chatInfo("§eWarning: snapshot chưa ready (< 30s hoặc < 200 packets)");
                }
            }

            // Patch probe confidence
            if (root.has("patch_probe")) {
                JsonObject probe = root.getAsJsonObject("patch_probe");
                if (probe.has("confidence")) confidence = probe.get("confidence").getAsString();
            }

            loadedConfig = new RaidConfig(
                speedCap, atkDelay, scafDelay, kbWindow, gcdYaw,
                detectedAc, antiXrayEngine, velBypassHole, tpBypassHole,
                noSetback, acNotes, confidence
            );

            // Apply vào settings
            applyConfig(loadedConfig);

            if (showStatus.get()) showStatus();
            chatInfo("§aConfig loaded từ: §f" + snapshotPath.getParent().getFileName());
            return true;

        } catch (Exception e) {
            chatError("Load config lỗi: " + e.getMessage());
            return false;
        }
    }

    /** Apply config vào module settings */
    private void applyConfig(RaidConfig cfg) {
        // Speed cap
        manualSpeedCap.set(cfg.speedCap());

        // Attack delay
        attackDelayMs.set((int) Math.max(50, cfg.attackDelayMs()));

        // Scaffold delay
        scaffoldDelay.set((int) Math.max(0, cfg.scaffoldDelayMs()));

        // Velocity bypass — chỉ bật nếu ACCollector detect hole
        if (cfg.velocityBypassHole()) {
            velocityBypass.set(true);
            chatInfo("§eVelocity bypass hole detected! velocityBypass bật tự động.");
        }

        // No setback — an toàn hơn khi bypass
        if (cfg.noSetback()) {
            chatInfo("§aServer không setback (flag-only AC) — bypass an toàn hơn.");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKET HANDLERS
    // ══════════════════════════════════════════════════════════════════════════

    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        var pkt = event.packet;

        // ── PACKET X-RAY: BlockUpdate S→C ────────────────────────────────────
        // Anti-xray Engine 1 gửi fake stone trong chunk data, rồi gửi BlockUpdate
        // khi player đến gần để reveal ore thật.
        // TA ĐỌC PACKET TRƯỚC KHI RENDER → biết vị trí ore dù nhìn vào đó không thấy gì.
        // Tức là: ore position lộ ra trong packet ngay cả khi client vẫn render stone.
        if (packetXray.get() && pkt instanceof BlockUpdateS2CPacket blockUpdate) {
            handlePacketXray(blockUpdate.getPos(), blockUpdate.getState().toString());
            // V10: feed into Y-reveal mapper
            if (yMapperEnabled.get()) {
                String stateLower = blockUpdate.getState().toString().toLowerCase();
                boolean isSignal = stateLower.contains("chest") || stateLower.contains("furnace")
                    || stateLower.contains("piston") || stateLower.contains("redstone")
                    || stateLower.contains("hopper") || stateLower.contains("barrel")
                    || stateLower.contains("smoker") || stateLower.contains("dispenser")
                    || stateLower.contains("dropper") || stateLower.contains("observer")
                    || stateLower.contains("comparator") || stateLower.contains("repeater")
                    || stateLower.contains("torch") || stateLower.contains("lantern");
                if (isSignal && blockUpdate.getPos().getY() <= ChunkSectionParser.UNDERGROUND_Y_MAX) {
                    yRevealMapper.addReveal(blockUpdate.getPos(), blockUpdate.getState().toString());
                }
            }
        }

        // ── PACKET X-RAY: MultiBlockUpdate ───────────────────────────────────
        else if (packetXray.get() && pkt instanceof ChunkDeltaUpdateS2CPacket multiUpdate) {
            // Duyệt qua từng block trong multi-update packet
            // Dùng forEach callback của packet (không parse internal storage trực tiếp)
            try {
                multiUpdate.visitUpdates((pos, state) -> {
                    if (pos != null && state != null) {
                        handlePacketXray(pos, state.toString());
                    }
                });
            } catch (Exception ignored) {
                // Fallback: không access được → skip
            }
        }

        // V10: ChunkData → queue section parser scan
        else if (sectionParserEnabled.get() && pkt instanceof ChunkDataS2CPacket chunkPkt) {
            sectionParser.queueScan(chunkPkt.getChunkX(), chunkPkt.getChunkZ(),
                System.currentTimeMillis());
        }

        // ── VELOCITY BYPASS ───────────────────────────────────────────────────
        // Nếu bypass hole detected và bật velocity bypass:
        // Khi nhận EntityVelocityUpdateS2CPacket → schedule cancel/modify
        else if (velocityBypass.get() && pkt instanceof EntityVelocityUpdateS2CPacket vel) {
            var mc = MinecraftClient.getInstance();
            if (mc.player != null && PktUtil.firstInt(vel, -1) == mc.player.getId()) {
                RaidConfig cfg = loadedConfig;
                long kbWindow = cfg != null ? cfg.kbAcceptWindowMs() : 200;
                pendingVelocityBypass = true;
                velocityBypassUntilMs = System.currentTimeMillis() + kbWindow;
            }
        }
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        var pkt = event.packet;

        // ── SCAFFOLD DELAY BYPASS ─────────────────────────────────────────────
        // Nếu scaffold bypass bật và packet là block placement:
        // throttle để không bị flag RAPID_PLACE
        if (scaffoldBypass.get() && pkt instanceof PlayerInteractBlockC2SPacket) {
            long now = System.currentTimeMillis();
            long minDelay = scaffoldDelay.get();
            long sinceLastPlace = now - lastScaffoldPlaceMs;
            if (sinceLastPlace < minDelay) {
                // Cancel packet — Meteor's PacketEvent.Send là cancellable
                event.cancel();
                return;
            }
            lastScaffoldPlaceMs = now;
        }

        // ── ATTACK DELAY BYPASS ───────────────────────────────────────────────
        // Throttle attack packets để không flag KILL_AURA
        if (attackDelay.get() && pkt instanceof PlayerInteractEntityC2SPacket attack) {
            int[] ia = PktUtil.readInteract(attack);
            if (ia != null && ia[1] == 1) { // attack type
                long now = System.currentTimeMillis();
                long minDelay = attackDelayMs.get();
                long sinceLastAtk = now - lastAttackMs.get();
                if (sinceLastAtk < minDelay) {
                    event.cancel();
                    return;
                }
                lastAttackMs.set(now);
            }
        }

        // ── VELOCITY BYPASS: giảm hDist khi trong bypass window ──────────────
        // NOTE: Thực tế velocity bypass phức tạp hơn — cần modify movement packet.
        // Đây là placeholder; full implementation cần custom movement module.
        // ACCollector detect hole → user biết server không verify velocity → bypass thủ công.
        if (velocityBypass.get() && pkt instanceof PlayerMoveC2SPacket
                && pendingVelocityBypass && System.currentTimeMillis() < velocityBypassUntilMs) {
            // Velocity bypass window đang active
            // Packet sẽ được gửi bình thường nhưng movement reduction phải ở movement module
            // Log để user biết window đang active
            pendingVelocityBypass = false;
        }
    }

    // ── Tick handler: section parser + Y mapper + ore log ────────────────────
    @EventHandler
    private void onTick(TickEvent.Post event) {
        long now = System.currentTimeMillis();

        // V10: drain section parser queue (main thread — reads world)
        if (sectionParserEnabled.get()) {
            sectionParser.drainQueue(parserTickBudget.get(),
                ChunkSectionParser.UNDERGROUND_Y_MAX);

            // Alert khi tìm được chunk có block entities
            if (parserChatAlert.get()) {
                List<ChunkSectionParser.SectionProfile> hits =
                    sectionParser.getHighSignalProfiles(parserMinBlockEntities.get());
                for (ChunkSectionParser.SectionProfile p : hits) {
                    long key = YRevealMapper.chunkKey(p.chunkX(), p.chunkZ());
                    if (!parserAlerted.contains(key)) {
                        parserAlerted.add(key);
                        int wy = p.weightedMeanY();
                        chatInfo(String.format(
                            "§b[PARSER] §fChunk §a%d,%d §f— %d block entities, %d signal blocks | Y≈§a%d §f| Conf: §a%s",
                            p.chunkX(), p.chunkZ(),
                            p.blockEntityCount(), p.signalBlockCount(),
                            wy, p.confidenceLabel()));
                        // Log từng block entity
                        for (ChunkSectionParser.BlockEntityFind be : p.blockEntities()) {
                            chatInfo(String.format("  §7%s at (%d,%d,%d)",
                                be.beType(), be.x(), be.y(), be.z()));
                        }
                    }
                }
            }
        }

        // V10: Y-reveal mapper — alert khi chunk đủ confidence
        if (yMapperEnabled.get() && yMapperChat.get()) {
            List<YRevealMapper.ChunkYProfile> profiles =
                yRevealMapper.getAllProfiles(yMapperMinConfidence.get());
            for (YRevealMapper.ChunkYProfile p : profiles) {
                long key = YRevealMapper.chunkKey(p.chunkX(), p.chunkZ());
                // Chỉ alert HIGH confidence lần đầu
                if (p.confidence() >= 0.7
                        && !parserAlerted.contains(key ^ Long.MIN_VALUE)) {
                    parserAlerted.add(key ^ Long.MIN_VALUE);
                    chatInfo(String.format(
                        "§e[YMAPPER] §fChunk §a%d,%d §f— %d reveals | peakY≈§a%d §f| meanY≈§a%d §f| Conf: §a%s",
                        p.chunkX(), p.chunkZ(),
                        p.totalReveals(), p.peakYBand(), p.weightedMeanY(),
                        p.confidenceLabel()));
                }
            }
        }

        // Purge expired reveals mỗi 60s
        if (now - lastParserPurgeMs > 60_000L) {
            lastParserPurgeMs = now;
            yRevealMapper.purgeExpired();
        }

        if (!packetXray.get()) return;
        // Flush ore log vào chat mỗi 2s
        if (xrayLogToChat.get() && now - lastOreChatMs > 2000 && !oreFinds.isEmpty()) {
            int batchSize = 0;
            OreFind find;
            while ((find = oreFinds.poll()) != null && batchSize < 5) {
                var mc = MinecraftClient.getInstance();
                String distStr = "";
                if (mc.player != null) {
                    Vec3d pp = mc.player.getPos();
                    double dx = pp.x - find.pos().getX();
                    double dy = pp.y - find.pos().getY();
                    double dz = pp.z - find.pos().getZ();
                    double dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
                    distStr = String.format(" §7(%.1fm)", dist);
                }
                chatInfo(String.format("§6[XRAY] §e%s §fat (%d, %d, %d)%s",
                    find.type(), find.pos().getX(), find.pos().getY(), find.pos().getZ(),
                    distStr));
                batchSize++;
            }
            if (batchSize > 0) lastOreChatMs = now;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKET X-RAY HANDLER
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Phân tích block state từ packet và log nếu là ore.
     *
     * Logic anti-xray bypass:
     * - Anti-xray Engine 1 (ProOre): server gửi stone/deepslate trong ChunkData,
     *   rồi gửi BlockUpdate khi reveal. TA NHẬN PACKET NÀY TRƯỚC KHI RENDER.
     *   → BlockUpdate state = ore thật → ta biết vị trí ore dù renderer vẫn vẽ stone.
     * - Không cần mod renderer hay bypass anti-xray plugin.
     * - 100% passive: không gửi thêm packet, không làm server detect.
     *
     * Hạn chế:
     * - Engine 2 (strip mining / obfuscation): server không gửi ore cho đến khi
     *   player nhìn trực tiếp vào wall → packet-level xray chỉ hoạt động khi ore reveal.
     * - Engine 1 với reveal radius nhỏ: ore chỉ lộ khi rất gần.
     */
    private void handlePacketXray(BlockPos pos, String stateStr) {
        if (pos.getY() > xrayMinY.get()) return; // Chỉ track ore ở Y thấp

        String stateLower = stateStr.toLowerCase();
        String oreType = null;

        if (xrayDiamond.get() && (stateLower.contains("diamond_ore") || stateLower.contains("deepslate_diamond"))) {
            oreType = "DIAMOND";
        } else if (xrayAncientDebris.get() && stateLower.contains("ancient_debris")) {
            oreType = "ANCIENT_DEBRIS";
        } else if (xrayGold.get() && (stateLower.contains("gold_ore") || stateLower.contains("deepslate_gold") || stateLower.contains("nether_gold"))) {
            oreType = "GOLD";
        } else if (xrayIron.get() && (stateLower.contains("iron_ore") || stateLower.contains("deepslate_iron"))) {
            oreType = "IRON";
        } else if (stateLower.contains("emerald_ore") || stateLower.contains("deepslate_emerald")) {
            oreType = "EMERALD";
        } else if (stateLower.contains("lapis_ore") || stateLower.contains("deepslate_lapis")) {
            oreType = "LAPIS";
        }

        if (oreType != null) {
            oreFinds.offer(new OreFind(pos.toImmutable(), oreType, System.currentTimeMillis()));
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // STATUS / HELP / ORE LIST
    // ══════════════════════════════════════════════════════════════════════════

    private void showStatus() {
        RaidConfig cfg = loadedConfig;
        if (cfg == null) {
            chatInfo("§eKhông có config. Chạy /raidbase reload sau khi export ACCollector.");
            return;
        }
        chatInfo("§6=== RaidBase Status ===");
        chatInfo("§7Detected AC:    §f" + cfg.detectedAc());
        chatInfo("§7AC Notes:       §f" + (cfg.acNotes().isEmpty() ? "none" : cfg.acNotes()));
        chatInfo("§7Anti-Xray:      §f" + cfg.antiXrayEngine());
        chatInfo("§7Speed Cap:      §a" + String.format("%.4f", cfg.speedCap()) + " §7bpt");
        chatInfo("§7Attack Delay:   §a" + cfg.attackDelayMs() + " §7ms");
        chatInfo("§7Scaffold Delay: §a" + cfg.scaffoldDelayMs() + " §7ms");
        chatInfo("§7KB Window:      §a" + cfg.kbAcceptWindowMs() + " §7ms");
        chatInfo("§7GCD Yaw:        §a" + cfg.gcdYawMdeg() + " §7mdeg");
        chatInfo("§7Vel Bypass:     " + (cfg.velocityBypassHole() ? "§aYES (hole detected)" : "§7no"));
        chatInfo("§7No Setback:     " + (cfg.noSetback() ? "§aYES (safe)" : "§eNO (setback active)"));
        chatInfo("§7Confidence:     §f" + cfg.patchProbeConfidence());
        chatInfo("§7Packet Xray:    " + (packetXray.get() ? "§aBẬT" : "§cTẮT"));
        chatInfo("§7Scaffold Byp:   " + (scaffoldBypass.get() ? "§aBẬT (delay=" + scaffoldDelay.get() + "ms)" : "§7tắt"));
        chatInfo("§7Attack Byp:     " + (attackDelay.get() ? "§aBẬT (delay=" + attackDelayMs.get() + "ms)" : "§7tắt"));
    }

    private void showOreFinds() {
        if (oreFinds.isEmpty()) {
            chatInfo("§7Chưa detect ore nào. Bật packet-xray và vào hầm mỏ.");
            return;
        }
        // Snapshot và group by type
        List<OreFind> all = new ArrayList<>(oreFinds);
        Map<String, List<OreFind>> byType = new LinkedHashMap<>();
        for (OreFind f : all) byType.computeIfAbsent(f.type(), k -> new ArrayList<>()).add(f);
        chatInfo("§6=== Ore Finds (" + all.size() + " total) ===");
        byType.forEach((type, finds) -> {
            chatInfo("§e" + type + " §7x" + finds.size() + ":");
            finds.stream().limit(5).forEach(f ->
                chatInfo(String.format("  §f(%d, %d, %d)", f.pos().getX(), f.pos().getY(), f.pos().getZ())));
            if (finds.size() > 5) chatInfo("  §7... và " + (finds.size()-5) + " nữa");
        });
    }

    // ── V10: Y mapper display ─────────────────────────────────────────────────
    private void showYMapper() {
        List<YRevealMapper.ChunkYProfile> profiles =
            yRevealMapper.getAllProfiles(0.0);
        if (profiles.isEmpty()) {
            chatInfo("§7Y-Mapper: Chưa có data. Bật xray và di chuyển để accumulate reveals.");
            return;
        }
        chatInfo(String.format("§e=== Y-Reveal Mapper (%d chunks) ===", profiles.size()));
        int shown = 0;
        for (YRevealMapper.ChunkYProfile p : profiles) {
            if (shown++ >= 10) break;
            chatInfo(String.format("§aChunk %d,%d §f| reveals=%d | peakY=%d | meanY=%d | conf=%s",
                p.chunkX(), p.chunkZ(),
                p.totalReveals(), p.peakYBand(), p.weightedMeanY(),
                p.confidenceLabel()));
        }
        if (profiles.size() > 10)
            chatInfo(String.format("§7... và %d chunks nữa", profiles.size() - 10));
    }

    // ── V10: Section parser display ───────────────────────────────────────────
    private void showParserFinds() {
        List<ChunkSectionParser.SectionProfile> all = sectionParser.snapshotAll();
        List<ChunkSectionParser.SectionProfile> hits = sectionParser.getHighSignalProfiles(1);
        chatInfo(String.format("§b=== Section Parser (%d chunks scanned, %d with signal) ===",
            all.size(), hits.size()));
        if (hits.isEmpty()) {
            chatInfo("§7Chưa tìm được block entities underground. Bay thêm để load chunks.");
            chatInfo("§7Queue: " + sectionParser.queueSize() + " chunks đang chờ scan.");
            return;
        }
        int shown = 0;
        for (ChunkSectionParser.SectionProfile p : hits) {
            if (shown++ >= 10) break;
            chatInfo(String.format("§aChunk %d,%d §f| BE=%d | palette=%d | Y≈%d | conf=%s",
                p.chunkX(), p.chunkZ(),
                p.blockEntityCount(), p.signalBlockCount(),
                p.weightedMeanY(), p.confidenceLabel()));
            for (ChunkSectionParser.BlockEntityFind be : p.blockEntities()) {
                chatInfo(String.format("  §b%s §fat (%d,%d,%d)",
                    be.beType(), be.x(), be.y(), be.z()));
            }
        }
        chatInfo("§7Queue còn: " + sectionParser.queueSize() + " chunks chờ scan.");
    }

    private void showHelp() {
        chatInfo("§6=== RaidBase Help ===");
        chatInfo("§f/raidbase reload   §7— Load config từ ACCollector snapshot mới nhất");
        chatInfo("§f/raidbase xray     §7— Toggle packet x-ray (bypass anti-xray Engine 1)");
        chatInfo("§f/raidbase ore      §7— Xem danh sách ore detect được");
        chatInfo("§f/raidbase ymapper  §7— Xem Y-reveal mapper (depth estimate per chunk)");
        chatInfo("§f/raidbase parser   §7— Xem section parser finds (block entities underground)");
        chatInfo("§f/raidbase status   §7— Xem config hiện tại");
        chatInfo("§f/raidbase help     §7— Hiện menu này");
        chatInfo("§7");
        chatInfo("§7WORKFLOW (bay Y75 tìm base):");
        chatInfo("§71. Bật RaidBase → section-parser bật tự động");
        chatInfo("§72. Bay ở Y75 → parser scan chunks khi load → alert nếu thấy BE");
        chatInfo("§73. /raidbase parser → xem chunk nào có block entities");
        chatInfo("§74. /raidbase xray → bật để accumulate reveals cho ymapper");
        chatInfo("§75. /raidbase ymapper → xem Y estimate của từng chunk suspect");
        chatInfo("§76. Xuống Y thấp hơn để confirm bằng palette scan chi tiết");
    }

    private static void chatInfo(String msg) {
        MinecraftClient.getInstance().execute(
            () -> ChatUtils.infoPrefix("RaidBase", "%s", msg));
    }
    private static void chatError(String msg) {
        MinecraftClient.getInstance().execute(
            () -> ChatUtils.errorPrefix("RaidBase", "%s", msg));
    }
}
