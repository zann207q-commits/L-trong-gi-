// Language: Java 21
// File: YRevealMapper.java
// Runtime: Fabric 1.21.11 / Meteor 0.5.9-SNAPSHOT
//
// Track BlockUpdate reveals theo chunk + Y band.
// Mỗi khi server gửi BlockUpdate (ore reveal, container reveal, activity block),
// ghi lại vào histogram Y của chunk đó.
// Khi đủ samples → estimate Y của structure (base depth, farm level).
//
// Output:
//   ChunkYProfile  — per chunk: Y histogram + peak band + confidence
//   revealEvents   — raw list để export
//
// Dùng bởi RaidBaseModule để:
//   1. Hiện ESP box ở đúng Y (thay vì hardcode Y=64)
//   2. Khi bay ở Y75 scan diện rộng → accumulate reveals → biết base ở Y bao nhiêu
//   3. Xuất ra snapshot.json → ACCollector đọc lại

package dev.ollie.modules;

import net.minecraft.util.math.BlockPos;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class YRevealMapper {

    // ── Y band config ────────────────────────────────────────────────────────
    // Chia Y thành bands 8 block để smooth histogram
    private static final int BAND_SIZE   = 8;
    // Min reveal count để một band được coi là "significant"
    private static final int MIN_REVEALS = 3;
    // Max chunks tracked (tránh memory leak khi di chuyển nhiều)
    private static final int MAX_CHUNKS  = 2048;
    // Max reveals per chunk (tránh một chunk spam)
    private static final int MAX_REVEALS_PER_CHUNK = 500;
    // TTL của reveal entry (ms) — 10 phút
    private static final long REVEAL_TTL_MS = 600_000L;

    // ── Types ────────────────────────────────────────────────────────────────

    /**
     * Một lần reveal: vị trí block, loại block, timestamp.
     */
    public record RevealEvent(int x, int y, int z, String blockType, long receivedMs) {
        public long chunkKey() { return chunkKey(x >> 4, z >> 4); }
        public int  yBand()    { return Math.floorDiv(y, BAND_SIZE) * BAND_SIZE; }
    }

    /**
     * Profile của một chunk — Y histogram + peak + confidence.
     * peak() = Y band có nhiều reveals nhất.
     * confidence() = LOW / MEDIUM / HIGH dựa vào số reveals.
     */
    public record ChunkYProfile(
        int    chunkX,
        int    chunkZ,
        int    totalReveals,
        int    peakYBand,       // Y band có nhiều reveals nhất
        int    peakBandCount,   // số reveals trong peak band
        double confidence,      // 0.0 - 1.0
        Map<Integer, Integer> yHistogram  // yBand → count
    ) {
        public String confidenceLabel() {
            if (confidence >= 0.7) return "HIGH";
            if (confidence >= 0.4) return "MEDIUM";
            return "LOW";
        }

        /** Y trung bình có trọng số (weighted average từ histogram). */
        public int weightedMeanY() {
            if (yHistogram.isEmpty()) return peakYBand;
            long sumWeighted = 0, sumCount = 0;
            for (Map.Entry<Integer, Integer> e : yHistogram.entrySet()) {
                sumWeighted += (long) e.getKey() * e.getValue();
                sumCount    += e.getValue();
            }
            return sumCount == 0 ? peakYBand : (int)(sumWeighted / sumCount);
        }
    }

    // ── State ────────────────────────────────────────────────────────────────

    // chunkKey → list of reveals (bounded)
    private final Map<Long, List<RevealEvent>> revealsByChunk = new ConcurrentHashMap<>();
    // chunkKey → cached profile (invalidated on new reveal)
    private final Map<Long, ChunkYProfile>     profileCache   = new ConcurrentHashMap<>();
    // Dirty flags — invalidate cache khi có reveal mới
    private final Set<Long>                    dirty          = ConcurrentHashMap.newKeySet();

    // ── Public API ───────────────────────────────────────────────────────────

    /**
     * Ghi nhận một reveal event.
     * Thread-safe — gọi từ netty thread.
     */
    public void addReveal(BlockPos pos, String blockType) {
        long key = chunkKey(pos.getX() >> 4, pos.getZ() >> 4);
        List<RevealEvent> list = revealsByChunk.computeIfAbsent(key,
            k -> Collections.synchronizedList(new ArrayList<>()));

        // Cap để tránh memory leak
        if (list.size() >= MAX_REVEALS_PER_CHUNK) return;

        list.add(new RevealEvent(pos.getX(), pos.getY(), pos.getZ(),
            blockType, System.currentTimeMillis()));
        dirty.add(key);

        // Trim nếu quá nhiều chunks
        if (revealsByChunk.size() > MAX_CHUNKS) {
            trimOldest();
        }
    }

    /**
     * Lấy Y profile của một chunk.
     * Trả về null nếu chưa đủ data.
     */
    public ChunkYProfile getProfile(int cx, int cz) {
        long key = chunkKey(cx, cz);
        if (dirty.remove(key)) {
            profileCache.put(key, buildProfile(cx, cz, key));
        }
        return profileCache.get(key);
    }

    /**
     * Lấy tất cả profiles đang có, chỉ những cái đủ confidence.
     * Sorted theo totalReveals descending.
     */
    public List<ChunkYProfile> getAllProfiles(double minConfidence) {
        // Rebuild dirty ones
        for (long key : new ArrayList<>(dirty)) {
            dirty.remove(key);
            int cx = decodeCx(key), cz = decodeCz(key);
            profileCache.put(key, buildProfile(cx, cz, key));
        }

        List<ChunkYProfile> result = new ArrayList<>();
        for (ChunkYProfile p : profileCache.values()) {
            if (p.confidence() >= minConfidence) result.add(p);
        }
        result.sort(Comparator.comparingInt(ChunkYProfile::totalReveals).reversed());
        return result;
    }

    /**
     * Snapshot tất cả raw reveals — dùng để export vào snapshot.json.
     */
    public List<RevealEvent> snapshotAllReveals() {
        List<RevealEvent> all = new ArrayList<>();
        for (List<RevealEvent> list : revealsByChunk.values()) {
            synchronized (list) { all.addAll(list); }
        }
        all.sort(Comparator.comparingLong(RevealEvent::receivedMs));
        return all;
    }

    /**
     * Xóa toàn bộ state.
     */
    public void clear() {
        revealsByChunk.clear();
        profileCache.clear();
        dirty.clear();
    }

    /**
     * Xóa reveals cũ hơn REVEAL_TTL_MS.
     * Gọi từ tick() để tránh memory leak khi session dài.
     */
    public void purgeExpired() {
        long cutoff = System.currentTimeMillis() - REVEAL_TTL_MS;
        for (Map.Entry<Long, List<RevealEvent>> e : revealsByChunk.entrySet()) {
            List<RevealEvent> list = e.getValue();
            synchronized (list) {
                boolean removed = list.removeIf(r -> r.receivedMs() < cutoff);
                if (removed) dirty.add(e.getKey());
                if (list.isEmpty()) revealsByChunk.remove(e.getKey());
            }
        }
    }

    // ── Internal ─────────────────────────────────────────────────────────────

    private ChunkYProfile buildProfile(int cx, int cz, long key) {
        List<RevealEvent> list = revealsByChunk.get(key);
        if (list == null || list.isEmpty()) {
            return new ChunkYProfile(cx, cz, 0, 0, 0, 0.0, Map.of());
        }

        // Build Y histogram
        Map<Integer, Integer> hist = new TreeMap<>();
        synchronized (list) {
            for (RevealEvent r : list) {
                hist.merge(r.yBand(), 1, Integer::sum);
            }
        }

        // Find peak band
        int peakBand = 0, peakCount = 0;
        for (Map.Entry<Integer, Integer> e : hist.entrySet()) {
            if (e.getValue() > peakCount) {
                peakCount = e.getValue();
                peakBand  = e.getKey();
            }
        }

        int total = list.size();
        // Confidence formula:
        //   base = peakCount / total (how focused the reveals are)
        //   bonus nếu total >= MIN_REVEALS
        //   cap tại 1.0
        double base = total > 0 ? (double) peakCount / total : 0.0;
        double totalBonus = Math.min(1.0, (double) total / 20.0);  // max bonus at 20 reveals
        double confidence = Math.min(1.0, base * 0.6 + totalBonus * 0.4);
        if (peakCount < MIN_REVEALS) confidence *= 0.3;  // penalize if peak too small

        return new ChunkYProfile(cx, cz, total, peakBand, peakCount,
            confidence, Collections.unmodifiableMap(hist));
    }

    private void trimOldest() {
        // Remove chunk với reveal cũ nhất
        long oldestKey = -1;
        long oldestMs  = Long.MAX_VALUE;
        for (Map.Entry<Long, List<RevealEvent>> e : revealsByChunk.entrySet()) {
            List<RevealEvent> list = e.getValue();
            synchronized (list) {
                if (!list.isEmpty() && list.get(0).receivedMs() < oldestMs) {
                    oldestMs  = list.get(0).receivedMs();
                    oldestKey = e.getKey();
                }
            }
        }
        if (oldestKey != -1) {
            revealsByChunk.remove(oldestKey);
            profileCache.remove(oldestKey);
            dirty.remove(oldestKey);
        }
    }

    // ── Key encoding ─────────────────────────────────────────────────────────
    public static long chunkKey(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xFFFFFFFFL);
    }
    public static int decodeCx(long key) { return (int)(key >> 32); }
    public static int decodeCz(long key) { return (int)(key & 0xFFFFFFFFL); }
}
