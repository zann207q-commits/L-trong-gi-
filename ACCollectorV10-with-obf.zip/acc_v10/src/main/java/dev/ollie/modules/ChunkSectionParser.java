// Language: Java 21
// File: ChunkSectionParser.java
// Runtime: Fabric 1.21.11 / Yarn 1.21.1+build.3
//
// Parse ChunkDataS2CPacket sections để detect signal blocks underground.
// Khác với YRevealMapper (track BlockUpdate reveals): parser này đọc toàn bộ
// palette của chunk ngay khi load → không cần chờ server reveal.
//
// Hoạt động ở Y75:
//   - Khi bay ngang, server vẫn gửi ChunkDataS2CPacket cho chunk trong XZ range
//   - Section underground (Y < 0) được gửi nhưng thường là fake stone (anti-xray)
//   - Tuy nhiên, block entities (chest, furnace...) KHÔNG bị anti-xray che
//     → vẫn xuất hiện trong chunk data dưới dạng block entity list
//   - Parser đọc cả block state palette VÀ block entity list
//
// Output: SectionProfile per chunk — signal block count, Y distribution, block entity list

package dev.ollie.modules;

import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class ChunkSectionParser {

    // ── Signal block sets ────────────────────────────────────────────────────
    // Block types coi là "signal" — xuất hiện underground = nhân tạo
    private static final Set<String> SIGNAL_BLOCKS = Set.of(
        // Storage — không bị anti-xray che (block entity)
        "chest", "trapped_chest", "barrel", "shulker_box", "hopper",
        "furnace", "blast_furnace", "smoker", "dispenser", "dropper",
        "brewing_stand", "enchanting_table", "beacon", "mob_spawner",
        "trial_spawner", "vault", "crafter", "chiseled_bookshelf",
        // Redstone — thường bị anti-xray che nhưng vẫn thử
        "redstone_wire", "comparator", "repeater", "observer",
        "piston", "sticky_piston", "redstone_torch", "redstone_wall_torch",
        "tripwire_hook", "lever", "sculk_sensor", "sculk_shrieker",
        // Light source nhân tạo — không tự nhiên underground ngoài lava
        "torch", "wall_torch", "soul_torch", "soul_wall_torch",
        "lantern", "soul_lantern", "glowstone", "sea_lantern",
        "shroomlight", "end_rod", "glow_lichen",
        // Player-built
        "crafting_table", "anvil", "chipped_anvil", "damaged_anvil",
        "respawn_anchor", "lodestone", "tnt", "note_block",
        "jukebox", "bell", "grindstone", "stonecutter",
        "loom", "cartography_table", "fletching_table",
        "smithing_table", "bookshelf", "lectern",
        // Beds (đánh dấu spawn point → ai đó ở đây)
        "white_bed", "orange_bed", "magenta_bed", "light_blue_bed",
        "yellow_bed", "lime_bed", "pink_bed", "gray_bed",
        "light_gray_bed", "cyan_bed", "purple_bed", "blue_bed",
        "brown_bed", "green_bed", "red_bed", "black_bed"
    );

    // Block entity types coi là signal (quan trọng nhất — không bị anti-xray che)
    private static final Set<String> SIGNAL_BE_TYPES = Set.of(
        "chest", "trapped_chest", "barrel", "shulker_box", "hopper",
        "furnace", "blast_furnace", "smoker", "dispenser", "dropper",
        "brewing_stand", "enchanting_table", "beacon", "mob_spawner",
        "trial_spawner", "vault", "crafter"
    );

    // ── Config ───────────────────────────────────────────────────────────────
    // Max chunks tracked
    private static final int MAX_CHUNKS = 2048;
    // Scan underground sections only (Y <= this)
    public static final int UNDERGROUND_Y_MAX = 10;

    // ── Types ────────────────────────────────────────────────────────────────

    /**
     * Một block entity tìm được trong chunk data.
     * Đây là signal mạnh nhất — server không fake block entities.
     */
    public record BlockEntityFind(
        int    x, int y, int z,
        String beType,
        long   foundMs
    ) {
        public BlockPos toBlockPos() { return new BlockPos(x, y, z); }
    }

    /**
     * Một signal block tìm được trong section palette.
     * Yếu hơn BlockEntityFind vì có thể bị anti-xray fake.
     */
    public record PaletteFind(
        int    x, int y, int z,
        String blockType,
        long   foundMs
    ) {}

    /**
     * Profile của một chunk — kết quả scan toàn bộ chunk.
     *
     * signalBlockCount  = tổng signal blocks trong palette (có thể bị anti-xray fake)
     * blockEntityCount  = tổng block entities (KHÔNG bị anti-xray fake → đáng tin)
     * blockEntities     = danh sách block entities underground
     * paletteFinds      = danh sách signal blocks trong palette underground
     * yBandHistogram    = signal count per Y band (key = floor(y/8)*8)
     * peakYBand         = Y band có nhiều signals nhất
     * confidence        = tính theo block entity count (đáng tin hơn palette)
     */
    public record SectionProfile(
        int    chunkX,
        int    chunkZ,
        int    signalBlockCount,
        int    blockEntityCount,
        List<BlockEntityFind> blockEntities,
        List<PaletteFind>     paletteFinds,
        Map<Integer, Integer> yBandHistogram,
        int    peakYBand,
        double confidence,
        long   scannedMs
    ) {
        public boolean hasBlockEntities()  { return blockEntityCount > 0; }
        public boolean hasSignalBlocks()   { return signalBlockCount > 0; }
        public boolean isHighConfidence()  { return confidence >= 0.6; }

        public String confidenceLabel() {
            if (confidence >= 0.7) return "HIGH";
            if (confidence >= 0.4) return "MEDIUM";
            return "LOW";
        }

        /**
         * Y trung bình có trọng số từ histogram.
         * Dùng để set waypoint Y, ESP box Y.
         */
        public int weightedMeanY() {
            if (yBandHistogram.isEmpty()) return peakYBand;
            long sumW = 0, sumC = 0;
            for (Map.Entry<Integer, Integer> e : yBandHistogram.entrySet()) {
                sumW += (long) e.getKey() * e.getValue();
                sumC += e.getValue();
            }
            return sumC == 0 ? peakYBand : (int)(sumW / sumC);
        }
    }

    // ── State ────────────────────────────────────────────────────────────────
    // chunkKey → SectionProfile (last scan)
    private final Map<Long, SectionProfile> profiles = new ConcurrentHashMap<>();
    // Queue của chunks cần scan (from ChunkDataS2CPacket, drained in tick)
    private final Queue<long[]> scanQueue = new ArrayDeque<>();

    // ── Public API ───────────────────────────────────────────────────────────

    /**
     * Queue một chunk để scan.
     * Gọi từ netty thread khi nhận ChunkDataS2CPacket.
     * Actual scan xảy ra trong tick() (main thread) để đọc world.
     */
    public void queueScan(int cx, int cz, long receivedMs) {
        synchronized (scanQueue) {
            if (scanQueue.size() < 1024) {
                scanQueue.offer(new long[]{cx, cz, receivedMs});
            }
        }
    }

    /**
     * Drain scan queue — gọi từ main thread (tick).
     * Scan tối đa maxPerTick chunks mỗi tick để không lag.
     */
    public void drainQueue(int maxPerTick, int yMax) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.world == null) return;
        int worldBottom = mc.world.getBottomY();

        int processed = 0;
        while (processed < maxPerTick) {
            long[] entry;
            synchronized (scanQueue) { entry = scanQueue.poll(); }
            if (entry == null) break;
            processed++;

            int cx = (int) entry[0], cz = (int) entry[1], ts = (int) entry[2];
            WorldChunk chunk = mc.world.getChunk(cx, cz);
            if (chunk == null) continue;

            // Trim cache nếu quá đầy
            if (profiles.size() >= MAX_CHUNKS) {
                profiles.entrySet().stream()
                    .min(Comparator.comparingLong(e -> e.getValue().scannedMs()))
                    .map(Map.Entry::getKey)
                    .ifPresent(profiles::remove);
            }

            SectionProfile profile = scanChunk(chunk, cx, cz, worldBottom, yMax, entry[2]);
            if (profile != null) {
                profiles.put(YRevealMapper.chunkKey(cx, cz), profile);
            }
        }
    }

    /**
     * Lấy profile của một chunk.
     * Trả về null nếu chưa scan.
     */
    public SectionProfile getProfile(int cx, int cz) {
        return profiles.get(YRevealMapper.chunkKey(cx, cz));
    }

    /**
     * Lấy tất cả profiles có block entities (signal mạnh nhất).
     * Sorted theo blockEntityCount descending.
     */
    public List<SectionProfile> getHighSignalProfiles(int minBlockEntities) {
        List<SectionProfile> result = new ArrayList<>();
        for (SectionProfile p : profiles.values()) {
            if (p.blockEntityCount() >= minBlockEntities) result.add(p);
        }
        result.sort(Comparator.comparingInt(SectionProfile::blockEntityCount).reversed());
        return result;
    }

    /**
     * Snapshot tất cả profiles — dùng để export.
     */
    public List<SectionProfile> snapshotAll() {
        return new ArrayList<>(profiles.values());
    }

    public void clear() {
        profiles.clear();
        synchronized (scanQueue) { scanQueue.clear(); }
    }

    public int queueSize() {
        synchronized (scanQueue) { return scanQueue.size(); }
    }

    public int profileCount() { return profiles.size(); }

    // ── Scan logic ───────────────────────────────────────────────────────────

    /**
     * Scan một WorldChunk:
     *  1. Walk tất cả sections có Y <= yMax
     *  2. Per section: iterate 16×16×16 blocks, collect signal blocks
     *  3. Scan block entity list (quan trọng hơn — không bị anti-xray)
     *  4. Build Y histogram + compute confidence
     */
    private SectionProfile scanChunk(WorldChunk chunk, int cx, int cz,
                                      int worldBottom, int yMax, long receivedMs) {
        ChunkSection[] sections = chunk.getSectionArray();
        int maxSectionIdx = Math.min((yMax - worldBottom) / 16, sections.length - 1);
        if (maxSectionIdx < 0) return null;

        List<PaletteFind>     paletteFinds = new ArrayList<>();
        Map<Integer, Integer> hist         = new TreeMap<>();
        int signalCount = 0;

        // ── 1. Scan sections (palette) ────────────────────────────────────────
        for (int si = 0; si <= maxSectionIdx; si++) {
            ChunkSection section = sections[si];
            if (section == null || section.isEmpty()) continue;

            for (int bx = 0; bx < 16; bx++) {
                for (int by = 0; by < 16; by++) {
                    for (int bz = 0; bz < 16; bz++) {
                        var state = section.getBlockState(bx, by, bz);
                        if (state == null || state.isAir()) continue;

                        var id = Registries.BLOCK.getId(state.getBlock());
                        if (id == null) continue;
                        String path = id.getPath();

                        // Check suffix match cho beds (white_bed, etc.)
                        boolean isSignal = SIGNAL_BLOCKS.contains(path)
                            || path.endsWith("_bed")
                            || path.endsWith("_shulker_box");

                        if (isSignal) {
                            int absY = worldBottom + si * 16 + by;
                            if (absY > yMax) continue;

                            int absX = cx * 16 + bx;
                            int absZ = cz * 16 + bz;

                            paletteFinds.add(new PaletteFind(absX, absY, absZ, path, receivedMs));
                            signalCount++;

                            // Y histogram (band size 8)
                            int band = Math.floorDiv(absY, 8) * 8;
                            hist.merge(band, 1, Integer::sum);
                        }
                    }
                }
            }
        }

        // ── 2. Scan block entities (không bị anti-xray fake) ─────────────────
        List<BlockEntityFind> beFinds = new ArrayList<>();
        chunk.getBlockEntities().forEach((bePos, be) -> {
            if (bePos.getY() > yMax) return;

            var beType = be.getType();
            var beId   = Registries.BLOCK_ENTITY_TYPE.getId(beType);
            if (beId == null) return;

            String bePath = beId.getPath();
            if (SIGNAL_BE_TYPES.contains(bePath)) {
                beFinds.add(new BlockEntityFind(
                    bePos.getX(), bePos.getY(), bePos.getZ(),
                    bePath, receivedMs));

                // Cũng thêm vào histogram
                int band = Math.floorDiv(bePos.getY(), 8) * 8;
                hist.merge(band, 3, Integer::sum); // weight 3 cho BE (đáng tin hơn palette)
            }
        });

        // ── 3. Build peak + confidence ────────────────────────────────────────
        int peakBand = 0, peakCount = 0;
        for (Map.Entry<Integer, Integer> e : hist.entrySet()) {
            if (e.getValue() > peakCount) {
                peakCount = e.getValue();
                peakBand  = e.getKey();
            }
        }

        // Confidence:
        //   Block entities = strong signal (server cannot fake)
        //   Palette signal = weak signal (may be anti-xray obfuscation)
        double beFactor      = Math.min(1.0, beFinds.size() / 3.0);  // 3 BEs = max BE score
        double paletteFactor = Math.min(1.0, signalCount / 10.0);     // 10 palette = max palette score
        double confidence    = beFactor * 0.75 + paletteFactor * 0.25;

        return new SectionProfile(
            cx, cz,
            signalCount,
            beFinds.size(),
            Collections.unmodifiableList(beFinds),
            Collections.unmodifiableList(paletteFinds),
            Collections.unmodifiableMap(hist),
            peakBand,
            confidence,
            receivedMs
        );
    }
}
