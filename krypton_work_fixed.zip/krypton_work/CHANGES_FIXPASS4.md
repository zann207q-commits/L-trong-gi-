# Fix pass 4 (bug fixes from the audit)

Not compiled against Minecraft/Yarn (no Gradle/network here). Only checked with javac that every changed file
parses; symbol/API errors can only be found by a real `gradlew build` on JDK 21.

## Fixed
- AutoSell / AutoSpawnerSell: removed the infinite `do/while` / `while(true)` loops (game freeze). One click per tick; closes the screen when nothing is left.
- TunnelBaseFinder: `isBlockPositionValid` empty `while` -> returns the real check; shulker boxes no longer `throw new RuntimeException()`.
- Rtp/TunnelBaseFinder: spider check uses `.equals` instead of `!=`; removed duplicate `toggle()` (module re-enabled itself after disconnect).
- ConfigManager: now reads/writes `config/krypton.json`; fixed ItemSetting load (wrong cast, silently failed).
- AutoInventoryTotem / HoverTotem / AutoTotem: inventory index -> screen-handler slot id (hotbar = 36-44); AutoTotem skips while a chest/GUI is open.
- AuctionSniper: no more negative price when price unreadable; API flag always reset; callback + chat on main thread; snipingItems cleared.
- KeyPearl: aborts when no pearl in hotbar. KeyUtils.isKeyPressed(-1) returns false (no GLFW spam: CordSnapper, KeyPearl, AutoFirework).
- DoubleAnchor: reset clears `step`, per-step delay, reset on disable.
- Freecam: restores FOV effect, view bobbing and perspective; null guards; `KeyInput(key, 0, 0)`.
- AutoEat: releases use key on disable; skips rotten flesh, spider eye, poisonous potato, pufferfish, chorus fruit.
- PositionPacketFilter: registers its settings. ElytraSwap: "Move to slot" searches the inventory for the item.
- AutoTool: counter clamp; documented that cancel() is inert. CordSnapper: skips empty webhook.
- Mixins: null guards for Camera/Entity/TextVisitFactory and `stop()`; FakeInvScreen uses `mouseClicked(Click, boolean)`; WorldChunkMixin takes `int flags`.

## Not changed
- SelfDestruct (not touched).
- RtpBaseFinder / StorageESP per-tick / per-frame scans (performance only, behaviour would change if throttled).
- Unverified 1.21.11 signatures: WorldChunkMixin `int flags`, `KeyInput` ctor, EntityRenderDispatcherMixin, FrustumAccessor, ChunkOcclusionDataBuilderMixin.
