package skid.krypton;

import java.io.File;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import skid.krypton.gui.ClickGUI;
import skid.krypton.manager.ConfigManager;
import skid.krypton.manager.EventManager;
import skid.krypton.module.ModuleManager;

public final class Krypton {
   public ConfigManager configManager;
   public ModuleManager MODULE_MANAGER;
   public EventManager EVENT_BUS;
   public static MinecraftClient mc;
   public String version;
   public static Krypton INSTANCE;
   public boolean shouldPreventClose;
   public ClickGUI GUI;
   public Screen screen;
   public long modified;
   public File jar;

   public Krypton() {
      // mc must be assigned first: modules/GUI read Krypton.mc while they are being constructed.
      mc = MinecraftClient.getInstance();
      INSTANCE = this;
      this.version = " b1.3";
      this.screen = null;
      this.shouldPreventClose = false;
      this.EVENT_BUS = new EventManager();

      try {
         this.MODULE_MANAGER = new ModuleManager();
         this.GUI = new ClickGUI();
         this.configManager = new ConfigManager();
         this.getConfigManager().loadProfile();
      } catch (Throwable t) {
         System.err.println("[Krypton] Initialisation failed - modules/GUI may be unavailable:");
         t.printStackTrace(System.err);
      }

      try {
         this.jar = new File(Krypton.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         this.modified = this.jar.lastModified();
      } catch (Throwable t) {
         // running from a dev environment (directory) - not fatal
      }

   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public ModuleManager getModuleManager() {
      return this.MODULE_MANAGER;
   }

   public EventManager getEventBus() {
      return this.EVENT_BUS;
   }

   public void resetModifiedDate() {
      if (this.jar != null) {
         this.jar.setLastModified(this.modified);
      }

   }
}
