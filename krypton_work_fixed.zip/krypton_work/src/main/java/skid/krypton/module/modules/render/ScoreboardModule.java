package skid.krypton.module.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.text.Text;
import net.minecraft.text.Style;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.text.MutableText;
import net.minecraft.text.TextColor;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.number.NumberFormat;
import net.minecraft.scoreboard.ScoreboardCriterion.RenderType;
import skid.krypton.event.EventListener;
import skid.krypton.event.events.TickEvent;
import skid.krypton.module.Category;
import skid.krypton.module.Module;
import skid.krypton.module.setting.StringSetting;
import skid.krypton.utils.ColorUtil;
import skid.krypton.utils.EncryptedString;
import skid.krypton.utils.PingUtil;

public final class ScoreboardModule extends Module {
   private static final String OBJECTIVE_NAME = "fore_scoreboard";
   private ScoreboardObjective customObjective;
   private ScoreboardObjective originalObjective;
   private boolean wasEnabled = false;
   private final StringSetting Money = new StringSetting(EncryptedString.of("Money"), "67M");
   private final StringSetting Shards = new StringSetting(EncryptedString.of("Shards"), "67");
   private final StringSetting Kills = new StringSetting(EncryptedString.of("Kills"), "67");
   private final StringSetting Deaths = new StringSetting(EncryptedString.of("Deaths"), "67");
   private final StringSetting Keyall = new StringSetting(EncryptedString.of("Key All"), "6m 7s");
   private final StringSetting Playtime = new StringSetting(EncryptedString.of("Playtime"), "6h 7m");
   private final StringSetting Team = new StringSetting(EncryptedString.of("Team"), "Sponge Team");
   private final StringSetting Title = new StringSetting(EncryptedString.of("Title"), "Sponge Protected");
   private final StringSetting Region = new StringSetting(EncryptedString.of("Region"), "Sponge Protected");
   private final Boolean enabled = true;

   public ScoreboardModule() {
      super(EncryptedString.of("Fake Stats"), EncryptedString.of("Custom scoreboard overlay"), -1, Category.RENDER);
      this.addsettings(this.Money, this.Shards, this.Kills, this.Deaths, this.Keyall, this.Playtime, this.Team, this.Title, this.Region);
   }

   private void addsettings(StringSetting money, StringSetting shards, StringSetting kills, StringSetting deaths, StringSetting keyall, StringSetting playtime, StringSetting team, StringSetting title, StringSetting region) {
   }

   public void onEnable() {
      super.onEnable();
      this.wasEnabled = true;
   }

   public void onDisable() {
      super.onDisable();
      this.restoreOriginalScoreboard();
      this.wasEnabled = false;
   }

   @EventListener
   public void onTick(TickEvent tickEvent) {
      if (this.mc.player != null && this.mc.world != null) {
         if (this.enabled && this.isEnabled()) {
            this.updateCustomScoreboard();
         } else if (this.wasEnabled) {
            this.restoreOriginalScoreboard();
            this.wasEnabled = false;
         }

      }
   }

   private void updateCustomScoreboard() {
      Scoreboard scoreboard = this.mc.world.getScoreboard();
      if (this.originalObjective == null) {
         this.originalObjective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
      }

      if (this.customObjective == null) {
         ScoreboardObjective nullableObjective = scoreboard.getNullableObjective("fore_scoreboard");
         if (nullableObjective != null) {
            scoreboard.removeObjective(nullableObjective);
         }

         this.customObjective = scoreboard.addObjective("fore_scoreboard", ScoreboardCriterion.DUMMY, this.parseGradientText("  Protected by 4E  ", "#007CF9", "#00C6F9"), RenderType.INTEGER, true, (NumberFormat)null);
      }

      scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.customObjective);
      scoreboard.removeObjective(this.customObjective);
      this.customObjective = scoreboard.addObjective("fore_scoreboard", ScoreboardCriterion.DUMMY, this.parseGradientText("  Protected by 4E  ", "#007CF9", "#00C6F9"), RenderType.INTEGER, true, (NumberFormat)null);
      scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.customObjective);
      List<Text> scoreboardLines = this.getScoreboardLines();

      for(int i = 0; i < scoreboardLines.size(); ++i) {
         Text text = (Text)scoreboardLines.get(i);
         ScoreAccess orCreateScore = scoreboard.getOrCreateScore(ScoreHolder.fromName("§" + i + "§r"), this.customObjective);
         orCreateScore.setScore(scoreboardLines.size() - i);
         orCreateScore.setDisplayText(text);
      }

      this.customObjective.setDisplayName(this.parseGradientText("   " + this.Title.getValue() + "   ", "#007CF9", "#00C6F9"));
   }

   private List<Text> getScoreboardLines() {
      ArrayList arrayList = new ArrayList();
      arrayList.add(Text.literal(" "));
      arrayList.add(Text.literal("").append(Text.literal("$ ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(64512)).withBold(true))).append(Text.literal("Money ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)))).append(Text.literal(this.Money.getValue()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(64512)))));
      arrayList.add(Text.literal("").append(Text.literal("★ ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(10683385)))).append(Text.literal("Shards ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)))).append(Text.literal(this.Shards.getValue()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(10683385)))));
      arrayList.add(Text.literal("").append(Text.literal("�� ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16515072)))).append(Text.literal("Kills ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)))).append(Text.literal(this.Kills.getValue()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16515072)))));
      arrayList.add(Text.literal("").append(Text.literal("☠ ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16348675)))).append(Text.literal("Deaths ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)))).append(Text.literal(this.Deaths.getValue()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16348675)))));
      arrayList.add(Text.literal("").append(Text.literal("⌛ ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(42236)))).append(Text.literal("Keyall ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)))).append(Text.literal(this.Keyall.getValue()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(42236)))));
      arrayList.add(Text.literal("").append(Text.literal("⌚ ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16573184)))).append(Text.literal("Playtime ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)))).append(Text.literal(this.Playtime.getValue()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16573184)))));
      arrayList.add(Text.literal("").append(Text.literal("�� ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(42236)))).append(Text.literal("Team ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)))).append(Text.literal(this.Team.getValue()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(42236)))));
      arrayList.add(Text.literal(" "));
      arrayList.add(Text.literal("").append(Text.literal(this.Region.getValue() + " (").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(11053224)))).append(Text.literal(PingUtil.getPingString().toString()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(42236)))).append(Text.literal(")").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(11053224)))));
      return arrayList;
   }

   private void restoreOriginalScoreboard() {
      if (this.mc.world != null) {
         Scoreboard scoreboard = this.mc.world.getScoreboard();
         if (this.customObjective != null) {
            scoreboard.removeObjective(this.customObjective);
            this.customObjective = null;
         }

         if (this.originalObjective != null) {
            scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.originalObjective);
            this.originalObjective = null;
         }

      }
   }

   private Text parseGradientText(String str, String str2, String str3) {
      if (str.isEmpty()) {
         return Text.literal("");
      } else {
         Color decode = Color.decode(str2);
         Color decode2 = Color.decode(str3);
         MutableText literal = Text.literal("");

         for(int i = 0; i < str.length(); ++i) {
            Color keyCodec = ColorUtil.keyCodec(decode, decode2, str.length() > 1 ? (float)(i / (str.length() - 1)) : 0.0F);
            literal.append(Text.literal(String.valueOf(str.charAt(i))).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(keyCodec.getRed() << 16 | keyCodec.getGreen() << 8 | keyCodec.getBlue())).withBold(true)));
         }

         return literal;
      }
   }

   private String formatColoredText(String str, String str2) {
      Color decode = Color.decode(str2);
      StringBuilder sb = new StringBuilder();

      for(int i = 0; i < str.length(); ++i) {
         sb.append(this.formatMinecraftColor(decode));
         sb.append(str.charAt(i));
      }

      return sb.toString();
   }

   private String formatMinecraftColor(Color color) {
      String format = String.format("%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
      StringBuilder sb = new StringBuilder("§x");

      for(char c : format.toCharArray()) {
         sb.append("§").append(c);
      }

      return sb.toString();
   }
}
