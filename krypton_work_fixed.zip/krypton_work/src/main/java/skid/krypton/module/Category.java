package skid.krypton.module;

import skid.krypton.utils.EncryptedString;

public enum Category {
   COMBAT(EncryptedString.of("Combat")),
   MISC(EncryptedString.of("Misc")),
   DONUT(EncryptedString.of("Donut")),
   RENDER(EncryptedString.of("Render")),
   CLIENT(EncryptedString.of("Client"));

   public final CharSequence name;

   private Category(final CharSequence name) {
      this.name = name;
   }

   // $FF: synthetic method
   private static Category[] $values() {
      return new Category[]{COMBAT, MISC, DONUT, RENDER, CLIENT};
   }
}
