package skid.krypton.module.modules.misc;

import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.item.Items;
import skid.krypton.event.EventListener;
import skid.krypton.event.events.TickEvent;
import skid.krypton.module.Category;
import skid.krypton.module.Module;
import skid.krypton.module.setting.BindSetting;
import skid.krypton.module.setting.BooleanSetting;
import skid.krypton.module.setting.NumberSetting;
import skid.krypton.module.setting.Setting;
import skid.krypton.utils.EncryptedString;
import skid.krypton.utils.InventoryUtil;
import skid.krypton.utils.KeyUtils;

public final class KeyPearl extends Module {
   private final BindSetting activateKey = new BindSetting(EncryptedString.of("Activate Key"), -1, false);
   private final NumberSetting throwDelay = new NumberSetting(EncryptedString.of("Delay"), (double)0.0F, (double)20.0F, (double)0.0F, (double)1.0F);
   private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
   private final NumberSetting switchBackDelay = (new NumberSetting(EncryptedString.of("Switch Delay"), (double)0.0F, (double)20.0F, (double)0.0F, (double)1.0F)).getValue(EncryptedString.of("Delay after throwing pearl before switching back"));
   private boolean isActivated;
   private boolean hasThrown;
   private int currentThrowDelay;
   private int previousSlot;
   private int currentSwitchBackDelay;

   public KeyPearl() {
      super(EncryptedString.of("Key Pearl"), EncryptedString.of("Switches to an ender pearl and throws it when you press a bind"), -1, Category.MISC);
      this.addSettings(new Setting[]{this.activateKey, this.throwDelay, this.switchBack, this.switchBackDelay});
   }

   public void onEnable() {
      this.resetState();
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.currentScreen == null) {
         if (KeyUtils.isKeyPressed(this.activateKey.getValue())) {
            this.isActivated = true;
         }

         if (this.isActivated) {
            if (this.previousSlot == -1) {
               this.previousSlot = this.mc.player.getInventory().getSelectedSlot();
            }

            if (!InventoryUtil.swap(Items.ENDER_PEARL) && !this.hasThrown) {
               // no pearl in the hotbar: abort instead of right-clicking whatever is held
               this.resetState();
               return;
            }

            if (this.currentThrowDelay < this.throwDelay.getIntValue()) {
               ++this.currentThrowDelay;
               return;
            }

            if (!this.hasThrown) {
               ActionResult interactItem = this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
               if (interactItem instanceof net.minecraft.util.ActionResult.Success success && success.shouldSwingHand()) {
                  this.mc.player.swingHand(Hand.MAIN_HAND);
               }

               this.hasThrown = true;
            }

            if (this.switchBack.getValue()) {
               this.handleSwitchBack();
            } else {
               this.resetState();
            }
         }

      }
   }

   private void handleSwitchBack() {
      if (this.currentSwitchBackDelay < this.switchBackDelay.getIntValue()) {
         ++this.currentSwitchBackDelay;
      } else {
         InventoryUtil.swap(this.previousSlot);
         this.resetState();
      }
   }

   private void resetState() {
      this.previousSlot = -1;
      this.currentThrowDelay = 0;
      this.currentSwitchBackDelay = 0;
      this.isActivated = false;
      this.hasThrown = false;
   }
}
