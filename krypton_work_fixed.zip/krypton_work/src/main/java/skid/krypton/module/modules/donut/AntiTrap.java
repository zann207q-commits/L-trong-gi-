package skid.krypton.module.modules.donut;

import java.util.ArrayList;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.Entity.RemovalReason;
import skid.krypton.event.EventListener;
import skid.krypton.event.events.EntitySpawnEvent;
import skid.krypton.module.Category;
import skid.krypton.module.Module;
import skid.krypton.module.setting.Setting;
import skid.krypton.utils.EncryptedString;

public final class AntiTrap extends Module {
   public AntiTrap() {
      super(EncryptedString.of("Anti Trap"), EncryptedString.of("Module that helps you escape Polish traps"), -1, Category.DONUT);
      this.addSettings(new Setting[0]);
   }

   public void onEnable() {
      this.removeTrapEntities();
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onEntitySpawn(EntitySpawnEvent entitySpawnEvent) {
      if (this.isTrapEntity(entitySpawnEvent.packet.getEntityType())) {
         entitySpawnEvent.cancel();
      }

   }

   private void removeTrapEntities() {
      if (this.mc.world != null) {
         ArrayList<Entity> trapEntities = new ArrayList();
         this.mc.world.getEntities().forEach((entity) -> {
            if (entity != null && this.isTrapEntity(entity.getType())) {
               trapEntities.add(entity);
            }

         });
         trapEntities.forEach((trapEntity) -> {
            if (!trapEntity.isRemoved()) {
               trapEntity.remove(RemovalReason.DISCARDED);
            }

         });
      }
   }

   private boolean isTrapEntity(EntityType<?> entityType) {
      return entityType != null && (entityType.equals(EntityType.ARMOR_STAND) || entityType.equals(EntityType.CHEST_MINECART));
   }
}
