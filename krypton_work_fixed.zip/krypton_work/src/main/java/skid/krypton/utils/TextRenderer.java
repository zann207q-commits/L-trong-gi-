package skid.krypton.utils;

import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

/** Text helpers. The GUI works in raw framebuffer pixels, so vanilla text is drawn at 2x. The custom TTF renderer was removed (needed the old GL pipeline). */
public final class TextRenderer {
   public static void drawString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      Matrix3x2fStack m = ctx.getMatrices();
      m.pushMatrix();
      m.scale(2.0F, 2.0F);
      ctx.drawText(skid.krypton.Krypton.mc.textRenderer, text.toString(), x / 2, y / 2, color, false);
      m.popMatrix();
   }

   public static int getWidth(CharSequence text) {
      return skid.krypton.Krypton.mc.textRenderer.getWidth(text.toString()) * 2;
   }

   public static void drawCenteredString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawString(text, ctx, x - getWidth(text) / 2, y, color);
   }

   public static void drawLargeString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawString(text, ctx, x, y, color);
   }

   public static void drawCenteredMinecraftText(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawCenteredString(text, ctx, x, y, color);
   }
}
