package skid.krypton.gui.components;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import skid.krypton.Krypton;
import skid.krypton.gui.CategoryWindow;
import skid.krypton.gui.Component;
import skid.krypton.module.Module;
import skid.krypton.module.setting.BindSetting;
import skid.krypton.module.setting.BooleanSetting;
import skid.krypton.module.setting.ItemSetting;
import skid.krypton.module.setting.MinMaxSetting;
import skid.krypton.module.setting.ModeSetting;
import skid.krypton.module.setting.NumberSetting;
import skid.krypton.module.setting.Setting;
import skid.krypton.module.setting.StringSetting;
import skid.krypton.utils.Animation;
import skid.krypton.utils.ColorUtil;
import skid.krypton.utils.MathUtil;
import skid.krypton.utils.RenderUtils;
import skid.krypton.utils.TextRenderer;
import skid.krypton.utils.Utils;

public final class ModuleButton {
   public List<Component> settings = new ArrayList();
   public CategoryWindow parent;
   public Module module;
   public int offset;
   public boolean extended;
   public int settingOffset;
   public Color currentColor;
   public Color currentAlpha;
   public Animation animation = new Animation((double)0.0F);
   private final float CORNER_RADIUS = 6.0F;
   private final Color ACCENT_COLOR = new Color(65, 105, 225);
   private final Color HOVER_COLOR = new Color(255, 255, 255, 20);
   private final Color ENABLED_COLOR = new Color(120, 190, 255);
   private final Color DISABLED_COLOR = new Color(180, 180, 180);
   private final Color DESCRIPTION_BG = new Color(40, 40, 40, 200);
   private float hoverAnimation = 0.0F;
   private float enabledAnimation = 0.0F;
   private final float expandAnimation = 0.0F;

   public ModuleButton(CategoryWindow parent, Module module, int offset) {
      this.parent = parent;
      this.module = module;
      this.offset = offset;
      this.extended = false;
      this.settingOffset = parent.getHeight();

      for(Object next : module.getSettings()) {
         if (next instanceof BooleanSetting) {
            this.settings.add(new Checkbox(this, (Setting)next, this.settingOffset));
         } else if (next instanceof NumberSetting) {
            this.settings.add(new NumberBox(this, (Setting)next, this.settingOffset));
         } else if (next instanceof ModeSetting) {
            this.settings.add(new ModeBox(this, (Setting)next, this.settingOffset));
         } else if (next instanceof BindSetting) {
            this.settings.add(new Keybind(this, (Setting)next, this.settingOffset));
         } else if (next instanceof StringSetting) {
            this.settings.add(new TextBox(this, (Setting)next, this.settingOffset));
         } else if (next instanceof MinMaxSetting) {
            this.settings.add(new Slider(this, (Setting)next, this.settingOffset));
         } else if (next instanceof ItemSetting) {
            this.settings.add(new ItemBox(this, (Setting)next, this.settingOffset));
         }

         this.settingOffset += parent.getHeight();
      }

   }

   public void render(DrawContext drawContext, int n, int n2, float n3) {
      if (this.parent.getY() + this.offset <= MinecraftClient.getInstance().getWindow().getHeight()) {
         Iterator<Component> iterator = this.settings.iterator();

         while(iterator.hasNext()) {
            ((Component)iterator.next()).onUpdate();
         }

         this.updateAnimations(n, n2, n3);
         int x = this.parent.getX();
         int n4 = this.parent.getY() + this.offset;
         int width = this.parent.getWidth();
         int height = this.parent.getHeight();
         this.renderButtonBackground(drawContext, x, n4, width, height);
         this.renderIndicator(drawContext, x, n4, height);
         this.renderModuleInfo(drawContext, x, n4, width, height);
         if (this.extended) {
            this.renderSettings(drawContext, n, n2, n3);
         }

         if (this.isHovered((double)n, (double)n2) && !this.parent.dragging) {
            Krypton.INSTANCE.GUI.setTooltip(this.module.getDescription(), n + 10, n2 + 10);
         }

      }
   }

   private void updateAnimations(int n, int n2, float n3) {
      float n4 = n3 * 0.05F;
      float n5;
      if (this.isHovered((double)n, (double)n2) && !this.parent.dragging) {
         n5 = 1.0F;
      } else {
         n5 = 0.0F;
      }

      this.hoverAnimation = (float)MathUtil.exponentialInterpolate((double)this.hoverAnimation, (double)n5, (double)0.05F, (double)n4);
      float n6;
      if (this.module.isEnabled()) {
         n6 = 1.0F;
      } else {
         n6 = 0.0F;
      }

      this.enabledAnimation = (float)MathUtil.exponentialInterpolate((double)this.enabledAnimation, (double)n6, (double)0.005F, (double)n4);
      this.enabledAnimation = (float)MathUtil.clampValue((double)this.enabledAnimation, (double)0.0F, (double)1.0F);
   }

   private void renderButtonBackground(DrawContext drawContext, int n, int n2, int n3, int n4) {
      Color a = ColorUtil.a(new Color(25, 25, 30, 230), this.HOVER_COLOR, this.hoverAnimation);
      boolean b = this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) == this;
      if (b && !this.extended) {
         RenderUtils.renderRoundedQuad(drawContext, a, (double)n, (double)n2, (double)(n + n3), (double)(n2 + n4), (double)0.0F, (double)0.0F, (double)6.0F, (double)6.0F, (double)50.0F);
      } else if (b && this.extended) {
         RenderUtils.renderRoundedQuad(drawContext, a, (double)n, (double)n2, (double)(n + n3), (double)(n2 + n4), (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)50.0F);
      } else {
         drawContext.fill(n, n2, n + n3, n2 + n4, a.getRGB());
      }

      if (this.parent.moduleButtons.indexOf(this) > 0) {
         drawContext.fill(n + 4, n2, n + n3 - 4, n2 + 1, (new Color(60, 60, 65, 100)).getRGB());
      }

   }

   private void renderIndicator(DrawContext drawContext, int n, int n2, int n3) {
      Color color;
      if (this.module.isEnabled()) {
         color = Utils.getMainColor(255, Krypton.INSTANCE.getModuleManager().a(this.module.getCategory()).indexOf(this.module));
      } else {
         color = this.ACCENT_COLOR;
      }

      float n4 = 5.0F * this.enabledAnimation;
      if (n4 > 0.1F) {
         RenderUtils.renderRoundedQuad(drawContext, ColorUtil.a(this.DISABLED_COLOR, color, this.enabledAnimation), (double)n, (double)(n2 + 2), (double)((float)n + n4), (double)(n2 + n3 - 2), (double)1.5F, (double)1.5F, (double)1.5F, (double)1.5F, (double)60.0F);
      }

   }

   private void renderModuleInfo(DrawContext drawContext, int n, int n2, int n3, int n4) {
      TextRenderer.drawString(this.module.getName(), drawContext, n + 10, n2 + n4 / 2 - 6, ColorUtil.a(this.DISABLED_COLOR, this.ENABLED_COLOR, this.enabledAnimation).getRGB());
      int n5 = n + n3 - 40;
      int n6 = n2 + n4 / 2 - 6;
      RenderUtils.renderRoundedQuad(drawContext, ColorUtil.a(new Color(60, 60, 65, 200), new Color(65, 105, 225, 100), this.enabledAnimation), (double)n5, (double)n6, (double)((float)n5 + 24.0F), (double)((float)n6 + 12.0F), (double)6.0F, (double)6.0F, (double)6.0F, (double)6.0F, (double)50.0F);
      float n7 = (float)n5 + 6.0F + 12.0F * this.enabledAnimation;
      RenderUtils.renderCircle(drawContext, ColorUtil.a(new Color(180, 180, 180), this.ENABLED_COLOR, this.enabledAnimation), (double)n7, (double)((float)n6 + 6.0F), (double)5.0F, 12);
      if (this.module.isEnabled()) {
         RenderUtils.renderCircle(drawContext, new Color(this.ENABLED_COLOR.getRed(), this.ENABLED_COLOR.getGreen(), this.ENABLED_COLOR.getBlue(), 30), (double)n7, (double)((float)n6 + 6.0F), (double)8.0F, 16);
      }

   }

   private void renderSettings(DrawContext drawContext, int n, int n2, float n3) {
      int n4 = this.parent.getY() + this.offset + this.parent.getHeight();
      double animation = this.animation.getAnimation();
      if ((int)animation < 1) {
         return;
      }

      drawContext.enableScissor(this.parent.getX(), n4, this.parent.getX() + this.parent.getWidth(), n4 + (int)animation);
      Iterator<Component> iterator = this.settings.iterator();

      while(iterator.hasNext()) {
         ((Component)iterator.next()).render(drawContext, n, n2 - n4, n3);
      }

      this.renderSliderControls(drawContext);
      drawContext.disableScissor();
   }

   private void renderSliderControls(DrawContext drawContext) {
      for(Component next : this.settings) {
         if (next instanceof NumberBox numberBox) {
            this.renderModernSliderKnob(drawContext, (double)next.parentX() + Math.max(numberBox.lerpedOffsetX, (double)2.5F), (double)(next.parentY() + numberBox.offset + next.parentOffset()) + (double)27.5F, numberBox.currentColor1);
         } else if (next instanceof Slider) {
            this.renderModernSliderKnob(drawContext, (double)next.parentX() + Math.max(((Slider)next).lerpedOffsetMinX, (double)2.5F), (double)(next.parentY() + next.offset + next.parentOffset()) + (double)27.5F, ((Slider)next).accentColor1);
            this.renderModernSliderKnob(drawContext, (double)next.parentX() + Math.max(((Slider)next).lerpedOffsetMaxX, (double)2.5F), (double)(next.parentY() + next.offset + next.parentOffset()) + (double)27.5F, ((Slider)next).accentColor1);
         }
      }

   }

   private void renderModernSliderKnob(DrawContext drawContext, double n, double n2, Color color) {
      RenderUtils.renderCircle(drawContext, new Color(0, 0, 0, 100), n, n2, (double)7.0F, 18);
      RenderUtils.renderCircle(drawContext, color, n, n2, (double)5.5F, 16);
      RenderUtils.renderCircle(drawContext, new Color(255, 255, 255, 70), n, n2 - (double)1.0F, (double)3.0F, 12);
   }

   public void onExtend() {
      for(Iterator<ModuleButton> iterator = this.parent.moduleButtons.iterator(); iterator.hasNext(); ((ModuleButton)iterator.next()).extended = false) {
      }

   }

   public void keyPressed(int n, int n2, int n3) {
      Iterator<Component> iterator = this.settings.iterator();

      while(iterator.hasNext()) {
         ((Component)iterator.next()).keyPressed(n, n2, n3);
      }

   }

   public void mouseDragged(double n, double n2, int n3, double n4, double n5) {
      if (this.extended) {
         Iterator<Component> iterator = this.settings.iterator();

         while(iterator.hasNext()) {
            ((Component)iterator.next()).mouseDragged(n, n2, n3, n4, n5);
         }
      }

   }

   public void mouseClicked(double n, double n2, int button) {
      if (this.isHovered(n, n2)) {
         if (button == 0) {
            int n4 = this.parent.getX() + this.parent.getWidth() - 30;
            int n5 = this.parent.getY() + this.offset + this.parent.getHeight() / 2 - 3;
            if (n >= (double)n4 && n <= (double)(n4 + 12) && n2 >= (double)n5 && n2 <= (double)(n5 + 6)) {
               this.module.toggle();
            } else if (!this.module.getSettings().isEmpty() && n > (double)(this.parent.getX() + this.parent.getWidth() - 25)) {
               if (!this.extended) {
                  this.onExtend();
               }

               this.extended = !this.extended;
            } else {
               this.module.toggle();
            }
         } else if (button == 1) {
            if (this.module.getSettings().isEmpty()) {
               return;
            }

            if (!this.extended) {
               this.onExtend();
            }

            this.extended = !this.extended;
         }
      }

      if (this.extended) {
         for(Component setting : this.settings) {
            setting.mouseClicked(n, n2, button);
         }
      }

   }

   public void onGuiClose() {
      this.currentAlpha = null;
      this.currentColor = null;
      this.hoverAnimation = 0.0F;
      float enabledAnimation;
      if (this.module.isEnabled()) {
         enabledAnimation = 1.0F;
      } else {
         enabledAnimation = 0.0F;
      }

      this.enabledAnimation = enabledAnimation;
      Iterator<Component> iterator = this.settings.iterator();

      while(iterator.hasNext()) {
         ((Component)iterator.next()).onGuiClose();
      }

   }

   public void mouseReleased(double n, double n2, int n3) {
      Iterator<Component> iterator = this.settings.iterator();

      while(iterator.hasNext()) {
         ((Component)iterator.next()).mouseReleased(n, n2, n3);
      }

   }

   public boolean isHovered(double n, double n2) {
      return n > (double)this.parent.getX() && n < (double)(this.parent.getX() + this.parent.getWidth()) && n2 > (double)(this.parent.getY() + this.offset) && n2 < (double)(this.parent.getY() + this.offset + this.parent.getHeight());
   }
}
