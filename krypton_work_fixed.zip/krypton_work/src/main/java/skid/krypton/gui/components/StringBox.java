package skid.krypton.gui.components;

import java.awt.Color;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import org.lwjgl.glfw.GLFW;
import skid.krypton.module.modules.client.Krypton;
import skid.krypton.module.setting.StringSetting;
import skid.krypton.utils.MathUtil;
import skid.krypton.utils.RenderUtils;
import skid.krypton.utils.TextRenderer;
import skid.krypton.utils.Utils;

class StringBox extends Screen {
   private final StringSetting setting;
   private String content;
   private int cursorPosition;
   private int selectionStart;
   private final boolean selecting;
   private long lastCursorBlink;
   private boolean cursorVisible;
   private final int CURSOR_BLINK_SPEED = 530;
   final TextBox this$0;

   public StringBox(TextBox this$0, StringSetting setting) {
      super(Text.empty());
      this.this$0 = this$0;
      this.selectionStart = -1;
      this.selecting = false;
      this.lastCursorBlink = 0L;
      this.cursorVisible = true;
      this.setting = setting;
      this.content = setting.getValue();
      this.cursorPosition = this.content.length();
   }

   public void render(DrawContext drawContext, int n, int n2, float n3) {
      RenderUtils.unscaledProjection(drawContext);
      super.render(drawContext, n * (int)MinecraftClient.getInstance().getWindow().getScaleFactor(), n2 * (int)MinecraftClient.getInstance().getWindow().getScaleFactor(), n3);
      long currentTimeMillis = System.currentTimeMillis();
      if (currentTimeMillis - this.lastCursorBlink > 530L) {
         this.cursorVisible = !this.cursorVisible;
         this.lastCursorBlink = currentTimeMillis;
      }

      int width = this.this$0.mc.getWindow().getWidth();
      int height = this.this$0.mc.getWindow().getHeight();
      int a;
      if (Krypton.renderBackground.getValue()) {
         a = 180;
      } else {
         a = 0;
      }

      drawContext.fill(0, 0, width, height, (new Color(0, 0, 0, a)).getRGB());
      int width2 = this.this$0.mc.getWindow().getWidth();
      int height2 = this.this$0.mc.getWindow().getHeight();
      int a2 = MathUtil.clampInt(TextRenderer.getWidth(this.content) + 80, 600, this.this$0.mc.getWindow().getWidth() - 100);
      int n4 = (width2 - a2) / 2;
      int n5 = (height2 - 120) / 2;
      RenderUtils.renderRoundedQuad(drawContext, new Color(30, 30, 35, 240), (double)n4, (double)n5, (double)(n4 + a2), (double)(n5 + 120), (double)8.0F, (double)8.0F, (double)8.0F, (double)8.0F, (double)20.0F);
      RenderUtils.renderRoundedQuad(drawContext, new Color(40, 40, 45, 255), (double)n4, (double)n5, (double)(n4 + a2), (double)(n5 + 30), (double)8.0F, (double)8.0F, (double)0.0F, (double)0.0F, (double)20.0F);
      drawContext.fill(n4, n5 + 30, n4 + a2, n5 + 31, Utils.getMainColor(255, 1).getRGB());
      TextRenderer.drawCenteredString(this.setting.getName(), drawContext, n4 + a2 / 2, n5 + 8, (new Color(245, 245, 245, 255)).getRGB());
      int n6 = n4 + 20;
      int n7 = n5 + 50;
      int n8 = a2 - 40;
      RenderUtils.renderRoundedQuad(drawContext, new Color(20, 20, 25, 255), (double)n6, (double)n7, (double)(n6 + n8), (double)(n7 + 30), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)20.0F);
      RenderUtils.renderRoundedOutline(drawContext, new Color(60, 60, 65, 255), (double)n6, (double)n7, (double)(n6 + n8), (double)(n7 + 30), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)1.0F, (double)20.0F);
      String content = this.content;
      int n9 = n6 + 10;
      int n10 = n7 + 10;
      String substring = this.content.substring(0, this.cursorPosition);
      content.substring(this.cursorPosition);
      int n11 = n9 + TextRenderer.getWidth(substring);
      if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
         int min = Math.min(this.selectionStart, this.cursorPosition);
         int max = Math.max(this.selectionStart, this.cursorPosition);
         String substring2 = content.substring(0, min);
         String substring3 = content.substring(min, max);
         String substring4 = content.substring(max);
         int a3 = TextRenderer.getWidth(substring2);
         int a4 = TextRenderer.getWidth(substring3);
         TextRenderer.drawString(substring2, drawContext, n9, n10, (new Color(245, 245, 245, 255)).getRGB());
         drawContext.fill(n9 + a3, n10 - 2, n9 + a3 + a4, n10 + 14, Utils.getMainColor(100, 1).getRGB());
         TextRenderer.drawString(substring3, drawContext, n9 + a3, n10, (new Color(255, 255, 255, 255)).getRGB());
         TextRenderer.drawString(substring4, drawContext, n9 + a3 + a4, n10, (new Color(245, 245, 245, 255)).getRGB());
      } else {
         TextRenderer.drawString(content, drawContext, n9, n10, (new Color(245, 245, 245, 255)).getRGB());
         if (this.cursorVisible) {
            drawContext.fill(n11, n10 - 2, n11 + 1, n10 + 14, (new Color(245, 245, 245, 255)).getRGB());
         }
      }

      int n12 = n5 + 120 - 30;
      int n13 = n4 + a2 - 80 - 20;
      int n14 = n13 - 80 - 10;
      RenderUtils.renderRoundedQuad(drawContext, Utils.getMainColor(255, 1), (double)n13, (double)n12, (double)(n13 + 80), (double)(n12 + 25), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)20.0F);
      TextRenderer.drawCenteredString("Save", drawContext, n13 + 40, n12 + 6, (new Color(245, 245, 245, 255)).getRGB());
      RenderUtils.renderRoundedQuad(drawContext, new Color(60, 60, 65, 255), (double)n14, (double)n12, (double)(n14 + 80), (double)(n12 + 25), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)20.0F);
      TextRenderer.drawCenteredString("Cancel", drawContext, n14 + 40, n12 + 6, (new Color(245, 245, 245, 255)).getRGB());
      TextRenderer.drawString("Press Escape to save and close", drawContext, n4 + 20, n5 + 120 - 20, (new Color(150, 150, 150, 200)).getRGB());
      RenderUtils.scaledProjection(drawContext);
   }

   public void mouseMoved(double n, double n2) {
      super.mouseMoved(n, n2);
      this.cursorVisible = true;
      this.lastCursorBlink = System.currentTimeMillis();
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      double n4 = click.x() * MinecraftClient.getInstance().getWindow().getScaleFactor();
      double n5 = click.y() * MinecraftClient.getInstance().getWindow().getScaleFactor();
      int width = this.this$0.mc.getWindow().getWidth();
      int height = this.this$0.mc.getWindow().getHeight();
      int max = Math.max(600, MathUtil.clampInt(TextRenderer.getWidth(this.content) + 80, 400, this.this$0.mc.getWindow().getWidth() - 100));
      int n6 = (height - 120) / 2 + 120 - 30;
      int n7 = (width - max) / 2 + max - 80 - 20;
      if (this.isHovered(n4, n5, n7, n6, 80, 25)) {
         this.setting.setValue(this.content.trim());
         this.this$0.mc.setScreen(skid.krypton.Krypton.INSTANCE.GUI);
         return true;
      } else if (this.isHovered(n4, n5, n7 - 80 - 10, n6, 80, 25)) {
         this.this$0.mc.setScreen(skid.krypton.Krypton.INSTANCE.GUI);
         return true;
      } else {
         return super.mouseClicked(click, doubled);
      }
   }

   private boolean isHovered(double n, double n2, int n3, int n4, int n5, int n6) {
      return n >= (double)n3 && n <= (double)(n3 + n5) && n2 >= (double)n4 && n2 <= (double)(n4 + n6);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int n = input.key();
      this.cursorVisible = true;
      this.lastCursorBlink = System.currentTimeMillis();
      if (n == 256) {
         this.setting.setValue(this.content.trim());
         this.this$0.mc.setScreen(skid.krypton.Krypton.INSTANCE.GUI);
         return true;
      } else if (n == 257) {
         this.setting.setValue(this.content.trim());
         this.this$0.mc.setScreen(skid.krypton.Krypton.INSTANCE.GUI);
         return true;
      } else if (isPaste(n)) {
         String clipboard = this.this$0.mc.keyboard.getClipboard();
         if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
            int min = Math.min(this.selectionStart, this.cursorPosition);
            this.content = this.content.substring(0, min) + clipboard + this.content.substring(Math.max(this.selectionStart, this.cursorPosition));
            this.cursorPosition = min + clipboard.length();
         } else {
            this.content = this.content.substring(0, this.cursorPosition) + clipboard + this.content.substring(this.cursorPosition);
            this.cursorPosition += clipboard.length();
         }

         this.selectionStart = -1;
         return true;
      } else if (isCopy(n)) {
         if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
            GLFW.glfwSetClipboardString(this.this$0.mc.getWindow().getHandle(), this.content.substring(Math.min(this.selectionStart, this.cursorPosition), Math.max(this.selectionStart, this.cursorPosition)));
         }

         return true;
      } else if (isCut(n)) {
         if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
            int min2 = Math.min(this.selectionStart, this.cursorPosition);
            int max = Math.max(this.selectionStart, this.cursorPosition);
            GLFW.glfwSetClipboardString(this.this$0.mc.getWindow().getHandle(), this.content.substring(min2, max));
            String var11 = this.content.substring(0, min2);
            this.content = var11 + this.content.substring(max);
            this.cursorPosition = min2;
            this.selectionStart = -1;
         }

         return true;
      } else if (n == 259) {
         if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
            int min3 = Math.min(this.selectionStart, this.cursorPosition);
            this.content = this.content.substring(0, min3) + this.content.substring(Math.max(this.selectionStart, this.cursorPosition));
            this.cursorPosition = min3;
            this.selectionStart = -1;
         } else if (this.cursorPosition > 0) {
            String var10 = this.content.substring(0, this.cursorPosition - 1);
            this.content = var10 + this.content.substring(this.cursorPosition);
            --this.cursorPosition;
         }

         return true;
      } else if (n != 261) {
         if (n == 263) {
            if ((input.modifiers() & 1) != 0) {
               if (this.selectionStart == -1) {
                  this.selectionStart = this.cursorPosition;
               }
            } else {
               this.selectionStart = -1;
            }

            if (this.cursorPosition > 0) {
               --this.cursorPosition;
            }

            return true;
         } else if (n == 262) {
            if ((input.modifiers() & 1) != 0) {
               if (this.selectionStart == -1) {
                  this.selectionStart = this.cursorPosition;
               }
            } else {
               this.selectionStart = -1;
            }

            if (this.cursorPosition < this.content.length()) {
               ++this.cursorPosition;
            }

            return true;
         } else if (n == 268) {
            if ((input.modifiers() & 1) != 0) {
               if (this.selectionStart == -1) {
                  this.selectionStart = this.cursorPosition;
               }
            } else {
               this.selectionStart = -1;
            }

            this.cursorPosition = 0;
            return true;
         } else if (n == 269) {
            if ((input.modifiers() & 1) != 0) {
               if (this.selectionStart == -1) {
                  this.selectionStart = this.cursorPosition;
               }
            } else {
               this.selectionStart = -1;
            }

            this.cursorPosition = this.content.length();
            return true;
         } else {
            return super.keyPressed(input);
         }
      } else {
         if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
            int min4 = Math.min(this.selectionStart, this.cursorPosition);
            this.content = this.content.substring(0, min4) + this.content.substring(Math.max(this.selectionStart, this.cursorPosition));
            this.cursorPosition = min4;
            this.selectionStart = -1;
         } else if (this.cursorPosition < this.content.length()) {
            String var10001 = this.content.substring(0, this.cursorPosition);
            this.content = var10001 + this.content.substring(this.cursorPosition + 1);
         }

         return true;
      }
   }

   @Override
   public boolean charTyped(CharInput charInput) {
      String c = new String(Character.toChars(charInput.codepoint()));
      if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
         int min = Math.min(this.selectionStart, this.cursorPosition);
         this.content = this.content.substring(0, min) + c + this.content.substring(Math.max(this.selectionStart, this.cursorPosition));
         this.cursorPosition = min + c.length();
         this.selectionStart = -1;
      } else {
         this.content = this.content.substring(0, this.cursorPosition) + c + this.content.substring(this.cursorPosition);
         this.cursorPosition += c.length();
      }

      this.cursorVisible = true;
      this.lastCursorBlink = System.currentTimeMillis();
      return true;
   }

   public static boolean isPaste(int n) {
      return n == 86 && hasControlDown();
   }

   public static boolean isCopy(int n) {
      return n == 67 && hasControlDown();
   }

   public static boolean isCut(int n) {
      return n == 88 && hasControlDown();
   }

   public static boolean hasControlDown() {
      int n;
      if (System.getProperty("os.name", "").toLowerCase().contains("mac")) {
         n = GLFW.glfwGetKey(MinecraftClient.getInstance().getWindow().getHandle(), 343);
      } else {
         n = GLFW.glfwGetKey(MinecraftClient.getInstance().getWindow().getHandle(), 341);
      }

      return n == 1;
   }

   public void renderBackground(DrawContext drawContext, int n, int n2, float n3) {
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }
}
