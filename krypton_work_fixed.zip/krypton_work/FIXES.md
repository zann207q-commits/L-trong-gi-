# Fix pass 3 — Minecraft 1.21.11 (Yarn 1.21.11+build.4)

NOT compiled or run (no Gradle / no network in the review environment). Everything below was checked
against the Yarn 1.21.11 docs where noted; build with `gradlew build` on JDK 21 and send back the log.

## Runtime bugs fixed (would have broken modules even after compiling)
- KeyboardMixin / MouseMixin used the pre-1.21.9 signatures -> keybinds, ClickGUI toggle and every
  key-activated module were dead. Now `Keyboard.onKey(long,int,KeyInput)` / `Mouse.onMouseButton(long,MouseInput,int)` (verified).
- TickEvent was fired twice per tick (MinecraftClientMixin + ClientPlayerEntityMixin) -> every module ran 2x. Removed the duplicate.
- Krypton ctor: `mc` was assigned last and any exception was swallowed -> half-initialised client. Reordered + errors printed.
- CameraMixin: `Camera.update` takes `World` (not `BlockView`) in 1.21.11 -> Freecam hook would not apply (verified).
- PlayerESP / StorageESP: NPE every frame when `crosshairTarget` is null (tracers). Fixed; PlayerESP rewritten.
- client.mixins.json: `defaultRequire` 1 -> 0 so one stale hook cannot crash the game on launch. Check latest.log for Mixin warnings.

## Port work
- GUI input (ClickGUI, StringBox, ItemFilter) moved to `KeyInput` / `Click` / `CharInput` (1.21.9+ API).
- RenderUtils rewritten on `DrawContext.fill` (rounded rects/circles/outlines, item draw) - old code used removed
  RenderSystem/Tessellator and contained raw intermediary names (class_286, method_34540, field_4344).
- 3D overlay: renderLine / renderFilledBox project world points to screen (Render3DEvent now fired from InGameHudMixin).
  Depth is ignored (through-walls) and FOV is the option value (no sprint FOV change).
- TextRenderer: vanilla font at 2x. Custom TTF renderer (GlyphPage*) deleted; "Custom Font" setting is now a no-op.
- ChunkFinder toast replaced by a chat message. TargetHUD skin draw uses `SkinTextures` overload (verified).
- ModuleButton scissor via `DrawContext.enableScissor`.

## Disabled
- NetheriteFinder, Ore, HeightContextMixin and the 3 placement-modifier accessors moved to `_disabled_needs_port/`
  (need ChunkRandom / PlacedFeatureIndexer worldgen port).

## Untouched / unverified
- SelfDestruct (not modified, not reviewed further).
- EntityRenderDispatcherMixin (hitbox render), TextVisitFactoryMixin, ChunkOcclusionDataBuilderMixin, Frustum accessor, WorldChunkMixin:
  targets not checked against 1.21.11 mappings.
- Combat/donut/misc modules were only checked for event wiring, not line-by-line against 1.21.11 APIs.
