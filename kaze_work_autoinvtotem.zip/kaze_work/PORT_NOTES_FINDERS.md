# Krispy -> Kaze port: Prime Chunk Finder, Chunk Finder Better, Sus Chunk V2, Lucky Finder

Bodies of the detection code are the Krispy originals, only re-targeted to Kaze's Module / Setting / EventManager.

## Modules (package skid.kaze.module.modules.donutfinding, category DONUT_FINDING)
| Kaze class | Krispy class | Notes |
|---|---|---|
| PrimeChunkFinder | PrimeChunkFinderModule | light-diff + redstone-below-Y0 detection, tracers, stacked toast |
| ChunkFinderKrispy ("Chunk Finder Better") | ChunkFinderBetterModule | stone-shaft scan, Calm/Aggressive, heat spreading |
| SusChunkV2 | SusChunkV2Module | geode light-pattern scoring + peak finder |
| LuckyFinder | LuckyFinderModule | random green platform, toast + sound |

## New support code
- events: `LightUpdateEvent`, `BlockUpdateEvent`, `PostTickEvent` (+ `ClientWorldMixin`, hooks in `ClientPlayNetworkHandlerMixin`
  and `MinecraftClientMixin`, `ClientWorldMixin` registered in client.mixins.json)
- utils/chunks: `ChunkLightSampler`, `ChunkPeakFinder`, `ChunkPlateRenderer`, `ChunkAreas`, `ChunkOverlay`, `LevelUtil`, `ColorSettings`
- utils/toast: `ChunkFlagToast`, `LuckyFinderToast`, `StackedNotificationToast`; utils/`RetryDeadline`
- assets/kaze: `sounds.json`, `sounds/lucky_flag.ogg`, `sounds/chunk_flag.ogg`, `textures/gui/chest-glow.png`

## Deliberate differences from Krispy
- Kaze's click GUI has no colour picker, so "Chunk Color" is exposed as Red/Green/Blue (+Alpha for Prime) sliders (`ColorSettings`).
- Krispy's ChunkOverlay used a Gizmo box; Kaze draws a 0.02-thick filled box + line edges through `RenderUtils`.
- Krispy `persistEnabled()=false` for Prime has no Kaze equivalent (Prime still refuses to enable above Y 0).
- Krispy's per-setting `visibleWhen`/`onChange` hooks are replaced by plain fields / polling.
- Sound/texture namespace changed `krispy:` -> `kaze:`.

## Build status
NOT compiled or run here (no Minecraft/Gradle dependencies available). A javac pass with Kaze sources on the source path
showed no syntax errors and no unresolved Kaze symbols in the new files; remaining errors were only the missing Minecraft /
fastutil classes. First thing to verify on a real build: the `ClientWorld#updateListeners` mixin signature.
