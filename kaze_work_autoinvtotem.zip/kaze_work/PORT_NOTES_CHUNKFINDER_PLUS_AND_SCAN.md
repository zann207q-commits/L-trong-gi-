# Krispy -> Kaze: Chunk Finder+ and Sus Chunk Finder Scan

Two new modules (category DONUT_FINDING). Existing `Chunk Finder` (render/ChunkFinder) and `Sus Chunk Finder+`
(SusChunkFinderPlus / ChunkScanModule) are NOT modified.

| Kaze module | Krispy source | Notes |
|---|---|---|
| Chunk Finder+ (`ChunkFinderPlus`) | `ChunkFinderModule` | zeroed/uniform-max light sections below Y 1, 4 s dig-ignore, green plate |
| Sus Chunk Finder Scan (`SusChunkFinderScan`) | `SusChunkFinderModule` | amethyst-next-to-stone / full beehive scan, simulation-distance region build |

## New support code
- utils/chunks: `ChunkLightQueue`, `ChunkLightSnapshot`, `LightPayloadClassifier`, `SkyLightPattern`, `ChunkRegionBuilder`
- utils/toast: `ChunkFinderPlusToast`
- `ModuleManager`: +2 imports, +2 registrations (nothing else touched)

## Differences from Krispy
- Rendering goes through Kaze `RenderUtils.renderFilledBox` / `renderBoxOutline` (same as Lucky Finder); no batched ColoredBox lists.
- Chunk Finder+: "Kick On Flag" only disconnects (Kaze has no Auto RTP module / settings saveNow), sound is `kaze:chunk_flag`.
- Sus Chunk Finder Scan: `BlockUtil.getLoadedChunksList()` replaced by `BlockUtil.getLoadedChunks()` collected to a list.
  `findBestLightSphere` / `matchesGeodeSphere` / `solve4x4` are kept but, exactly like the Krispy original, are not called by the scan.

## Build status
NOT compiled against Minecraft jars. javac with Kaze on the source path reports only missing Minecraft / fastutil / slf4j types.
