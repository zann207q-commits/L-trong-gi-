package skid.kaze.event.events;

import skid.kaze.event.CancellableEvent;

/** Fired at the end of every MinecraftClient#tick, even without a world (Krispy's Stage.POST tick). */
public final class PostTickEvent extends CancellableEvent {
}
