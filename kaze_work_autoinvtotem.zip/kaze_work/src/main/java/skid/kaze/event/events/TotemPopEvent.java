package skid.kaze.event.events;

import skid.kaze.event.CancellableEvent;

/** Fired when the local player's totem pops (EntityStatus 35). Port of Krispy's TotemPopEvent. */
public final class TotemPopEvent extends CancellableEvent {
}
