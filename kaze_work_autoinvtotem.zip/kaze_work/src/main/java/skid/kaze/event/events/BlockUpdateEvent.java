package skid.kaze.event.events;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import skid.kaze.event.CancellableEvent;

/** Fired from ClientWorld#updateListeners (port of Krispy's ext BlockUpdateEvent). */
public final class BlockUpdateEvent extends CancellableEvent {
   public final BlockPos pos;
   public final BlockState oldState;
   public final BlockState newState;

   public BlockUpdateEvent(BlockPos pos, BlockState oldState, BlockState newState) {
      this.pos = pos;
      this.oldState = oldState;
      this.newState = newState;
   }
}
