package skid.kaze.event.events;

import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import skid.kaze.event.CancellableEvent;

/** Fired after the client has applied a light update packet (port of Krispy's LightUpdateEvent). */
public final class LightUpdateEvent extends CancellableEvent {
   public final LightUpdateS2CPacket packet;

   public LightUpdateEvent(LightUpdateS2CPacket packet) {
      this.packet = packet;
   }
}
