package skid.kaze.utils.chunks;

public enum SkyLightPattern {
   NORMAL,
   EMPTY_MASK,
   ZEROED_PRESENT,
   UNIFORM_MAX,
   UNKNOWN;
}
