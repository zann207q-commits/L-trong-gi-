package skid.kaze.utils.chunks;

import skid.kaze.module.Module;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.utils.EncryptedString;

/**
 * Colour option for Kaze's click GUI (which has no colour-picker widget): exposes Red / Green / Blue (and
 * optionally Alpha) sliders and packs them into one ARGB int, replacing Krispy's ColorSetting.
 */
public final class ColorSettings {
   private final NumberSetting red;
   private final NumberSetting green;
   private final NumberSetting blue;
   private final NumberSetting alpha;

   public ColorSettings(Module module, String name, int defaultArgb, boolean withAlpha) {
      this.red = new NumberSetting(EncryptedString.of(name + " Red"), 0.0, 255.0, (double)(defaultArgb >> 16 & 0xFF), 1.0);
      this.green = new NumberSetting(EncryptedString.of(name + " Green"), 0.0, 255.0, (double)(defaultArgb >> 8 & 0xFF), 1.0);
      this.blue = new NumberSetting(EncryptedString.of(name + " Blue"), 0.0, 255.0, (double)(defaultArgb & 0xFF), 1.0);
      if (withAlpha) {
         this.alpha = new NumberSetting(EncryptedString.of(name + " Alpha"), 0.0, 255.0, (double)(defaultArgb >>> 24), 1.0);
         module.addSettings(this.red, this.green, this.blue, this.alpha);
      } else {
         this.alpha = null;
         module.addSettings(this.red, this.green, this.blue);
      }
   }

   public int rgb() {
      return this.red.getIntValue() << 16 | this.green.getIntValue() << 8 | this.blue.getIntValue();
   }

   public int argb() {
      int a = this.alpha == null ? 255 : this.alpha.getIntValue();
      return a << 24 | this.rgb();
   }
}
