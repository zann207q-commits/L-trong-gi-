package skid.kaze.utils.chunks;

import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongSet;
import java.awt.Color;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.Vec3d;
import skid.kaze.utils.RenderUtils;

/**
 * Port of Krispy's ChunkOverlay: a flat plate per flagged chunk at Y 63 with brighter edges on the outside of
 * every connected patch. Krispy drew these with a Gizmo box; Kaze draws a hair-thin filled box instead.
 */
public final class ChunkOverlay {
   public static final double MARKER_Y = 63.0;
   private static final double PLATE_THICKNESS = 0.02;
   private static final float EDGE_SHADE = 0.77F;
   private static final float LINE_WIDTH = 1.5F;

   private ChunkOverlay() {
   }

   public static void draw(MatrixStack stack, LongSet chunks, int argb) {
      if (stack == null || chunks.isEmpty()) {
         return;
      }

      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }

      Color fill = new Color(argb, true);
      int edgeArgb = ColorHelper.withAlpha(Math.min(255, ColorHelper.getAlpha(argb) * 3 / 2), ColorHelper.scaleRgb(argb, EDGE_SHADE));
      Color edgeColor = new Color(edgeArgb, true);
      LongIterator iterator = chunks.iterator();
      while (iterator.hasNext()) {
         long packed = iterator.nextLong();
         int cx = ChunkPos.getPackedX(packed);
         int cz = ChunkPos.getPackedZ(packed);
         double x1 = (double)(cx << 4);
         double z1 = (double)(cz << 4);
         double x2 = x1 + 16.0;
         double z2 = z1 + 16.0;
         RenderUtils.renderFilledBox(stack, x1, MARKER_Y, z1, x2, MARKER_Y + PLATE_THICKNESS, z2, fill);
         if (!chunks.contains(ChunkPos.toLong(cx, cz - 1))) {
            edge(stack, x1, z1, x2, z1, edgeColor);
         }

         if (!chunks.contains(ChunkPos.toLong(cx, cz + 1))) {
            edge(stack, x1, z2, x2, z2, edgeColor);
         }

         if (!chunks.contains(ChunkPos.toLong(cx - 1, cz))) {
            edge(stack, x1, z1, x1, z2, edgeColor);
         }

         if (!chunks.contains(ChunkPos.toLong(cx + 1, cz))) {
            edge(stack, x2, z1, x2, z2, edgeColor);
         }
      }
   }

   private static void edge(MatrixStack stack, double x1, double z1, double x2, double z2, Color color) {
      RenderUtils.renderLine(stack, color, new Vec3d(x1, MARKER_Y, z1), new Vec3d(x2, MARKER_Y, z2), LINE_WIDTH);
   }
}
