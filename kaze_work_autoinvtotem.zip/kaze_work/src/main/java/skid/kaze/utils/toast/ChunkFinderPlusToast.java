package skid.kaze.utils.toast;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.Toast.Visibility;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Port of Krispy's ChunkFinderToast (advancement-style popup) used by Chunk Finder+. */
public final class ChunkFinderPlusToast implements Toast {
   private static final Identifier TEXTURE = Identifier.ofVanilla("toast/advancement");
   private static final long DISPLAY_TIME_MS = 5000L;
   private static final int PURPLE = -43521;
   private static final int WHITE = -1;
   private static final ItemStack ICON = new ItemStack(Items.CHEST);
   private final Text coordinates;
   private Visibility visibility = Visibility.SHOW;

   public ChunkFinderPlusToast(int x, int z) {
      this.coordinates = Text.literal("X: " + x + " Z: " + z);
   }

   @Override
   public Visibility getVisibility() {
      return this.visibility;
   }

   @Override
   public void update(ToastManager manager, long time) {
      this.visibility = (double)time >= (double)DISPLAY_TIME_MS * manager.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
   }

   @Override
   public void draw(DrawContext context, TextRenderer textRenderer, long time) {
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, 0, 0, this.getWidth(), this.getHeight());
      context.drawText(textRenderer, Text.literal("Chunk Finder+"), 30, 7, PURPLE, false);
      context.drawText(textRenderer, this.coordinates, 30, 18, WHITE, false);
      context.drawItemWithoutEntity(ICON, 8, 8);
   }
}
