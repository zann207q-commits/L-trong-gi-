package skid.kaze.module.modules.donutfinding;

import it.unimi.dsi.fastutil.longs.Long2BooleanOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.Long2IntMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.awt.Color;
import java.util.function.LongConsumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.ChunkDataEvent;
import skid.kaze.event.events.LightUpdateEvent;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.chunks.ChunkLightSampler;
import skid.kaze.utils.chunks.ChunkPeakFinder;
import skid.kaze.utils.chunks.ChunkPlateRenderer;
import skid.kaze.utils.chunks.LevelUtil;

/**
 * Sus Chunk V2 - full port of Krispy's SusChunkV2Module: scores chunks by the geode light pattern in their
 * block-light data, spreads the heat over the simulation distance and only shows the hottest peaks.
 */
public final class SusChunkV2 extends Module {
   private static final long SCAN_BUDGET_NANOS = 3000000L;
   private static final int MIN_SCANNED_NEIGHBOURS = 3;
   private static final int NO_PACKET_SENSITIVITY = 1;
   private static final int VISIBLE_REFRESH_TICKS = 20;
   private static final int PACKET_MIN_Y = -16;
   private static final int PACKET_MAX_Y = 30;
   private static final int GLOW_CELLS_PER_POINT = 12;
   private final NumberSetting spreadRadius;
   private final NumberSetting sensitivity;
   private final BooleanSetting outline;
   private final NumberSetting alpha;
   private final ChunkLightSampler glow;
   private final ChunkPlateRenderer plates;
   private final Long2IntOpenHashMap heat;
   private final Long2IntOpenHashMap vetoes;
   private final Long2IntOpenHashMap chunkScore;
   private final Long2BooleanOpenHashMap chunkUngrown;
   private final Long2BooleanOpenHashMap chunkHasPacket;
   private final LongOpenHashSet scannedChunks;
   private final LongArrayFIFOQueue queue;
   private final LongOpenHashSet queued;
   private Long2IntOpenHashMap visible;
   private boolean visibleDirty;
   private final ChunkPeakFinder peakFinder;
   private int visibleAge;
   private ClientWorld lastLevel;
   private int appliedRadius;
   private int appliedSensitivity;
   private int ticks;
   private final Long2IntOpenHashMap settling;

   public SusChunkV2() {
      super(EncryptedString.of("Sus Chunk V2"),
         EncryptedString.of("Detects suspicious underground activity from geode light patterns."), -1, Category.DONUT_FINDING);
      this.spreadRadius = new NumberSetting(EncryptedString.of("Simulation Distance"), 2.0, 16.0, 5.0, 1.0);
      this.sensitivity = new NumberSetting(EncryptedString.of("Sensitivity"), 1.0, 20.0, 6.0, 1.0);
      this.outline = new BooleanSetting(EncryptedString.of("Outline"), true);
      this.alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 100.0, 1.0);
      this.addSettings(this.spreadRadius, this.sensitivity, this.outline, this.alpha);
      this.glow = new ChunkLightSampler();
      this.plates = new ChunkPlateRenderer();
      this.heat = new Long2IntOpenHashMap();
      this.vetoes = new Long2IntOpenHashMap();
      this.chunkScore = new Long2IntOpenHashMap();
      this.chunkUngrown = new Long2BooleanOpenHashMap();
      this.chunkHasPacket = new Long2BooleanOpenHashMap();
      this.scannedChunks = new LongOpenHashSet();
      this.queue = new LongArrayFIFOQueue();
      this.queued = new LongOpenHashSet();
      this.visible = new Long2IntOpenHashMap();
      this.visibleDirty = true;
      this.peakFinder = new ChunkPeakFinder();
      this.settling = new Long2IntOpenHashMap();
      this.appliedSensitivity = this.sensitivity.getIntValue();
   }

   @Override
   public void onEnable() {
      this.clearAll();
      this.lastLevel = MinecraftClient.getInstance().world;
      this.queueLoadedChunks();
   }

   @Override
   public void onDisable() {
      this.clearAll();
      this.lastLevel = null;
   }

   private void clearAll() {
      this.heat.clear();
      this.vetoes.clear();
      this.chunkScore.clear();
      this.chunkUngrown.clear();
      this.chunkHasPacket.clear();
      this.scannedChunks.clear();
      this.queue.clear();
      this.queued.clear();
      this.settling.clear();
      this.ticks = 0;
      this.visible = new Long2IntOpenHashMap();
      this.visibleDirty = true;
      this.visibleAge = 0;
      this.appliedRadius = this.spreadRadius.getIntValue();
   }

   private void syncState(ClientWorld var1) {
      if (var1 != this.lastLevel) {
         this.clearAll();
         this.lastLevel = var1;
         this.queueLoadedChunks();
      }
   }

   private void queueLoadedChunks() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.world != null && var1.player != null) {
         int var2 = (Integer)var1.options.getViewDistance().getValue() + 1;
         ChunkPos var3 = var1.player.getChunkPos();

         for (int var4 = var3.x - var2; var4 <= var3.x + var2; var4++) {
            for (int var5 = var3.z - var2; var5 <= var3.z + var2; var5++) {
               if (LevelUtil.isLoaded(var1.world, var4, var5)) {
                  this.enqueue(ChunkPos.toLong(var4, var5));
               }
            }
         }
      }
   }

   private void enqueue(long var1) {
      if (this.queued.add(var1)) {
         this.queue.enqueue(var1);
      }
   }

   @EventListener
   public void onChunkData(ChunkDataEvent var1) {
      this.syncState(MinecraftClient.getInstance().world);
      this.enqueue(ChunkPos.toLong(var1.packet.getChunkX(), var1.packet.getChunkZ()));
      this.settleAround(var1.packet.getChunkX(), var1.packet.getChunkZ());
   }

   @EventListener
   public void onLightUpdate(LightUpdateEvent var1) {
      this.syncState(MinecraftClient.getInstance().world);
      this.settleAround(var1.packet.getChunkX(), var1.packet.getChunkZ());
   }

   private void settleAround(int var1, int var2) {
      for (int var3 = -1; var3 <= 1; var3++) {
         for (int var4 = -1; var4 <= 1; var4++) {
            long var5 = ChunkPos.toLong(var1 + var3, var2 + var4);
            this.settling.put(var5, Math.min(this.settling.getOrDefault(var5, this.ticks + 2), this.ticks + 2));
         }
      }
   }

   private void drainSettling() {
      ObjectIterator var1 = this.settling.long2IntEntrySet().fastIterator();

      while (var1.hasNext()) {
         Entry var2 = (Entry)var1.next();
         if (var2.getIntValue() <= this.ticks) {
            this.enqueue(var2.getLongKey());
            var1.remove();
         }
      }
   }

   @EventListener
   public void onTick(TickEvent var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      ClientWorld var3 = var2.world;
      this.syncState(var3);
      if (var3 != null) {
         this.ticks++;
         this.drainSettling();
         if (this.spreadRadius.getIntValue() != this.appliedRadius) {
            this.clearAll();
            this.queueLoadedChunks();
         }

         long var4 = System.nanoTime() + 3000000L;

         while (!this.queue.isEmpty() && System.nanoTime() < var4) {
            long var6 = this.queue.dequeueLong();
            this.queued.remove(var6);
            int var8 = ChunkPos.getPackedX(var6);
            int var9 = ChunkPos.getPackedZ(var6);
            if (LevelUtil.isLoaded(var3, var8, var9)) {
               this.updateChunk(var6, var3.getChunk(var8, var9), var3);
               if (this.scannedChunks.add(var6)) {
                  this.visibleDirty = true;
               }
            }
         }

         int currentSensitivity = this.sensitivity.getIntValue();
         if (currentSensitivity != this.appliedSensitivity) {
            this.appliedSensitivity = currentSensitivity;
            this.visibleDirty = true;
         }

         if (this.visibleDirty || ++this.visibleAge >= 20) {
            this.visible = this.computeVisible(var3);
            this.visibleDirty = false;
            this.visibleAge = 0;
         }
      }
   }

   private void updateChunk(long var1, WorldChunk var3, ClientWorld var4) {
      int var5 = this.spreadRadius.getIntValue();
      int var6 = ChunkPos.getPackedX(var1);
      int var7 = ChunkPos.getPackedZ(var1);
      int var8 = this.chunkScore.getOrDefault(var1, 0);
      boolean var9 = this.chunkUngrown.getOrDefault(var1, false);
      boolean var10 = hasBlocksInRange(var3, -16, 30);
      SusChunkV2.ChunkEvidence var11 = this.scoreChunk(var3, var4);
      if (!this.chunkHasPacket.containsKey(var1) || this.chunkHasPacket.get(var1) != var10) {
         this.visibleDirty = true;
      }

      this.chunkHasPacket.put(var1, var10);
      if (var8 != var11.selfHeat() || var9 != var11.hasUngrown() || !this.chunkScore.containsKey(var1)) {
         if (var8 > 0) {
            forArea(var6, var7, var5, var2 -> subtract(this.heat, var2, var8));
         }

         if (var9) {
            forArea(var6, var7, var5, var1x -> subtract(this.vetoes, var1x, 1));
         }

         this.chunkScore.put(var1, var11.selfHeat());
         this.chunkUngrown.put(var1, var11.hasUngrown());
         if (var11.hasUngrown()) {
            forArea(var6, var7, var5, var1x -> this.vetoes.addTo(var1x, 1));
         }

         if (var11.selfHeat() > 0) {
            forArea(var6, var7, var5, var2 -> this.heat.addTo(var2, var11.selfHeat()));
         }

         this.visibleDirty = true;
      }
   }

   private static void forArea(int var0, int var1, int var2, LongConsumer var3) {
      for (int var4 = -var2; var4 <= var2; var4++) {
         for (int var5 = -var2; var5 <= var2; var5++) {
            var3.accept(ChunkPos.toLong(var0 + var4, var1 + var5));
         }
      }
   }

   private static void subtract(Long2IntOpenHashMap var0, long var1, int var3) {
      int var4 = var0.get(var1) - var3;
      if (var4 > 0) {
         var0.put(var1, var4);
      } else {
         var0.remove(var1);
      }
   }

   private static boolean hasBlocksInRange(WorldChunk var0, int var1, int var2) {
      ChunkSection[] var3 = var0.getSectionArray();
      int var4 = var0.getBottomSectionCoord();

      for (int var5 = 0; var5 < var3.length; var5++) {
         ChunkSection var6 = var3[var5];
         if (var6 != null && !var6.isEmpty()) {
            int var7 = var4 + var5 << 4;
            if (var7 >= var1 && var7 + 15 <= var2) {
               return true;
            }

            if (var7 + 15 >= var1 && var7 <= var2) {
               for (int var8 = 0; var8 < 16; var8++) {
                  int var9 = var7 + var8;
                  if (var9 >= var1 && var9 <= var2) {
                     for (int var10 = 0; var10 < 16; var10++) {
                        for (int var11 = 0; var11 < 16; var11++) {
                           if (!var6.getBlockState(var10, var8, var11).isAir()) {
                              return true;
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private SusChunkV2.ChunkEvidence scoreChunk(WorldChunk var1, ClientWorld var2) {
      return new SusChunkV2.ChunkEvidence(this.glow.scan(var2, var1, null) / 12, false);
   }

   private Long2IntOpenHashMap computeVisible(ClientWorld var1) {
      Long2IntOpenHashMap var2 = new Long2IntOpenHashMap();
      ObjectIterator var3 = this.heat.long2IntEntrySet().iterator();

      while (var3.hasNext()) {
         Entry var4 = (Entry)var3.next();
         long var5 = var4.getLongKey();
         if (!this.vetoes.containsKey(var5)) {
            int var7 = ChunkPos.getPackedX(var5);
            int var8 = ChunkPos.getPackedZ(var5);
            if (LevelUtil.isLoaded(var1, var7, var8) && this.scannedNeighbours(var7, var8) >= 3) {
               var2.put(var5, var4.getIntValue());
            }
         }
      }

      int var14 = this.sensitivity.getIntValue();
      int var15 = this.appliedRadius;
      Long2IntOpenHashMap var6 = new Long2IntOpenHashMap();
      LongOpenHashSet var16 = this.peakFinder.find(var2, var15);
      ObjectIterator var17 = var2.long2IntEntrySet().iterator();

      while (var17.hasNext()) {
         Entry var9 = (Entry)var17.next();
         long var10 = var9.getLongKey();
         int var12 = var9.getIntValue();
         int var13 = this.chunkHasPacket.getOrDefault(var10, true) ? var14 : 1;
         if (var12 >= var13 && var16.contains(var10)) {
            var6.put(var10, var12);
         }
      }

      return var6;
   }

   private int scannedNeighbours(int var1, int var2) {
      int var3 = 0;

      for (int var4 = -1; var4 <= 1; var4++) {
         for (int var5 = -1; var5 <= 1; var5++) {
            if ((var4 != 0 || var5 != 0) && this.scannedChunks.contains(ChunkPos.toLong(var1 + var4, var2 + var5))) {
               var3++;
            }
         }
      }

      return var3;
   }

   @EventListener
   public void onRender3D(Render3DEvent var1) {
      ClientWorld var2 = MinecraftClient.getInstance().world;
      this.syncState(var2);
      if (var2 != null) {
         int var3 = this.alpha.getIntValue();
         Color var4 = this.outline.getValue() ? new Color(255, 242, 75, Math.min(220, var3 + 45)) : null;
         this.plates.draw(var1, this.visible.keySet(), new Color(255, 235, 0, var3), var4, 1.0F);
      }
   }








   private static record ChunkEvidence(int selfHeat, boolean hasUngrown) {
   }
}
