package skid.kaze.module.modules.donutfinding;

import java.awt.Color;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.render.Camera;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap.Type;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.ChunkDataEvent;
import skid.kaze.event.events.LightUpdateEvent;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.event.events.SetBlockStateEvent;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;
import skid.kaze.utils.chunks.ChunkLightQueue;
import skid.kaze.utils.toast.ChunkFinderPlusToast;

/**
 * Chunk Finder+ - port of Krispy's ChunkFinderModule ("Chunk Finder"): classifies the light packets of every
 * chunk (zeroed / uniform-max light sections below Y 1) on a background-safe queue and flags the chunk as a
 * green plate. Chunks next to a block you just changed (digging) are ignored for 4 s.
 * Kaze's own Chunk Finder and Sus Chunk Finder+ are untouched.
 */
public final class ChunkFinderPlus extends Module {
   private static final int MAX_FLAGS = 512;
   private static final long DIG_IGNORE_MS = 4000L;
   private static final double DIG_RANGE_SQ = 64.0;
   private static final SoundEvent FLAG_SOUND = SoundEvent.of(Identifier.of("kaze", "chunk_flag"));

   private final NumberSetting plateSize;
   private final BooleanSetting outline;
   private final NumberSetting plateThickness;
   private final BooleanSetting advancementNotifications;
   private final BooleanSetting soundPing;
   private final NumberSetting soundVolume;
   private final BooleanSetting kickOnFlag;
   private final ChunkLightQueue lightCache;
   private final Map<Long, FlaggedChunk> flags = new LinkedHashMap<>();
   private final Map<Long, Long> recentDigs = new HashMap<>();
   private ClientWorld trackedWorld;

   public ChunkFinderPlus() {
      super(
         EncryptedString.of("Chunk Finder+"),
         EncryptedString.of("detects bases underground [ Only works on DonutSMP]"),
         -1,
         Category.DONUT_FINDING
      );
      plateSize = new NumberSetting(EncryptedString.of("Plate Size"), 1.0, 64.0, 16.0, 0.5);
      outline = new BooleanSetting(EncryptedString.of("Outline"), true);
      plateThickness = new NumberSetting(EncryptedString.of("Plate Thickness"), 0.01, 4.0, 0.15, 0.01);
      advancementNotifications = new BooleanSetting(EncryptedString.of("Advancement Notifications"), true)
         .setDescription(EncryptedString.of("Shows a Chunk Finder+ advancement popup for every new flagged chunk"));
      soundPing = new BooleanSetting(EncryptedString.of("Sound Ping"), true)
         .setDescription(EncryptedString.of("Plays the chunk flag sound"));
      soundVolume = new NumberSetting(EncryptedString.of("Sound Volume"), 0.0, 100.0, 100.0, 1.0);
      kickOnFlag = new BooleanSetting(EncryptedString.of("Kick On Flag"), false)
         .setDescription(EncryptedString.of("Disconnects on the next flag, then turns this setting off"));
      lightCache = new ChunkLightQueue(this::flagLightChunk);
      addSettings(plateSize, plateThickness, outline, advancementNotifications, soundPing, soundVolume, kickOnFlag);
   }

   @Override
   public void onEnable() {
      reset();
      trackedWorld = mc.world;
      super.onEnable();
   }

   @Override
   public void onDisable() {
      reset();
      super.onDisable();
   }

   private void reset() {
      lightCache.clear();
      flags.clear();
      recentDigs.clear();
      trackedWorld = null;
   }

   private void ensureWorld() {
      if (trackedWorld != mc.world) {
         reset();
         trackedWorld = mc.world;
      }
   }

   @EventListener
   public void onChunkData(ChunkDataEvent event) {
      ensureWorld();
      if (mc.world != null) {
         lightCache.offer(event.packet.getChunkX(), event.packet.getChunkZ(), event.packet.getLightData());
      }
   }

   @EventListener
   public void onLightUpdate(LightUpdateEvent event) {
      ensureWorld();
      if (mc.world != null) {
         lightCache.offer(event.packet.getChunkX(), event.packet.getChunkZ(), event.packet.getData());
      }
   }

   @EventListener
   public void onTick(TickEvent event) {
      ensureWorld();
      if (mc.world != null && mc.player != null) {
         lightCache.drain(mc.world.countVerticalSections(), mc.world.getBottomSectionCoord());
      }
   }

   @EventListener
   public void onBlockChanged(SetBlockStateEvent event) {
      if (mc.player != null && event.pos != null
         && mc.player.squaredDistanceTo(Vec3d.ofCenter(event.pos)) <= DIG_RANGE_SQ) {
         recentDigs.put(ChunkPos.toLong(event.pos.getX() >> 4, event.pos.getZ() >> 4), System.currentTimeMillis());
      }
   }

   private boolean nearRecentDig(int chunkX, int chunkZ) {
      long now = System.currentTimeMillis();
      recentDigs.values().removeIf(timestamp -> now - timestamp > DIG_IGNORE_MS);
      for (long packedPos : recentDigs.keySet()) {
         if (Math.abs(ChunkPos.getPackedX(packedPos) - chunkX) <= 1
            && Math.abs(ChunkPos.getPackedZ(packedPos) - chunkZ) <= 1) {
            return true;
         }
      }
      return false;
   }

   private void flagLightChunk(int chunkX, int chunkZ, int lightLevel) {
      if (nearRecentDig(chunkX, chunkZ)) {
         return;
      }
      int blockX = (chunkX << 4) + 8;
      int blockZ = (chunkZ << 4) + 8;
      int surfaceY = mc.world != null && mc.world.isChunkLoaded(chunkX, chunkZ)
         ? Math.max(21, mc.world.getTopY(Type.WORLD_SURFACE, blockX, blockZ))
         : 21;
      flagChunk(new BlockPos(blockX, surfaceY, blockZ));
   }

   private void flagChunk(BlockPos position) {
      ChunkPos chunk = new ChunkPos(position);
      FlaggedChunk flag = new FlaggedChunk(chunk, Math.max(21, position.getY()), position.getX(), position.getZ());
      if (flags.putIfAbsent(chunk.toLong(), flag) != null) {
         return;
      }
      if (flags.size() > MAX_FLAGS) {
         flags.remove(flags.keySet().iterator().next());
      }
      if (advancementNotifications.getValue()) {
         showAdvancement(flag);
      }
      if (soundPing.getValue()) {
         float volume = soundVolume.getIntValue() / 100.0F;
         mc.getSoundManager().play(PositionedSoundInstance.ui(FLAG_SOUND, 1.0F, volume));
      }
      if (kickOnFlag.getValue() && mc.getNetworkHandler() != null) {
         kickOnFlag.setValue(false);
         mc.getNetworkHandler().getConnection().disconnect(Text.literal(
            "Kicked - Chunk Finder+ flagged X: " + flag.x() + " Z: " + flag.z()
               + "\nKick On Flag was automatically turned OFF."
         ));
      }
   }

   private void showAdvancement(FlaggedChunk flag) {
      mc.getToastManager().add(new ChunkFinderPlusToast(flag.x(), flag.z()));
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (flags.isEmpty() || mc.player == null || event.matrixStack == null) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }
      MatrixStack matrices = event.matrixStack;
      double halfSize = plateSize.getValue() / 2.0;
      double thickness = plateThickness.getValue();
      Color fillColor = new Color(0, 255, 70, 75);
      Color outlineColor = new Color(0, 255, 70, 220);
      boolean drawOutline = outline.getValue();
      ChunkPos playerChunk = mc.player.getChunkPos();
      for (FlaggedChunk flag : flags.values()) {
         if (Math.abs(flag.chunk().x - playerChunk.x) > 24 || Math.abs(flag.chunk().z - playerChunk.z) > 24) {
            continue;
         }
         double centerX = flag.chunk().getCenterX();
         double centerZ = flag.chunk().getCenterZ();
         double topY = flag.y() + 1.002;
         RenderUtils.renderFilledBox(
            matrices, centerX - halfSize, topY, centerZ - halfSize,
            centerX + halfSize, topY + thickness, centerZ + halfSize, fillColor
         );
         if (drawOutline) {
            RenderUtils.renderBoxOutline(
               matrices, centerX - halfSize, topY, centerZ - halfSize,
               centerX + halfSize, topY + thickness, centerZ + halfSize, outlineColor, 1.5F
            );
         }
      }
   }

   private record FlaggedChunk(ChunkPos chunk, int y, int x, int z) {
   }
}
