package skid.kaze.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import skid.kaze.event.events.ChunkDataEvent;
import skid.kaze.event.events.EntitySpawnEvent;
import skid.kaze.event.events.LightUpdateEvent;
import skid.kaze.event.events.TotemPopEvent;
import skid.kaze.manager.EventManager;

@Mixin({ClientPlayNetworkHandler.class})
public abstract class ClientPlayNetworkHandlerMixin {
   @Inject(
      method = {"onEntityStatus"},
      at = {@At("TAIL")}
   )
   private void kaze$onEntityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null && packet.getStatus() == 35 && packet.getEntity(mc.world) == mc.player) {
         EventManager.b(new TotemPopEvent());
      }
   }

   @Inject(
      method = {"onChunkData"},
      at = {@At("TAIL")}
   )
   private void onChunkData(ChunkDataS2CPacket packet, CallbackInfo ci) {
      EventManager.b(new ChunkDataEvent(packet));
   }

   @Inject(
      method = {"onLightUpdate"},
      at = {@At("TAIL")}
   )
   private void onLightUpdate(LightUpdateS2CPacket packet, CallbackInfo ci) {
      EventManager.b(new LightUpdateEvent(packet));
   }

   @Inject(
      method = {"onEntitySpawn"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onEntitySpawn(EntitySpawnS2CPacket packet, CallbackInfo ci) {
      EntitySpawnEvent event = new EntitySpawnEvent(packet);
      EventManager.b(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

   }
}
