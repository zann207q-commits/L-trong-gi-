package skid.kaze.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import skid.kaze.event.events.BlockUpdateEvent;
import skid.kaze.manager.EventManager;

@Mixin({ClientWorld.class})
public abstract class ClientWorldMixin {
   @Inject(
      method = {"updateListeners"},
      at = {@At("HEAD")}
   )
   private void kaze$blockUpdated(BlockPos pos, BlockState oldState, BlockState newState, int flags, CallbackInfo ci) {
      EventManager.b(new BlockUpdateEvent(pos, oldState, newState));
   }
}
