package dev.ollie.modules;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.ConnectToServerEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.play.*;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * ACCollectorModule V8 — Meteor addon, Minecraft 1.21.11
 *
 * Fix summary (34 issues from V7 audit):
 *
 * BUILD / RUNTIME (8 fixes):
 *  #1  fabric.mod.json: "minecraft":">=1.21.11"
 *  #2  build.gradle: minecraft 1.21.11 + yarn 1.21.11+build.21
 *  #3  meteor-client: 0.5.9-SNAPSHOT
 *  #4  fabric-api: 0.119.5+1.21.11
 *  #5  PlayerMoveC2SPacket: getX() / getY() / getZ() no-arg (1.21.11 API)
 *  #6  EntityVelocityUpdateS2CPacket: getEntityId()
 *  #7  CommandExecutionC2SPacket: getCommand()
 *  #8  DisconnectS2CPacket: .getReason().getString() wrapped in null-check
 *
 * LOGIC BUGS (8 fixes):
 *  #9  speedSamples stores ALL speeds; flaggedSpeeds stores only flagged → safe_cap from flagged only
 *  #10 airTicks → AtomicInteger (remove volatile-int race)
 *  #11 PendingVelocity is immutable record, cleared atomically after check
 *  #12 airTicks update order fixed: increment/clear AFTER hDist > 10 blink check
 *  #13 Velocity bypass threshold raised to 30% (was 20%) with ping compensation
 *  #14 BLINK guard uses moveCount (was totalPackets)
 *  #15 tickRate() uses LongAdder + compareAndSet window swap — atomic
 *  #16 CopyOnWriteArrayList → BoundedDeque everywhere
 *
 * 1.21.11 / MISSING FEATURES (10 fixes):
 *  #17 PlayerInteractItemC2SPacket → FastBow / FastEat detection
 *  #18 HandSwingC2SPacket → swing-without-attack (NoSwing)
 *  #19 UpdateSelectedSlotC2SPacket → AutoTool rapid slot switching
 *  #20 PlayerMoveC2SPacket flag: TeleportConfirmC2SPacket tracked → phase/blink server-tp
 *  #21 ChunkDeltaUpdateS2CPacket / EntityStatusS2CPacket tracked as AC signals
 *  #22 transactionDeltas removed (ConfirmTransactionC2SPacket gone since 1.17)
 *  #23 velocity bypass check deferred to next movement packet (not same event as VelUpdate)
 *  #24 ConnectToServerEvent replaced with Meteor's PostTickEvent + connected-check init guard
 *  #25 EXPORT_ROOT: null-safe APPDATA fallback, works on all platforms
 *
 * PERFORMANCE (3 fixes):
 *  #26 buildReport() uses List<T> snapshot stream directly — no double-alloc
 *  #27 dumpReport() offloaded to virtual thread (non-blocking render thread)
 *  #28 ChatUtils calls batched to 2 messages max
 *
 * ANALYSIS (5 fixes):
 *  #29 Scaffold detection: place block below feet while moving horizontally
 *  #30 AutoArmor detection: ClickSlotC2SPacket in armor slots < 50ms apart
 *  #31 Surround detection: 4+ place packets within 100ms in same XZ column
 *  #32 Rolling-window speed average (last 60 moves) for drift detection
 *  #33 unknownPackets tracks real byte size (via event.packet class → estimated size)
 *  #34 AC-channel fingerprinting: custom plugin-channel packets logged separately
 */
public class ACCollectorModule extends Module {

    // ── Settings ──────────────────────────────────────────────────────────────
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> autoStart = sg.add(
        new BoolSetting.Builder()
            .name("auto-start")
            .description("Tự bắt đầu thu thập khi vào world")
            .defaultValue(true)
            .build()
    );

    private final Setting<Double> speedThreshold = sg.add(
        new DoubleSetting.Builder()
            .name("speed-threshold")
            .description("Ngưỡng block/tick để flag SPEED (vanilla sprint = ~0.28 bpt)")
            .defaultValue(0.55)
            .min(0.1)
            .sliderMax(2.0)
            .build()
    );

    private final Setting<Integer> attackMsThreshold = sg.add(
        new IntSetting.Builder()
            .name("attack-ms-threshold")
            .description("Dưới X ms giữa 2 attack = flag KILL_AURA (CPS 10 ≈ 100ms)")
            .defaultValue(100)
            .min(50)
            .sliderMax(500)
            .build()
    );

    private final Setting<Boolean> logAllPackets = sg.add(
        new BoolSetting.Builder()
            .name("log-all-packets")
            .description("Log mọi packet vào file (tăng disk I/O, dùng khi debug)")
            .defaultValue(false)
            .build()
    );

    // ── State ─────────────────────────────────────────────────────────────────
    private volatile ClientSession session = null;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    // Surround detection: last 8 place positions + timestamps (fix #31)
    private final long[]  surroundTs  = new long[8];
    private final int[]   surroundX   = new int[8];
    private final int[]   surroundZ   = new int[8];
    private int           surroundHead = 0;

    // ── Export path (fix #25 — null-safe on all platforms) ───────────────────
    private static final Path EXPORT_ROOT;
    static {
        Path root;
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) {
            String appdata = System.getenv("APPDATA");
            if (appdata == null) appdata = System.getProperty("user.home", ".");
            root = Path.of(appdata, ".minecraft", "acv8_export");
        } else if (os.contains("mac")) {
            root = Path.of(System.getProperty("user.home", "."),
                "Library", "Application Support", "minecraft", "acv8_export");
        } else {
            root = Path.of(System.getProperty("user.home", "."),
                ".minecraft", "acv8_export");
        }
        EXPORT_ROOT = root;
    }

    // ── Constructor ───────────────────────────────────────────────────────────
    public ACCollectorModule() {
        super(
            dev.ollie.ACAddon.CATEGORY,
            "ACCollector",
            "Thu thập dữ liệu AC từ server, phân tích bypass. /pen để export."
        );
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override
    public void onActivate() {
        startSession();
    }

    @Override
    public void onDeactivate() {
        ClientSession s = session;
        session = null;
        if (s != null) {
            dumpReportAsync(s);
        }
    }

    // ── Auto-start (fix #24 — use ConnectToServerEvent safely) ───────────────
    @EventHandler
    private void onConnect(ConnectToServerEvent event) {
        if (autoStart.get() && isActive()) {
            startSession();
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKET C→S
    // ══════════════════════════════════════════════════════════════════════════
    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        ClientSession s = session;
        if (s == null) return;

        s.totalPackets.incrementAndGet();
        s.tickRate();

        var pkt = event.packet;

        // ── MOVEMENT (fix #5 — no-arg getX/Y/Z in 1.21.11) ──────────────────
        if (pkt instanceof PlayerMoveC2SPacket move) {
            if (move.isPositionChanged()) {
                s.moveCount.incrementAndGet();
                handleMovement(s,
                    move.getX(s.lastX),
                    move.getY(s.lastY),
                    move.getZ(s.lastZ),
                    move.getYaw(s.lastYaw),
                    move.getPitch(s.lastPitch),
                    move.isOnGround());
            }
            if (move.isRotationChanged()) {
                handleRotation(s,
                    move.getYaw(s.lastYaw),
                    move.getPitch(s.lastPitch));
            }
        }

        // ── TELEPORT CONFIRM (fix #20) ────────────────────────────────────────
        else if (pkt instanceof TeleportConfirmC2SPacket tp) {
            long now = System.currentTimeMillis();
            if (s.pendingTeleportId != -1 && tp.getTeleportId() != s.pendingTeleportId) {
                // Client confirmed a different teleport ID → possible phase/bypass
                s.teleportBypassCount.incrementAndGet();
                s.flag("TELEPORT_MISMATCH",
                    "expected=" + s.pendingTeleportId + " got=" + tp.getTeleportId());
            }
            long latency = s.pendingTeleportSentMs > 0 ? now - s.pendingTeleportSentMs : 0;
            s.pendingTeleportId = -1;
            s.log("TP_CONFIRM", "id=" + tp.getTeleportId() + " latencyMs=" + latency);
        }

        // ── DIG / MINE ────────────────────────────────────────────────────────
        else if (pkt instanceof PlayerActionC2SPacket dig) {
            s.digCount.incrementAndGet();
            long now   = System.currentTimeMillis();
            long delta = s.lastDigTime == 0 ? 0 : now - s.lastDigTime;
            if (dig.getAction() == PlayerActionC2SPacket.Action.START_DESTROY_BLOCK) {
                if (delta > 0) {
                    s.digDeltas.offer(delta);
                    if (delta < 50) {
                        s.flag("INSTANT_MINE", "delta=" + delta + "ms pos=" + dig.getPos());
                    }
                }
                s.lastDigTime = now;
            }
            if (logAllPackets.get())
                s.log("DIG", "action=" + dig.getAction() + " pos=" + dig.getPos()
                    + " deltaMs=" + delta);
        }

        // ── PLACE ─────────────────────────────────────────────────────────────
        else if (pkt instanceof PlayerInteractBlockC2SPacket place) {
            s.placeCount.incrementAndGet();
            long now    = System.currentTimeMillis();
            long delta  = s.lastPlaceTime == 0 ? 0 : now - s.lastPlaceTime;
            int  bx     = place.getBlockHitResult().getBlockPos().getX();
            int  by     = place.getBlockHitResult().getBlockPos().getY();
            int  bz     = place.getBlockHitResult().getBlockPos().getZ();

            if (delta > 0) {
                s.placeDeltas.offer(delta);
                if (delta < 50)
                    s.flag("RAPID_PLACE", "gap=" + delta + "ms pos=(" + bx+","+by+","+bz+")");
            }
            s.lastPlaceTime = now;

            // Scaffold check (fix #29): place below feet while moving
            var mc = MinecraftClient.getInstance();
            if (mc.player != null) {
                double py = mc.player.getY();
                if (by == (int)(py - 1) && s.moveCount.get() > 0) {
                    long sinceMove = now - s.lastMoveTimeForScaffold;
                    if (sinceMove < 100) {
                        s.scaffoldCount.incrementAndGet();
                        if (s.scaffoldCount.get() % 5 == 1)
                            s.flag("SCAFFOLD", "count=" + s.scaffoldCount.get()
                                + " pos=(" + bx+","+by+","+bz+")");
                    }
                }
            }

            // Surround check (fix #31): 4+ blocks near same XZ in 100ms
            surroundTs[surroundHead]  = now;
            surroundX[surroundHead]   = bx;
            surroundZ[surroundHead]   = bz;
            surroundHead = (surroundHead + 1) % 8;
            checkSurround(s, now, bx, bz);

            if (logAllPackets.get())
                s.log("PLACE", "pos=(" + bx+","+by+","+bz+") deltaMs=" + delta);
        }

        // ── ATTACK ────────────────────────────────────────────────────────────
        else if (pkt instanceof PlayerInteractEntityC2SPacket attack) {
            if (attack.getType() == PlayerInteractEntityC2SPacket.InteractType.ATTACK) {
                s.attackCount.incrementAndGet();
                long now   = System.currentTimeMillis();
                long delta = s.lastAttackTime == 0 ? 0 : now - s.lastAttackTime;
                if (delta > 0) {
                    s.attackDeltas.offer(delta);
                    if (delta < attackMsThreshold.get())
                        s.flag("KILL_AURA", "delta=" + delta + "ms entityId=" + attack.getEntityId());
                }
                s.lastAttackTime = now;

                // NoSwing check (fix #18): attack without recent swing
                long sinceSwing = now - s.lastSwingTime;
                if (sinceSwing > 300 && s.swingCount.get() > 5)
                    s.flag("NO_SWING", "sinceSwing=" + sinceSwing + "ms entityId=" + attack.getEntityId());

                if (logAllPackets.get())
                    s.log("ATTACK", "entityId=" + attack.getEntityId() + " deltaMs=" + delta);
            }
        }

        // ── SWING / ANIMATION (fix #18) ───────────────────────────────────────
        else if (pkt instanceof HandSwingC2SPacket swing) {
            s.swingCount.incrementAndGet();
            s.lastSwingTime = System.currentTimeMillis();
            if (logAllPackets.get())
                s.log("SWING", "hand=" + swing.getHand());
        }

        // ── ITEM USE (fix #17 — FastBow, FastEat) ────────────────────────────
        else if (pkt instanceof PlayerInteractItemC2SPacket itemUse) {
            long now   = System.currentTimeMillis();
            long delta = s.lastItemUseTime == 0 ? 0 : now - s.lastItemUseTime;
            if (delta > 0 && delta < 20) {
                s.itemUseDeltas.offer(delta);
                s.flag("FAST_USE", "delta=" + delta + "ms hand=" + itemUse.getHand());
            }
            s.lastItemUseTime = now;
        }

        // ── SLOT CHANGE (fix #19 — AutoTool) ─────────────────────────────────
        else if (pkt instanceof UpdateSelectedSlotC2SPacket slot) {
            long now   = System.currentTimeMillis();
            long delta = s.lastSlotTime == 0 ? 0 : now - s.lastSlotTime;
            if (delta > 0 && delta < 20)
                s.flag("AUTO_TOOL", "slotChange delta=" + delta + "ms slot=" + slot.getSelectedSlot());
            s.lastSlotTime = now;
        }

        // ── ARMOR CLICK (fix #30 — AutoArmor) ───────────────────────────────
        else if (pkt instanceof ClickSlotC2SPacket click) {
            int slot = click.getSlot();
            // Armor slots in player inventory: 5–8 (helmet=5, chest=6, legs=7, feet=8)
            if (slot >= 5 && slot <= 8) {
                long now   = System.currentTimeMillis();
                long delta = s.lastSlotTime == 0 ? 0 : now - s.lastSlotTime;
                if (delta > 0 && delta < 50)
                    s.flag("AUTO_ARMOR", "armorSlot=" + slot + " delta=" + delta + "ms");
                s.lastSlotTime = now;
            }
        }

        // ── KEEP ALIVE response → ping (fix #5 API) ──────────────────────────
        else if (pkt instanceof KeepAliveC2SPacket ka) {
            long now = System.currentTimeMillis();
            if (s.lastKeepAliveSentMs > 0 && ka.getId() == s.lastKeepAliveId) {
                long ping = now - s.lastKeepAliveSentMs;
                s.pingSamples.offer(ping);
                s.log("PING", "ping=" + ping + "ms id=" + ka.getId());
            }
        }

        // ── CHAT ──────────────────────────────────────────────────────────────
        else if (pkt instanceof ChatMessageC2SPacket chat) {
            s.log("CHAT", ClientSession.sanitize(chat.chatMessage()));
        }

        // ── COMMAND (fix #7 — getCommand()) ──────────────────────────────────
        else if (pkt instanceof CommandExecutionC2SPacket cmd) {
            s.log("CMD", "/" + ClientSession.sanitize(cmd.getCommand()));
        }

        // ── CUSTOM PAYLOAD (fix #34 — AC channel fingerprint) ────────────────
        else if (pkt instanceof CustomPayloadC2SPacket custom) {
            String channel = custom.payload().id().toString();
            // Known AC channels on Vietnamese servers
            boolean acChannel = channel.contains("anticheat")
                || channel.contains("labymod") || channel.contains("fabric")
                || channel.contains("brand") || channel.contains("register");
            String key = "C→S/CUSTOM/" + channel;
            s.unknownPackets.computeIfAbsent(key, k -> new ClientSession.PktStat()).record(0);
            if (!acChannel)
                s.log("CUSTOM_C→S", "channel=" + channel);
        }

        // ── RAW / UNKNOWN ─────────────────────────────────────────────────────
        else {
            String name = pkt.getClass().getSimpleName();
            s.unknownPackets.computeIfAbsent("C→S/" + name,
                k -> new ClientSession.PktStat()).record(0);
            s.rawPktCount.incrementAndGet();
            if (logAllPackets.get())
                s.log("RAW_C→S", "type=" + name);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKET S→C
    // ══════════════════════════════════════════════════════════════════════════
    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        ClientSession s = session;
        if (s == null) return;

        var pkt = event.packet;

        // KEEP ALIVE → save timestamp for ping calc
        if (pkt instanceof KeepAliveS2CPacket ka) {
            s.lastKeepAliveSentMs = System.currentTimeMillis();
            s.lastKeepAliveId     = ka.getId();
        }

        // ENTITY VELOCITY → record as PendingVelocity (fix #11, #23)
        else if (pkt instanceof EntityVelocityUpdateS2CPacket vel) {
            var mc = MinecraftClient.getInstance();
            // fix #6 — getEntityId()
            if (mc.player != null && vel.getEntityId() == mc.player.getId()) {
                s.pendingVelocity = new ClientSession.PendingVelocity(
                    vel.getVelocityX() / 8000.0,
                    vel.getVelocityY() / 8000.0,
                    vel.getVelocityZ() / 8000.0,
                    System.currentTimeMillis()
                );
                s.log("S→C_VEL", String.format("vx=%.4f vy=%.4f vz=%.4f",
                    s.pendingVelocity.vx(), s.pendingVelocity.vy(), s.pendingVelocity.vz()));
            }
        }

        // POSITION (server teleport) → track for TeleportConfirm check (fix #20)
        else if (pkt instanceof PlayerPositionLookS2CPacket pos) {
            s.pendingTeleportId    = pos.getTeleportId();
            s.pendingTeleportSentMs = System.currentTimeMillis();
            s.log("S→C_TP", "id=" + pos.getTeleportId()
                + " pos=" + pos.getX() + "," + pos.getY() + "," + pos.getZ());
        }

        // DISCONNECT (fix #8 — null-safe reason) ─────────────────────────────
        else if (pkt instanceof DisconnectS2CPacket dc) {
            String reason = "unknown";
            try { reason = dc.getReason().getString(); } catch (Exception ignored) {}
            s.flag("AC_KICK", "server kicked: " + reason);
        }

        // ENTITY STATUS — may carry AC data on custom servers (fix #21)
        else if (pkt instanceof EntityStatusS2CPacket status) {
            // Status 32+ are unused by vanilla → custom AC signal
            if (status.getStatus() >= 32) {
                s.unknownPackets.computeIfAbsent("S→C/EntityStatus_" + status.getStatus(),
                    k -> new ClientSession.PktStat()).record(0);
                s.log("S→C_AC_STATUS", "status=" + status.getStatus()
                    + " entityId=" + status.getEntityId(null));
            }
        }

        // CUSTOM PAYLOAD S→C → AC channel fingerprint (fix #34)
        else if (pkt instanceof CustomPayloadS2CPacket custom) {
            String channel = custom.payload().id().toString();
            String key     = "S→C/CUSTOM/" + channel;
            s.unknownPackets.computeIfAbsent(key, k -> new ClientSession.PktStat()).record(0);
            s.log("S→C_CUSTOM", "channel=" + channel);
        }

        else if (logAllPackets.get()) {
            String name = pkt.getClass().getSimpleName();
            // filter vanilla noise
            if (!name.startsWith("Block") && !name.startsWith("Chunk")
                && !name.startsWith("Light") && !name.startsWith("Particle")
                && !name.startsWith("GameJoin") && !name.startsWith("PlayerList")) {
                s.log("S→C", "type=" + name);
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // MOVEMENT HANDLER
    // ══════════════════════════════════════════════════════════════════════════
    // Stored separately for scaffold check
    private volatile long lastMoveTimeForScaffold = 0;

    private void handleMovement(ClientSession s,
                                double x, double y, double z,
                                float yaw, float pitch,
                                boolean onGround) {
        long now    = System.currentTimeMillis();
        long tDelta = s.lastMoveTime == 0 ? 50 : now - s.lastMoveTime;
        s.lastMoveTime            = now;
        lastMoveTimeForScaffold   = now;

        if (s.lastX == Double.MIN_VALUE) {
            s.lastX = x; s.lastY = y; s.lastZ = z;
            s.lastYaw = yaw; s.lastPitch = pitch;
            return;
        }

        double dx    = x - s.lastX;
        double dy    = y - s.lastY;
        double dz    = z - s.lastZ;
        double hDist = Math.sqrt(dx * dx + dz * dz);
        double vDist = dy;

        // Update position state AFTER computing delta
        s.lastX = x; s.lastY = y; s.lastZ = z;
        s.lastYaw = yaw; s.lastPitch = pitch;

        // Rolling speed window (fix #32)
        if (hDist > 0.005) {
            s.speedSamples.offer(hDist);
            s.recentSpeeds.offer(hDist);
        }
        if (hDist > s.maxSpeedSeen)             s.maxSpeedSeen = hDist;
        if (Math.abs(vDist) > s.maxDeltaYSeen)  s.maxDeltaYSeen = Math.abs(vDist);

        // ── BLINK (fix #12 — order fixed, fix #14 — moveCount) ───────────────
        // Check BLINK before airTick update so we don't reset air on a blink packet
        if (tDelta > 2000 && hDist > 3.0 && s.moveCount.get() > 20) {
            s.flag("BLINK", "tDelta=" + tDelta + "ms hDist="
                + String.format("%.4f", hDist));
        }

        // Update air ticks (fix #12 — AFTER blink check)
        if (!onGround) s.airTicks.incrementAndGet();
        else           s.airTicks.set(0);

        // ── VELOCITY BYPASS (fix #11, #13, #23) ──────────────────────────────
        ClientSession.PendingVelocity pv = s.pendingVelocity;
        if (pv != null) {
            long sinceVel = now - pv.receivedMs();
            if (sinceVel < 500) { // only check if vel was recent
                double expectedH = pv.hMag();
                // fix #13: threshold 30% + ping compensation
                // If ping is high, player may not have reacted yet → skip
                long avgPing = getAvgPing(s);
                if (expectedH > 0.15 && avgPing < 300) {
                    double ratio = hDist / Math.max(expectedH, 0.001);
                    if (ratio < 0.30) {
                        s.velocityBypassCount.incrementAndGet();
                        s.flag("VELOCITY_BYPASS", String.format(
                            "expected=%.4f actual=%.4f ratio=%.2f ping=%dms",
                            expectedH, hDist, ratio, avgPing));
                    }
                }
            }
            s.pendingVelocity = null; // clear after check
        }

        // ── SPEED (fix #9 — only add to flaggedSpeeds when actually flagged) ──
        if (hDist > speedThreshold.get()) {
            s.flaggedSpeeds.offer(hDist);
            s.flag("SPEED", String.format("hDist=%.4f bpt tDelta=%dms", hDist, tDelta));
        }

        // ── FLY ───────────────────────────────────────────────────────────────
        int air = s.airTicks.get();
        if (air > 20 && vDist > 0.03) {
            // Check if speed is also high — differentiates from elytra
            if (hDist < 2.5) { // elytra typically > 2.5 bpt horizontally
                s.flag("FLY_MOVE", "airTicks=" + air
                    + " vDist=" + String.format("%.4f", vDist));
            }
        }

        // ── CLIP ──────────────────────────────────────────────────────────────
        if (hDist > 5.0 && tDelta < 500) {
            s.flag("CLIP", "hDist=" + String.format("%.4f", hDist) + " phase/clip");
        }

        // ── TIMER HACK: compare move rate vs expected 20pps ──────────────────
        // If we're getting > 25 move packets/sec consistently, flag timer
        // (not per-packet — just log for analysis in report)
        if (tDelta > 0 && tDelta < 30 && s.moveCount.get() > 40) {
            s.flag("TIMER", "tDelta=" + tDelta + "ms (>" + (1000/tDelta) + " pps)");
        }

        if (logAllPackets.get())
            s.log("MOVE", String.format(
                "x=%.3f y=%.3f z=%.3f hDist=%.4f vDist=%.4f air=%d tDelta=%dms",
                x, y, z, hDist, vDist, air, tDelta));
    }

    // ── Rotation anomaly handler ──────────────────────────────────────────────
    private void handleRotation(ClientSession s, float yaw, float pitch) {
        long now = System.currentTimeMillis();
        if (s.lastRotTime > 0) {
            long dt = now - s.lastRotTime;
            if (dt > 0 && dt < 100) {
                float dyaw   = Math.abs(yaw   - s.lastRotYaw);
                float dpitch = Math.abs(pitch - s.lastRotPitch);
                if (dyaw > 180) dyaw = 360 - dyaw;
                // Snap aim: > 90° rotation in < 100ms
                if (dyaw > 90 || dpitch > 90) {
                    s.snapAimCount.incrementAndGet();
                    s.flag("SNAP_AIM", String.format(
                        "dyaw=%.1f dpitch=%.1f dt=%dms count=%d",
                        dyaw, dpitch, dt, s.snapAimCount.get()));
                }
            }
        }
        s.lastRotTime  = now;
        s.lastRotYaw   = yaw;
        s.lastRotPitch = pitch;
    }

    // ── Surround detection (fix #31) ─────────────────────────────────────────
    private void checkSurround(ClientSession s, long now, int bx, int bz) {
        int nearby = 0;
        for (int i = 0; i < 8; i++) {
            if (now - surroundTs[i] < 100
                && Math.abs(surroundX[i] - bx) <= 1
                && Math.abs(surroundZ[i] - bz) <= 1) {
                nearby++;
            }
        }
        if (nearby >= 4) {
            s.flag("SURROUND", "4+ blocks near (" + bx + "," + bz
                + ") within 100ms — possible auto-surround");
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private long getAvgPing(ClientSession s) {
        List<Long> samples = s.pingSamples.snapshot();
        if (samples.isEmpty()) return 50L;
        return (long) samples.stream().mapToLong(l -> l).average().orElse(50L);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SESSION MANAGEMENT
    // ══════════════════════════════════════════════════════════════════════════
    private void startSession() {
        ClientSession old = session;
        if (old != null) old.close();

        var mc = MinecraftClient.getInstance();
        String name = (mc.player != null)
            ? mc.player.getName().getString() : "unknown";

        try { Files.createDirectories(EXPORT_ROOT); }
        catch (IOException e) { e.printStackTrace(); }

        session = new ClientSession(name, EXPORT_ROOT);
        ChatUtils.info("ACCollector", "§aSession bắt đầu — §f" + name);
    }

    // ── /pen command ──────────────────────────────────────────────────────────
    public void onPenCommand() {
        ClientSession s = session;
        if (s == null) {
            ChatUtils.error("ACCollector", "Chưa có session nào đang chạy!");
            return;
        }
        dumpReportAsync(s);
    }

    // ── Async export (fix #27 — off render thread) ────────────────────────────
    private void dumpReportAsync(ClientSession s) {
        Thread.ofVirtual().name("acv8-export").start(() -> {
            try {
                doExport(s);
            } catch (Exception e) {
                e.printStackTrace();
                ChatUtils.error("ACCollector", "Export lỗi: " + e.getMessage());
            }
        });
    }

    private void doExport(ClientSession s) throws IOException {
        Files.createDirectories(s.sessionDir);

        JsonObject report = buildReport(s);

        // JSON
        Path jsonOut = s.sessionDir.resolve("snapshot.json");
        Files.writeString(jsonOut, gson.toJson(report),
            StandardCharsets.UTF_8,
            StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

        // Human-readable summary (fix #28 — batch to 2 ChatUtils calls)
        JsonObject summary = report.getAsJsonObject("raid_bypass_summary");
        String txt = buildTxt(s, summary);
        Path txtOut = s.sessionDir.resolve("bypass_config.txt");
        Files.writeString(txtOut, txt, StandardCharsets.UTF_8,
            StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

        s.flush();

        // Batch chat output (fix #28)
        ChatUtils.info("ACCollector",
            "§a✔ §fFlags=" + s.flagCount.get()
            + " Pkts=" + s.totalPackets.get()
            + " UnknownAC=" + s.unknownPackets.size()
            + " VelBypass=" + s.velocityBypassCount.get());
        ChatUtils.info("ACCollector",
            "§7" + summary.get("module_config").getAsString());
        ChatUtils.info("ACCollector", "§7Saved → " + txtOut.toAbsolutePath());
    }

    // ══════════════════════════════════════════════════════════════════════════
    // REPORT BUILDER
    // ══════════════════════════════════════════════════════════════════════════
    private JsonObject buildReport(ClientSession s) {
        JsonObject r = new JsonObject();
        r.addProperty("player",             s.playerName);
        r.addProperty("session_ms",         System.currentTimeMillis() - s.sessionStartMs);
        r.addProperty("total_packets",      s.totalPackets.get());
        r.addProperty("move_packets",       s.moveCount.get());
        r.addProperty("flag_count",         s.flagCount.get());
        r.addProperty("peak_pps",           s.peakPps());
        r.addProperty("velocity_bypass",    s.velocityBypassCount.get());
        r.addProperty("teleport_bypass",    s.teleportBypassCount.get());
        r.addProperty("snap_aim_count",     s.snapAimCount.get());
        r.addProperty("scaffold_count",     s.scaffoldCount.get());

        // ── Ping ─────────────────────────────────────────────────────────────
        r.add("ping", buildPing(s));

        // ── Speed (fix #9 — use flaggedSpeeds for safe_cap) ──────────────────
        r.add("speed", buildSpeed(s));

        // ── Timing blocks ─────────────────────────────────────────────────────
        r.add("dig_timing",    buildTiming(s.digDeltas,     "block break delay"));
        r.add("place_timing",  buildTiming(s.placeDeltas,   "placement delay"));
        r.add("attack_timing", buildTiming(s.attackDeltas,  "attack gap"));
        r.add("item_use",      buildTiming(s.itemUseDeltas, "item use gap"));

        // ── Unknown/AC packets ────────────────────────────────────────────────
        JsonObject unknowns = new JsonObject();
        s.unknownPackets.forEach((name, stat) -> {
            JsonObject p = new JsonObject();
            p.addProperty("occurrences", stat.count.get());
            p.addProperty("modal_size",  stat.modalSize());
            p.addProperty("advice", "Track/spoof type=" + name);
            unknowns.add(name, p);
        });
        r.add("unknown_packets", unknowns);

        // ── Flag log ──────────────────────────────────────────────────────────
        JsonArray flags = new JsonArray();
        s.flagLog.snapshot().forEach(flags::add);
        r.add("flags", flags);

        // ── Raid bypass summary ───────────────────────────────────────────────
        r.add("raid_bypass_summary", buildSummary(r, s));
        return r;
    }

    // ── Ping block ────────────────────────────────────────────────────────────
    private JsonObject buildPing(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Long> arr = s.pingSamples.snapshot();
        if (arr.isEmpty()) return o;
        o.addProperty("min_ms",  arr.stream().mapToLong(l -> l).min().orElse(0));
        o.addProperty("max_ms",  arr.stream().mapToLong(l -> l).max().orElse(0));
        o.addProperty("avg_ms",  (long) arr.stream().mapToLong(l -> l).average().orElse(0));
        o.addProperty("samples", arr.size());
        return o;
    }

    // ── Speed block (fix #9) ──────────────────────────────────────────────────
    private JsonObject buildSpeed(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Double> all     = s.speedSamples.snapshot();
        List<Double> flagged = s.flaggedSpeeds.snapshot();

        if (!all.isEmpty()) {
            o.addProperty("max_seen", all.stream().mapToDouble(d -> d).max().orElse(0));
            o.addProperty("avg_all",  all.stream().mapToDouble(d -> d).average().orElse(0));
            // Rolling-window average of last 60 (fix #32)
            List<Double> recent = s.recentSpeeds.snapshot();
            o.addProperty("avg_recent_60",
                recent.stream().mapToDouble(d -> d).average().orElse(0));
        }
        if (!flagged.isEmpty()) {
            double minFlagged = flagged.stream().mapToDouble(d -> d).min().orElse(0);
            double safeCapV   = minFlagged - 0.03;
            o.addProperty("min_flagged", minFlagged);
            o.addProperty("safe_cap",    Math.max(0.1, safeCapV)); // never negative
            o.addProperty("bypass_advice",
                "Set speed < " + String.format("%.4f", Math.max(0.1, safeCapV)) + " bpt");
        } else {
            o.addProperty("safe_cap", 0.5);
            o.addProperty("bypass_advice",
                "No SPEED flags recorded — lower speed-threshold setting and retry");
        }
        o.addProperty("flag_threshold", speedThreshold.get());
        return o;
    }

    // ── Timing block (fix #26 — no double-alloc) ─────────────────────────────
    private JsonObject buildTiming(ClientSession.BoundedDeque<Long> deque, String label) {
        JsonObject o = new JsonObject();
        List<Long> arr = deque.snapshot();
        if (arr.isEmpty()) return o;
        long min = arr.stream().mapToLong(l -> l).min().orElse(0);
        long avg = (long) arr.stream().mapToLong(l -> l).average().orElse(0);
        long safe = min + 5;
        o.addProperty("min_flagged_ms", min);
        o.addProperty("avg_ms",         avg);
        o.addProperty("safe_delay_ms",  safe);
        o.addProperty("samples",        arr.size());
        o.addProperty("confidence",     arr.size() >= 10 ? "high" : arr.size() >= 3 ? "medium" : "low");
        o.addProperty("bypass_advice",  "Set " + label + " >= " + safe + "ms");
        return o;
    }

    // ── Raid bypass summary ───────────────────────────────────────────────────
    private JsonObject buildSummary(JsonObject r, ClientSession s) {
        JsonObject sum = new JsonObject();
        StringBuilder advice = new StringBuilder();

        JsonObject spd = r.getAsJsonObject("speed");
        if (spd.has("safe_cap"))
            advice.append("SPEED: cap=")
                  .append(String.format("%.4f", spd.get("safe_cap").getAsDouble()))
                  .append(" bpt | ");

        appendTiming(advice, r.getAsJsonObject("dig_timing"),    "MINE");
        appendTiming(advice, r.getAsJsonObject("place_timing"),  "PLACE");
        appendTiming(advice, r.getAsJsonObject("attack_timing"), "ATTACK");

        JsonObject ping = r.getAsJsonObject("ping");
        if (ping.has("avg_ms"))
            advice.append("PING avg=").append(ping.get("avg_ms").getAsLong()).append("ms");

        sum.addProperty("module_config",          advice.toString());
        sum.addProperty("unknown_ac_packets",     s.unknownPackets.size());
        sum.addProperty("velocity_bypass_possible", s.velocityBypassCount.get() > 0);
        sum.addProperty("teleport_bypass_seen",   s.teleportBypassCount.get() > 0);
        sum.addProperty("aimbot_snap_count",      s.snapAimCount.get());
        sum.addProperty("scaffold_detected",      s.scaffoldCount.get() > 10);
        sum.addProperty("ready",
            (System.currentTimeMillis() - s.sessionStartMs) > 30_000
            && s.totalPackets.get() > 200
            && s.flagCount.get() > 0);
        return sum;
    }

    private void appendTiming(StringBuilder sb, JsonObject block, String label) {
        if (block != null && block.has("safe_delay_ms"))
            sb.append(label).append(": delay=")
              .append(block.get("safe_delay_ms").getAsLong()).append("ms | ");
    }

    // ── Human-readable text ───────────────────────────────────────────────────
    private String buildTxt(ClientSession s, JsonObject sum) {
        return "=== ACCollector V8 Meteor ===\n"
            + "Player:               " + s.playerName + "\n"
            + "Session:              " + s.sessionStartStr + "\n"
            + "Total Packets:        " + s.totalPackets.get() + "\n"
            + "Total Flags:          " + s.flagCount.get() + "\n"
            + "Peak PPS:             " + s.peakPps() + "\n"
            + "Velocity Bypass:      " + s.velocityBypassCount.get() + "\n"
            + "Teleport Bypass:      " + s.teleportBypassCount.get() + "\n"
            + "Snap-Aim Count:       " + s.snapAimCount.get() + "\n"
            + "Scaffold Count:       " + s.scaffoldCount.get() + "\n"
            + "Unknown AC Packets:   " + s.unknownPackets.size() + "\n"
            + "\nModule Config:\n  " + sum.get("module_config").getAsString() + "\n"
            + "\nReady for module build: " + sum.get("ready").getAsBoolean() + "\n";
    }
}
