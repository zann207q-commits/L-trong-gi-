# 3D Character (custom model) — gộp vào Kaze

## Đã thêm (không sửa GUI / module khác)
- Module `3D Character` (Category RENDER) — `module/modules/render/Character3D.java`
  - Character: CJ / NEIGHBOR / CUSTOM (CUSTOM = file .anc đầu tiên trong `config/kaze/characters/`)
  - Detail: LOW / MEDIUM / HIGH
  - Held Items: bật/tắt vẽ item cầm tay
- Engine: package `skid.kaze.model` (loader .anc, mesh renderer, cache, ánh sáng, joint/knee/elbow)
- Mixin mới (đã thêm vào `client.mixins.json`): `LivingEntityRendererMixin`, `PlayerEntityRendererMixin`,
  `PlayerEntityRenderStateMixin`, `BipedEntityModelMixin` (tất cả `require = 0`)
- Asset: `assets/kaze/characters/cj.anc`, `neighbor.anc`
- Sửa duy nhất ở file cũ: `ModuleManager` (1 import + 1 dòng đăng ký), `client.mixins.json` (4 dòng)

## Giới hạn (do 3.zip thiếu file)
3.zip chỉ có 38 file, thiếu nhiều class mà các nhánh khác cần
(SdfMeshBaker, PixelCanvas, SurfacePaint, GlbDocument, GltfTransforms, MeshSimplifier, ...).
Vì vậy chỉ port nhánh chạy được hoàn chỉnh là **.anc (baked)**:
- Không port: Sakura/Luna/Mika/Aoi/Miku/TungTungSahur/Tralalero (thiết kế SDF) và nạp .glb.
- `BoneMotionProfile` (vật lý tóc/váy) thiếu trong zip -> chỉ giữ stub; .anc không dùng motion nên CJ/Neighbor không ảnh hưởng.
- `DirectionalLighting`, `ArgbColors.clamp` được viết lại (đơn giản, tương đương logic).
- Nút "Open Characters Folder" bỏ (Kaze chưa có ActionSetting); thư mục tự tạo khi bật module.

## Chưa build được ở đây (không có Gradle/jar Minecraft)
- Đã kiểm tra: javac không báo lỗi nào liên quan symbol nội bộ project; 2 file .anc parse đúng tới EOF theo format của loader.
- Mixin viết theo Yarn 1.21.11, chưa xác minh với jar thật. Nếu log có "Mixin ... not found/skipped" thì chỉ cần sửa descriptor:
  - `LivingEntityRenderer.updateRenderState` (quyết định mặc model)
  - `LivingEntityRenderer.getRenderLayer(S,Z,Z,Z)` (ẩn body vanilla; trả null)
  - `FeatureRenderer.render(...)` trong `LivingEntityRenderer.render` (vẽ model + ẩn giáp/cape/elytra/...)
  - `PlayerEntityRenderer.renderArm(...)` (tay góc nhìn thứ nhất), `BipedEntityModel.setArmAngle(...)` (item cầm tay)
- Chạy `./gradlew build` (JDK 21) và gửi log nếu có lỗi.
