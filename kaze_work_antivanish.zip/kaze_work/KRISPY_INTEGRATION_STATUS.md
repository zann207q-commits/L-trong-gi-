# Kaze + Krispy Donut Finding integration — repair pass

## Integrated into Kaze's module system
- Added `DONUT_FINDING` category between `DONUT` and `RENDER`.
- Existing `ChunkFinder` is registered in `DONUT_FINDING`; its `HoleESP` setting remains present.
- Added and registered three Kaze-native modules: `Chunk Finder Krispy`, `Prime Chunk Finder`, and `Sus Chunk V2`.
- All three use Kaze's `Module`, settings, event bus, and `TickEvent`, so they are visible in the normal module list instead of remaining in staging.
- Their scan loop runs on the client thread, checks only already-loaded chunks, scans a bounded vertical range, and processes at most one chunk per 10 ticks to reduce client stalls.
- NetheriteFinder/Netherfinder remains excluded.

## Important compatibility limitation
These three modules are **Kaze-native functional adaptations**, not byte-for-byte or algorithm-for-algorithm ports of the original Krispy implementations. Their current detection is deliberately conservative/simple:
- `Chunk Finder Krispy`: counts cobbled deepslate and sideways deepslate.
- `Prime Chunk Finder`: counts underground infrastructure-like blocks (cobbled deepslate, pistons, TNT, spawners).
- `Sus Chunk V2`: counts a broader set of suspicious/non-natural blocks, including obsidian and storage blocks.

They report chunk coordinates in chat when the configured hit threshold is reached. They do not yet reproduce Krispy's original render overlays, probing logic, heat maps, or all original settings. This limitation is explicit so the code is not misrepresented as a complete original Krispy port.

## Build and runtime status
- Static integration check: the three new classes are imported and instantiated by `ModuleManager`; their sources are inside Gradle's main source set.
- ZIP integrity check passes.
- A real Gradle build and Minecraft launch have **not** been verified in this environment because no Gradle executable/wrapper or cached Minecraft/Fabric dependencies are available. The `javac` check cannot type-check Minecraft API calls without those dependencies.
- Before using it, run `gradle build` (or add a Gradle Wrapper) with JDK 21 and network access. Fix any API compile errors shown by that build log, then test each module in a test world/server.

## Anti Vanish (added)
- `module/modules/donut/AntiVanish.java`, category `DONUT`, registered in `ModuleManager` after `AntiTrap`.
- Ported from Krispy `AntiVanishModule` + `AntiVanishHudOverlay`; the side panel is drawn by the module on `Render2DEvent`.
- Real Krispy helpers ported to `utils/vanish/`: `VanishChatParser` (unchanged), `VanishSignalClassifier`, `VanishAlertRules` (staff list kept), `PlayerWatchHud` (note text rebranded to Kaze).
- Still re-implemented locally: `ModuleChat` (plain chat lines), `NameFilter` (identity), `DonutRegionTracker` (reset on world change / 128+ block jump).
- Settings: Sensor Range, Chat Alerts, Alert Sound, Title Alert, HUD, Any Player, Command Probe, Extra Names.
- Not compiled: no javac / Gradle / Minecraft deps in this environment. Run `./gradlew build` and fix any API errors.
