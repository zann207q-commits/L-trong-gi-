package krispy.feature;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.network.packet.s2c.play.LightData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ChunkLightQueue {
   private static final Logger LOG = LoggerFactory.getLogger("Krispy ChunkFinder");
   private static final int DETECTION_CUTOFF_Y = 1;
   private static final int MAX_DRAIN_PER_TICK = 4096;
   private static final int MAX_SNAPSHOTS = 8192;
   private final Queue<PendingLight> queue = new ConcurrentLinkedQueue<>();
   private final Map<Long, ChunkLightSnapshot> snapshots =
      new LinkedHashMap<Long, ChunkLightSnapshot>(256, 0.75F, true) {
         @Override
         protected boolean removeEldestEntry(Map.Entry<Long, ChunkLightSnapshot> eldest) {
            return this.size() > MAX_SNAPSHOTS;
         }
      };
   private final Set<Long> alertedChunks = new HashSet<>();
   private final Set<AlertedSection> alertedSections = new HashSet<>();
   private final Listener listener;
   private long stamp;

   public ChunkLightQueue(Listener listener) {
      this.listener = listener;
   }

   public void offer(int var1, int var2, LightData var3) {
      if (var3 != null) {
         this.queue.offer(new PendingLight(var1, var2, var3));
      }
   }

   public void clear() {
      this.queue.clear();
      this.snapshots.clear();
      this.alertedChunks.clear();
      this.alertedSections.clear();
   }

   public void drain(int var1, int var2) {
      long var3 = System.nanoTime() + 3000000L;

      for (int var5 = 0; var5 < 4096; var5++) {
         if (var5 > 0 && (var5 & 7) == 0 && System.nanoTime() >= var3) {
            return;
         }

         PendingLight var6 = this.queue.poll();
         if (var6 == null) {
            return;
         }

         this.ingest(var6, var1, var2);
      }
   }

   private void ingest(PendingLight var1, int var2, int var3) {
      long var4 = chunkKey(var1.chunkX(), var1.chunkZ());
      ChunkLightSnapshot var6 = this.snapshots.get(var4);
      if (var6 == null || var6.sectionCount != var2 || var6.bottomSectionY != var3) {
         var6 = new ChunkLightSnapshot(var2, var3);
         this.snapshots.put(var4, var6);
      }

      long var7 = ++this.stamp;

      try {
         LightPayloadClassifier.apply(var1.data(), var6, var7);
      } catch (Throwable var10) {
         LOG.error("[Chunk Finder] Light classifier crashed on chunk " + var1.chunkX() + "," + var1.chunkZ(), var10);
         return;
      }

      this.maybeAlert(var1.chunkX(), var1.chunkZ(), var4, var6, var7);
   }

   private void maybeAlert(int var1, int var2, long var3, ChunkLightSnapshot var5, long var6) {
      for (int var8 = 1; var8 <= var5.sectionCount; var8++) {
         int var9 = (var5.bottomSectionY + var8 - 1) * 16;
         if (var9 >= 1) {
            break;
         }

         if (var5.skyUpdated[var8] == var6) {
            this.inspect(Track.SKY, var1, var2, var3, var9, var5.sky[var8]);
         }

         if (var5.blockUpdated[var8] == var6) {
            this.inspect(Track.BLOCK, var1, var2, var3, var9, var5.block[var8]);
         }
      }
   }

   private void inspect(Track var1, int var2, int var3, long var4, int var6, SkyLightPattern var7) {
      if ((var7 == SkyLightPattern.ZEROED_PRESENT || var7 == SkyLightPattern.UNIFORM_MAX)
         && this.alertedSections.add(new AlertedSection(var4, var6, var1))
         && this.alertedChunks.add(var4)) {
         this.listener.onChunkFound(var2, var3, var6);
      }
   }

   private static long chunkKey(int var0, int var1) {
      return (long)var0 & 4294967295L | ((long)var1 & 4294967295L) << 32;
   }

   private record AlertedSection(long chunkKey, int sectionY, Track track) {}

   public interface Listener {
      void onChunkFound(int chunkX, int chunkZ, int sectionY);
   }

   private enum Track { SKY, BLOCK }

   private record PendingLight(int chunkX, int chunkZ, LightData data) {}
}
