package krispy.feature;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import krispy.Krispy;
import krispy.event.EventListener;
import krispy.event.events.ChunkDataEvent;
import krispy.event.events.LightUpdateEvent;
import krispy.event.events.Render3DEvent;
import krispy.event.events.SetBlockStateEvent;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.utils.EncryptedString;
import krispy.utils.RenderUtils;
import net.minecraft.client.render.Camera;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap.Type;

public final class ChunkFinderModule extends Module {
   private static final int MAX_FLAGS = 512;
   private static final long DIG_IGNORE_MS = 4000L;
   private static final double DIG_RANGE_SQ = 64.0;
   private static final SoundEvent FLAG_SOUND = SoundEvent.of(Identifier.of("krispy", "chunk_flag"));

   private final NumberSetting plateSize;
   private final BooleanSetting outline;
   private final NumberSetting plateThickness;
   private final BooleanSetting advancementNotifications;
   private final BooleanSetting soundPing;
   private final NumberSetting soundVolume;
   private final BooleanSetting kickOnFlag;
   private final ChunkLightQueue lightCache;
   private final Map<Long, FlaggedChunk> flags = new LinkedHashMap<>();
   private final Map<Long, Long> recentDigs = new HashMap<>();
   private final List<RenderUtils.ColoredBox> renderBoxes = new ArrayList<>();
   private final List<RenderUtils.ColoredLine> renderLines = new ArrayList<>();
   private ClientWorld trackedWorld;

   public ChunkFinderModule() {
      super(
         EncryptedString.of("Chunk Finder"),
         EncryptedString.of("detects bases underground [ Only works on DonutSMP]"),
         -1,
         Category.DONUT
      );
      plateSize = new NumberSetting(EncryptedString.of("Plate Size"), 1.0, 64.0, 16.0, 0.5);
      outline = new BooleanSetting(EncryptedString.of("Outline"), true);
      plateThickness = new NumberSetting(EncryptedString.of("Plate Thickness"), 0.01, 4.0, 0.15, 0.01);
      advancementNotifications = new BooleanSetting(EncryptedString.of("Advancement Notifications"), true)
         .setDescription(EncryptedString.of("Shows a Chunk Finder advancement popup for every new flagged chunk"));
      soundPing = new BooleanSetting(EncryptedString.of("Sound Ping"), true)
         .setDescription(EncryptedString.of("Plays the original Nexus chunk flag sound"));
      soundVolume = new NumberSetting(EncryptedString.of("Sound Volume"), 0.0, 100.0, 100.0, 1.0);
      kickOnFlag = new BooleanSetting(EncryptedString.of("Kick On Flag"), false)
         .setDescription(EncryptedString.of("Disconnects on the next flag, then turns this setting and Auto RTP off"));
      lightCache = new ChunkLightQueue(this::flagLightChunk);
      addSettings(plateSize, plateThickness, outline, advancementNotifications, soundPing, soundVolume, kickOnFlag);
   }

   @Override
   public void onEnable() {
      reset();
      trackedWorld = mc.world;
      super.onEnable();
   }

   @Override
   public void onDisable() {
      reset();
      super.onDisable();
   }

   private void reset() {
      lightCache.clear();
      flags.clear();
      recentDigs.clear();
      renderBoxes.clear();
      renderLines.clear();
      trackedWorld = null;
   }

   private void ensureWorld() {
      if (trackedWorld != mc.world) {
         reset();
         trackedWorld = mc.world;
      }
   }

   @EventListener
   public void onChunkData(ChunkDataEvent event) {
      ensureWorld();
      if (mc.world != null) {
         lightCache.offer(event.packet.getChunkX(), event.packet.getChunkZ(), event.packet.getLightData());
      }
   }

   @EventListener
   public void onLightUpdate(LightUpdateEvent event) {
      ensureWorld();
      if (mc.world != null) {
         lightCache.offer(event.packet.getChunkX(), event.packet.getChunkZ(), event.packet.getData());
      }
   }

   @EventListener
   public void onTick(TickEvent event) {
      ensureWorld();
      if (mc.world != null && mc.player != null) {
         lightCache.drain(mc.world.countVerticalSections(), mc.world.getBottomSectionCoord());
      }
   }

   @EventListener
   public void onBlockChanged(SetBlockStateEvent event) {
      if (mc.player != null && event.pos != null
         && mc.player.squaredDistanceTo(Vec3d.ofCenter(event.pos)) <= DIG_RANGE_SQ) {
         recentDigs.put(ChunkPos.toLong(event.pos.getX() >> 4, event.pos.getZ() >> 4), System.currentTimeMillis());
      }
   }

   private boolean nearRecentDig(int chunkX, int chunkZ) {
      long now = System.currentTimeMillis();
      recentDigs.values().removeIf(timestamp -> now - timestamp > DIG_IGNORE_MS);
      for (long packedPos : recentDigs.keySet()) {
         if (Math.abs(ChunkPos.getPackedX(packedPos) - chunkX) <= 1
            && Math.abs(ChunkPos.getPackedZ(packedPos) - chunkZ) <= 1) {
            return true;
         }
      }
      return false;
   }

   private void flagLightChunk(int chunkX, int chunkZ, int lightLevel) {
      if (nearRecentDig(chunkX, chunkZ)) {
         return;
      }
      int blockX = (chunkX << 4) + 8;
      int blockZ = (chunkZ << 4) + 8;
      int surfaceY = mc.world != null && mc.world.isChunkLoaded(chunkX, chunkZ)
         ? Math.max(21, mc.world.getTopY(Type.WORLD_SURFACE, blockX, blockZ))
         : 21;
      flagChunk(new BlockPos(blockX, surfaceY, blockZ));
   }

   private void flagChunk(BlockPos position) {
      ChunkPos chunk = new ChunkPos(position);
      FlaggedChunk flag = new FlaggedChunk(chunk, Math.max(21, position.getY()), position.getX(), position.getZ());
      if (flags.putIfAbsent(chunk.toLong(), flag) != null) {
         return;
      }
      if (flags.size() > MAX_FLAGS) {
         flags.remove(flags.keySet().iterator().next());
      }
      if (advancementNotifications.getValue()) {
         showAdvancement(flag);
      }
      if (soundPing.getValue()) {
         float volume = soundVolume.getIntValue() / 100.0F;
         mc.getSoundManager().play(PositionedSoundInstance.ui(FLAG_SOUND, 1.0F, volume));
      }
      if (kickOnFlag.getValue() && mc.getNetworkHandler() != null) {
         kickOnFlag.setValue(false);
         AutoRtpModule autoRtp = (AutoRtpModule)Krispy.INSTANCE.getModuleManager().getModuleByClass(AutoRtpModule.class);
         if (autoRtp != null) {
            autoRtp.toggle(false);
         }
         Krispy.INSTANCE.getSettingsManager().saveNow();
         mc.getNetworkHandler().getConnection().disconnect(Text.literal(
            "Kicked - Chunk Finder flagged X: " + flag.x() + " Z: " + flag.z()
               + "\nKick On Flag was automatically turned OFF."
         ));
      }
   }

   private void showAdvancement(FlaggedChunk flag) {
      mc.getToastManager().add(new ChunkFinderToast(flag.x(), flag.z()));
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (flags.isEmpty() || mc.player == null) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }
      renderBoxes.clear();
      renderLines.clear();
      double halfSize = plateSize.getValue() / 2.0;
      double thickness = plateThickness.getValue();
      Color fillColor = new Color(0, 255, 70, 75);
      Color outlineColor = new Color(0, 255, 70, 220);
      ChunkPos playerChunk = mc.player.getChunkPos();
      for (FlaggedChunk flag : flags.values()) {
         if (Math.abs(flag.chunk().x - playerChunk.x) > 24 || Math.abs(flag.chunk().z - playerChunk.z) > 24) {
            continue;
         }
         double centerX = flag.chunk().getCenterX();
         double centerZ = flag.chunk().getCenterZ();
         double topY = flag.y() + 1.002;
         renderBoxes.add(new RenderUtils.ColoredBox(
            centerX - halfSize, topY, centerZ - halfSize,
            centerX + halfSize, topY + thickness, centerZ + halfSize, fillColor
         ));
         if (outline.getValue()) {
            RenderUtils.addBoxOutline(
               renderLines,
               centerX - halfSize, topY, centerZ - halfSize,
               centerX + halfSize, topY + thickness, centerZ + halfSize, outlineColor, 1.5F
            );
         }
      }
      if (!renderBoxes.isEmpty()) {
         MatrixStack matrices = event.matrixStack;
         matrices.push();
         RenderUtils.applyCameraTransform(matrices, camera);
         RenderUtils.renderFilledBoxes(matrices, renderBoxes);
         if (!renderLines.isEmpty()) {
            RenderUtils.renderLines(matrices, renderLines);
         }
         matrices.pop();
      }
   }

   private record FlaggedChunk(ChunkPos chunk, int y, int x, int z) {
   }
}
