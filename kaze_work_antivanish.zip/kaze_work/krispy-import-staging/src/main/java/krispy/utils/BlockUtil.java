package krispy.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import krispy.Krispy;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.block.RespawnAnchorBlock;

public final class BlockUtil {
   public static Stream<WorldChunk> getLoadedChunks() {
      return getLoadedChunksList().stream();
   }

   public static List<WorldChunk> getLoadedChunksList() {
      int radius = Math.max(2, Krispy.mc.options.getClampedViewDistance()) + 3;
      ChunkPos center = Krispy.mc.player.getChunkPos();
      List<WorldChunk> loaded = new ArrayList<>((radius * 2 + 1) * (radius * 2 + 1));

      for (int x = center.x - radius; x <= center.x + radius; x++) {
         for (int z = center.z - radius; z <= center.z + radius; z++) {
            if (Krispy.mc.world.isChunkLoaded(x, z)) {
               WorldChunk chunk = Krispy.mc.world.getChunk(x, z);
               if (chunk != null) {
                  loaded.add(chunk);
               }
            }
         }
      }

      return loaded;
   }

   public static boolean isBlockAtPosition(BlockPos blockPos, Block block) {
      return Krispy.mc.world.getBlockState(blockPos).getBlock() == block;
   }

   public static boolean isRespawnAnchorCharged(BlockPos blockPos) {
      return isBlockAtPosition(blockPos, Blocks.RESPAWN_ANCHOR)
         && (Integer)Krispy.mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) != 0;
   }

   public static boolean isRespawnAnchorUncharged(BlockPos blockPos) {
      return isBlockAtPosition(blockPos, Blocks.RESPAWN_ANCHOR)
         && (Integer)Krispy.mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) == 0;
   }

   public static void interactWithBlock(BlockHitResult blockHitResult, boolean shouldSwingHand) {
      ActionResult result = Krispy.mc.interactionManager.interactBlock(Krispy.mc.player, Hand.MAIN_HAND, blockHitResult);
      if (result.isAccepted() && shouldSwingHand) {
         Krispy.mc.player.swingHand(Hand.MAIN_HAND);
      }
   }
}
