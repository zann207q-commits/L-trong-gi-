package krispy.utils.ext;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.world.World;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.dimension.DimensionTypes;

@Environment(EnvType.CLIENT)
public final class LevelUtil {
   private LevelUtil() {
   }

   public static boolean isOverworld(ClientWorld var0) {
      return var0.getRegistryKey() == World.OVERWORLD || var0.getDimensionEntry().matchesKey(DimensionTypes.OVERWORLD);
   }

   public static boolean isLoaded(ClientWorld var0, int var1, int var2) {
      return var0.getChunkManager().isChunkLoaded(var1, var2);
   }
}
