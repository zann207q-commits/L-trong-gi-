Krispy — base/chunk finder source subset

Included finder modules:
- ChunkFinderModule
- ChunkFinderBetterModule
- PrimeChunkFinderModule
- SusChunkFinderModule
- SusChunkV2Module
- RegionMapModule
- LuckyFinderModule (included at user's request; this marks nearby chunks randomly and is not a reliable base detector)

Included toast/helper/event/render source files selected for these modules.

Intentionally excluded:
- RtpBaseFinderModule
- TunnelBaseFinderModule
- NetheriteFinderModule (user refers to this as Netherfinder)
- AutoRtpModule, AutoTotemModule, AutoEatModule

This is a source subset, not a complete project or ready-to-install JAR. It may need additional framework files from the original project to compile and has not been built or runtime-tested.
