# Kaze + Krispy Donut Finding — port pass

## Kaze-native modules registered in ClickGUI
- `Chunk Finder Krispy`
- `Prime Chunk Finder`
- `Sus Chunk V2`

All three are registered through Kaze's `ModuleManager`, use Kaze's event bus and settings, and are assigned to `DONUT_FINDING`. The legacy `Chunk Finder` remains available under the same category and its `HoleESP` setting is preserved.

## Compatibility note
These are Kaze-native adaptations of the source module ideas, not full algorithm-preserving ports of Krispy's original implementations. The original modules rely on Krispy-specific events, settings, mixins, rendering helpers and packet hooks. Their complete original behaviour (heat maps, packet/light-delta detection, overlays and every original setting) has not been reproduced in this pass. The original source snippets remain in `krispy-import-staging` for reference; that folder is deliberately outside Gradle's compiled source set.

## Build configuration
- Target Minecraft: 1.21.11
- Java: 21
- Updated Fabric Loom, Yarn mappings, loader and Fabric API versions to the versions declared by the supplied `krispy-cleaned.zip` source project.
- Added Gradle Wrapper scripts and wrapper JAR.

## Verification
- ZIP integrity and static source/registration checks pass.
- A real Gradle build could not be completed in this environment because `services.gradle.org` cannot be resolved (network/DNS unavailable). Therefore no claim is made that this ZIP compiles or launches. Run `./gradlew build` on a network-connected machine with JDK 21 and resolve any compiler/API errors from the resulting build log.
