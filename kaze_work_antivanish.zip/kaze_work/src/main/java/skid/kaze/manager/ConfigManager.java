package skid.kaze.manager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import skid.kaze.Kaze;
import skid.kaze.module.Module;
import skid.kaze.module.modules.client.SelfDestruct;
import skid.kaze.module.setting.BindSetting;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.ItemSetting;
import skid.kaze.module.setting.MinMaxSetting;
import skid.kaze.module.setting.ModeSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.module.setting.StringSetting;

public final class ConfigManager {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private JsonObject jsonObject;
   private final Path file;

   public ConfigManager() {
      Path path;
      try {
         path = FabricLoader.getInstance().getConfigDir().resolve("kaze").resolve("config.json");
      } catch (Throwable t) {
         path = Path.of("config", "kaze", "config.json");
      }

      this.file = path;
      // Fallback: the game can also end through System.exit (crash report, launcher "stop"), which
      // may not pass through MinecraftClient.stop(). save() is idempotent, so a second write is harmless.
      try {
         Runtime.getRuntime().addShutdownHook(new Thread(this::save, "Kaze-config-save"));
      } catch (Throwable ignored) {
      }
   }

   public void loadProfile() {
      if (this.jsonObject == null) {
         this.jsonObject = this.readFile();
      }

      if (Kaze.INSTANCE == null || Kaze.INSTANCE.getModuleManager() == null) {
         return;
      }

      for(Module next : Kaze.INSTANCE.getModuleManager().c()) {
         try {
            JsonElement value = this.jsonObject.get(next.getName().toString());
            if (value == null || !value.isJsonObject()) {
               continue;
            }

            JsonObject asJsonObject = value.getAsJsonObject();

            // Settings first, so onEnable() already sees the saved values.
            for(Object next2 : next.getSettings()) {
               JsonElement value3 = asJsonObject.get(((Setting)next2).getName().toString());
               if (value3 != null) {
                  this.setValueFromJson((Setting)next2, value3, next);
               }
            }

            JsonElement value2 = asJsonObject.get("enabled");
            if (value2 != null && value2.isJsonPrimitive() && value2.getAsBoolean()) {
               try {
                  next.toggle(true);
               } catch (Throwable t) {
                  // onEnable() needs a world/player that does not exist yet at startup.
                  next.setEnabled(false);
                  System.err.println("[Kaze] Could not re-enable " + next.getName() + " on load: " + t);
               }
            }
         } catch (Throwable ex) {
            System.err.println("[Kaze] Error loading profile entry: " + ex);
         }
      }

   }

   private JsonObject readFile() {
      try {
         if (Files.isRegularFile(this.file)) {
            String text = Files.readString(this.file, StandardCharsets.UTF_8);
            JsonElement parsed = JsonParser.parseString(text);
            if (parsed != null && parsed.isJsonObject()) {
               return parsed.getAsJsonObject();
            }
         }
      } catch (Throwable ex) {
         System.err.println("[Kaze] Could not read " + this.file + ": " + ex);
      }

      return new JsonObject();
   }

   /** Snapshots all modules to disk. Called when the game stops (and by the shutdown hook). */
   public synchronized void save() {
      if (SelfDestruct.isActive) {
         return; // self destruct wipes names/state on purpose - never persist that.
      }

      if (Kaze.INSTANCE == null || Kaze.INSTANCE.getModuleManager() == null) {
         return;
      }

      try {
         this.shutdown();
         Path dir = this.file.getParent();
         if (dir != null) {
            Files.createDirectories(dir);
         }

         Path tmp = this.file.resolveSibling(this.file.getFileName() + ".tmp");
         Files.writeString(tmp, GSON.toJson(this.jsonObject), StandardCharsets.UTF_8);
         try {
            Files.move(tmp, this.file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, this.file, StandardCopyOption.REPLACE_EXISTING);
         }
      } catch (Throwable ex) {
         System.err.println("[Kaze] Could not save " + this.file + ": " + ex);
      }

   }

   private void setValueFromJson(Setting setting, JsonElement jsonElement, Module module) {
      try {
         if (setting instanceof BooleanSetting booleanSetting) {
            if (jsonElement.isJsonPrimitive()) {
               booleanSetting.setValue(jsonElement.getAsBoolean());
            }
         } else if (setting instanceof ModeSetting enumSetting) {
            if (jsonElement.isJsonPrimitive()) {
               int asInt = jsonElement.getAsInt();
               if (asInt != -1) {
                  enumSetting.setModeIndex(asInt);
               } else {
                  enumSetting.setModeIndex(enumSetting.getOriginalValue());
               }
            }
         } else if (setting instanceof NumberSetting numberSetting) {
            if (jsonElement.isJsonPrimitive()) {
               numberSetting.getValue(jsonElement.getAsDouble());
            }
         } else if (setting instanceof BindSetting bindSetting) {
            if (jsonElement.isJsonPrimitive()) {
               int asInt2 = jsonElement.getAsInt();
               bindSetting.setValue(asInt2);
               if (bindSetting.isModuleKey()) {
                  module.setKeybind(asInt2);
               }
            }
         } else if (setting instanceof StringSetting stringSetting) {
            if (jsonElement.isJsonPrimitive()) {
               stringSetting.setValue(jsonElement.getAsString());
            }
         } else if (setting instanceof MinMaxSetting minMaxSetting) {
            if (jsonElement.isJsonObject()) {
               JsonObject asJsonObject = jsonElement.getAsJsonObject();
               if (asJsonObject.has("min") && asJsonObject.has("max")) {
                  double asDouble = asJsonObject.get("min").getAsDouble();
                  double asDouble2 = asJsonObject.get("max").getAsDouble();
                  minMaxSetting.setCurrentMin(asDouble);
                  minMaxSetting.setCurrentMax(asDouble2);
               }
            }
         } else if (setting instanceof ItemSetting && jsonElement.isJsonPrimitive()) {
            ((ItemSetting)setting).setItem(Registries.ITEM.get(Identifier.of(jsonElement.getAsString())));
         }
      } catch (Exception var15) {
      }

   }

   /** In-memory snapshot only (SelfDestruct relies on this not touching the disk). */
   public void shutdown() {
      JsonObject snapshot = new JsonObject();

      for(Module module : Kaze.INSTANCE.getModuleManager().c()) {
         try {
            if (module.getName() == null) {
               continue;
            }

            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("enabled", module.isEnabled());

            for(Setting setting : module.getSettings()) {
               this.save(setting, jsonObject, module);
            }

            snapshot.add(module.getName().toString(), jsonObject);
         } catch (Throwable _t) {
            _t.printStackTrace(System.err);
         }
      }

      this.jsonObject = snapshot;
   }

   private void save(Setting setting, JsonObject jsonObject, Module module) {
      try {
         if (setting instanceof BooleanSetting booleanSetting) {
            jsonObject.addProperty(setting.getName().toString(), booleanSetting.getValue());
         } else if (setting instanceof ModeSetting<?> enumSetting) {
            jsonObject.addProperty(setting.getName().toString(), enumSetting.getModeIndex());
         } else if (setting instanceof NumberSetting numberSetting) {
            jsonObject.addProperty(setting.getName().toString(), numberSetting.getValue());
         } else if (setting instanceof BindSetting bindSetting) {
            jsonObject.addProperty(setting.getName().toString(), bindSetting.getValue());
         } else if (setting instanceof StringSetting stringSetting) {
            jsonObject.addProperty(setting.getName().toString(), stringSetting.getValue());
         } else if (setting instanceof MinMaxSetting) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("min", ((MinMaxSetting)setting).getCurrentMin());
            jsonObject2.addProperty("max", ((MinMaxSetting)setting).getCurrentMax());
            jsonObject.add(setting.getName().toString(), jsonObject2);
         } else if (setting instanceof ItemSetting) {
            ItemSetting itemSetting = (ItemSetting)setting;
            jsonObject.addProperty(setting.getName().toString(), Registries.ITEM.getId(itemSetting.getItem()).toString());
         }
      } catch (Exception ex) {
         PrintStream var10000 = System.err;
         String var10001 = String.valueOf(setting.getName());
         var10000.println("Error saving setting " + var10001 + ": " + ex.getMessage());
      }

   }
}
