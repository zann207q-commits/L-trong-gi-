package skid.kaze.module.modules.donutfinding;

import java.awt.Color;
import net.minecraft.block.BlockState;

/** Kaze-native suspicious infrastructure density finder inspired by Krispy's Prime finder. */
public final class PrimeChunkFinder extends ChunkScanModule {
    public PrimeChunkFinder() {
        super("Prime Chunk Finder", "Flags chunks with dense underground infrastructure blocks", 8);
    }

    @Override protected boolean matches(BlockState state) {
        return isKrispySuspiciousBlock(state);
    }

    @Override protected Color plateColor() {
        return new Color(170, 60, 255);
    }
}
