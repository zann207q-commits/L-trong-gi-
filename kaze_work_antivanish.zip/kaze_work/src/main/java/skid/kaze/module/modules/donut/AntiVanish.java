package skid.kaze.module.modules.donut;

import com.mojang.brigadier.suggestion.Suggestion;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.RequestCommandCompletionsC2SPacket;
import net.minecraft.network.packet.s2c.play.CommandSuggestionsS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityTrackerUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.ParticleS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundFromEntityS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import skid.kaze.Kaze;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.PacketReceiveEvent;
import skid.kaze.event.events.PacketSendEvent;
import skid.kaze.event.events.Render2DEvent;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.StringSetting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;
import skid.kaze.utils.TextRenderer;
import skid.kaze.utils.vanish.PlayerWatchHud;
import skid.kaze.utils.vanish.VanishAlertRules;
import skid.kaze.utils.vanish.VanishChatParser;
import skid.kaze.utils.vanish.VanishSignalClassifier;

/**
 * Anti Vanish - detects players (staff) that vanish.
 *
 * Ported from the Krispy AntiVanishModule + AntiVanishHudOverlay into Kaze's module system.
 * Helpers live in skid.kaze.utils.vanish (VanishChatParser, VanishAlertRules,
 * VanishSignalClassifier, PlayerWatchHud). Only ModuleChat, NameFilter and
 * DonutRegionTracker are re-implemented locally.
 */
public final class AntiVanish extends Module {
   private static final String PROBE_COMMAND = "minecraft:msg";
   private static final long SIGNAL_WINDOW_MS = 15000L;
   private static final long DETECTION_TTL_MS = 20000L;
   private static final long CRITICAL_COOLDOWN_MS = 12000L;
   private static final long ANNOUNCE_COOLDOWN_MS = 1500L;
   private static final long ANNOUNCE_WINDOW_MS = 4000L;
   private static final int MAX_ANNOUNCE_PER_WINDOW = 6;
   private static final int MAX_OBSERVATIONS_PER_TICK = 512;
   private static final int CRITICAL_SCORE = 35;
   private static final long SELF_PLACE_TTL_MS = 6000L;
   private static final long CONTAINER_SELF_GRACE_MS = 2500L;
   private static final long RECENT_MESSAGE_TTL_MS = 8000L;
   private static final long TRUSTED_LISTED_MS = 1500L;
   private static final int WARN_COLOR = 0xFFFFAA00;

   // ---- settings
   private final NumberSetting sensorRange = new NumberSetting(EncryptedString.of("Sensor Range"), 16, 128, 64, 1);
   private final BooleanSetting chatAlerts = new BooleanSetting(EncryptedString.of("Chat Alerts"), true);
   private final BooleanSetting alertSound = new BooleanSetting(EncryptedString.of("Alert Sound"), true);
   private final BooleanSetting hud = new BooleanSetting(EncryptedString.of("HUD"), true);
   private final BooleanSetting titleAlert = new BooleanSetting(EncryptedString.of("Title Alert"), true)
      .setDescription(EncryptedString.of("Spinning face + WATCHING YOU title on a critical alert"));
   private final BooleanSetting anyPlayer = new BooleanSetting(EncryptedString.of("Any Player"), false)
      .setDescription(EncryptedString.of("Watch every player instead of only the Donut staff list"));
   private final BooleanSetting commandProbe = new BooleanSetting(EncryptedString.of("Command Probe"), true)
      .setDescription(EncryptedString.of("Tab-completes /msg every 5s to find players hidden from TAB"));
   private final StringSetting watchNames = new StringSetting(EncryptedString.of("Extra Names"), "")
      .setDescription(EncryptedString.of("Comma separated names to watch in addition to the staff list"));

   // ---- runtime state (client thread unless noted)
   private final ConcurrentLinkedQueue<Signal> observations = new ConcurrentLinkedQueue<>();
   private final Map<UUID, String> knownPlayers = new HashMap<>();
   private final Map<String, Alert> detections = new LinkedHashMap<>();
   private final Map<String, Long> signalCooldowns = new HashMap<>();
   private final Map<String, Long> announceCooldowns = new HashMap<>();
   private final Deque<Long> announceTimes = new ArrayDeque<>();
   private final Map<Long, Long> selfPlacedBlocks = new ConcurrentHashMap<>();
   private final Map<UUID, Long> confirmedDepartures = new HashMap<>();
   private final Map<Long, Long> automatedMechanisms = new HashMap<>();
   private final Map<String, Deque<Long>> weakParticleBursts = new HashMap<>();
   private final Deque<Finding> signals = new ArrayDeque<>();
   private final Deque<Blast> recentExplosions = new ArrayDeque<>();
   private final Deque<PendingRemoval> pendingVanishes = new ArrayDeque<>();
   private final Map<String, Spell> hiddenSpells = new LinkedHashMap<>();
   private final Deque<Message> recentMessages = new ArrayDeque<>();
   private final Map<UUID, Long> listedSinceMs = new HashMap<>();
   private final Set<Integer> completionRequestIds = ConcurrentHashMap.newKeySet();
   private volatile List<String> pendingCompletionNames;
   private volatile long lastLocalActionMs;
   private boolean serverSendsLeaveMessages;
   private int nextCompletionId = 30000;
   private int tickCounter;
   private long lastContainerActivityMs;
   private long lastCriticalMs;
   private long criticalUntilMs;
   private String criticalWatcher = "";
   private boolean pendingChime;
   private UUID ghostId;
   private String ghostName;

   // region tracker (resets state after teleports / world changes)
   private Object trackedWorld;
   private Vec3d lastPos;

   public AntiVanish() {
      super(EncryptedString.of("Anti Vanish"), EncryptedString.of("Detects vanished players."), -1, Category.DONUT);
      this.addSettings(sensorRange, chatAlerts, alertSound, titleAlert, hud, anyPlayer, commandProbe, watchNames);
   }

   @Override
   public void onEnable() {
      resetRuntime();
      if (mc.player != null && mc.world != null) {
         trackListedPlayers();
      }
      super.onEnable();
   }

   @Override
   public void onDisable() {
      resetRuntime();
      super.onDisable();
   }

   // ------------------------------------------------------------------ events

   @EventListener
   public void onTick(TickEvent event) {
      if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) {
         resetRuntime();
         return;
      }
      if (regionChanged()) {
         resetRuntime();
      }
      playPendingChime();
      tickCounter++;
      if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) {
         lastContainerActivityMs = System.currentTimeMillis();
      }
      drainObservations();
      processPendingVanishes();
      processCompletionProbe();
      if (commandProbe.getValue() && tickCounter % 100 == 0) {
         sendCompletionProbe();
      }
      if (tickCounter % 10 == 0) {
         trackListedPlayers();
         reviewSpells();
      }
      if (tickCounter % 5 == 0) {
         scanInvisiblePlayers();
      }
      pruneState();
   }

   @EventListener
   public void onPacketSend(PacketSendEvent event) {
      handleOutbound(event.packet);
   }

   @EventListener
   public void onPacketReceive(PacketReceiveEvent event) {
      if (handleInbound(event.packet)) {
         event.cancel();
      }
   }

   @EventListener
   public void onRender2D(Render2DEvent event) {
      if (mc.currentScreen == Kaze.INSTANCE.GUI) {
         return;
      }
      PlayerWatchHud.render(event.context);
      if (!hud.getValue()) {
         return;
      }
      List<HudEntry> entries = hudSnapshot();
      if (entries.isEmpty()) {
         return;
      }
      DrawContext ctx = event.context;
      RenderUtils.unscaledProjection(ctx);
      try {
         int rowH = 28;
         int pad = 14;
         int tagW = 0;
         int valW = 0;
         for (HudEntry e : entries) {
            tagW = Math.max(tagW, TextRenderer.getWidth(hudTag(e)));
            valW = Math.max(valW, TextRenderer.getWidth(hudValue(e)));
         }
         int w = pad * 2 + tagW + 14 + valW;
         int h = rowH * entries.size() + 10;
         int x = 12;
         int y = (int) (mc.getWindow().getFramebufferHeight() * 0.3F);
         RenderUtils.renderRoundedQuad(ctx, new Color(20, 20, 24, 200), x, y, x + w, y + h, 8.0, 15.0);
         for (int i = 0; i < entries.size(); i++) {
            HudEntry e = entries.get(i);
            String tag = hudTag(e);
            boolean hot = "ALERT".equals(tag) || "VANISH".equals(tag);
            int ty = y + 8 + i * rowH;
            TextRenderer.drawString(tag, ctx, x + pad, ty, hot ? WARN_COLOR : 0x8CFFFFFF);
            TextRenderer.drawString(hudValue(e), ctx, x + pad + tagW + 14, ty, 0xF2FFFFFF);
         }
      } finally {
         RenderUtils.scaledProjection(ctx);
      }
   }

   // ------------------------------------------------------------------ packets

   private void handleOutbound(Packet<?> packet) {
      if (packet instanceof PlayerInteractBlockC2SPacket place) {
         lastLocalActionMs = System.currentTimeMillis();
         if (place.getBlockHitResult() == null || place.getBlockHitResult().getBlockPos() == null) {
            return;
         }
         long expiresAt = System.currentTimeMillis() + SELF_PLACE_TTL_MS;
         BlockPos target = place.getBlockHitResult().getBlockPos();
         BlockPos adjacent = target.offset(place.getBlockHitResult().getSide());
         selfPlacedBlocks.put(target.asLong(), expiresAt);
         selfPlacedBlocks.put(adjacent.asLong(), expiresAt);
         String itemPath = "";
         if (mc.player != null && place.getHand() != null) {
            Identifier id = Registries.ITEM.getId(mc.player.getStackInHand(place.getHand()).getItem());
            itemPath = path(id == null ? "" : id.toString());
         }
         markSelfMultiBlockFootprint(target, itemPath, expiresAt);
         markSelfMultiBlockFootprint(adjacent, itemPath, expiresAt);
      } else if (packet instanceof PlayerActionC2SPacket
         || packet instanceof PlayerInteractItemC2SPacket
         || packet instanceof PlayerInteractEntityC2SPacket
         || packet instanceof HandSwingC2SPacket) {
         lastLocalActionMs = System.currentTimeMillis();
      }
   }

   private void markSelfMultiBlockFootprint(BlockPos pos, String itemPath, long expiresAt) {
      selfPlacedBlocks.put(pos.asLong(), expiresAt);
      boolean tall = (itemPath.endsWith("_door") && !itemPath.endsWith("trapdoor"))
         || itemPath.contains("sunflower") || itemPath.contains("lilac") || itemPath.contains("rose_bush")
         || itemPath.contains("peony") || itemPath.contains("tall_grass")
         || itemPath.contains("large_fern") || itemPath.contains("pitcher_plant");
      if (tall) {
         selfPlacedBlocks.put(pos.up().asLong(), expiresAt);
         selfPlacedBlocks.put(pos.down().asLong(), expiresAt);
      }
      if (itemPath.endsWith("_bed")) {
         selfPlacedBlocks.put(pos.add(1, 0, 0).asLong(), expiresAt);
         selfPlacedBlocks.put(pos.add(-1, 0, 0).asLong(), expiresAt);
         selfPlacedBlocks.put(pos.add(0, 0, 1).asLong(), expiresAt);
         selfPlacedBlocks.put(pos.add(0, 0, -1).asLong(), expiresAt);
      }
   }

   /** May run on the network thread: only touches thread-safe state. @return true to cancel the packet. */
   private boolean handleInbound(Packet<?> packet) {
      if (packet instanceof PlayerRemoveS2CPacket removed) {
         if (removed.profileIds().size() < 4) {
            for (UUID id : removed.profileIds()) {
               observations.offer(Signal.of(SignalType.TAB_REMOVE, id, -1, null, ""));
            }
         }
         return false;
      }

      if (packet instanceof PlayerListS2CPacket listed
         && listed.getActions().contains(PlayerListS2CPacket.Action.UPDATE_LISTED)) {
         int hidden = 0;
         for (PlayerListS2CPacket.Entry entry : listed.getEntries()) {
            if (entry != null && !entry.listed()) {
               hidden++;
            }
         }
         if (hidden > 0 && hidden < 4) {
            for (PlayerListS2CPacket.Entry entry : listed.getEntries()) {
               if (entry != null && !entry.listed()) {
                  observations.offer(Signal.of(SignalType.TAB_HIDE, entry.profileId(), -1, null, ""));
               }
            }
         }
         return false;
      }

      if (packet instanceof PlayerListS2CPacket gm
         && gm.getActions().contains(PlayerListS2CPacket.Action.UPDATE_GAME_MODE)) {
         if (!gm.getActions().contains(PlayerListS2CPacket.Action.ADD_PLAYER)) {
            for (PlayerListS2CPacket.Entry entry : gm.getEntries()) {
               if (entry != null && entry.gameMode() != null && entry.profileId() != null) {
                  observations.offer(Signal.of(SignalType.GAMEMODE, entry.profileId(), -1, null, entry.gameMode().getId()));
               }
            }
         }
         return false;
      }

      if (packet instanceof GameMessageS2CPacket message) {
         String text = message.content() == null ? "" : message.content().getString();
         if (!text.isBlank()) {
            observations.offer(Signal.of(SignalType.SYSTEM_CHAT, null, -1, null, text));
         }
         String departed = departedPlayerName(message.content());
         if (!departed.isBlank()) {
            observations.offer(Signal.of(SignalType.PLAYER_LEFT, null, -1, null, departed));
         }
         return false;
      }

      if (packet instanceof CommandSuggestionsS2CPacket suggestions
         && completionRequestIds.remove(suggestions.id())) {
         ArrayList<String> names = new ArrayList<>();
         for (Suggestion s : suggestions.getSuggestions().getList()) {
            String name = s.getText();
            if (name != null && !name.isBlank()) {
               names.add(name.trim());
            }
         }
         pendingCompletionNames = names;
         return true; // our own probe: don't let the game process it
      }

      if (packet instanceof EntityTrackerUpdateS2CPacket metadata) {
         observations.offer(Signal.of(SignalType.ENTITY_METADATA, null, metadata.id(), null, ""));
      } else if (packet instanceof ExplosionS2CPacket explosion) {
         observations.offer(Signal.of(SignalType.EXPLOSION, null, -1, explosion.center(), Float.toString(explosion.radius())));
      } else if (packet instanceof PlaySoundFromEntityS2CPacket sound) {
         observations.offer(Signal.of(SignalType.ENTITY_SOUND, null, sound.getEntityId(), null,
            soundId(sound.getSound().value().id())));
      } else if (packet instanceof ParticleS2CPacket particle) {
         Identifier id = Registries.PARTICLE_TYPE.getId(particle.getParameters().getType());
         observations.offer(Signal.of(SignalType.PARTICLE, null, -1,
            new Vec3d(particle.getX(), particle.getY(), particle.getZ()), id == null ? "" : id.toString()));
      } else if (packet instanceof PlaySoundS2CPacket sound) {
         if (sound.getSound() != null && sound.getSound().value() != null) {
            observations.offer(Signal.of(SignalType.POSITIONAL_SOUND, null, -1,
               new Vec3d(sound.getX(), sound.getY(), sound.getZ()), soundId(sound.getSound().value().id())));
         }
      }
      return false;
   }

   private static String departedPlayerName(Text text) {
      if (text != null && text.getContent() instanceof TranslatableTextContent t
         && "multiplayer.player.left".equals(t.getKey())) {
         Object[] args = t.getArgs();
         if (args.length != 0 && args[0] != null) {
            return args[0] instanceof Text a ? a.getString() : String.valueOf(args[0]);
         }
      }
      return "";
   }

   // ------------------------------------------------------------------ observation processing

   private void drainObservations() {
      for (int i = 0; i < MAX_OBSERVATIONS_PER_TICK; i++) {
         Signal s = observations.poll();
         if (s == null) {
            break;
         }
         processObservation(s);
      }
      while (observations.size() > 4096) {
         observations.poll();
      }
   }

   private void processObservation(Signal s) {
      switch (s.type) {
         case TAB_REMOVE -> handleTabRemoval(s.profileId);
         case TAB_HIDE -> handleTabHidden(s.profileId);
         case PLAYER_LEFT -> {
            serverSendsLeaveMessages = true;
            confirmDeparture(s.detail);
         }
         case SYSTEM_CHAT -> cacheRecentMessage(s.detail);
         case ENTITY_METADATA -> inspectInvisibleEntity(s.entityId);
         case POSITIONAL_SOUND -> inspectPositionalSound(s);
         case ENTITY_SOUND -> inspectEntitySound(s);
         case PARTICLE -> inspectParticle(s);
         case EXPLOSION -> rememberExplosion(s);
         case GAMEMODE -> announceGamemode(s.profileId, s.detail);
      }
   }

   private void trackListedPlayers() {
      if (mc.getNetworkHandler() == null) {
         return;
      }
      long now = System.currentTimeMillis();
      for (PlayerListEntry entry : mc.getNetworkHandler().getListedPlayerListEntries()) {
         if (entry == null || entry.getProfile() == null || entry.getProfile().id() == null) {
            continue;
         }
         UUID id = entry.getProfile().id();
         if (mc.player != null && mc.player.getUuid().equals(id)) {
            continue;
         }
         listedSinceMs.putIfAbsent(id, now);
         String name = entry.getProfile().name();
         if (name != null) {
            knownPlayers.putIfAbsent(id, name);
            if (!hiddenSpells.isEmpty()) {
               endSpell(name, false, 1000L);
            }
         }
      }
      if (listedSinceMs.size() > 1024 || knownPlayers.size() > 1024) {
         Set<UUID> present = new HashSet<>();
         for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            if (e != null && e.getProfile() != null) {
               present.add(e.getProfile().id());
            }
         }
         listedSinceMs.keySet().retainAll(present);
         knownPlayers.keySet().retainAll(present);
      }
   }

   private boolean trustedListed(UUID id) {
      Long since = id == null ? null : listedSinceMs.get(id);
      return since != null && System.currentTimeMillis() - since >= TRUSTED_LISTED_MS;
   }

   private boolean credibleSubject(UUID id, String name) {
      return id != null && VanishChatParser.isUsername(name) && isWatched(name) && trustedListed(id);
   }

   private boolean isWatched(String name) {
      if (anyPlayer.getValue() || VanishAlertRules.isStaffName(name)) {
         return true;
      }
      String list = watchNames.getValue();
      if (list != null && !list.isBlank()) {
         for (String part : list.split("[,\s]+")) {
            if (!part.isBlank() && part.equalsIgnoreCase(name)) {
               return true;
            }
         }
      }
      return false;
   }

   private void handleTabRemoval(UUID id) {
      if (id == null || mc.player.getUuid().equals(id)) {
         return;
      }
      String name = knownName(id);
      if (credibleSubject(id, name) && VanishChatParser.isPlausiblePlayerName(name)) {
         pendingVanishes.removeIf(p -> p.uuid.equals(id));
         pendingVanishes.addLast(new PendingRemoval(id, name, tickCounter + 20));
      }
   }

   private void handleTabHidden(UUID id) {
      if (id == null || mc.player.getUuid().equals(id)) {
         return;
      }
      String name = knownName(id);
      if (credibleSubject(id, name) && VanishChatParser.isPlausiblePlayerName(name) && !recentMessageNames(name)) {
         reportHidden(id, name, false, "Vanish Event: hidden from TAB", "hidden from TAB", 100);
      }
   }

   private String knownName(UUID id) {
      String n = knownPlayers.get(id);
      if (n != null && !n.isBlank()) {
         return n;
      }
      if (mc.getNetworkHandler() != null) {
         PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(id);
         if (e != null && e.getProfile() != null) {
            return e.getProfile().name();
         }
      }
      return null;
   }

   private UUID knownUuid(String name) {
      for (Map.Entry<UUID, String> e : knownPlayers.entrySet()) {
         if (e.getValue().equalsIgnoreCase(name)) {
            return e.getKey();
         }
      }
      return null;
   }

   private void confirmDeparture(String text) {
      long now = System.currentTimeMillis();
      for (Map.Entry<UUID, String> e : new ArrayList<>(knownPlayers.entrySet())) {
         UUID id = e.getKey();
         String name = e.getValue();
         if (VanishChatParser.containsPlayerName(text, name)) {
            confirmedDepartures.put(id, now + 5000L);
            pendingVanishes.removeIf(p -> p.uuid.equals(id));
            hiddenSpells.remove(spellKey(name));
            Alert a = detections.get(id.toString());
            if (a != null && tabDepartureReason(a.reason)) {
               detections.remove(id.toString());
            }
            signals.removeIf(f -> f.type == EvidenceType.VANISH
               && f.subject.equalsIgnoreCase(name) && tabDepartureReason(f.reason));
         }
      }
   }

   private void processPendingVanishes() {
      while (!pendingVanishes.isEmpty() && pendingVanishes.peekFirst().dueTick <= tickCounter) {
         PendingRemoval p = pendingVanishes.removeFirst();
         if (mc.getNetworkHandler().getPlayerListEntry(p.uuid) != null) {
            continue; // came back
         }
         long now = System.currentTimeMillis();
         if (confirmedDepartures.getOrDefault(p.uuid, 0L) > now) {
            continue; // real leave
         }
         if (recentMessageNames(p.name)) {
            serverSendsLeaveMessages = true;
            continue;
         }
         PlayerEntity entity = mc.world.getPlayerByUuid(p.uuid);
         if (entity != null && !entity.isRemoved()) {
            reportHidden(p.uuid, p.name, false, "Vanish Event: entity remained", "off TAB, still nearby", 100);
            continue;
         }
         String reason = "Vanish Event: silent TAB disappearance";
         int score = serverSendsLeaveMessages ? 100 : 30;
         if (serverSendsLeaveMessages) {
            reportHidden(p.uuid, p.name, false, reason, "left TAB silently", score);
         } else {
            Proof proof = regionProof(p.uuid);
            if (proof != null) {
               signals.addLast(new Finding(EvidenceType.VANISH, p.name, proof, reason, score, now));
               evaluateCritical();
            }
         }
      }
   }

   private static boolean tabDepartureReason(String reason) {
      if (reason == null) {
         return false;
      }
      String l = reason.toLowerCase(Locale.ROOT);
      return l.startsWith("vanish event:")
         && (l.contains("tab") || l.contains("entity remained") || l.contains("no leave packet"));
   }

   private void cacheRecentMessage(String text) {
      if (text == null || text.isBlank()) {
         return;
      }
      long now = System.currentTimeMillis();
      recentMessages.addLast(new Message(text, now));
      while (!recentMessages.isEmpty()
         && (now - recentMessages.peekFirst().atMs > RECENT_MESSAGE_TTL_MS || recentMessages.size() > 64)) {
         recentMessages.removeFirst();
      }
   }

   private boolean recentMessageNames(String name) {
      if (name == null || name.isBlank()) {
         return false;
      }
      long now = System.currentTimeMillis();
      for (Message m : recentMessages) {
         if (now - m.atMs <= RECENT_MESSAGE_TTL_MS && VanishChatParser.looksLikeLeaveMessage(m.text, name)) {
            return true;
         }
      }
      return false;
   }

   // ------------------------------------------------------------------ command-completion probe

   private void sendCompletionProbe() {
      if (mc.getNetworkHandler() == null) {
         return;
      }
      int id = nextCompletionId++;
      if (nextCompletionId > 40000) {
         nextCompletionId = 30000;
      }
      completionRequestIds.add(id);
      while (completionRequestIds.size() > 8) {
         completionRequestIds.remove(completionRequestIds.iterator().next());
      }
      try {
         mc.getNetworkHandler().sendPacket(new RequestCommandCompletionsC2SPacket(id, PROBE_COMMAND + " "));
      } catch (Throwable ignored) {
      }
   }

   private void processCompletionProbe() {
      List<String> names = pendingCompletionNames;
      if (names == null) {
         return;
      }
      pendingCompletionNames = null;
      if (mc.getNetworkHandler() == null || mc.player == null) {
         return;
      }
      Set<String> inTab = new HashSet<>();
      for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
         if (e != null && e.getProfile() != null && e.getProfile().name() != null) {
            inTab.add(e.getProfile().name().toLowerCase(Locale.ROOT));
         }
      }
      String self = mc.player.getName().getString();
      List<String> hidden = new ArrayList<>();
      for (String name : names) {
         if (isWatched(name) && VanishChatParser.isPlausiblePlayerName(name) && !name.equalsIgnoreCase(self)
            && !inTab.contains(name.toLowerCase(Locale.ROOT)) && !recentMessageNames(name)) {
            hidden.add(name);
         }
      }
      if (!hidden.isEmpty() && hidden.size() <= 3) {
         for (String name : hidden) {
            reportHidden(knownUuid(name), name, false, "Vanish Event: hidden but targetable", "off TAB, still targetable", 90);
         }
      }
   }

   // ------------------------------------------------------------------ hidden "spells" (tracked vanishes)

   private void reportHidden(UUID id, String name, boolean spectator, String reason, String detail, int score) {
      upsertDetection(detectionKey(id, name), name, reason, score, System.currentTimeMillis() + DETECTION_TTL_MS);
      Spell s = hiddenSpells.get(spellKey(name));
      if (s == null || s.spectator != spectator) {
         hiddenSpells.put(spellKey(name), new Spell(id, name, spectator, detail, regionProof(id), tickCounter));
      }
   }

   private void reviewSpells() {
      Iterator<Spell> it = hiddenSpells.values().iterator();
      while (it.hasNext()) {
         Spell s = it.next();
         if (s.spectator && mc.getNetworkHandler().getPlayerListEntry(s.uuid) == null) {
            it.remove();
         } else if (!s.watched && s.sinceTick < tickCounter) {
            Proof proof = regionProof(s.uuid);
            if (proof == null && !s.told) {
               proof = s.proof;
            }
            if (proof != null) {
               s.told = true;
               s.watched = true;
               watchingYou(s.name, proof);
            } else if (!s.told) {
               s.told = true;
               news(s.name, s.spectator ? "§eswitched to spectator" : "§cvanished", s.detail);
            }
         }
      }
   }

   private boolean endSpell(String name, boolean spectator, long minAgeMs) {
      Spell s = hiddenSpells.get(spellKey(name));
      if (s != null && s.spectator == spectator && System.currentTimeMillis() - s.sinceMs >= minAgeMs) {
         hiddenSpells.remove(spellKey(name));
         detections.remove(detectionKey(s.uuid, s.name));
         if (s.told) {
            news(s.name, "§ais visible again", "");
         }
         return true;
      }
      return false;
   }

   private Proof regionProof(UUID id) {
      if (id == null) {
         return null;
      }
      PlayerEntity p = mc.world.getPlayerByUuid(id);
      if (p != null && p != mc.player) {
         return new Proof(id, Math.round(p.distanceTo(mc.player)));
      }
      return null; // region-based proof (Krispy DonutRegionTracker) is not available in Kaze
   }

   private static String spellKey(String name) {
      return name.toLowerCase(Locale.ROOT);
   }

   private static String detectionKey(UUID id, String name) {
      return id != null ? id.toString() : name;
   }

   // ------------------------------------------------------------------ sensors (invisible / sound / particle)

   private double sensorRangeSq() {
      double r = sensorRange.getValue();
      return r * r;
   }

   private void scanInvisiblePlayers() {
      double range = sensorRangeSq();
      for (PlayerEntity p : mc.world.getPlayers()) {
         if (p != null && p != mc.player && p.isInvisible()
            && p.squaredDistanceTo(mc.player) <= range && realPlayer(p)) {
            triggerSensor(EvidenceType.INVISIBLE, p, "Invisible Entity: metadata flag", 35, 5000L);
         }
      }
   }

   private void inspectInvisibleEntity(int entityId) {
      if (mc.world.getEntityById(entityId) instanceof PlayerEntity p && p != mc.player && p.isInvisible()
         && p.squaredDistanceTo(mc.player) <= sensorRangeSq() && realPlayer(p)) {
         triggerSensor(EvidenceType.INVISIBLE, p, "Invisible Entity: metadata flag", 35, 5000L);
      }
   }

   private boolean realPlayer(PlayerEntity p) {
      String name = p.getGameProfile() == null ? p.getName().getString() : p.getGameProfile().name();
      return credibleSubject(p.getUuid(), name);
   }

   private void inspectPositionalSound(Signal s) {
      if (!VanishSignalClassifier.suspiciousSound(s.detail)) {
         return;
      }
      Vec3d pos = s.pos;
      long now = System.currentTimeMillis();
      if (nearPlayer(pos) && !hasVisibleCause(pos) && !isExplosionRelated(pos)
         && !isPoweredMechanism(pos, s.detail)
         && now - lastLocalActionMs >= 1000L
         && !recentlySelfPlaced(pos)
         && !villagerToggledDoor(s.detail, pos)
         && (!selfContainerActive() || !isContainerSignal(s.detail))) {
         triggerSensor(EvidenceType.SOUND, locatedSubject(pos), "Suspicious Sound: " + path(s.detail), 14, 3000L);
      }
   }

   private void inspectEntitySound(Signal s) {
      if (VanishSignalClassifier.suspiciousSound(s.detail) && mc.world.getEntityById(s.entityId) instanceof PlayerEntity p
         && p != mc.player && p.isInvisible()
         && p.squaredDistanceTo(mc.player) <= sensorRangeSq() && realPlayer(p)) {
         triggerSensor(EvidenceType.SOUND, p, "Suspicious Sound: invisible source", 16, 3000L);
      }
   }

   private void inspectParticle(Signal s) {
      if (!VanishSignalClassifier.suspiciousParticle(s.detail)) {
         return;
      }
      Vec3d pos = s.pos;
      long now = System.currentTimeMillis();
      if (nearPlayer(pos) && !hasVisibleCause(pos) && !isExplosionRelated(pos)
         && now - lastLocalActionMs >= 900L && !hasAmbientParticleSource(pos, s.detail)) {
         String id = path(s.detail);
         boolean weak = id.equals("block") || id.contains("smoke");
         if ((!weak || !nearSelf(pos, 6.25)) && (!weak || particleBurstReady(id, now))) {
            triggerSensor(EvidenceType.PARTICLE, locatedSubject(pos), "Ghost Particle: " + id, 16, 3000L);
         }
      }
   }

   private boolean villagerToggledDoor(String soundId, Vec3d pos) {
      String p = path(soundId);
      boolean door = (p.contains("door") && !p.contains("trapdoor")) || p.contains("fence_gate");
      if (!door || pos == null || mc.world == null) {
         return false;
      }
      for (Entity e : mc.world.getEntities()) {
         if (e.getType() == EntityType.VILLAGER && e.getEntityPos().squaredDistanceTo(pos) <= 9.0) {
            return true;
         }
      }
      return false;
   }

   private boolean recentlySelfPlaced(Vec3d pos) {
      if (pos == null) {
         return false;
      }
      Long until = selfPlacedBlocks.get(BlockPos.ofFloored(pos).asLong());
      return until != null && until > System.currentTimeMillis();
   }

   private void rememberExplosion(Signal s) {
      double radius = Math.max(2.0, parseDouble(s.detail, 4.0) + 4.0);
      recentExplosions.addLast(new Blast(s.pos, radius, System.currentTimeMillis()));
      while (recentExplosions.size() > 8) {
         recentExplosions.removeFirst();
      }
   }

   private boolean particleBurstReady(String id, long now) {
      Deque<Long> q = weakParticleBursts.computeIfAbsent(id, k -> new ArrayDeque<>());
      q.addLast(now);
      while (!q.isEmpty() && now - q.peekFirst() > 2000L) {
         q.removeFirst();
      }
      if (q.size() < 2) {
         return false;
      }
      q.clear();
      return true;
   }

   private void triggerSensor(EvidenceType type, String subject, String reason, int weight, long cooldownMs) {
      addSignal(type, subject, null, reason, weight, cooldownMs);
   }

   private void triggerSensor(EvidenceType type, PlayerEntity p, String reason, int weight, long cooldownMs) {
      String name = p.getGameProfile() == null ? p.getName().getString() : p.getGameProfile().name();
      addSignal(type, name, regionProof(p.getUuid()), reason, weight, cooldownMs);
   }

   private void addSignal(EvidenceType type, String subject, Proof proof, String reason, int weight, long cooldownMs) {
      long now = System.currentTimeMillis();
      String key = type.name() + "|" + subject.toLowerCase(Locale.ROOT);
      long last = signalCooldowns.getOrDefault(key, 0L);
      if (now - last >= cooldownMs) {
         signalCooldowns.put(key, now);
         signals.addLast(new Finding(type, subject, proof, reason, weight, now));
         upsertDetection("signal:" + key, subject, reason, weight, now + DETECTION_TTL_MS);
         announceTrigger(key, subject, proof != null, reason);
         evaluateCritical();
      }
   }

   private void evaluateCritical() {
      long now = System.currentTimeMillis();
      pruneSignals(now);
      EnumMap<EvidenceType, Integer> best = new EnumMap<>(EvidenceType.class);
      Finding withProof = null;
      for (Finding f : signals) {
         best.merge(f.type, f.weight, Math::max);
         if (f.proof != null) {
            withProof = f;
         }
      }
      int total = best.values().stream().mapToInt(Integer::intValue).sum();
      if (withProof != null && best.size() >= 2 && total >= CRITICAL_SCORE
         && now - lastCriticalMs >= CRITICAL_COOLDOWN_MS) {
         watchingYou(withProof.subject, withProof.proof);
      }
   }

   private void watchingYou(String name, Proof proof) {
      long now = System.currentTimeMillis();
      lastCriticalMs = now;
      criticalUntilMs = now + 7000L;
      criticalWatcher = name;
      pendingChime = true;
      ghostId = proof.id;
      ghostName = name;
      if (chatAlerts.getValue()) {
         send("§c§l" + name + " §cis vanished and watching you" + (proof.distance >= 0 ? " §7(" + proof.distance + "m)" : ""));
      }
   }

   private void playPendingChime() {
      if (!pendingChime) {
         return;
      }
      pendingChime = false;
      if (VanishAlertRules.alarmedRecently(ghostId)) {
         return;
      }
      if (alertSound.getValue() && mc.getSoundManager() != null) {
         mc.getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, 1.0F, 1.0F));
      }
      if (titleAlert.getValue()) {
         PlayerWatchHud.watching(ghostId, ghostName, 0);
      }
   }

   // ------------------------------------------------------------------ chat output

   private void send(String message) {
      if (mc.player != null) {
         mc.player.sendMessage(Text.literal("§8[§bAntiVanish§8] §r" + message), false);
      }
   }

   private void news(String name, String what, String detail) {
      if (!chatAlerts.getValue()) {
         return;
      }
      send("§f" + name + " " + what + (detail.isEmpty() ? "" : " §7(" + detail + ")"));
   }

   private void announceGamemode(UUID id, String mode) {
      if (id == null || (mc.player != null && mc.player.getUuid().equals(id))) {
         return;
      }
      String name = knownPlayers.get(id);
      if (name == null || !isWatched(name)) {
         return;
      }
      if (GameMode.SPECTATOR.getId().equals(mode)) {
         if (credibleSubject(id, name)) {
            reportHidden(id, name, true, "Vanish Event: switched to spectator", "", 100);
            return;
         }
      } else if (endSpell(name, true, 0L)) {
         return;
      }
      if (chatAlerts.getValue()) {
         send("§f" + name + " §7switched to §f" + mode);
      }
   }

   private void announceTrigger(String key, String subject, boolean isPlayer, String reason) {
      if (!chatAlerts.getValue()) {
         return;
      }
      long now = System.currentTimeMillis();
      Long last = announceCooldowns.get(key);
      if (last != null && now - last < ANNOUNCE_COOLDOWN_MS) {
         return;
      }
      while (!announceTimes.isEmpty() && now - announceTimes.peekFirst() > ANNOUNCE_WINDOW_MS) {
         announceTimes.removeFirst();
      }
      if (announceTimes.size() >= MAX_ANNOUNCE_PER_WINDOW) {
         return;
      }
      announceCooldowns.put(key, now);
      announceTimes.addLast(now);
      boolean named = subject != null && !subject.isBlank()
         && !"Unknown".equalsIgnoreCase(subject) && !"CRITICAL".equalsIgnoreCase(subject);
      send("§6" + reason + (named ? " §7(§f" + subject + "§7)" : ""));
   }

   // ------------------------------------------------------------------ detections / HUD data

   private void upsertDetection(String key, String name, String reason, int score, long expiresAt) {
      Alert a = detections.get(key);
      if (a == null) {
         detections.put(key, new Alert(name, reason, score, expiresAt));
      } else {
         a.name = name;
         a.expiresAt = Math.max(a.expiresAt, expiresAt);
         if (score >= a.score) {
            a.reason = reason;
            a.score = score;
         }
      }
   }

   private static boolean detectionWorthShowing(Alert a) {
      if (a == null) {
         return false;
      }
      String n = a.name == null ? "" : a.name.trim();
      return !n.isBlank() && !"Unknown".equalsIgnoreCase(n) && !"You".equalsIgnoreCase(n) && !"CRITICAL".equalsIgnoreCase(n);
   }

   private List<HudEntry> hudSnapshot() {
      long now = System.currentTimeMillis();
      List<HudEntry> out = new ArrayList<>();
      if (now < criticalUntilMs) {
         out.add(new HudEntry("CRITICAL", criticalWatcher));
      }
      Set<String> seen = new HashSet<>();
      detections.values().stream()
         .filter(a -> a.expiresAt > now)
         .filter(AntiVanish::detectionWorthShowing)
         .sorted(Comparator.<Alert>comparingInt(a -> a.score).reversed()
            .thenComparing(a -> a.name, String.CASE_INSENSITIVE_ORDER))
         .map(a -> new HudEntry(a.name, a.reason))
         .filter(e -> seen.add(hudTag(e) + "\u0000" + hudValue(e)))
         .limit(4L)
         .forEach(out::add);
      return out;
   }

   private static String hudTag(HudEntry e) {
      if (e == null) {
         return "WATCH";
      }
      if ("CRITICAL".equalsIgnoreCase(e.name)) {
         return "ALERT";
      }
      String r = e.reason == null ? "" : e.reason.toLowerCase(Locale.ROOT);
      if (r.startsWith("vanish event")) return "VANISH";
      if (r.startsWith("invisible entity")) return "INVIS";
      if (r.startsWith("suspicious sound")) return "SOUND";
      if (r.startsWith("ghost particle")) return "PARTICLE";
      return "WATCH";
   }

   private static String hudValue(HudEntry e) {
      if (e == null) {
         return "Staff";
      }
      if ("CRITICAL".equalsIgnoreCase(e.name)) {
         return shortName(e.reason);
      }
      String n = e.name == null ? "" : e.name.trim();
      return !n.isBlank() && !"Unknown".equalsIgnoreCase(n) && !"You".equalsIgnoreCase(n) ? shortName(n) : "Staff";
   }

   private static String shortName(String s) {
      String t = s == null ? "" : s.trim();
      return t.length() <= 16 ? t : t.substring(0, 16);
   }

   // ------------------------------------------------------------------ spatial helpers

   private boolean nearPlayer(Vec3d pos) {
      return pos != null && pos.squaredDistanceTo(mc.player.getEntityPos()) <= sensorRangeSq();
   }

   private boolean nearSelf(Vec3d pos, double distSq) {
      return pos != null && mc.player != null && pos.squaredDistanceTo(mc.player.getEntityPos()) < distSq;
   }

   private boolean selfContainerActive() {
      return System.currentTimeMillis() - lastContainerActivityMs < CONTAINER_SELF_GRACE_MS;
   }

   private static boolean isContainerSignal(String id) {
      String p = path(id);
      return p.contains("chest") || p.contains("barrel") || p.contains("shulker");
   }

   private String locatedSubject(Vec3d pos) {
      if (pos == null || mc.player == null) {
         return "nearby";
      }
      Vec3d me = mc.player.getEntityPos();
      double dx = pos.x - me.x;
      double dy = pos.y - me.y;
      double dz = pos.z - me.z;
      long dist = Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz));
      String c = (dz < -1.0 ? "N" : dz > 1.0 ? "S" : "") + (dx > 1.0 ? "E" : dx < -1.0 ? "W" : "");
      return c.isEmpty() ? dist + "m" : dist + "m " + c;
   }

   private boolean hasVisibleCause(Vec3d pos) {
      if (pos == null) {
         return true;
      }
      for (Entity e : mc.world.getEntities()) {
         if (e == mc.player) {
            continue;
         }
         if (e instanceof PlayerEntity p) {
            if (!p.isInvisible() && e.getEntityPos().squaredDistanceTo(pos) <= 16.0) {
               return true;
            }
         } else if (e instanceof ProjectileEntity && e.getEntityPos().squaredDistanceTo(pos) <= 16.0) {
            return true;
         }
      }
      return false;
   }

   private boolean isExplosionRelated(Vec3d pos) {
      if (pos == null) {
         return false;
      }
      long now = System.currentTimeMillis();
      while (!recentExplosions.isEmpty() && now - recentExplosions.peekFirst().timeMs > 3000L) {
         recentExplosions.removeFirst();
      }
      for (Blast b : recentExplosions) {
         if (b.center.squaredDistanceTo(pos) <= b.radius * b.radius) {
            return true;
         }
      }
      return false;
   }

   private boolean hasAmbientParticleSource(Vec3d pos, String particleId) {
      if (pos == null || !path(particleId).contains("smoke")) {
         return false;
      }
      BlockPos origin = BlockPos.ofFloored(pos);
      for (int x = -2; x <= 2; x++) {
         for (int y = -2; y <= 2; y++) {
            for (int z = -2; z <= 2; z++) {
               Identifier id = Registries.BLOCK.getId(mc.world.getBlockState(origin.add(x, y, z)).getBlock());
               String b = path(id == null ? "" : id.toString());
               if (b.contains("campfire") || b.contains("furnace") || b.contains("smoker") || b.contains("torch")
                  || b.contains("fire") || b.contains("candle") || b.contains("respawn_anchor")) {
                  return true;
               }
            }
         }
      }
      return false;
   }

   private boolean isPoweredMechanism(Vec3d pos, String soundId) {
      String p = path(soundId);
      if (!p.contains("door") && !p.contains("trapdoor")) {
         return false;
      }
      BlockPos origin = BlockPos.ofFloored(pos);
      long now = System.currentTimeMillis();
      for (int dy = -1; dy <= 1; dy++) {
         BlockPos bp = origin.add(0, dy, 0);
         BlockState state = mc.world.getBlockState(bp);
         long key = bp.asLong();
         boolean powered = state.contains(Properties.POWERED) && state.get(Properties.POWERED);
         if (powered || mc.world.isReceivingRedstonePower(bp)) {
            automatedMechanisms.put(key, now + 5000L);
            return true;
         }
         if (automatedMechanisms.getOrDefault(key, 0L) > now) {
            return true;
         }
      }
      return false;
   }

   private static double parseDouble(String s, double fallback) {
      try {
         return Double.parseDouble(s);
      } catch (Exception e) {
         return fallback;
      }
   }

   private static String soundId(Identifier id) {
      return id == null ? "" : id.toString();
   }

   // ------------------------------------------------------------------ state upkeep

   private void pruneState() {
      long now = System.currentTimeMillis();
      detections.entrySet().removeIf(e -> e.getValue().expiresAt <= now);
      signalCooldowns.entrySet().removeIf(e -> now - e.getValue() > 60000L);
      announceCooldowns.entrySet().removeIf(e -> now - e.getValue() > 60000L);
      selfPlacedBlocks.entrySet().removeIf(e -> e.getValue() <= now);
      confirmedDepartures.entrySet().removeIf(e -> e.getValue() <= now);
      automatedMechanisms.entrySet().removeIf(e -> e.getValue() <= now);
      weakParticleBursts.values().removeIf(q -> {
         while (!q.isEmpty() && now - q.peekFirst() > 2000L) {
            q.removeFirst();
         }
         return q.isEmpty();
      });
      while (!recentExplosions.isEmpty() && now - recentExplosions.peekFirst().timeMs > 3000L) {
         recentExplosions.removeFirst();
      }
      pruneSignals(now);
   }

   private void pruneSignals(long now) {
      while (!signals.isEmpty() && now - signals.peekFirst().timeMs > SIGNAL_WINDOW_MS) {
         signals.removeFirst();
      }
   }

   /** Replacement for Krispy's DonutRegionTracker: world change or a big jump (RTP/TPA) resets state. */
   private boolean regionChanged() {
      boolean changed = false;
      if (trackedWorld != mc.world) {
         changed = trackedWorld != null;
         trackedWorld = mc.world;
      }
      Vec3d now = mc.player.getEntityPos();
      if (lastPos != null && now.squaredDistanceTo(lastPos) > 128.0 * 128.0) {
         changed = true;
      }
      lastPos = now;
      return changed;
   }

   private void resetRuntime() {
      observations.clear();
      knownPlayers.clear();
      detections.clear();
      signalCooldowns.clear();
      announceCooldowns.clear();
      announceTimes.clear();
      selfPlacedBlocks.clear();
      confirmedDepartures.clear();
      automatedMechanisms.clear();
      weakParticleBursts.clear();
      signals.clear();
      recentExplosions.clear();
      pendingVanishes.clear();
      hiddenSpells.clear();
      recentMessages.clear();
      listedSinceMs.clear();
      completionRequestIds.clear();
      pendingCompletionNames = null;
      nextCompletionId = 30000;
      serverSendsLeaveMessages = false;
      tickCounter = 0;
      lastLocalActionMs = 0L;
      lastContainerActivityMs = 0L;
      lastCriticalMs = 0L;
      criticalUntilMs = 0L;
      criticalWatcher = "";
      pendingChime = false;
      ghostId = null;
      ghostName = null;
      PlayerWatchHud.clear();
      trackedWorld = null;
      lastPos = null;
   }

   private static String path(String id) {
      return VanishSignalClassifier.path(id);
   }

   // ------------------------------------------------------------------ data types

   private static final class Alert {
      String name;
      String reason;
      int score;
      long expiresAt;

      Alert(String name, String reason, int score, long expiresAt) {
         this.name = name;
         this.reason = reason;
         this.score = score;
         this.expiresAt = expiresAt;
      }
   }

   private static final class Spell {
      final UUID uuid;
      final String name;
      final boolean spectator;
      final String detail;
      final Proof proof;
      final int sinceTick;
      final long sinceMs = System.currentTimeMillis();
      boolean told;
      boolean watched;

      Spell(UUID uuid, String name, boolean spectator, String detail, Proof proof, int sinceTick) {
         this.uuid = uuid;
         this.name = name;
         this.spectator = spectator;
         this.detail = detail;
         this.proof = proof;
         this.sinceTick = sinceTick;
      }
   }

   private record Blast(Vec3d center, double radius, long timeMs) {
   }

   private record HudEntry(String name, String reason) {
   }

   private record PendingRemoval(UUID uuid, String name, int dueTick) {
   }

   private record Message(String text, long atMs) {
   }

   private record Proof(UUID id, int distance) {
   }

   private record Finding(EvidenceType type, String subject, Proof proof, String reason, int weight, long timeMs) {
   }

   private record Signal(SignalType type, UUID profileId, int entityId, Vec3d pos, String detail) {
      static Signal of(SignalType type, UUID profileId, int entityId, Vec3d pos, String detail) {
         return new Signal(type, profileId, entityId, pos, detail == null ? "" : detail);
      }
   }

   private enum SignalType {
      TAB_REMOVE, TAB_HIDE, PLAYER_LEFT, SYSTEM_CHAT, ENTITY_METADATA,
      POSITIONAL_SOUND, ENTITY_SOUND, PARTICLE, EXPLOSION, GAMEMODE
   }

   private enum EvidenceType {
      VANISH, INVISIBLE, PARTICLE, SOUND
   }
}
