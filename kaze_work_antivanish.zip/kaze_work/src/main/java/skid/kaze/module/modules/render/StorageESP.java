package skid.kaze.module.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.PistonBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.BlockUtil;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;

public final class StorageESP extends Module {
   private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), (double)1.0F, (double)255.0F, (double)125.0F, (double)1.0F);
   private final BooleanSetting tracers = (new BooleanSetting(EncryptedString.of("Tracers"), false)).setDescription(EncryptedString.of("Draws a line from your player to the storage block"));
   private final BooleanSetting chests = new BooleanSetting(EncryptedString.of("Chests"), true);
   private final BooleanSetting enderChests = new BooleanSetting(EncryptedString.of("Ender Chests"), true);
   private final BooleanSetting spawners = new BooleanSetting(EncryptedString.of("Spawners"), true);
   private final BooleanSetting shulkerBoxes = new BooleanSetting(EncryptedString.of("Shulker Boxes"), true);
   private final BooleanSetting furnaces = new BooleanSetting(EncryptedString.of("Furnaces"), true);
   private final BooleanSetting barrels = new BooleanSetting(EncryptedString.of("Barrels"), true);
   private final BooleanSetting enchant = new BooleanSetting(EncryptedString.of("Enchanting Tables"), true);
   private final BooleanSetting pistons = new BooleanSetting(EncryptedString.of("Pistons"), true);

   public StorageESP() {
      super(EncryptedString.of("Storage ESP"), EncryptedString.of("Renders storage blocks through walls"), -1, Category.RENDER);
      this.addSettings(new Setting[]{this.alpha, this.tracers, this.chests, this.enderChests, this.spawners, this.shulkerBoxes, this.furnaces, this.barrels, this.enchant, this.pistons});
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      this.renderStorages(event);
   }

   /** Returns null when the block entity is not a tracked (or not enabled) storage type. */
   private Color getBlockEntityColor(BlockEntity blockEntity, int a) {
      if (blockEntity instanceof TrappedChestBlockEntity) {
         return this.chests.getValue() ? new Color(200, 91, 0, a) : null;
      } else if (blockEntity instanceof ChestBlockEntity) {
         return this.chests.getValue() ? new Color(156, 91, 0, a) : null;
      } else if (blockEntity instanceof EnderChestBlockEntity) {
         return this.enderChests.getValue() ? new Color(117, 0, 255, a) : null;
      } else if (blockEntity instanceof MobSpawnerBlockEntity) {
         return this.spawners.getValue() ? new Color(138, 126, 166, a) : null;
      } else if (blockEntity instanceof ShulkerBoxBlockEntity) {
         return this.shulkerBoxes.getValue() ? new Color(134, 0, 158, a) : null;
      } else if (blockEntity instanceof FurnaceBlockEntity) {
         return this.furnaces.getValue() ? new Color(125, 125, 125, a) : null;
      } else if (blockEntity instanceof BarrelBlockEntity) {
         return this.barrels.getValue() ? new Color(255, 140, 140, a) : null;
      } else if (blockEntity instanceof EnchantingTableBlockEntity) {
         return this.enchant.getValue() ? new Color(80, 80, 255, a) : null;
      } else if (blockEntity instanceof PistonBlockEntity) {
         return this.pistons.getValue() ? new Color(35, 226, 0, a) : null;
      } else {
         return null;
      }
   }

   private void renderStorages(Render3DEvent event) {
      if (this.mc.world == null || this.mc.player == null) {
         return;
      }

      Camera cam = RenderUtils.getCamera();
      if (cam == null) {
         return;
      }

      // Queued in world coordinates, drawn once per frame by RenderUtils (world-space renderer).
      MatrixStack matrices = event.matrixStack;
      Vec3d tracerStart = RenderUtils.getTracerStart(cam);
      int a = this.alpha.getIntValue();
      boolean drawTracers = this.tracers.getValue();

      for(WorldChunk chunk : BlockUtil.getLoadedChunks().toList()) {
         for(BlockPos pos : new ArrayList<>(chunk.getBlockEntityPositions())) {
            BlockEntity blockEntity = this.mc.world.getBlockEntity(pos);
            if (blockEntity == null) {
               continue;
            }

            Color fill = this.getBlockEntityColor(blockEntity, a);
            if (fill == null) {
               continue;
            }

            double x = (double)pos.getX();
            double y = (double)pos.getY();
            double z = (double)pos.getZ();
            RenderUtils.renderFilledBox(matrices, x + 0.1, y + 0.05, z + 0.1, x + 0.9, y + 0.85, z + 0.9, fill);
            Color edge = new Color(fill.getRed(), fill.getGreen(), fill.getBlue(), Math.min(255, a + 100));
            RenderUtils.renderBoxOutline(matrices, x + 0.1, y + 0.05, z + 0.1, x + 0.9, y + 0.85, z + 0.9, edge, 2.0F);
            if (drawTracers) {
               Color line = this.getBlockEntityColor(blockEntity, 255);
               RenderUtils.renderLine(matrices, line, tracerStart, new Vec3d(x + 0.5, y + 0.5, z + 0.5));
            }
         }
      }
   }
}
