package skid.kaze.module.modules.donutfinding;

import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.WorldChunk;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;

/**
 * Kaze-native adaptation of Krispy's Lucky Finder.
 * Marks candidate chunks from the already-loaded client view only; it never requests chunk loads.
 */
public final class LuckyFinder extends Module {
    private static final double PLATE_SIZE = 48.0;
    private static final double PLATE_THICKNESS = 0.15;

    private final BooleanSetting notifications = new BooleanSetting(EncryptedString.of("Notifications"), true);
    private final BooleanSetting sound = new BooleanSetting(EncryptedString.of("Sound"), true);
    private final NumberSetting volume = new NumberSetting(EncryptedString.of("Sound Volume"), 0, 100, 35, 1);
    private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), 0, 255, 75, 1);
    private final Map<Long, Marker> markers = new LinkedHashMap<>();
    private Object trackedWorld;
    private int ticksUntilNext;

    public LuckyFinder() {
        super(EncryptedString.of("Lucky Finder"),
            EncryptedString.of("Marks candidate chunks in the loaded view with a green platform"),
            -1, Category.DONUT_FINDING);
        addSettings(notifications, sound, volume, alpha);
    }

    @Override
    public void onEnable() {
        clear();
        ticksUntilNext = ThreadLocalRandom.current().nextInt(20, 61);
    }

    @Override
    public void onDisable() {
        clear();
    }

    private void clear() {
        markers.clear();
        trackedWorld = null;
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (mc.player == null || mc.world == null) {
            clear();
            return;
        }
        if (trackedWorld != mc.world) {
            clear();
            trackedWorld = mc.world;
            ticksUntilNext = ThreadLocalRandom.current().nextInt(20, 61);
        }

        ChunkPos playerChunk = mc.player.getChunkPos();
        int viewDistance = Math.max(2, mc.options.getClampedViewDistance());
        markers.values().removeIf(marker ->
            Math.abs((long) marker.chunkX - playerChunk.x) > viewDistance
                || Math.abs((long) marker.chunkZ - playerChunk.z) > viewDistance);

        if (--ticksUntilNext > 0) return;
        ticksUntilNext = ThreadLocalRandom.current().nextInt(100, 241);

        int radius = Math.max(1, Math.min(8, viewDistance - 1));
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int attempt = 0; attempt < 32; attempt++) {
            int cx = playerChunk.x + random.nextInt(-radius, radius + 1);
            int cz = playerChunk.z + random.nextInt(-radius, radius + 1);
            long key = ChunkPos.toLong(cx, cz);
            if (markers.containsKey(key)) continue;
            WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
            if (chunk == null || chunk.isEmpty()) continue;

            int localX = random.nextInt(16);
            int localZ = random.nextInt(16);
            int surfaceY = chunk.sampleHeightmap(Heightmap.Type.WORLD_SURFACE, localX, localZ);
            if (surfaceY < mc.world.getBottomY()) continue;

            markers.put(key, new Marker(cx, cz, surfaceY + 1.002));
            int centerX = (cx << 4) + 8;
            int centerZ = (cz << 4) + 8;
            if (notifications.getValue()) {
                mc.player.sendMessage(net.minecraft.text.Text.literal(
                    "[Lucky Finder] X: " + centerX + " Z: " + centerZ), false);
            }
            if (sound.getValue() && volume.getIntValue() > 0) {
                float v = volume.getFloatValue() / 100.0F;
                mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, v, 1.35F);
            }
            break;
        }
    }

    @EventListener
    public void onRender3D(Render3DEvent event) {
        if (mc.player == null || mc.world == null || markers.isEmpty()) return;
        int a = alpha.getIntValue();
        if (a <= 0) return;

        double px = mc.player.getX();
        double pz = mc.player.getZ();
        double maxDistance = mc.options.getClampedViewDistance() * 16.0 + 24.0;
        Color green = new Color(0, 255, 70, a);
        for (Marker marker : markers.values()) {
            double centerX = marker.chunkX * 16.0 + 8.0;
            double centerZ = marker.chunkZ * 16.0 + 8.0;
            if (Math.abs(centerX - px) > maxDistance || Math.abs(centerZ - pz) > maxDistance) continue;
            RenderUtils.renderFilledBox(event.matrixStack,
                centerX - PLATE_SIZE / 2.0, marker.y, centerZ - PLATE_SIZE / 2.0,
                centerX + PLATE_SIZE / 2.0, marker.y + PLATE_THICKNESS,
                centerZ + PLATE_SIZE / 2.0, green);
        }
    }

    private record Marker(int chunkX, int chunkZ, double y) { }
}
