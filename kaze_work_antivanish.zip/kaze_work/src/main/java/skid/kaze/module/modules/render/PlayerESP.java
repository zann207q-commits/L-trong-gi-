package skid.kaze.module.modules.render;

import java.awt.Color;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;
import skid.kaze.utils.Utils;

public final class PlayerESP extends Module {
   private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), (double)0.0F, (double)255.0F, (double)100.0F, (double)1.0F);
   private final NumberSetting lineWidth = new NumberSetting(EncryptedString.of("Line width"), (double)1.0F, (double)10.0F, (double)1.0F, (double)1.0F);
   private final BooleanSetting tracers = (new BooleanSetting(EncryptedString.of("Tracers"), false)).setDescription(EncryptedString.of("Draws a line from your player to the other"));

   public PlayerESP() {
      super(EncryptedString.of("Player ESP"), EncryptedString.of("Renders players through walls"), -1, Category.RENDER);
      this.addSettings(new Setting[]{this.alpha, this.lineWidth, this.tracers});
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (this.mc.world == null || this.mc.player == null) {
         return;
      }

      Camera camera = RenderUtils.getCamera();
      if (camera == null) {
         return;
      }

      // Geometry is queued in world coordinates and drawn once per frame by RenderUtils (world-space renderer).
      MatrixStack ms = event.matrixStack;
      Vec3d tracerStart = RenderUtils.getTracerStart(camera);
      Color fill = Utils.getMainColor(this.alpha.getIntValue(), 1).brighter();
      Color line = Utils.getMainColor(255, 1);
      float width = (float)this.lineWidth.getIntValue();
      boolean drawTracers = this.tracers.getValue();

      for(PlayerEntity p : this.mc.world.getPlayers()) {
         if (p == this.mc.player || p.isRemoved() || !p.isAlive()) {
            continue;
         }

         Vec3d lerped = p.getLerpedPos(event.tickDelta);
         double hw = (double)(p.getWidth() / 2.0F);
         double h = (double)p.getHeight();
         RenderUtils.renderFilledBox(ms, lerped.x - hw, lerped.y, lerped.z - hw, lerped.x + hw, lerped.y + h, lerped.z + hw, fill);
         RenderUtils.renderBoxOutline(ms, lerped.x - hw, lerped.y, lerped.z - hw, lerped.x + hw, lerped.y + h, lerped.z + hw, line, width);
         if (drawTracers) {
            RenderUtils.renderLine(ms, line, tracerStart, new Vec3d(lerped.x, lerped.y + h / 2.0, lerped.z), width);
         }
      }
   }
}
