package skid.kaze.module;

import skid.kaze.utils.EncryptedString;

public enum Category {
   COMBAT(EncryptedString.of("Combat")),
   MISC(EncryptedString.of("Misc")),
   DONUT(EncryptedString.of("Donut")),
   DONUT_FINDING(EncryptedString.of("Donut Finding")),
   RENDER(EncryptedString.of("Render")),
   CLIENT(EncryptedString.of("Client"));

   public final CharSequence name;

   private Category(final CharSequence name) {
      this.name = name;
   }

   // $FF: synthetic method
   private static Category[] $values() {
      return new Category[]{COMBAT, MISC, DONUT, DONUT_FINDING, RENDER, CLIENT};
   }
}
