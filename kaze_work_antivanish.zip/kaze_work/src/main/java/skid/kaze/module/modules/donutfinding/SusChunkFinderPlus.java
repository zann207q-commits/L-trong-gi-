package skid.kaze.module.modules.donutfinding;

import java.awt.Color;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.Direction;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.utils.EncryptedString;

/**
 * Unified base-finding scanner for Kaze 1.21.11.
 *
 * Reuses ChunkScanModule's time-budgeted, loaded-chunk-only scan and plate renderer.
 * Combines structural signals from the existing Sus Chunk V2 with block families
 * used by the SusChunkFinder variants. This is a heuristic, not a guarantee that a
 * flagged chunk contains a player base.
 */
public final class SusChunkFinderPlus extends ChunkScanModule {
    private final BooleanSetting structures = new BooleanSetting(EncryptedString.of("Structures"), true)
        .setDescription(EncryptedString.of("Pistons, TNT, spawners, chests, barrels, obsidian and cobbled deepslate"));
    private final BooleanSetting rotatedDeepslate = new BooleanSetting(EncryptedString.of("Rotated Deepslate"), true)
        .setDescription(EncryptedString.of("Count deepslate with horizontal X/Z axis"));
    private final BooleanSetting plants = new BooleanSetting(EncryptedString.of("Growth Blocks"), true)
        .setDescription(EncryptedString.of("Kelp, vines, bamboo and cocoa; natural growth can cause false positives"));
    private final BooleanSetting amethyst = new BooleanSetting(EncryptedString.of("Amethyst"), true);
    private final BooleanSetting beeNests = new BooleanSetting(EncryptedString.of("Bee Nests"), true)
        .setDescription(EncryptedString.of("Bee nests and beehives; natural nests can cause false positives"));
    private final BooleanSetting dripstone = new BooleanSetting(EncryptedString.of("Long Dripstone Blocks"), true);

    public SusChunkFinderPlus() {
        super("Sus Chunk Finder+", "Combined base-finding heuristic with budgeted chunk scanning", 8);
        addSettings(structures, rotatedDeepslate, plants, amethyst, beeNests, dripstone);
    }

    @Override
    protected boolean matches(BlockState state) {
        if (structures.getValue() && (
                state.isOf(Blocks.COBBLED_DEEPSLATE)
                || state.isOf(Blocks.PISTON)
                || state.isOf(Blocks.STICKY_PISTON)
                || state.isOf(Blocks.TNT)
                || state.isOf(Blocks.SPAWNER)
                || state.isOf(Blocks.OBSIDIAN)
                || state.isOf(Blocks.CHEST)
                || state.isOf(Blocks.TRAPPED_CHEST)
                || state.isOf(Blocks.BARREL)
                || state.isOf(Blocks.REDSTONE_BLOCK)
                || state.isOf(Blocks.DISPENSER)
                || state.isOf(Blocks.DROPPER)
                || state.isOf(Blocks.HOPPER)
                || state.isOf(Blocks.OBSERVER))) {
            return true;
        }

        if (rotatedDeepslate.getValue() && state.isOf(Blocks.DEEPSLATE)
                && state.contains(Properties.AXIS)) {
            Direction.Axis axis = state.get(Properties.AXIS);
            if (axis == Direction.Axis.X || axis == Direction.Axis.Z) return true;
        }

        if (plants.getValue() && (
                state.isOf(Blocks.KELP)
                || state.isOf(Blocks.KELP_PLANT)
                || state.isOf(Blocks.CAVE_VINES)
                || state.isOf(Blocks.CAVE_VINES_PLANT)
                || state.isOf(Blocks.VINE)
                || state.isOf(Blocks.BAMBOO)
                || state.isOf(Blocks.COCOA))) {
            return true;
        }

        if (amethyst.getValue() && (
                state.isOf(Blocks.AMETHYST_CLUSTER)
                || state.isOf(Blocks.LARGE_AMETHYST_BUD)
                || state.isOf(Blocks.MEDIUM_AMETHYST_BUD)
                || state.isOf(Blocks.SMALL_AMETHYST_BUD))) {
            return true;
        }

        if (beeNests.getValue() && (
                state.isOf(Blocks.BEE_NEST)
                || state.isOf(Blocks.BEEHIVE))) {
            return true;
        }

        return dripstone.getValue() && state.isOf(Blocks.POINTED_DRIPSTONE);
    }

    @Override
    protected Color plateColor() {
        return new Color(255, 55, 95);
    }
}
