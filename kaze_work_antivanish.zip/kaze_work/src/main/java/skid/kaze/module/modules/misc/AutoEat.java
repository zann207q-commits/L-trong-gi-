package skid.kaze.module.modules.misc;

import net.minecraft.component.type.FoodComponent;
import net.minecraft.component.DataComponentTypes;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.TickEvent;
import skid.kaze.mixin.MinecraftClientAccessor;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.InventoryUtil;

public final class AutoEat extends Module {
   private final NumberSetting healthThreshold = new NumberSetting(EncryptedString.of("Health Threshold"), (double)0.0F, (double)19.0F, (double)17.0F, (double)1.0F);
   private final NumberSetting hungerThreshold = new NumberSetting(EncryptedString.of("Hunger Threshold"), (double)0.0F, (double)19.0F, (double)19.0F, (double)1.0F);
   public boolean isEa;
   private int selectedFoodSlot;
   private int previousSelectedSlot;

   public AutoEat() {
      super(EncryptedString.of("Auto Eat"), EncryptedString.of(" It detects whenever the hungerbar/health falls a certain threshold, selects food in your hotbar, and starts eating."), -1, Category.MISC);
      this.addSettings(new Setting[]{this.healthThreshold, this.hungerThreshold});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent tickEvent) {
      if (this.isEa) {
         if (this.shouldEat()) {
            if (this.selectedFoodSlot < 0 || this.mc.player.getInventory().getStack(this.selectedFoodSlot).get(DataComponentTypes.FOOD) == null) {
               int k = this.findBestFoodSlot();
               if (k == -1) {
                  this.stopEating();
                  return;
               }

               this.selectSlot(k);
            }

            this.startEating();
         } else {
            this.stopEating();
         }
      } else if (this.shouldEat()) {
         this.selectedFoodSlot = this.findBestFoodSlot();
         if (this.selectedFoodSlot != -1) {
            this.saveCurrentSlot();
         }
      }

   }

   public boolean shouldEat() {
      boolean b = this.mc.player.getHealth() <= (float)this.healthThreshold.getIntValue();
      boolean b2 = this.mc.player.getHungerManager().getFoodLevel() <= this.hungerThreshold.getIntValue();
      return this.findBestFoodSlot() != -1 && (b || b2);
   }

   private int findBestFoodSlot() {
      int n = -1;
      int n2 = -1;

      for(int i = 0; i < 9; ++i) {
         Object value = this.mc.player.getInventory().getStack(i).getItem().getComponents().get(DataComponentTypes.FOOD);
         if (value != null) {
            int nutrition = ((FoodComponent)value).nutrition();
            if (nutrition > n2) {
               n = i;
               n2 = nutrition;
            }
         }
      }

      return n;
   }

   private void saveCurrentSlot() {
      this.previousSelectedSlot = this.mc.player.getInventory().getSelectedSlot();
      this.startEating();
   }

   private void startEating() {
      this.selectSlot(this.selectedFoodSlot);
      this.setUseKeyPressed(true);
      if (!this.mc.player.isUsingItem()) {
         ((MinecraftClientAccessor)this.mc).invokeDoItemUse();
      }

      this.isEa = true;
   }

   private void stopEating() {
      this.selectSlot(this.previousSelectedSlot);
      this.setUseKeyPressed(false);
      this.isEa = false;
   }

   private void setUseKeyPressed(boolean pressed) {
      this.mc.options.useKey.setPressed(pressed);
   }

   private void selectSlot(int f) {
      InventoryUtil.swap(f);
      this.selectedFoodSlot = f;
   }
}
