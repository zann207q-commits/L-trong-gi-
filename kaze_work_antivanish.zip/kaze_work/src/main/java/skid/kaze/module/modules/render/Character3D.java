package skid.kaze.module.modules.render;

import java.lang.ref.WeakReference;
import net.minecraft.client.world.ClientWorld;
import skid.kaze.Kaze;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.TickEvent;
import skid.kaze.model.Character3dHelper;
import skid.kaze.model.Character3dRuntime;
import skid.kaze.model.CharacterDefinition;
import skid.kaze.model.CharacterDetailLevel;
import skid.kaze.model.CharacterModelCache;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.modules.misc.Freecam;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.ModeSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;

/**
 * Replaces your own player model with a baked 3D character (.anc).
 * Built-in: CJ, Neighbor. "Custom" loads the first *.anc found in config/kaze/characters.
 */
public final class Character3D extends Module {
   public enum CharacterChoice {
      CJ,
      NEIGHBOR,
      CUSTOM
   }

   private final ModeSetting<CharacterChoice> character = (new ModeSetting("Character", CharacterChoice.CJ, CharacterChoice.class)).setDescription(EncryptedString.of("Which 3D character to wear (Custom = first .anc in config/kaze/characters)"));
   private final ModeSetting<CharacterDetailLevel> detail = (new ModeSetting("Detail", CharacterDetailLevel.MEDIUM, CharacterDetailLevel.class)).setDescription(EncryptedString.of("Mesh detail level"));
   private final BooleanSetting heldItems = (new BooleanSetting("Held Items", false)).setDescription(EncryptedString.of("Show held items on the character"));

   private WeakReference<ClientWorld> level = new WeakReference(null);
   private CharacterDefinition customCache;
   private int ticks;
   private int lastCharacter = -1;
   private int lastDetail = -1;
   private boolean customWarned;

   public Character3D() {
      super(EncryptedString.of("3D Character"), EncryptedString.of("Replaces your player model with a 3D character"), -1, Category.RENDER);
      this.addSettings(new Setting[]{this.character, this.detail, this.heldItems});
   }

   public void onEnable() {
      super.onEnable();
      Character3dHelper.ensureFolder();
      this.customCache = null;
      this.customWarned = false;
      this.lastCharacter = -1;
      this.lastDetail = -1;
      this.ticks = 0;
      this.level = new WeakReference(this.mc.world);
      this.sync(true);
   }

   public void onDisable() {
      super.onDisable();
      Character3dRuntime.configure(false, null, CharacterDetailLevel.MEDIUM, false, () -> false);
      CharacterModelCache.clear();
   }

   @EventListener
   public void onTick(TickEvent event) {
      ClientWorld world = this.mc.world;
      if (this.level.get() != world) {
         this.level = new WeakReference(world);
         CharacterModelCache.releaseTextures();
      }

      if (++this.ticks % 40 == 0 && this.character.getValue() == CharacterChoice.CUSTOM) {
         this.customCache = null;
         this.sync(true);
      } else {
         this.sync(false);
      }
   }

   private void sync(boolean force) {
      int characterIndex = this.character.getModeIndex();
      int detailIndex = this.detail.getModeIndex();
      boolean changed = force || characterIndex != this.lastCharacter || detailIndex != this.lastDetail;
      this.lastCharacter = characterIndex;
      this.lastDetail = detailIndex;
      CharacterDefinition definition = this.resolve();
      CharacterDetailLevel level = (CharacterDetailLevel)this.detail.getValue();
      Character3dRuntime.configure(true, definition, level, this.heldItems.getValue(), Character3D::freecamActive);
      if (changed) {
         Character3dRuntime.prepare();
      }
   }

   private CharacterDefinition resolve() {
      switch ((CharacterChoice)this.character.getValue()) {
         case NEIGHBOR:
            return Character3dHelper.neighbor();
         case CUSTOM:
            if (this.customCache == null) {
               this.customCache = Character3dHelper.firstCustom();
            }

            if (this.customCache != null) {
               return this.customCache;
            }

            if (!this.customWarned && this.mc.player != null) {
               this.customWarned = true;
               this.mc.player.sendMessage(net.minecraft.text.Text.of("\u00a7b[3D Character]\u00a7r No .anc file in " + Character3dHelper.folder() + " - using CJ"), false);
            }

            return Character3dHelper.cj();
         default:
            return Character3dHelper.cj();
      }
   }

   private static boolean freecamActive() {
      Kaze kaze = Kaze.INSTANCE;
      if (kaze == null || kaze.MODULE_MANAGER == null) {
         return false;
      }

      Module freecam = kaze.MODULE_MANAGER.getModuleByClass(Freecam.class);
      return freecam != null && freecam.isEnabled();
   }
}
