package skid.kaze.module.modules.client;

import com.sun.jna.Memory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import skid.kaze.gui.ClickGUI;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.module.setting.StringSetting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.Utils;

public final class SelfDestruct extends Module {
   public static boolean isActive = false;
   private final BooleanSetting replaceMod = (new BooleanSetting(EncryptedString.of("Replace Mod"), true)).setDescription(EncryptedString.of("Repalces the mod with the original JAR file of the ImmediatelyFast mod"));
   private final BooleanSetting saveLastModified = (new BooleanSetting(EncryptedString.of("Save Last Modified"), true)).setDescription(EncryptedString.of("Saves the last modified date after self destruct"));
   private final BooleanSetting usnJournalCleaner = new BooleanSetting(EncryptedString.of("USN Journal Cleaner"), true);
   private final StringSetting replaceUrl = new StringSetting(EncryptedString.of("Replace URL"), "https://cdn.modrinth.com/data/8shC1gFX/versions/sXO3idkS/BetterF3-11.0.1-Fabric-1.21.jar");
   private static final Path tempDirectory = Paths.get(System.getProperty("java.io.tmpdir"));
   private static final AtomicLong modificationCounter = new AtomicLong();

   public SelfDestruct() {
      super(EncryptedString.of("Self Destruct"), EncryptedString.of("Removes the client from your game |Credits to Argon for deletion|"), -1, Category.CLIENT);
      this.addSettings(new Setting[]{this.replaceMod, this.saveLastModified, this.usnJournalCleaner, this.replaceUrl});
   }

   public void onEnable() {
      isActive = true;
      skid.kaze.Kaze.INSTANCE.getModuleManager().getModuleByClass(Kaze.class).toggle(false);
      this.toggle(false);
      skid.kaze.Kaze.INSTANCE.getConfigManager().shutdown();
      if (this.mc.currentScreen instanceof ClickGUI) {
         skid.kaze.Kaze.INSTANCE.shouldPreventClose = false;
         this.mc.currentScreen.close();
      }

      if (this.replaceMod.getValue()) {
         try {
            String string = this.replaceUrl.getValue();
            if (Utils.getCurrentJarPath().exists()) {
               Utils.overwriteFile(string, Utils.getCurrentJarPath());
            }
         } catch (Exception var8) {
         }
      }

      for(Module module : skid.kaze.Kaze.INSTANCE.getModuleManager().c()) {
         module.toggle(false);
         module.setName((CharSequence)null);
         module.setDescription((CharSequence)null);

         for(Setting setting : module.getSettings()) {
            setting.getDescription((CharSequence)null);
            setting.setDescription((CharSequence)null);
            if (setting instanceof StringSetting) {
               ((StringSetting)setting).setValue((String)null);
            }
         }

         module.getSettings().clear();
      }

      Runtime runtime = Runtime.getRuntime();
      if (this.saveLastModified.getValue()) {
         skid.kaze.Kaze.INSTANCE.resetModifiedDate();
      }

      for(int i = 0; i <= 10; ++i) {
         runtime.gc();
         runtime.runFinalization();

         try {
            Thread.sleep((long)(100 * i));
            Memory.purge();
            Memory.disposeAll();
         } catch (InterruptedException var7) {
         }
      }

      if (this.usnJournalCleaner.getValue()) {
         try {
            Path[] pathArray = new Path[20];
            ExecutorService executorService = Executors.newWorkStealingPool(20);
            CountDownLatch countDownLatch = new CountDownLatch(20);

            for(int i = 0; i < 20; ++i) {
               final int index = i;
               executorService.submit(() -> {
                  try {
                     pathArray[index] = Files.createTempFile(tempDirectory, "meta", ".tmp");
                     countDownLatch.countDown();
                  } catch (Throwable _t) {
                     _t.printStackTrace(System.err);
                  }

               });
            }

            countDownLatch.await();
            System.nanoTime();

            for(int i = 0; i < 20; ++i) {
               Path path = pathArray[i];
               executorService.submit(() -> {
                  for(; modificationCounter.get() < 500000L; modificationCounter.addAndGet(2L)) {
                     try {
                        Files.setLastModifiedTime(path, FileTime.fromMillis(System.currentTimeMillis()));
                        boolean bl = !(Boolean)Files.getAttribute(path, "dos:archive");
                        Files.setAttribute(path, "dos:archive", bl);
                     } catch (IOException var2) {
                     }
                  }

               });
            }

            executorService.shutdown();
            executorService.awaitTermination(1L, TimeUnit.HOURS);
         } catch (Exception var9) {
         }
      }

   }
}
