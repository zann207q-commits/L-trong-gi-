package skid.kaze.module.modules.donutfinding;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;

/**
 * Client-thread-only base for the Krispy-inspired Donut Finding modules.
 *
 * Scanning is time-budgeted: every tick it scans the nearest not-yet-scanned loaded chunks
 * until a small time budget is used up, so it is fast but cannot cause frame spikes.
 * Sections whose palette has no matching block are skipped without touching a single block.
 * Flagged chunks are drawn as a flat plate (same style as Lucky Finder).
 */
public abstract class ChunkScanModule extends Module {
    private static final long BUDGET_NANOS = 1_500_000L; // ~1.5 ms per tick
    private static final int MAX_CHUNKS_PER_TICK = 6;
    private static final int REFRESH_TICKS = 10;
    private static final double PLATE_SIZE = 16.0;
    private static final double PLATE_THICKNESS = 0.15;

    private final NumberSetting threshold;
    private final NumberSetting radius;
    private final NumberSetting alpha;
    private final BooleanSetting chatNotify;
    private final Set<Long> scanned = new HashSet<>();
    private final Map<Long, Flag> flags = new HashMap<>();
    private final List<long[]> queue = new ArrayList<>(); // {distSq, chunkX, chunkZ}
    private int queuePos;
    private int refreshCounter;
    private Object trackedWorld;

    protected ChunkScanModule(String name, String description, int defaultThreshold) {
        super(EncryptedString.of(name), EncryptedString.of(description), -1, Category.DONUT_FINDING);
        threshold = new NumberSetting(EncryptedString.of("Minimum Hits"), 1, 100, defaultThreshold, 1);
        radius = new NumberSetting(EncryptedString.of("Scan Radius"), 2, 32, 16, 1);
        alpha = new NumberSetting(EncryptedString.of("Alpha"), 0, 255, 75, 1);
        chatNotify = new BooleanSetting(EncryptedString.of("Chat Notification"), true);
        addSettings(threshold, radius, alpha, chatNotify);
    }

    /** Plate colour (alpha is taken from the Alpha setting). */
    protected Color plateColor() {
        return new Color(255, 140, 0);
    }

    @Override public void onEnable() {
        clear();
    }

    @Override public void onDisable() {
        clear();
    }

    private void clear() {
        scanned.clear();
        flags.clear();
        queue.clear();
        queuePos = 0;
        refreshCounter = 0;
        trackedWorld = null;
    }

    @EventListener
    public final void onTick(TickEvent event) {
        if (mc.player == null || mc.world == null) {
            clear();
            return;
        }
        ClientWorld world = mc.world;
        if (trackedWorld != world) {
            clear();
            trackedWorld = world;
        }

        ChunkPos center = mc.player.getChunkPos();
        int scanRadius = Math.max(2, Math.min(radius.getIntValue(), mc.options.getClampedViewDistance() + 1));

        // Every few ticks: forget chunks that left the area (so they are re-scanned on return)
        // and queue newly loaded chunks, nearest first.
        if (++refreshCounter >= REFRESH_TICKS) {
            refreshCounter = 0;
            prune(center, scanRadius + 2);
            rebuildQueue(world, center, scanRadius);
        }

        long start = System.nanoTime();
        int done = 0;
        while (queuePos < queue.size() && done < MAX_CHUNKS_PER_TICK) {
            long[] entry = queue.get(queuePos++);
            int cx = (int) entry[1];
            int cz = (int) entry[2];
            long key = ChunkPos.toLong(cx, cz);
            if (!scanned.add(key)) continue;
            WorldChunk chunk = world.getChunkManager().getWorldChunk(cx, cz);
            if (chunk == null || chunk.isEmpty()) {
                scanned.remove(key); // not ready yet, try again on the next refresh
                continue;
            }
            done++;
            int hits = countHits(chunk);
            if (hits >= threshold.getIntValue()) {
                int surfaceY = chunk.sampleHeightmap(Heightmap.Type.WORLD_SURFACE, 8, 8);
                if (surfaceY < world.getBottomY()) surfaceY = world.getBottomY();
                flags.put(key, new Flag(cx, cz, surfaceY + 1.002, hits));
                if (chatNotify.getValue()) {
                    mc.player.sendMessage(Text.literal("[" + getName() + "] Suspicious chunk at X="
                        + chunk.getPos().getStartX() + " Z=" + chunk.getPos().getStartZ()
                        + " (hits=" + hits + ")"), false);
                }
            }
            if (System.nanoTime() - start > BUDGET_NANOS) break;
        }
    }

    private void prune(ChunkPos center, int maxDist) {
        scanned.removeIf(key -> {
            int cx = ChunkPos.getPackedX(key);
            int cz = ChunkPos.getPackedZ(key);
            return Math.abs(cx - center.x) > maxDist || Math.abs(cz - center.z) > maxDist;
        });
        flags.values().removeIf(f -> Math.abs(f.chunkX - center.x) > maxDist || Math.abs(f.chunkZ - center.z) > maxDist);
    }

    private void rebuildQueue(ClientWorld world, ChunkPos center, int scanRadius) {
        queue.clear();
        queuePos = 0;
        for (int dx = -scanRadius; dx <= scanRadius; dx++) {
            for (int dz = -scanRadius; dz <= scanRadius; dz++) {
                int cx = center.x + dx;
                int cz = center.z + dz;
                if (scanned.contains(ChunkPos.toLong(cx, cz))) continue;
                if (world.getChunkManager().getWorldChunk(cx, cz) == null) continue;
                queue.add(new long[] {(long) dx * dx + (long) dz * dz, cx, cz});
            }
        }
        queue.sort((a, b) -> Long.compare(a[0], b[0])); // nearest first
    }

    @EventListener
    public final void onRender3D(Render3DEvent event) {
        if (mc.player == null || mc.world == null || flags.isEmpty()) return;
        int a = alpha.getIntValue();
        if (a <= 0) return;
        Color base = plateColor();
        Color color = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
        double px = mc.player.getX();
        double pz = mc.player.getZ();
        double maxDistance = mc.options.getClampedViewDistance() * 16.0 + 24.0;
        for (Flag f : flags.values()) {
            double centerX = f.chunkX * 16.0 + 8.0;
            double centerZ = f.chunkZ * 16.0 + 8.0;
            if (Math.abs(centerX - px) > maxDistance || Math.abs(centerZ - pz) > maxDistance) continue;
            RenderUtils.renderFilledBox(event.matrixStack,
                centerX - PLATE_SIZE / 2.0, f.y, centerZ - PLATE_SIZE / 2.0,
                centerX + PLATE_SIZE / 2.0, f.y + PLATE_THICKNESS, centerZ + PLATE_SIZE / 2.0, color);
        }
    }

    private int countHits(WorldChunk chunk) {
        int count = 0;
        int bottom = chunk.getBottomY();
        int minY = Math.max(bottom, -32);
        int maxY = Math.min(bottom + chunk.getHeight() - 1, 48);
        ChunkSection[] sections = chunk.getSectionArray();
        for (int i = 0; i < sections.length; i++) {
            ChunkSection section = sections[i];
            if (section == null || section.isEmpty()) continue;
            int sectionY = bottom + i * 16;
            int fromY = Math.max(0, minY - sectionY);
            int toY = Math.min(15, maxY - sectionY);
            if (fromY > 15 || toY < 0 || fromY > toY) continue;
            if (!section.hasAny(this::matches)) continue; // palette check: skips most sections instantly
            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    for (int y = fromY; y <= toY; y++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (matches(state)) count++;
                    }
                }
            }
        }
        return count;
    }

    protected abstract boolean matches(BlockState state);

    protected static boolean isKrispySuspiciousBlock(BlockState state) {
        return state.isOf(Blocks.COBBLED_DEEPSLATE)
            || state.isOf(Blocks.PISTON)
            || state.isOf(Blocks.STICKY_PISTON)
            || state.isOf(Blocks.TNT)
            || state.isOf(Blocks.SPAWNER);
    }

    private record Flag(int chunkX, int chunkZ, double y, int hits) { }
}
