package skid.kaze.model;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;

/** Resolves the characters the module can wear: two built-in .anc assets plus .anc files in config/kaze/characters. */
@Environment(EnvType.CLIENT)
public final class Character3dHelper {
   private static final BakedCharacterAsset CJ = BakedCharacterAsset.builtIn("cj", "CJ", "/assets/kaze/characters/cj.anc");
   private static final BakedCharacterAsset NEIGHBOR = BakedCharacterAsset.builtIn("neighbor", "Neighbor", "/assets/kaze/characters/neighbor.anc");

   private Character3dHelper() {
   }

   public static CharacterDefinition cj() {
      return CJ;
   }

   public static CharacterDefinition neighbor() {
      return NEIGHBOR;
   }

   public static Path folder() {
      return FabricLoader.getInstance().getConfigDir().resolve("kaze").resolve("characters");
   }

   /** First *.anc file (alphabetical) in the characters folder, or null when there is none. */
   public static CharacterDefinition firstCustom() {
      List<Path> files = new ArrayList<>();
      try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder(), "*.{anc,ANC}")) {
         for (Path path : stream) {
            if (Files.isRegularFile(path)) {
               files.add(path);
            }
         }
      } catch (IOException ignored) {
         return null;
      }
      if (files.isEmpty()) {
         return null;
      }
      files.sort(null);
      Path file = files.get(0);
      String fileName = file.getFileName().toString();
      String base = fileName.substring(0, fileName.length() - 4);
      String slug = base.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_");
      long stamp;
      try {
         stamp = Files.size(file) * 31L + Files.getLastModifiedTime(file).toMillis();
      } catch (IOException e) {
         stamp = 0L;
      }
      return new BakedCharacterAsset("custom_" + slug + "_" + Long.toHexString(stamp), base, () -> Files.newInputStream(file));
   }

   public static void ensureFolder() {
      try {
         Files.createDirectories(folder());
      } catch (IOException ignored) {
      }
   }
}
