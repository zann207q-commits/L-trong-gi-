package skid.kaze.model;

/** Mip-chain helper extracted from the original CharacterTextureAtlasPacker. */
final class AtlasMips {
   private AtlasMips() {
   }

   static int[][] mips(int[] var0, int var1, int var2) {
      int var3 = Math.min(5, (1) + ((31) - Integer.numberOfLeadingZeros(Math.min(var1, var2))));
      int[][] var4 = new int[var3][];
      var4[0] = var0;
      int var5 = var1;
      int var6 = var2;

      for (int var7 = 1; var7 < var3; var7++) {
         var4[var7] = down(var4[var7 - (1)], var5, var6);
         var5 = Math.max(1, var5 / (2));
         var6 = Math.max(1, var6 / (2));
      }

      return var4;
   }

   private static int[] down(int[] var0, int var1, int var2) {
      int var3 = Math.max(1, var1 / (2));
      int var4 = Math.max(1, var2 / (2));
      int[] var5 = new int[var3 * var4];

      for (int var6 = 0; var6 < var4; var6++) {
         for (int var7 = 0; var7 < var3; var7++) {
            float var8 = 0.0F;
            float var9 = 0.0F;
            float var10 = 0.0F;
            float var11 = 0.0F;
            float var12 = 0.0F;
            float var13 = 0.0F;
            float var14 = 0.0F;

            for (int var15 = 0; var15 < (4); var15++) {
               int var16 = Math.min(var1 - (1), var7 * (2) + (var15 & (1)));
               int var17 = Math.min(var2 - (1), var6 * (2) + (var15 >> (1)));
               int var18 = var0[var17 * var1 + var16];
               float var19 = (float)(var18 >>> (24)) / 255.0F;
               var8 += var19;
               var9 += (float)(var18 >> (16) & (255)) * var19;
               var10 += (float)(var18 >> (8) & (255)) * var19;
               var11 += (float)(var18 & (255)) * var19;
               var12 += (float)(var18 >> (16) & (255));
               var13 += (float)(var18 >> (8) & (255));
               var14 += (float)(var18 & (255));
            }

            int var20 = Math.round(var8 / 4.0F * 255.0F);
            int var21;
            int var22;
            int var23;
            if (var8 > 9.999999747378752e-05F) {
               var21 = Math.round(var9 / var8);
               var22 = Math.round(var10 / var8);
               var23 = Math.round(var11 / var8);
            } else {
               var21 = Math.round(var12 / 4.0F);
               var22 = Math.round(var13 / 4.0F);
               var23 = Math.round(var14 / 4.0F);
            }

            var5[var6 * var3 + var7] = clamp(var20) << (24)
               | clamp(var21) << (16)
               | clamp(var22) << (8)
               | clamp(var23);
         }
      }

      return var5;
   }

   private static int clamp(int value) {
      return Math.max(0, Math.min(255, value));
   }
}
