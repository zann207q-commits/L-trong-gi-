package skid.kaze.model;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.joml.Vector3f;

/** Two directional lights used to pre-bend normals of flat-lit (unshaded) vertices. */
@Environment(EnvType.CLIENT)
final class DirectionalLighting {
   static final DirectionalLighting WORLD = new DirectionalLighting(0.2F, 1.0F, -0.7F, -0.2F, 1.0F, 0.7F);

   private final float fx;
   private final float fy;
   private final float fz;

   DirectionalLighting(float ax, float ay, float az, float bx, float by, float bz) {
      Vector3f a = new Vector3f(ax, ay, az).normalize();
      Vector3f b = new Vector3f(bx, by, bz).normalize();
      Vector3f sum = a.add(b, new Vector3f());
      if (sum.lengthSquared() < 1.0E-6F) {
         sum.set(0.0F, 1.0F, 0.0F);
      }
      sum.normalize();
      this.fx = sum.x;
      this.fy = sum.y;
      this.fz = sum.z;
   }

   /** Blends the normal stored at out[offset..offset+2] towards the fully-lit direction. */
   void flatten(float[] out, int offset, float amount) {
      float t = Math.min(1.0F, Math.max(0.0F, amount));
      float nx = out[offset] + (this.fx - out[offset]) * t;
      float ny = out[offset + 1] + (this.fy - out[offset + 1]) * t;
      float nz = out[offset + 2] + (this.fz - out[offset + 2]) * t;
      float len = (float)Math.sqrt(nx * nx + ny * ny + nz * nz);
      if (len > 1.0E-6F) {
         nx /= len;
         ny /= len;
         nz /= len;
      }
      out[offset] = nx;
      out[offset + 1] = ny;
      out[offset + 2] = nz;
   }
}
