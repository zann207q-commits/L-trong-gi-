package skid.kaze.model;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class CharacterDefinition {
   private final String id;
   private final String name;

   protected CharacterDefinition(String id, String name) {
      if (id == null || !id.matches("[a-z0-9_]+")) {
         throw new IllegalArgumentException("character id must match [a-z0-9_]+: " + id);
      }
      this.id = id;
      this.name = name;
   }

   public final String id() {
      return this.id;
   }

   public final String name() {
      return this.name;
   }
}
