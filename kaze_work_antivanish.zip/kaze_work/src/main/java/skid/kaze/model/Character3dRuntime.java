package skid.kaze.model;

import java.util.function.BooleanSupplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.feature.Deadmau5FeatureRenderer;
import net.minecraft.client.render.entity.feature.ElytraFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.HeadFeatureRenderer;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.feature.ShoulderParrotFeatureRenderer;
import net.minecraft.client.render.entity.feature.StuckObjectsFeatureRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;

/**
 * Static bridge between the Kaze "3D Character" module, the mixins and the renderer.
 * All state is pushed in by the module; nothing here touches Kaze's module system.
 */
@Environment(EnvType.CLIENT)
public final class Character3dRuntime {
   private static volatile boolean active;
   private static volatile CharacterDefinition character;
   private static volatile CharacterDetailLevel detail = CharacterDetailLevel.MEDIUM;
   private static volatile boolean heldItems;
   private static volatile BooleanSupplier freecamActive = () -> false;

   private Character3dRuntime() {
   }

   // ---- state pushed by the module -------------------------------------------------------

   public static void configure(boolean enabled, CharacterDefinition def, CharacterDetailLevel level, boolean showHeldItems, BooleanSupplier freecam) {
      active = enabled;
      character = def;
      detail = level;
      heldItems = showHeldItems;
      freecamActive = freecam;
   }

   public static boolean isActive() {
      return active && character != null;
   }

   // ---- hooks used by the mixins -----------------------------------------------------------

   public static void extract(Entity entity, PlayerEntityRenderState state) {
      WornCharacterModel worn = isActive() ? resolve(entity, state) : null;
      CharacterRenderStateAccess access = (CharacterRenderStateAccess)state;
      access.kaze$setCharacter(worn);
      access.kaze$setDrawn(false);
      if (worn != null) {
         Entity vehicle = entity.getVehicle();
         access.kaze$setSeat(vehicle == null ? 0.0F : (vehicle instanceof LivingEntity ? 1.35F : 0.3F));
         if (state.nameLabelPos != null) {
            BakedCharacterData data = worn.model;
            float extra = data.maxY * data.scale - 32.0F;
            if (extra > 0.0F) {
               state.nameLabelPos = state.nameLabelPos.add(0.0, extra * 0.05859375F * state.baseScale, 0.0);
            }
         }
      }
   }

   public static boolean hidesModel(EntityRenderState state) {
      return worn(state) != null;
   }

   public static boolean hidesLayer(FeatureRenderer<?, ?> layer, EntityRenderState state) {
      if (worn(state) == null) {
         return false;
      }
      return layer instanceof ArmorFeatureRenderer
         || layer instanceof CapeFeatureRenderer
         || layer instanceof ElytraFeatureRenderer
         || layer instanceof StuckObjectsFeatureRenderer
         || layer instanceof HeadFeatureRenderer
         || layer instanceof ShoulderParrotFeatureRenderer
         || layer instanceof Deadmau5FeatureRenderer
         || (layer instanceof HeldItemFeatureRenderer && !heldItems);
   }

   // ---- used by the renderer ---------------------------------------------------------------

   static WornCharacterModel worn(EntityRenderState state) {
      return state instanceof CharacterRenderStateAccess access ? access.kaze$character() : null;
   }

   static float seat(EntityRenderState state) {
      return state instanceof CharacterRenderStateAccess access ? access.kaze$seat() : 0.0F;
   }

   static WornCharacterModel firstPerson() {
      if (!isActive()) {
         return null;
      }
      ClientPlayerEntity player = MinecraftClient.getInstance().player;
      if (player == null || player.isSpectator()) {
         return null;
      }
      WornCharacterModel worn = CharacterModelCache.ready(character, detail);
      return worn != null && worn.model.firstPersonArms ? worn : null;
   }

   // ---- internals --------------------------------------------------------------------------

   private static WornCharacterModel resolve(Entity entity, PlayerEntityRenderState state) {
      if (state.spectator || entity.isSpectator()) {
         return null;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity player = mc.player;
      if (player == null || mc.world == null || state.id != player.getId()) {
         return null;
      }
      boolean firstPerson = mc.options.getPerspective().isFirstPerson();
      if (!freecamActive.getAsBoolean() && firstPerson && (mc.currentScreen == null || player.isSleeping())) {
         return null;
      }
      return CharacterModelCache.ready(character, detail);
   }

   static void chat(String message) {
      MinecraftClient mc = MinecraftClient.getInstance();
      mc.execute(() -> {
         if (mc.player != null) {
            mc.player.sendMessage(Text.of("\u00a7b[3D Character]\u00a7r " + message), false);
         }
      });
   }

   static void failed(CharacterDefinition def, Throwable error) {
      Throwable cause = error.getCause() != null ? error.getCause() : error;
      chat("\u00a7cCouldn't load " + def.name() + ": " + cause.getMessage());
   }

   public static void prepare() {
      CharacterDefinition def = character;
      if (active && def != null) {
         CharacterModelCache.prepare(def, detail);
      }
   }
}
