package skid.kaze.model;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;

/**
 * Entry points called from the mixins. The character mesh is submitted from inside the vanilla
 * feature-layer loop (so it uses exactly the same matrix state a real layer would get).
 */
@Environment(EnvType.CLIENT)
public final class CharacterFeatureRenderer {
   private CharacterFeatureRenderer() {
   }

   /** Submits the character once per render pass, from the first feature layer that gets drawn. */
   public static void drawOnce(Object rendererModel, MatrixStack matrices, OrderedRenderCommandQueue commands, int light, EntityRenderState state) {
      if (!(state instanceof PlayerEntityRenderState player) || !(state instanceof CharacterRenderStateAccess access)) {
         return;
      }
      if (access.kaze$drawn()) {
         return;
      }
      WornCharacterModel worn = access.kaze$character();
      if (worn == null) {
         return;
      }
      access.kaze$setDrawn(true);
      if (player.invisible && player.invisibleToPlayer) {
         return;
      }
      if (rendererModel instanceof PlayerEntityModel model) {
         CharacterMeshRenderer.submit(worn, model, matrices, commands, light, player);
      }
   }

   public static boolean firstPersonHand(PlayerEntityModel model, MatrixStack matrices, OrderedRenderCommandQueue commands, int light, ModelPart hand) {
      return CharacterMeshRenderer.firstPersonHand(model, matrices, commands, light, hand);
   }

   public static boolean translateToHand(PlayerEntityModel model, PlayerEntityRenderState state, Arm arm, MatrixStack matrices) {
      return CharacterMeshRenderer.translateToHand(model, state, arm, matrices);
   }
}
