package skid.kaze.model;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface CharacterRenderStateAccess {
   WornCharacterModel kaze$character();

   void kaze$setCharacter(WornCharacterModel worn);

   float kaze$seat();

   void kaze$setSeat(float seat);

   boolean kaze$drawn();

   void kaze$setDrawn(boolean drawn);
}
