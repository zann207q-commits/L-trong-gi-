package skid.kaze.model;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/**
 * Minimal stand-in for the original (missing from the supplied sources) physics bone profile.
 * Baked ".anc" characters carry no secondary-motion data (motion == null, motionSlots == 0),
 * so only the arm/leg swing soft-limit helper is needed at runtime.
 */
@Environment(EnvType.CLIENT)
public final class BoneMotionProfile {
   private BoneMotionProfile() {
   }

   public float bendPower() {
      return 0.0F;
   }

   /** Smoothly limits {@code value} to roughly +-limit (no limit when limit <= 0). */
   public static float soft(float value, float limit) {
      if (limit <= 0.0F) {
         return value;
      }
      return limit * (float)Math.tanh(value / limit);
   }
}
