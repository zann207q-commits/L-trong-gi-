package skid.kaze.model;

import java.util.Arrays;

/** Quad-pairing helper extracted from the original CharacterMeshBaker. */
final class MeshPairing {
   private MeshPairing() {
   }

   static void pair(int[] var0, int var1, int var2, MeshBufferBuilder.MeshArrays var3) {
      long[] var4 = new long[var1 * (3)];

      for (int var5 = 0; var5 < var1; var5++) {
         for (int var6 = 0; var6 < (3); var6++) {
            int var7 = var0[var5 * (3) + var6];
            int var8 = var0[var5 * (3) + (var6 + (1)) % (3)];
            long var9 = (long)Math.min(var7, var8) * (long)var2 + (long)Math.max(var7, var8);
            var4[var5 * (3) + var6] = var9 << (21)
               | (long)var5 * (3L) + (long)var6;
         }
      }

      Arrays.sort(var4);
      int[] var20 = new int[var1 * (3)];
      Arrays.fill(var20, -1);
      long var21 = 2097151L;

      for (int var22 = 0; var22 + (1) < var4.length; var22++) {
         if (var4[var22] >>> (21) == var4[var22 + (1)] >>> (21)) {
            if (var22 + (2) < var4.length
               && var4[var22 + (2)] >>> (21) == var4[var22] >>> (21)) {
               while (
                  var22 + (1) < var4.length
                     && var4[var22 + (1)] >>> (21) == var4[var22] >>> (21)
               ) {
                  var22++;
               }
            } else {
               int var24 = (int)(var4[var22] & var21);
               int var10 = (int)(var4[var22 + (1)] & var21);
               var20[var24] = var10;
               var20[var10] = var24;
               var22++;
            }
         }
      }

      boolean[] var23 = new boolean[var1];

      for (int var25 = 0; var25 < var1; var25++) {
         if (!var23[var25]) {
            int var26 = -1;

            for (int var11 = 0; var11 < (3) && var26 < 0; var11++) {
               int var12 = var20[var25 * (3) + var11];
               if (var12 >= 0 && !var23[var12 / (3)] && var12 / (3) != var25) {
                  var26 = var11;
               }
            }

            int var27 = var0[var25 * (3)];
            int var28 = var0[var25 * (3) + (1)];
            int var13 = var0[var25 * (3) + (2)];
            if (var26 < 0) {
               var23[var25] = true;
               var3.quad(var27, var28, var13, var13, 1);
            } else {
               int var14 = var20[var25 * (3) + var26];
               int var15 = var14 / (3);
               var23[var25] = true;
               var23[var15] = true;
               int var16 = var0[var25 * (3) + var26];
               int var17 = var0[var25 * (3) + (var26 + (1)) % (3)];
               int var18 = var0[var25 * (3) + (var26 + (2)) % (3)];
               int var19 = var0[var15 * (3) + (var14 % (3) + (2)) % (3)];
               var3.quad(var16, var19, var17, var18, 2);
            }
         }
      }
   }
}
