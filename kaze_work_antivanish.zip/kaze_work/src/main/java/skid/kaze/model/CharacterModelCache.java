package skid.kaze.model;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinWorkerThread;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public final class CharacterModelCache {
   private static final Logger LOGGER = LoggerFactory.getLogger("Kaze");
   private static final int KEEP = 4;
   private static final ForkJoinPool POOL = new ForkJoinPool(
      Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 2)), pool -> {
         ForkJoinWorkerThread thread = ForkJoinPool.defaultForkJoinWorkerThreadFactory.newThread(pool);
         thread.setName("Kaze Character Builder " + thread.getPoolIndex());
         thread.setDaemon(true);
         thread.setPriority(4);
         return thread;
      }, null, false
   );
   private static final Map<String, CacheEntry> ENTRIES = new LinkedHashMap<>(8, 0.75F, true);
   private static CacheEntry shown;

   private CharacterModelCache() {
   }

   static void prepare(CharacterDefinition def, CharacterDetailLevel level) {
      String key = def.id() + "/" + level.name();
      if (!ENTRIES.containsKey(key)) {
         CacheEntry entry = new CacheEntry(def, level);
         ENTRIES.put(key, entry);
         trim();
         CompletableFuture.runAsync(() -> build(entry), POOL);
      }
   }

   static WornCharacterModel ready(CharacterDefinition def, CharacterDetailLevel level) {
      String key = def.id() + "/" + level.name();
      CacheEntry entry = ENTRIES.get(key);
      if (entry == null) {
         prepare(def, level);
         return previous();
      }
      if (entry.worn != null) {
         shown = entry;
         return entry.worn;
      }
      BakedCharacterData data = entry.model;
      if (entry.failed) {
         return null;
      }
      if (data == null) {
         return previous();
      }
      MinecraftClient.getInstance().getTextureManager().registerTexture(
         entry.texture, new CharacterAtlasTexture(entry.texture.toString(), data.atlasWidth, data.atlasHeight, data.atlasMips)
      );
      entry.worn = new WornCharacterModel(data, entry.texture);
      shown = entry;
      return entry.worn;
   }

   private static WornCharacterModel previous() {
      CacheEntry entry = shown;
      return entry != null && ENTRIES.containsValue(entry) ? entry.worn : null;
   }

   private static void build(CacheEntry entry) {
      try {
         if (!(entry.design instanceof BakedCharacterAsset asset)) {
            throw new IllegalStateException(entry.design.name() + " is not a baked (.anc) character");
         }
         BakedCharacterData data = BakedCharacterLoader.load(asset, entry.detail);
         LOGGER.info("[Kaze] 3D Character '{}' ({}) loaded: {} triangles in {} ms", entry.design.name(), entry.detail.label, data.triangles(), data.buildMillis);
         entry.model = data;
      } catch (Throwable error) {
         entry.failed = true;
         LOGGER.error("[Kaze] 3D Character '{}' ({}) failed to load", entry.design.name(), entry.detail.label, error);
         Character3dRuntime.failed(entry.design, error);
      }
   }

   private static void trim() {
      Iterator<CacheEntry> it = ENTRIES.values().iterator();
      while (ENTRIES.size() > KEEP && it.hasNext()) {
         release(it.next());
         it.remove();
      }
   }

   public static void releaseTextures() {
      for (CacheEntry entry : ENTRIES.values()) {
         release(entry);
      }
   }

   public static void clear() {
      releaseTextures();
      ENTRIES.clear();
      shown = null;
   }

   private static void release(CacheEntry entry) {
      if (entry.worn != null) {
         entry.worn = null;
         MinecraftClient.getInstance().getTextureManager().destroyTexture(entry.texture);
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class CacheEntry {
      final CharacterDefinition design;
      final CharacterDetailLevel detail;
      final Identifier texture;
      volatile BakedCharacterData model;
      volatile boolean failed;
      WornCharacterModel worn;

      CacheEntry(CharacterDefinition design, CharacterDetailLevel detail) {
         this.design = design;
         this.detail = detail;
         this.texture = Identifier.of("kaze", "character/" + design.id() + "_" + detail.name().toLowerCase(Locale.ROOT));
      }
   }
}
