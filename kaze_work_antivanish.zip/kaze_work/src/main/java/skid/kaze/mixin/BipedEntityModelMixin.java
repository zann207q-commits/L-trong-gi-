package skid.kaze.mixin;

import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import skid.kaze.model.CharacterFeatureRenderer;

@Mixin({BipedEntityModel.class})
public abstract class BipedEntityModelMixin {
   /** Held items: move them to the character's hand instead of the vanilla arm. */
   @Inject(
      method = {"setArmAngle(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;Lnet/minecraft/util/Arm;Lnet/minecraft/client/util/math/MatrixStack;)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void kaze$handTransform(BipedEntityRenderState state, Arm arm, MatrixStack matrices, CallbackInfo ci) {
      if ((Object)this instanceof PlayerEntityModel model
         && state instanceof PlayerEntityRenderState playerState
         && CharacterFeatureRenderer.translateToHand(model, playerState, arm, matrices)) {
         ci.cancel();
      }
   }
}
