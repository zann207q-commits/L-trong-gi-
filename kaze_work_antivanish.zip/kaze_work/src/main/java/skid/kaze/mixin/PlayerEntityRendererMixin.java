package skid.kaze.mixin;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import skid.kaze.model.CharacterFeatureRenderer;

@Mixin({PlayerEntityRenderer.class})
public abstract class PlayerEntityRendererMixin {
   /** First-person arms: draw the character's own arm instead of the vanilla one. */
   @Inject(
      method = {"renderArm(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/util/Identifier;Lnet/minecraft/client/model/ModelPart;Z)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void kaze$firstPersonArm(MatrixStack matrices, OrderedRenderCommandQueue queue, int light, Identifier skin, ModelPart arm, boolean sleeveVisible, CallbackInfo ci) {
      Object model = ((LivingEntityRenderer<?, ?, ?>)(Object)this).getModel();
      if (model instanceof PlayerEntityModel playerModel && CharacterFeatureRenderer.firstPersonHand(playerModel, matrices, queue, light, arm)) {
         ci.cancel();
      }
   }
}
