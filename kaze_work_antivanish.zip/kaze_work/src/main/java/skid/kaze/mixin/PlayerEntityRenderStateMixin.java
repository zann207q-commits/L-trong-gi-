package skid.kaze.mixin;

import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import skid.kaze.model.CharacterRenderStateAccess;
import skid.kaze.model.WornCharacterModel;

@Mixin({PlayerEntityRenderState.class})
public class PlayerEntityRenderStateMixin implements CharacterRenderStateAccess {
   @Unique
   private WornCharacterModel kaze$character;
   @Unique
   private float kaze$seat;
   @Unique
   private boolean kaze$drawn;

   public WornCharacterModel kaze$character() {
      return this.kaze$character;
   }

   public void kaze$setCharacter(WornCharacterModel worn) {
      this.kaze$character = worn;
   }

   public float kaze$seat() {
      return this.kaze$seat;
   }

   public void kaze$setSeat(float seat) {
      this.kaze$seat = seat;
   }

   public boolean kaze$drawn() {
      return this.kaze$drawn;
   }

   public void kaze$setDrawn(boolean drawn) {
      this.kaze$drawn = drawn;
   }
}
