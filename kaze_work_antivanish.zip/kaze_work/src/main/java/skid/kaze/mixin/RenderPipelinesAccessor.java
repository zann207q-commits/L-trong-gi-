package skid.kaze.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gl.RenderPipelines;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Registers a custom RenderPipeline so the renderer knows (and precompiles) it. */
@Mixin({RenderPipelines.class})
public interface RenderPipelinesAccessor {
   @Invoker("register")
   static RenderPipeline kaze$register(RenderPipeline pipeline) {
      throw new AssertionError();
   }
}
