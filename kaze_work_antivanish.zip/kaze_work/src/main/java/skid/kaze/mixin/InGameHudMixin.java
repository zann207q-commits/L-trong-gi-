package skid.kaze.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import skid.kaze.Kaze;
import skid.kaze.event.events.Render2DEvent;
import skid.kaze.manager.EventManager;
import skid.kaze.module.Module;
import skid.kaze.module.modules.render.ChunkFinder;
import skid.kaze.module.modules.render.PlayerESP;
import skid.kaze.module.modules.render.StorageESP;
import skid.kaze.utils.RenderUtils;

@Mixin({InGameHud.class})
public class InGameHudMixin {
   private static final java.util.List<Class<? extends Module>> WORLD_ESP_MODULES = java.util.List.of(PlayerESP.class, StorageESP.class, ChunkFinder.class);

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void onRenderHud(DrawContext ctx, RenderTickCounter rtc, CallbackInfo ci) {
      // 3D ESP is drawn in world space from GameRendererMixin; here we only make sure a broken hook is noticed.
      boolean espOn = false;
      if (Kaze.INSTANCE != null && Kaze.INSTANCE.getModuleManager() != null && Kaze.mc != null && Kaze.mc.world != null) {
         for (Class<? extends Module> type : WORLD_ESP_MODULES) {
            Module m = Kaze.INSTANCE.getModuleManager().getModuleByClass(type);
            if (m != null && m.isEnabled()) {
               espOn = true;
               break;
            }
         }
      }

      RenderUtils.watchWorldRenderer(espOn);
      EventManager.b(new Render2DEvent(ctx, rtc.getTickProgress(true)));
   }
}
