package skid.kaze.mixin;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Lets RenderUtils build its own RenderLayer (ESP boxes / lines) with a custom pipeline. */
@Mixin({RenderLayer.class})
public interface RenderLayerAccessor {
   @Invoker("of")
   static RenderLayer kaze$create(String name, RenderSetup setup) {
      throw new AssertionError();
   }
}
