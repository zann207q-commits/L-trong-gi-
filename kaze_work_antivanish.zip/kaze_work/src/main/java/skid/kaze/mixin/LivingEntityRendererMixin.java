package skid.kaze.mixin;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import skid.kaze.model.Character3dRuntime;
import skid.kaze.model.CharacterFeatureRenderer;

@Mixin({LivingEntityRenderer.class})
public abstract class LivingEntityRendererMixin {
   /** Decides (per frame) whether the local player wears the 3D character. */
   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"},
      at = {@At("TAIL")},
      require = 0
   )
   private void kaze$extract(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
      if (state instanceof PlayerEntityRenderState playerState) {
         Character3dRuntime.extract(entity, playerState);
      }
   }

   /** Hides the vanilla body while the character is worn (the vanilla model is still posed for the animation data). */
   @Inject(
      method = {"getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void kaze$hideModel(LivingEntityRenderState state, boolean showBody, boolean translucent, boolean showOutline, CallbackInfoReturnable<RenderLayer> cir) {
      if (Character3dRuntime.hidesModel(state)) {
         cir.setReturnValue(null);
      }
   }

   /** Draws the character from the first feature layer and suppresses layers that would clip through it. */
   @Redirect(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/feature/FeatureRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/EntityRenderState;FF)V"
      ),
      require = 0
   )
   @SuppressWarnings({"rawtypes", "unchecked"})
   private void kaze$renderLayer(FeatureRenderer feature, MatrixStack matrices, OrderedRenderCommandQueue queue, int light, EntityRenderState state, float limbAngle, float limbDistance) {
      if (Character3dRuntime.hidesModel(state)) {
         CharacterFeatureRenderer.drawOnce(((LivingEntityRenderer<?, ?, ?>)(Object)this).getModel(), matrices, queue, light, state);
         if (Character3dRuntime.hidesLayer(feature, state)) {
            return;
         }
      }

      feature.render(matrices, queue, light, state, limbAngle, limbDistance);
   }
}
