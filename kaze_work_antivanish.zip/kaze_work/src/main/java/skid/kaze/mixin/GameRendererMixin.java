package skid.kaze.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import skid.kaze.Kaze;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.manager.EventManager;
import skid.kaze.module.modules.misc.Freecam;
import skid.kaze.utils.RenderUtils;

@Mixin({GameRenderer.class})
public abstract class GameRendererMixin {
   /**
    * World-space ESP hook: runs inside renderWorld, right before the hand is drawn, i.e. with the world
    * projection active and the world framebuffer bound. The two captured matrices are the engine's own
    * projection and view matrices; RenderUtils works out which is which.
    * (require = 0: if this injection point is ever missing the client still starts - the HUD watchdog in
    * RenderUtils then tells the user that the ESP hook did not run.)
    */
   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE_STRING",
         target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V",
         args = {"ldc=hand"}
      )},
      require = 0
   )
   private void kaze$onWorldRender(RenderTickCounter tickCounter, CallbackInfo ci, @Local(ordinal = 0) Matrix4f first, @Local(ordinal = 1) Matrix4f second) {
      if (Kaze.mc == null || Kaze.mc.world == null || Kaze.mc.player == null) {
         return;
      }

      RenderUtils.beginWorldFrame(first, second);
      try {
         EventManager.b(new Render3DEvent(new MatrixStack(), new Matrix4f(first), tickCounter.getTickProgress(true)));
      } finally {
         RenderUtils.endWorldFrame();
      }
   }

   @Inject(
      method = {"shouldRenderBlockOutline"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void onShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> cir) {
      if (Kaze.INSTANCE != null && Kaze.INSTANCE.getModuleManager() != null
         && Kaze.INSTANCE.getModuleManager().getModuleByClass(Freecam.class) != null
         && Kaze.INSTANCE.getModuleManager().getModuleByClass(Freecam.class).isEnabled()) {
         cir.setReturnValue(false);
      }

   }
}
