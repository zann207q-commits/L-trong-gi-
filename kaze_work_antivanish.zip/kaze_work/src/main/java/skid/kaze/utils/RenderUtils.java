package skid.kaze.utils;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import skid.kaze.mixin.RenderLayerAccessor;
import skid.kaze.mixin.RenderPipelinesAccessor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import skid.kaze.Kaze;

/**
 * 1.21.11 render helpers.
 *
 *  - 2D (GUI / HUD): rounded rects, circles and outlines are built from a few filled bands (DrawContext.fill).
 *  - 3D (ESP / tracers): real world-space rendering. Modules call renderFilledBox / renderLine as before; the
 *    geometry is queued and drawn once per frame (one draw call for all boxes, one for all lines) with custom
 *    no-depth pipelines, inside GameRenderer.renderWorld (see GameRendererMixin). The GPU rasterises the
 *    lines, so they are smooth, have a real width and stay glued to the world (FOV effects / bobbing included).
 */
public final class RenderUtils {
   // ------------------------------------------------------------------ camera / misc

   public static Camera getCamera() {
      return Kaze.mc.gameRenderer.getCamera();
   }

   public static Vec3d getCameraPos() {
      return getCamera().getCameraPos();
   }

   public static double deltaTime() {
      return Kaze.mc.getCurrentFps() > 0 ? 1.0 / (double)Kaze.mc.getCurrentFps() : 1.0;
   }

   public static float fast(float from, float to, float speed) {
      float t = MathHelper.clamp((float)(deltaTime() * (double)speed), 0.0F, 1.0F);
      return (1.0F - t) * from + t * to;
   }

   public static Vec3d getPlayerLookVec(PlayerEntity player) {
      float cos = MathHelper.cos(player.getYaw() * ((float)Math.PI / 180F) - (float)Math.PI);
      float sin = MathHelper.sin(player.getYaw() * ((float)Math.PI / 180F) - (float)Math.PI);
      float cos2 = MathHelper.cos(player.getPitch() * ((float)Math.PI / 180F));
      return (new Vec3d((double)(sin * cos2), (double)MathHelper.sin(player.getPitch() * ((float)Math.PI / 180F)), (double)(cos * cos2))).normalize();
   }

   // ------------------------------------------------------------------ "unscaled" GUI space
   // The GUI/HUD code works in raw framebuffer pixels. Instead of swapping the projection matrix
   // (no longer possible) we scale the DrawContext matrix by 1/guiScale while drawing.

   public static void unscaledProjection(DrawContext ctx) {
      float s = (float)(1.0 / Kaze.mc.getWindow().getScaleFactor());
      Matrix3x2fStack m = ctx.getMatrices();
      m.pushMatrix();
      m.scale(s, s);
   }

   public static void scaledProjection(DrawContext ctx) {
      ctx.getMatrices().popMatrix();
   }

   // ------------------------------------------------------------------ 2D shapes

   // ---- cheap rounded shapes ------------------------------------------------------------
   // Since 1.21.6 every DrawContext.fill() becomes a GuiRenderState element (allocation + layer
   // lookup). The old code drew rounded rects / circles one pixel row at a time, i.e. hundreds of
   // elements per button, which is what made the ClickGUI stutter. Corners are now built from at most
   // a handful of bands (rows with the same inset are merged into one fill).

   private static final int[] NO_ROWS = new int[0];
   private static final Map<Integer, int[]> CORNER_CACHE = new HashMap<>();

   /** Inset (in pixels) of each row of a corner, from the outer edge inwards. Trailing zero rows are dropped. */
   private static int[] cornerProfile(int radius) {
      if (radius <= 0) {
         return NO_ROWS;
      }

      int[] cached = CORNER_CACHE.get(radius);
      if (cached != null) {
         return cached;
      }

      int q = Math.max(1, radius / 4);
      int[] rows = new int[radius];
      int used = 0;
      for(int i = 0; i < radius; ++i) {
         double dy = (double)radius - ((double)i + 0.5);
         double dx = Math.sqrt(Math.max(0.0, (double)(radius * radius) - dy * dy));
         int inset = (int)Math.round(((double)radius - dx) / (double)q) * q;
         rows[i] = Math.min(radius, inset);
         if (rows[i] > 0) {
            used = i + 1;
         }
      }

      int[] out = new int[used];
      System.arraycopy(rows, 0, out, 0, used);
      CORNER_CACHE.put(radius, out);
      return out;
   }

   private static int rowInset(int[] profile, int row) {
      return row < profile.length ? profile[row] : 0;
   }

   private static void fillRounded(DrawContext ctx, int l, int t, int r, int b, int tl, int tr, int bl, int br, int argb) {
      int[] ptl = cornerProfile(tl);
      int[] ptr = cornerProfile(tr);
      int[] pbl = cornerProfile(bl);
      int[] pbr = cornerProfile(br);
      int topRows = Math.max(ptl.length, ptr.length);
      int botRows = Math.max(pbl.length, pbr.length);
      if (topRows + botRows > b - t) {
         // degenerate (tiny) rectangle: plain fill
         ctx.fill(l, t, r, b, argb);
         return;
      }

      int y = 0;
      while(y < topRows) {
         int inL = rowInset(ptl, y);
         int inR = rowInset(ptr, y);
         int y2 = y + 1;
         while(y2 < topRows && rowInset(ptl, y2) == inL && rowInset(ptr, y2) == inR) {
            ++y2;
         }

         if (l + inL < r - inR) {
            ctx.fill(l + inL, t + y, r - inR, t + y2, argb);
         }

         y = y2;
      }

      if (b - botRows > t + topRows) {
         ctx.fill(l, t + topRows, r, b - botRows, argb);
      }

      // bottom band: fromEdge = 0 is the bottom-most row
      int yy = b - botRows;
      while(yy < b) {
         int fromEdge = b - 1 - yy;
         int inL = rowInset(pbl, fromEdge);
         int inR = rowInset(pbr, fromEdge);
         int yy2 = yy + 1;
         while(yy2 < b && rowInset(pbl, b - 1 - yy2) == inL && rowInset(pbr, b - 1 - yy2) == inR) {
            ++yy2;
         }

         if (l + inL < r - inR) {
            ctx.fill(l + inL, yy, r - inR, yy2, argb);
         }

         yy = yy2;
      }
   }

   /** Radii order: top-left, top-right, bottom-left, bottom-right. */
   public static void renderRoundedQuad(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double rTL, double rTR, double rBL, double rBR, double segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) == 0) {
         return;
      }

      int l = (int)Math.round(Math.min(x1, x2));
      int r = (int)Math.round(Math.max(x1, x2));
      int t = (int)Math.round(Math.min(y1, y2));
      int b = (int)Math.round(Math.max(y1, y2));
      if (r <= l || b <= t) {
         return;
      }

      int maxR = Math.min(r - l, b - t) / 2;
      int tl = MathHelper.clamp((int)Math.round(rTL), 0, maxR);
      int tr = MathHelper.clamp((int)Math.round(rTR), 0, maxR);
      int bl = MathHelper.clamp((int)Math.round(rBL), 0, maxR);
      int br = MathHelper.clamp((int)Math.round(rBR), 0, maxR);
      fillRounded(ctx, l, t, r, b, tl, tr, bl, br, argb);
   }

   public static void renderRoundedQuad(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double radius, double segments) {
      renderRoundedQuad(ctx, color, x1, y1, x2, y2, radius, radius, radius, radius, segments);
   }

   /** Outline = 4 bars + 4 corner dots (<= 8 fills) instead of 2 fills per pixel row. */
   public static void renderRoundedOutline(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double rTL, double rTR, double rBL, double rBR, double thickness, double segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) == 0) {
         return;
      }

      int l = (int)Math.round(Math.min(x1, x2));
      int r = (int)Math.round(Math.max(x1, x2));
      int t = (int)Math.round(Math.min(y1, y2));
      int b = (int)Math.round(Math.max(y1, y2));
      int th = Math.max(1, (int)Math.round(thickness));
      if (r <= l || b <= t) {
         return;
      }

      if (r - l <= th * 2 || b - t <= th * 2) {
         ctx.fill(l, t, r, b, argb);
         return;
      }

      int maxR = Math.min(r - l, b - t) / 2;
      int tl = MathHelper.clamp((int)Math.round(rTL), 0, maxR);
      int tr = MathHelper.clamp((int)Math.round(rTR), 0, maxR);
      int bl = MathHelper.clamp((int)Math.round(rBL), 0, maxR);
      int br = MathHelper.clamp((int)Math.round(rBR), 0, maxR);
      int iTL = (int)Math.ceil((double)tl * 0.6);
      int iTR = (int)Math.ceil((double)tr * 0.6);
      int iBL = (int)Math.ceil((double)bl * 0.6);
      int iBR = (int)Math.ceil((double)br * 0.6);
      ctx.fill(l + iTL, t, r - iTR, t + th, argb);
      ctx.fill(l + iBL, b - th, r - iBR, b, argb);
      ctx.fill(l, t + iTL, l + th, b - iBL, argb);
      ctx.fill(r - th, t + iTR, r, b - iBR, argb);
      if (tl > 2) {
         int c = (int)Math.round((double)tl * 0.29);
         ctx.fill(l + c, t + c, l + c + th, t + c + th, argb);
      }

      if (tr > 2) {
         int c = (int)Math.round((double)tr * 0.29);
         ctx.fill(r - c - th, t + c, r - c, t + c + th, argb);
      }

      if (bl > 2) {
         int c = (int)Math.round((double)bl * 0.29);
         ctx.fill(l + c, b - c - th, l + c + th, b - c, argb);
      }

      if (br > 2) {
         int c = (int)Math.round((double)br * 0.29);
         ctx.fill(r - c - th, b - c - th, r - c, b - c, argb);
      }
   }

   public static void renderCircle(DrawContext ctx, Color color, double cx, double cy, double radius, int segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) == 0 || radius <= 0.0) {
         return;
      }

      int l = (int)Math.round(cx - radius);
      int r = (int)Math.round(cx + radius);
      int t = (int)Math.round(cy - radius);
      int b = (int)Math.round(cy + radius);
      if (r <= l || b <= t) {
         return;
      }

      int rad = Math.min(r - l, b - t) / 2;
      fillRounded(ctx, l, t, r, b, rad, rad, rad, rad, argb);
   }

   public static void drawItem(DrawContext ctx, ItemStack stack, int x, int y, float size, int z) {
      if (!stack.isEmpty()) {
         float scale = size / 16.0F;
         Matrix3x2fStack m = ctx.getMatrices();
         m.pushMatrix();
         m.translate((float)x, (float)y);
         m.scale(scale, scale);
         ctx.drawItem(stack, 0, 0);
         m.popMatrix();
      }
   }

   // ------------------------------------------------------------------ 3D world-space ESP
   //
   // Modules call renderFilledBox / renderLine / renderBoxOutline while handling Render3DEvent. Nothing is
   // drawn immediately: the shapes are queued (primitive arrays, no per-shape allocation) and endWorldFrame()
   // draws them in ONE call per kind. The MatrixStack argument of the old API is accepted but ignored - all
   // geometry is made relative to the camera and transformed by the engine's own view matrix.

   private static final int LINE_STRIDE = 8; // x1 y1 z1 x2 y2 z2 argb width
   private static final int BOX_STRIDE = 7;  // x1 y1 z1 x2 y2 z2 argb
   private static final int MAX_LINES = 40000;
   private static final int MAX_BOXES = 10000;
   private static final float DEFAULT_LINE_WIDTH = 2.0F;
   private static final long HOOK_TIMEOUT_NANOS = 4_000_000_000L;

   private static double[] lineData = new double[LINE_STRIDE * 512];
   private static int lineCount;
   private static double[] boxData = new double[BOX_STRIDE * 256];
   private static int boxCount;

   private static boolean frameActive;
   private static boolean drawFailed;
   private static boolean failureReported;
   private static boolean hookWarned;
   private static long lastFrameNanos;
   private static long watchStartNanos;
   private static double originX;
   private static double originY;
   private static double originZ;
   private static Vec3d tracerStart;
   private static final Matrix4f worldView = new Matrix4f();
   private static final Matrix4f invProjection = new Matrix4f();
   private static final Matrix4f invView = new Matrix4f();
   private static final Vector4f scratch4 = new Vector4f();
   private static final Vector3f scratch3 = new Vector3f();

   /**
    * Called from GameRenderer.renderWorld right before the Render3DEvent. The two matrices are the engine's
    * projection and view matrices (the order is detected, so a swapped capture still works).
    */
   public static void beginWorldFrame(Matrix4f first, Matrix4f second) {
      lineCount = 0;
      boxCount = 0;
      frameActive = false;
      tracerStart = null;
      lastFrameNanos = System.nanoTime();
      if (drawFailed) {
         return;
      }

      Camera camera = getCamera();
      if (camera == null || !camera.isReady()) {
         RenderVisibility.disable();
         return;
      }

      Vec3d cam = camera.getCameraPos();
      originX = cam.x;
      originY = cam.y;
      originZ = cam.z;

      Matrix4f v = isViewMatrix(second) ? second : (isViewMatrix(first) ? first : null);
      Matrix4f p = v == null ? null : (v == second ? first : second);
      if (v != null) {
         // real view matrix: includes view bobbing / hurt tilt, so ESP stays glued to the world
         worldView.set(v);
      } else {
         worldView.rotation(new Quaternionf(camera.getRotation()).conjugate());
      }

      tracerStart = computeTracerStart(camera, p, v);
      if (p != null) {
         RenderVisibility.begin(p, v, originX, originY, originZ);
      } else {
         RenderVisibility.disable();
      }

      frameActive = true;
   }

   /** A camera-relative view matrix is a rotation (+ tiny bobbing offset): affine, det ~ 1, small translation. */
   private static boolean isViewMatrix(Matrix4f m) {
      if (m == null || !m.isFinite()) {
         return false;
      }

      return Math.abs(m.m03()) < 1.0E-4F && Math.abs(m.m13()) < 1.0E-4F && Math.abs(m.m23()) < 1.0E-4F
         && Math.abs(m.m33() - 1.0F) < 1.0E-4F
         && Math.abs(m.determinant() - 1.0F) < 0.01F
         && Math.abs(m.m30()) < 8.0F && Math.abs(m.m31()) < 8.0F && Math.abs(m.m32()) < 8.0F;
   }

   private static Vec3d computeTracerStart(Camera camera, Matrix4f projection, Matrix4f view) {
      Vec3d cam = camera.getCameraPos();
      if (projection != null && view != null) {
         try {
            invProjection.set(projection).invert();
            invView.set(view).invert();
            scratch4.set(0.0F, 0.0F, 0.0F, 1.0F).mul(invProjection).mul(invView);
            if (scratch4.w != 0.0F) {
               scratch4.div(scratch4.w);
               Vec3d r = new Vec3d(cam.x + (double)scratch4.x, cam.y + (double)scratch4.y, cam.z + (double)scratch4.z);
               if (Double.isFinite(r.x) && Double.isFinite(r.y) && Double.isFinite(r.z)) {
                  return r;
               }
            }
         } catch (RuntimeException ignored) {
         }
      }

      scratch3.set(0.0F, 0.0F, -1.0F).rotate(camera.getRotation());
      return cam.add((double)scratch3.x, (double)scratch3.y, (double)scratch3.z);
   }

   /** Where tracers should start: the middle of the screen (crosshair), a hair in front of the camera. */
   public static Vec3d getTracerStart(Camera camera) {
      if (tracerStart != null) {
         return tracerStart;
      }

      Vec3d cam = camera.getCameraPos();
      scratch3.set(0.0F, 0.0F, -1.0F).rotate(camera.getRotation());
      return cam.add((double)scratch3.x, (double)scratch3.y, (double)scratch3.z);
   }

   /** Draws everything queued this frame. Never throws: on error the 3D ESP switches itself off. */
   public static void endWorldFrame() {
      if (!frameActive) {
         return;
      }

      frameActive = false;
      try {
         if (boxCount > 0) {
            drawBoxes();
         }

         if (lineCount > 0) {
            drawLines();
         }
      } catch (Throwable t) {
         drawFailed = true;
         System.err.println("[Kaze] World ESP renderer disabled after an error:");
         t.printStackTrace();
      } finally {
         lineCount = 0;
         boxCount = 0;
      }
   }

   /**
    * Called every HUD frame. If an ESP module is on but the world hook never fires (injection point missing)
    * or the renderer crashed, tell the user once instead of failing silently.
    */
   public static void watchWorldRenderer(boolean needed) {
      if (!needed) {
         watchStartNanos = 0L;
         return;
      }

      long now = System.nanoTime();
      if (watchStartNanos == 0L) {
         watchStartNanos = now;
      }

      if (drawFailed && !failureReported) {
         failureReported = true;
         warnUser("3D ESP renderer crashed and was switched off - see the game log (latest.log).");
      } else if (!hookWarned && !drawFailed && now - Math.max(lastFrameNanos, watchStartNanos) > HOOK_TIMEOUT_NANOS) {
         hookWarned = true;
         warnUser("3D ESP is on but the world render hook never ran (GameRenderer.renderWorld injection failed).");
      }
   }

   private static void warnUser(String text) {
      System.err.println("[Kaze] " + text);
      try {
         if (Kaze.mc.player != null) {
            Kaze.mc.player.sendMessage(net.minecraft.text.Text.literal("[Kaze] " + text), false);
         }
      } catch (Throwable ignored) {
      }
   }

   // ---- queueing -------------------------------------------------------------------------

   public static void renderLine(MatrixStack matrixStack, Color color, Vec3d from, Vec3d to) {
      renderLine(matrixStack, color, from, to, DEFAULT_LINE_WIDTH);
   }

   public static void renderLine(MatrixStack matrixStack, Color color, Vec3d from, Vec3d to, float width) {
      if (from != null && to != null) {
         addLine(from.x, from.y, from.z, to.x, to.y, to.z, color, width);
      }
   }

   public static void addLine(double x1, double y1, double z1, double x2, double y2, double z2, Color color, float width) {
      if (!frameActive || color == null || color.getAlpha() == 0 || lineCount >= MAX_LINES) {
         return;
      }

      if (!RenderVisibility.box(x1, y1, z1, x2, y2, z2)) {
         return;
      }

      queueLine(x1, y1, z1, x2, y2, z2, color.getRGB(), width);
   }

   private static void queueLine(double x1, double y1, double z1, double x2, double y2, double z2, int argb, float width) {
      if ((lineCount + 1) * LINE_STRIDE > lineData.length) {
         lineData = Arrays.copyOf(lineData, lineData.length * 2);
      }

      int o = lineCount++ * LINE_STRIDE;
      lineData[o] = x1;
      lineData[o + 1] = y1;
      lineData[o + 2] = z1;
      lineData[o + 3] = x2;
      lineData[o + 4] = y2;
      lineData[o + 5] = z2;
      lineData[o + 6] = (double)argb;
      lineData[o + 7] = (double)width;
   }

   public static void renderFilledBox(MatrixStack matrixStack, float x1, float y1, float z1, float x2, float y2, float z2, Color color) {
      renderFilledBox(matrixStack, (double)x1, (double)y1, (double)z1, (double)x2, (double)y2, (double)z2, color);
   }

   public static void renderFilledBox(MatrixStack matrixStack, double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
      if (!frameActive || color == null || color.getAlpha() == 0 || boxCount >= MAX_BOXES) {
         return;
      }

      if (!RenderVisibility.box(x1, y1, z1, x2, y2, z2)) {
         return;
      }

      if ((boxCount + 1) * BOX_STRIDE > boxData.length) {
         boxData = Arrays.copyOf(boxData, boxData.length * 2);
      }

      int o = boxCount++ * BOX_STRIDE;
      boxData[o] = Math.min(x1, x2);
      boxData[o + 1] = Math.min(y1, y2);
      boxData[o + 2] = Math.min(z1, z2);
      boxData[o + 3] = Math.max(x1, x2);
      boxData[o + 4] = Math.max(y1, y2);
      boxData[o + 5] = Math.max(z1, z2);
      boxData[o + 6] = (double)color.getRGB();
   }

   public static void renderBoxOutline(MatrixStack matrixStack, float x1, float y1, float z1, float x2, float y2, float z2, Color color, float width) {
      renderBoxOutline(matrixStack, (double)x1, (double)y1, (double)z1, (double)x2, (double)y2, (double)z2, color, width);
   }

   /** 12 edges of an axis-aligned box. */
   public static void renderBoxOutline(MatrixStack matrixStack, double x1, double y1, double z1, double x2, double y2, double z2, Color color, float width) {
      if (!frameActive || color == null || color.getAlpha() == 0 || lineCount + 12 > MAX_LINES) {
         return;
      }

      if (!RenderVisibility.box(x1, y1, z1, x2, y2, z2)) {
         return;
      }

      int c = color.getRGB();
      queueLine(x1, y1, z1, x2, y1, z1, c, width);
      queueLine(x2, y1, z1, x2, y1, z2, c, width);
      queueLine(x2, y1, z2, x1, y1, z2, c, width);
      queueLine(x1, y1, z2, x1, y1, z1, c, width);
      queueLine(x1, y2, z1, x2, y2, z1, c, width);
      queueLine(x2, y2, z1, x2, y2, z2, c, width);
      queueLine(x2, y2, z2, x1, y2, z2, c, width);
      queueLine(x1, y2, z2, x1, y2, z1, c, width);
      queueLine(x1, y1, z1, x1, y2, z1, c, width);
      queueLine(x2, y1, z1, x2, y2, z1, c, width);
      queueLine(x2, y1, z2, x2, y2, z2, c, width);
      queueLine(x1, y1, z2, x1, y2, z2, c, width);
   }

   // ---- drawing --------------------------------------------------------------------------

   private static void drawBoxes() {
      RenderLayer layer = EspLayers.FILLED;
      BufferBuilder buffer = Tessellator.getInstance().begin(layer.getDrawMode(), layer.getVertexFormat());
      Matrix4f m = worldView;
      for (int i = 0; i < boxCount; ++i) {
         int o = i * BOX_STRIDE;
         float x1 = (float)(boxData[o] - originX);
         float y1 = (float)(boxData[o + 1] - originY);
         float z1 = (float)(boxData[o + 2] - originZ);
         float x2 = (float)(boxData[o + 3] - originX);
         float y2 = (float)(boxData[o + 4] - originY);
         float z2 = (float)(boxData[o + 5] - originZ);
         int argb = (int)(long)boxData[o + 6];
         quad(buffer, m, argb, x1, y1, z1, x2, y1, z1, x2, y2, z1, x1, y2, z1);
         quad(buffer, m, argb, x1, y1, z2, x1, y2, z2, x2, y2, z2, x2, y1, z2);
         quad(buffer, m, argb, x1, y1, z1, x1, y2, z1, x1, y2, z2, x1, y1, z2);
         quad(buffer, m, argb, x2, y1, z1, x2, y1, z2, x2, y2, z2, x2, y2, z1);
         quad(buffer, m, argb, x1, y1, z1, x1, y1, z2, x2, y1, z2, x2, y1, z1);
         quad(buffer, m, argb, x1, y2, z1, x2, y2, z1, x2, y2, z2, x1, y2, z2);
      }

      BuiltBuffer built = buffer.endNullable();
      if (built != null) {
         layer.draw(built);
      }
   }

   private static void quad(BufferBuilder b, Matrix4f m, int argb,
                            float ax, float ay, float az, float bx, float by, float bz,
                            float cx, float cy, float cz, float dx, float dy, float dz) {
      b.vertex(m, ax, ay, az).color(argb);
      b.vertex(m, bx, by, bz).color(argb);
      b.vertex(m, cx, cy, cz).color(argb);
      b.vertex(m, dx, dy, dz).color(argb);
   }

   private static void drawLines() {
      RenderLayer layer = EspLayers.LINES;
      BufferBuilder buffer = Tessellator.getInstance().begin(layer.getDrawMode(), layer.getVertexFormat());
      Matrix4f m = worldView;
      boolean any = false;
      for (int i = 0; i < lineCount; ++i) {
         int o = i * LINE_STRIDE;
         double dx = lineData[o + 3] - lineData[o];
         double dy = lineData[o + 4] - lineData[o + 1];
         double dz = lineData[o + 5] - lineData[o + 2];
         double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
         if (len <= 1.0E-6) {
            continue;
         }

         // the line shader wants the direction in view space
         m.transformDirection((float)(dx / len), (float)(dy / len), (float)(dz / len), scratch3);
         float nx = scratch3.x;
         float ny = scratch3.y;
         float nz = scratch3.z;
         int argb = (int)(long)lineData[o + 6];
         float width = MathHelper.clamp((float)lineData[o + 7], 1.0F, 10.0F);
         buffer.vertex(m, (float)(lineData[o] - originX), (float)(lineData[o + 1] - originY), (float)(lineData[o + 2] - originZ))
            .color(argb).normal(nx, ny, nz).lineWidth(width);
         buffer.vertex(m, (float)(lineData[o + 3] - originX), (float)(lineData[o + 4] - originY), (float)(lineData[o + 5] - originZ))
            .color(argb).normal(nx, ny, nz).lineWidth(width);
         any = true;
      }

      BuiltBuffer built = buffer.endNullable();
      if (built != null) {
         layer.draw(built);
      } else if (any) {
         throw new IllegalStateException("line buffer came back empty");
      }
   }

   /** Custom pipelines: translucent, no culling, NO depth test (shows through walls), drawn in view space. */
   private static final class EspLayers {
      private static final RenderLayer FILLED = createFilled();
      private static final RenderLayer LINES = createLines();

      private static RenderLayer createFilled() {
         RenderPipeline pipeline = RenderPipeline.builder(new RenderPipeline.Snippet[0])
            .withLocation(Identifier.of("kaze", "pipeline/esp_filled"))
            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
            .withUniform("Projection", UniformType.UNIFORM_BUFFER)
            .withVertexShader("core/position_color")
            .withFragmentShader("core/position_color")
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
            .build();
         pipeline = RenderPipelinesAccessor.kaze$register(pipeline);
         return RenderLayerAccessor.kaze$create("kaze_esp_filled", RenderSetup.builder(pipeline).translucent().expectedBufferSize(1536).build());
      }

      private static RenderLayer createLines() {
         RenderPipeline pipeline = RenderPipeline.builder(new RenderPipeline.Snippet[0])
            .withLocation(Identifier.of("kaze", "pipeline/esp_lines"))
            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
            .withUniform("Projection", UniformType.UNIFORM_BUFFER)
            .withUniform("Globals", UniformType.UNIFORM_BUFFER)
            .withVertexShader("core/rendertype_lines")
            .withFragmentShader("core/rendertype_lines")
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withVertexFormat(VertexFormats.POSITION_COLOR_NORMAL_LINE_WIDTH, DrawMode.LINES)
            .build();
         pipeline = RenderPipelinesAccessor.kaze$register(pipeline);
         return RenderLayerAccessor.kaze$create("kaze_esp_lines", RenderSetup.builder(pipeline).translucent().expectedBufferSize(256).build());
      }
   }
}
