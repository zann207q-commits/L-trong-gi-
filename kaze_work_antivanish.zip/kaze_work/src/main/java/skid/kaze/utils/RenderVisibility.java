package skid.kaze.utils;

import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

/** Cheap frustum test so ESP code can skip boxes/lines that are nowhere near the screen. */
public final class RenderVisibility {
   private static final FrustumIntersection FRUSTUM = new FrustumIntersection();
   private static final Matrix4f CLIP = new Matrix4f();
   private static double originX;
   private static double originY;
   private static double originZ;
   private static boolean ready;

   private RenderVisibility() {
   }

   /** projection * view, with the camera position the geometry is made relative to. */
   public static void begin(Matrix4fc projection, Matrix4fc view, double camX, double camY, double camZ) {
      CLIP.set(projection).mul(view);
      ready = CLIP.isFinite() && Double.isFinite(camX) && Double.isFinite(camY) && Double.isFinite(camZ);
      if (ready) {
         FRUSTUM.set(CLIP);
         originX = camX;
         originY = camY;
         originZ = camZ;
      }
   }

   public static void disable() {
      ready = false;
   }

   /** World-space AABB test (0.5 block margin). When no frustum is known everything counts as visible. */
   public static boolean box(double x1, double y1, double z1, double x2, double y2, double z2) {
      if (!ready) {
         return true;
      }

      return FRUSTUM.testAab(
         (float)(Math.min(x1, x2) - originX - 0.5),
         (float)(Math.min(y1, y2) - originY - 0.5),
         (float)(Math.min(z1, z2) - originZ - 0.5),
         (float)(Math.max(x1, x2) - originX + 0.5),
         (float)(Math.max(y1, y2) - originY + 0.5),
         (float)(Math.max(z1, z2) - originZ + 0.5)
      );
   }
}
