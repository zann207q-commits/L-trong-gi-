package skid.kaze.utils.vanish;

import java.util.Locale;

public final class VanishSignalClassifier {
   private static final String[] SOUNDS = {
      "chest.open", "chest.close", "chest.locked", "barrel.open", "barrel.close",
      "shulker_box.open", "shulker_box.close", "door.open", "door.close",
      "fence_gate.open", "fence_gate.close", "button.click", "lever.click"
   };

   private VanishSignalClassifier() {
   }

   public static boolean suspiciousSound(String id) {
      String p = path(id);
      for (String s : SOUNDS) {
         if (p.contains(s)) {
            return true;
         }
      }
      return false;
   }

   public static boolean suspiciousParticle(String id) {
      String p = path(id);
      return p.contains("crit") || p.contains("enchanted_hit") || p.contains("damage_indicator")
         || p.contains("smoke") || p.equals("block");
   }

   /** "minecraft:block.chest.open" -> "block.chest.open" */
   public static String path(String id) {
      if (id == null) {
         return "unknown";
      }
      int colon = id.indexOf(':');
      return (colon >= 0 && colon + 1 < id.length() ? id.substring(colon + 1) : id).toLowerCase(Locale.ROOT);
   }
}
