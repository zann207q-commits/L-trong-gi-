package skid.kaze.utils.vanish;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class VanishAlertRules {
   public static final List<String> DONUT_STAFF = List.of(
      "FluffyMaster07",
      "archivePedro",
      "Munkerlich",
      "Frenk_Btw",
      "Napooo_",
      "auzzitech",
      "CryptoDaveYT",
      "W1zox_",
      "ZEEF69",
      "showered",
      "CaptainMoose35",
      "BobIsFound",
      "NoahvdAa",
      "0GSummer",
      "LzouzMP5",
      "Pastagamer08",
      "u_vv",
      "Owen1212055",
      "Splaterd",
      "Fallerfly"
   );
   private static final Set<String> STAFF_KEYS = staffKeys();

   private VanishAlertRules() {
   }

   public static boolean isStaffName(String name) {
      return name != null && STAFF_KEYS.contains(name.toLowerCase(Locale.ROOT));
   }

   /** Same as the Krispy original: region proof is not available, always false. */
   public static boolean isInYourRegion(UUID id) {
      return false;
   }

   /** Same as the Krispy original: never throttled here (the module has its own critical cooldown). */
   public static boolean alarmedRecently(UUID id) {
      return false;
   }

   private static Set<String> staffKeys() {
      Set<String> keys = new HashSet<>();
      for (String n : DONUT_STAFF) {
         keys.add(n.toLowerCase(Locale.ROOT));
      }
      return Set.copyOf(keys);
   }
}
