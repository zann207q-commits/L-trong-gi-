package skid.kaze.utils.vanish;

import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.ColorHelper;

/** "WATCHING YOU" effect: spinning skin face, big title, then a short note. */
public final class PlayerWatchHud {
   private static final float FACE_SECONDS = 1.5F;
   private static final float TITLE_DELAY_SECONDS = 1.25F;
   private static final float TITLE_END_SECONDS = 4.5F;
   private static final Text NOTE = Text.literal("Goodluck Kaze User, Be Careful");
   private static UUID watcher;
   private static boolean hidden;
   private static String title;
   private static int stage;
   private static long startNanos;
   private static long noteNanos;
   private static boolean active;

   private PlayerWatchHud() {
   }

   public static void watching(UUID id, String name, int extra) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null && name != null) {
         watcher = id;
         hidden = false;
         title = extra > 0 ? name + " +" + extra : name;
         stage = 0;
         startNanos = System.nanoTime();
         noteNanos = 0L;
         active = true;
      }
   }

   /** Stop everything (module disabled / world left). */
   public static void clear() {
      if (active && stage == 1) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.inGameHud != null) {
            mc.inGameHud.setDefaultTitleFade();
         }
      }
      active = false;
      noteNanos = 0L;
   }

   public static boolean hasWork() {
      if (active && MinecraftClient.getInstance().world == null) {
         active = false;
      }
      return active || noteNanos != 0L;
   }

   public static void render(DrawContext ctx) {
      if (!hasWork()) {
         return;
      }
      if (active) {
         MinecraftClient mc = MinecraftClient.getInstance();
         float t = (float) (System.nanoTime() - startNanos) / 1.0E9F;
         if (stage == 0 && t >= TITLE_DELAY_SECONDS) {
            stage = 1;
            mc.inGameHud.setTitleTicks(10, 40, 15);
            mc.inGameHud.setSubtitle(Text.literal("WATCHING YOU").formatted(Formatting.RED, Formatting.BOLD));
            mc.inGameHud.setTitle(Text.literal(title).formatted(Formatting.RED, Formatting.BOLD));
         } else if (stage == 1 && t >= TITLE_END_SECONDS) {
            stage = 2;
            mc.inGameHud.setDefaultTitleFade();
            noteNanos = System.nanoTime();
            active = false;
         }
         if (active && t < FACE_SECONDS && watcher != null) {
            drawFace(ctx, mc, t / FACE_SECONDS);
         }
      }
      renderNote(ctx);
   }

   private static void drawFace(DrawContext ctx, MinecraftClient mc, float progress) {
      SkinTextures skin = null;
      if (!hidden && mc.getNetworkHandler() != null) {
         PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(watcher);
         if (entry != null) {
            skin = entry.getSkinTextures();
         }
      }
      if (skin == null) {
         skin = DefaultSkinHelper.getSkinTextures(watcher);
      }
      float alpha = 0.05F + 0.6F * (float) Math.sin((double) progress * Math.PI);
      double angle = Math.toRadians(60.0 - 150.0 * (double) progress);
      float squash = (float) Math.cos(angle);
      float size = (float) ctx.getScaledWindowHeight() * 0.42F;
      ctx.getMatrices().pushMatrix();
      ctx.getMatrices().translate((float) ctx.getScaledWindowWidth() / 2.0F,
         (float) ctx.getScaledWindowHeight() / 2.0F - size * 0.08F);
      ctx.getMatrices().scale(Math.max(0.04F, Math.abs(squash)), 1.0F);
      int px = Math.round(size);
      int color = ColorHelper.withAlpha(Math.round(Math.max(0.0F, Math.min(1.0F, alpha)) * 255.0F), 0xFFFFFF);
      PlayerSkinDrawer.draw(ctx, skin, -px / 2, -px / 2, px, color);
      ctx.getMatrices().popMatrix();
   }

   private static void renderNote(DrawContext ctx) {
      if (noteNanos == 0L) {
         return;
      }
      float t = (float) (System.nanoTime() - noteNanos) / 1.0E9F;
      if (t >= 4.0F) {
         noteNanos = 0L;
         return;
      }
      float fade = t < 0.5F ? t / 0.5F : Math.min(1.0F, (4.0F - t) / 1.0F);
      int alpha = Math.round(fade * 255.0F);
      if (alpha > 8) {
         TextRenderer font = MinecraftClient.getInstance().textRenderer;
         ctx.getMatrices().pushMatrix();
         ctx.getMatrices().translate((float) ctx.getScaledWindowWidth() / 2.0F, (float) ctx.getScaledWindowHeight() / 2.0F);
         ctx.getMatrices().scale(2.0F, 2.0F);
         ctx.drawText(font, NOTE, -font.getWidth(NOTE) / 2, -4, ColorHelper.withAlpha(alpha, 0xFFFF55), true);
         ctx.getMatrices().popMatrix();
      }
   }
}
