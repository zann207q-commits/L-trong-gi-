# Kaze 1.21.11 — A+B audit pass

## Changes made in this pass
- ChunkFinder now schedules its chunk scan and Hole ESP scan on all server types, rather than only on DonutSMP. The prior non-Donut branch called `handleSlowChunkFlagging`, which marked arbitrary loaded chunks as flagged and did not periodically refresh Hole ESP.
- Preserved the existing `HoleESP` BooleanSetting and its render toggle.
- Corrected `CameraMixin.onUpdateHead` parameter from `BlockView` to `World` to match the intended 1.21.11 Camera.update signature.
- Added null guards to the hitbox render mixin and Freecam block-outline mixin to avoid dereferencing an absent module manager/module during startup or teardown.
- NetheriteFinder remains excluded from compiled source and ModuleManager registration.

## Static audit findings still requiring follow-up
- ChunkFinder scan tasks still access Minecraft world/chunk/entity data from a background executor. This is a concurrency risk and should be moved to safe client-thread snapshots or a bounded client-thread scan before calling it fully stable.
- Trader scan methods exist but are not scheduled by normal module flow; trader-related settings/constants appear inactive.
- `ChunkFinder` still contains empty exception handlers, including hole scan paths, which can hide runtime failures.
- Several Mixin targets/signatures/accessors have not been verified against the resolved 1.21.11 Yarn artifacts. In particular, inspect `EntityRenderDispatcherMixin`, `FrustumAccessor`, `ChunkOcclusionDataBuilderMixin`, `TextVisitFactoryMixin`, `WorldChunkMixin`.
- `client.mixins.json` uses `defaultRequire: 0`; this avoids some launch failures but can silently disable injection behavior when a target no longer matches.
- Full module behavior for Combat/Donut/Misc/Render cannot be certified from static inspection alone.

## Build status
- Not built. This environment has JDK 21 but no Gradle executable, no Gradle Wrapper in the project, and network DNS is unavailable, so Gradle/Minecraft/Fabric dependencies could not be resolved.
- A direct `javac` attempt is not a valid project compile because Minecraft/Fabric/Gson dependencies are absent; it fails with missing-package/symbol errors. No Java parser/syntax errors were detected in that output, but that does not substitute for Gradle build.

## Recommended verification
1. Run `gradle build` (or add a Gradle Wrapper) with JDK 21 and network access.
2. Resolve compiler errors first; then launch the client and inspect `latest.log` for Mixin warnings.
3. Test Hole ESP toggle on/off, chunk scanning on singleplayer and a non-Donut server, and each module's enable/disable lifecycle.


## Kaze + Krispy staging review (2026-10-11)
- Fixed category placement: the existing Kaze `ChunkFinder` is now registered with `Category.DONUT_FINDING` rather than `Category.DONUT`. Its existing Hole ESP setting remains in the module and was not removed.
- Confirmed the ClickGUI creates windows in `Category.values()` order, and `DONUT_FINDING` is between `DONUT` and `RENDER`.
- Confirmed the supplied Krispy finder sources remain under `krispy-import-staging/`, outside Gradle's `src/main/java`; they are not active modules yet because their `krispy.*` framework and event hooks are incomplete/incompatible with Kaze.
- Build remains unverified: no Gradle executable or wrapper is present in this environment. Do not treat this ZIP as a successfully compiled client.
