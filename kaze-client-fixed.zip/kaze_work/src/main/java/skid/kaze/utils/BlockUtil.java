package skid.kaze.utils;

import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.block.RespawnAnchorBlock;
import skid.kaze.Kaze;

public final class BlockUtil {
   public static Stream<WorldChunk> getLoadedChunks() {
      int radius = Math.max(2, Kaze.mc.options.getClampedViewDistance()) + 3;
      int diameter = radius * 2 + 1;
      ChunkPos center = Kaze.mc.player.getChunkPos();
      ChunkPos min = new ChunkPos(center.x - radius, center.z - radius);
      ChunkPos max = new ChunkPos(center.x + radius, center.z + radius);
      return Stream.iterate(min, (pos) -> {
         int x = pos.x;
         int z = pos.z;
         ++x;
         if (x > max.x) {
            x = min.x;
            ++z;
         }

         if (z > max.z) {
            throw new IllegalStateException("Stream limit didn't work.");
         } else {
            return new ChunkPos(x, z);
         }
      }).limit((long)diameter * (long)diameter).filter((c) -> Kaze.mc.world.isChunkLoaded(c.x, c.z)).map((c) -> Kaze.mc.world.getChunk(c.x, c.z)).filter(Objects::nonNull);
   }

   public static boolean isBlockAtPosition(BlockPos blockPos, Block block) {
      return Kaze.mc.world.getBlockState(blockPos).getBlock() == block;
   }

   public static boolean isRespawnAnchorCharged(BlockPos blockPos) {
      return isBlockAtPosition(blockPos, Blocks.RESPAWN_ANCHOR) && (Integer)Kaze.mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) != 0;
   }

   public static boolean isRespawnAnchorUncharged(BlockPos blockPos) {
      return isBlockAtPosition(blockPos, Blocks.RESPAWN_ANCHOR) && (Integer)Kaze.mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) == 0;
   }

   public static boolean clientSwings(ActionResult result) {
      return result instanceof ActionResult.Success success && "CLIENT".equals(String.valueOf(success.swingSource()));
   }

   public static void interactWithBlock(BlockHitResult blockHitResult, boolean shouldSwingHand) {
      ActionResult result = Kaze.mc.interactionManager.interactBlock(Kaze.mc.player, Hand.MAIN_HAND, blockHitResult);
      if (clientSwings(result) && shouldSwingHand) {
         Kaze.mc.player.swingHand(Hand.MAIN_HAND);
      }

   }
}
