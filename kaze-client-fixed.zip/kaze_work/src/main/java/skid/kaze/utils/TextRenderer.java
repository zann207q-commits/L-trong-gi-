package skid.kaze.utils;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;
import skid.kaze.module.modules.client.Kaze;

/**
 * Text helpers. The GUI works in raw framebuffer pixels, so text is drawn at 2x.
 * With the "Custom Font" setting on, text uses assets/kaze/font/custom.json (Minecraft Ten TTF);
 * otherwise (or for glyphs the TTF lacks) it falls back to the vanilla font.
 */
public final class TextRenderer {
   private static final Identifier CUSTOM_FONT_ID = Identifier.of("kaze", "custom");
   private static Style customStyle;

   /** Only place that touches the 1.21.9+ font API (StyleSpriteSource.Font). Adjust here if the mapping differs. */
   private static Style customStyle() {
      if (customStyle == null) {
         customStyle = Style.EMPTY.withFont(new StyleSpriteSource.Font(CUSTOM_FONT_ID));
      }

      return customStyle;
   }

   private static boolean useCustom() {
      return Kaze.useCustomFont.getValue();
   }

   private static Text make(CharSequence text) {
      MutableText t = Text.literal(text.toString());
      return useCustom() ? t.setStyle(customStyle()) : t;
   }

   public static void drawString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      Matrix3x2fStack m = ctx.getMatrices();
      m.pushMatrix();
      m.scale(2.0F, 2.0F);
      ctx.drawText(skid.kaze.Kaze.mc.textRenderer, make(text), x / 2, y / 2, color, false);
      m.popMatrix();
   }

   public static int getWidth(CharSequence text) {
      return skid.kaze.Kaze.mc.textRenderer.getWidth(make(text)) * 2;
   }

   public static void drawCenteredString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawString(text, ctx, x - getWidth(text) / 2, y, color);
   }

   public static void drawLargeString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawString(text, ctx, x, y, color);
   }

   public static void drawCenteredMinecraftText(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawCenteredString(text, ctx, x, y, color);
   }
}
