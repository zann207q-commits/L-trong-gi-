package skid.kaze.utils;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import skid.kaze.Kaze;

/**
 * 1.21.11 render helpers.
 *
 * Mojang removed the old immediate-mode pipeline (RenderSystem.setShader, Tessellator + BufferRenderer,
 * setProjectionMatrix ...), so this class draws everything through DrawContext.fill():
 *  - 2D (GUI / HUD): rounded rects, circles and outlines are built from filled rows.
 *  - 3D (ESP / tracers): world positions are projected to the screen and drawn as a 2D overlay
 *    (ignores depth, i.e. "through walls" - which is what the ESP modules want anyway).
 */
public final class RenderUtils {
   public static boolean rendering3D = true;
   private static final float NEAR = 0.05F;
   private static DrawContext ctx3D;
   private static Matrix4f projection3D;
   private static int fbWidth;
   private static int fbHeight;

   // ------------------------------------------------------------------ camera / misc

   public static Camera getCamera() {
      return Kaze.mc.gameRenderer.getCamera();
   }

   public static Vec3d getCameraPos() {
      return getCamera().getCameraPos();
   }

   public static double deltaTime() {
      return Kaze.mc.getCurrentFps() > 0 ? 1.0 / (double)Kaze.mc.getCurrentFps() : 1.0;
   }

   public static float fast(float from, float to, float speed) {
      float t = MathHelper.clamp((float)(deltaTime() * (double)speed), 0.0F, 1.0F);
      return (1.0F - t) * from + t * to;
   }

   public static Vec3d getPlayerLookVec(PlayerEntity player) {
      float cos = MathHelper.cos(player.getYaw() * ((float)Math.PI / 180F) - (float)Math.PI);
      float sin = MathHelper.sin(player.getYaw() * ((float)Math.PI / 180F) - (float)Math.PI);
      float cos2 = MathHelper.cos(player.getPitch() * ((float)Math.PI / 180F));
      return (new Vec3d((double)(sin * cos2), (double)MathHelper.sin(player.getPitch() * ((float)Math.PI / 180F)), (double)(cos * cos2))).normalize();
   }

   // ------------------------------------------------------------------ "unscaled" GUI space
   // The GUI/HUD code works in raw framebuffer pixels. Instead of swapping the projection matrix
   // (no longer possible) we scale the DrawContext matrix by 1/guiScale while drawing.

   public static void unscaledProjection(DrawContext ctx) {
      float s = (float)(1.0 / Kaze.mc.getWindow().getScaleFactor());
      Matrix3x2fStack m = ctx.getMatrices();
      m.pushMatrix();
      m.scale(s, s);
      rendering3D = false;
   }

   public static void scaledProjection(DrawContext ctx) {
      ctx.getMatrices().popMatrix();
      rendering3D = true;
   }

   // ------------------------------------------------------------------ 2D shapes

   private static int cornerInset(int radius, int rowFromEdge) {
      double dy = (double)radius - ((double)rowFromEdge + 0.5);
      double dx = Math.sqrt(Math.max(0.0, (double)(radius * radius) - dy * dy));
      return (int)Math.round((double)radius - dx);
   }

   /** Radii order: top-left, top-right, bottom-left, bottom-right. */
   public static void renderRoundedQuad(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double rTL, double rTR, double rBL, double rBR, double segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) == 0) {
         return;
      }

      int l = (int)Math.round(Math.min(x1, x2));
      int r = (int)Math.round(Math.max(x1, x2));
      int t = (int)Math.round(Math.min(y1, y2));
      int b = (int)Math.round(Math.max(y1, y2));
      if (r <= l || b <= t) {
         return;
      }

      int maxR = Math.min(r - l, b - t) / 2;
      int tl = MathHelper.clamp((int)Math.round(rTL), 0, maxR);
      int tr = MathHelper.clamp((int)Math.round(rTR), 0, maxR);
      int bl = MathHelper.clamp((int)Math.round(rBL), 0, maxR);
      int br = MathHelper.clamp((int)Math.round(rBR), 0, maxR);
      int topBand = Math.max(tl, tr);
      int botBand = Math.max(bl, br);

      for(int i = 0; i < topBand; ++i) {
         int inL = i < tl ? cornerInset(tl, i) : 0;
         int inR = i < tr ? cornerInset(tr, i) : 0;
         if (l + inL < r - inR) {
            ctx.fill(l + inL, t + i, r - inR, t + i + 1, argb);
         }
      }

      if (b - botBand > t + topBand) {
         ctx.fill(l, t + topBand, r, b - botBand, argb);
      }

      for(int i = 0; i < botBand; ++i) {
         int fromEdge = botBand - 1 - i;
         int inL = fromEdge < bl ? cornerInset(bl, fromEdge) : 0;
         int inR = fromEdge < br ? cornerInset(br, fromEdge) : 0;
         int y = b - botBand + i;
         if (l + inL < r - inR) {
            ctx.fill(l + inL, y, r - inR, y + 1, argb);
         }
      }

   }

   public static void renderRoundedQuad(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double radius, double segments) {
      renderRoundedQuad(ctx, color, x1, y1, x2, y2, radius, radius, radius, radius, segments);
   }

   private static int[] span(int l, int t, int r, int b, int tl, int tr, int bl, int br, int y) {
      if (y >= t && y < b) {
         int inL = 0;
         int inR = 0;
         int fromTop = y - t;
         int fromBottom = b - 1 - y;
         if (fromTop < tl) {
            inL = Math.max(inL, cornerInset(tl, fromTop));
         }

         if (fromTop < tr) {
            inR = Math.max(inR, cornerInset(tr, fromTop));
         }

         if (fromBottom < bl) {
            inL = Math.max(inL, cornerInset(bl, fromBottom));
         }

         if (fromBottom < br) {
            inR = Math.max(inR, cornerInset(br, fromBottom));
         }

         return l + inL < r - inR ? new int[]{l + inL, r - inR} : null;
      } else {
         return null;
      }
   }

   public static void renderRoundedOutline(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double rTL, double rTR, double rBL, double rBR, double thickness, double segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) == 0) {
         return;
      }

      int l = (int)Math.round(Math.min(x1, x2));
      int r = (int)Math.round(Math.max(x1, x2));
      int t = (int)Math.round(Math.min(y1, y2));
      int b = (int)Math.round(Math.max(y1, y2));
      int th = Math.max(1, (int)Math.round(thickness));
      if (r <= l || b <= t) {
         return;
      }

      int maxR = Math.min(r - l, b - t) / 2;
      int tl = MathHelper.clamp((int)Math.round(rTL), 0, maxR);
      int tr = MathHelper.clamp((int)Math.round(rTR), 0, maxR);
      int bl = MathHelper.clamp((int)Math.round(rBL), 0, maxR);
      int br = MathHelper.clamp((int)Math.round(rBR), 0, maxR);

      for(int y = t; y < b; ++y) {
         int[] outer = span(l, t, r, b, tl, tr, bl, br, y);
         if (outer != null) {
            int[] inner = span(l + th, t + th, r - th, b - th, Math.max(0, tl - th), Math.max(0, tr - th), Math.max(0, bl - th), Math.max(0, br - th), y);
            if (inner == null) {
               ctx.fill(outer[0], y, outer[1], y + 1, argb);
            } else {
               ctx.fill(outer[0], y, inner[0], y + 1, argb);
               ctx.fill(inner[1], y, outer[1], y + 1, argb);
            }
         }
      }

   }

   public static void renderCircle(DrawContext ctx, Color color, double cx, double cy, double radius, int segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) != 0 && !(radius <= 0.0)) {
         int top = (int)Math.floor(cy - radius);
         int bottom = (int)Math.ceil(cy + radius);

         for(int y = top; y < bottom; ++y) {
            double dy = (double)y + 0.5 - cy;
            if (!(Math.abs(dy) > radius)) {
               double hw = Math.sqrt(radius * radius - dy * dy);
               int x1 = (int)Math.round(cx - hw);
               int x2 = (int)Math.round(cx + hw);
               if (x2 > x1) {
                  ctx.fill(x1, y, x2, y + 1, argb);
               }
            }
         }

      }
   }

   public static void drawItem(DrawContext ctx, ItemStack stack, int x, int y, float size, int z) {
      if (!stack.isEmpty()) {
         float scale = size / 16.0F;
         Matrix3x2fStack m = ctx.getMatrices();
         m.pushMatrix();
         m.translate((float)x, (float)y);
         m.scale(scale, scale);
         ctx.drawItem(stack, 0, 0);
         m.popMatrix();
      }
   }

   // ------------------------------------------------------------------ 3D overlay

   public static Matrix4f createProjection() {
      double fov = (double)Kaze.mc.options.getFov().getValue();
      float aspect = (float)Kaze.mc.getWindow().getFramebufferWidth() / (float)Math.max(1, Kaze.mc.getWindow().getFramebufferHeight());
      return (new Matrix4f()).perspective((float)Math.toRadians(fov), aspect, NEAR, 1024.0F);
   }

   public static void begin3D(DrawContext ctx, Matrix4f projection) {
      ctx3D = ctx;
      projection3D = projection;
      fbWidth = Kaze.mc.getWindow().getFramebufferWidth();
      fbHeight = Kaze.mc.getWindow().getFramebufferHeight();
      float s = (float)(1.0 / Kaze.mc.getWindow().getScaleFactor());
      ctx.getMatrices().pushMatrix();
      ctx.getMatrices().scale(s, s);
   }

   public static void end3D() {
      if (ctx3D != null) {
         ctx3D.getMatrices().popMatrix();
      }

      ctx3D = null;
      projection3D = null;
   }

   /** Kept for source compatibility with older modules: returns a MatrixStack positioned at the given world point. */
   public static MatrixStack matrixFrom(double x, double y, double z) {
      MatrixStack stack = new MatrixStack();
      Camera camera = getCamera();
      stack.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
      stack.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
      stack.translate(x - camera.getCameraPos().x, y - camera.getCameraPos().y, z - camera.getCameraPos().z);
      return stack;
   }

   private static Vector4f toView(Matrix4f view, double x, double y, double z) {
      return view.transform(new Vector4f((float)x, (float)y, (float)z, 1.0F));
   }

   private static double[] toScreen(Vector4f v) {
      Vector4f c = projection3D.transform(new Vector4f(v));
      if (c.w <= 0.0F) {
         return null;
      } else {
         double nx = (double)(c.x / c.w);
         double ny = (double)(c.y / c.w);
         return new double[]{(nx * 0.5 + 0.5) * (double)fbWidth, (0.5 - ny * 0.5) * (double)fbHeight};
      }
   }

   /** view-space segment -> screen segment (clips against the near plane). */
   private static void drawViewLine(Vector4f a, Vector4f b, int argb, int thickness) {
      float zn = -NEAR;
      boolean aIn = a.z < zn;
      boolean bIn = b.z < zn;
      if (aIn || bIn) {
         Vector4f pa = new Vector4f(a);
         Vector4f pb = new Vector4f(b);
         if (!aIn) {
            float t = (zn - a.z) / (b.z - a.z);
            pa.set(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, zn, 1.0F);
         } else if (!bIn) {
            float t = (zn - b.z) / (a.z - b.z);
            pb.set(b.x + (a.x - b.x) * t, b.y + (a.y - b.y) * t, zn, 1.0F);
         }

         double[] sa = toScreen(pa);
         double[] sb = toScreen(pb);
         if (sa != null && sb != null) {
            rasterLine(sa[0], sa[1], sb[0], sb[1], argb, thickness);
         }
      }
   }

   public static void renderLine(MatrixStack matrixStack, Color color, Vec3d from, Vec3d to) {
      if (ctx3D != null && projection3D != null && color.getAlpha() != 0) {
         Matrix4f view = matrixStack.peek().getPositionMatrix();
         drawViewLine(toView(view, from.x, from.y, from.z), toView(view, to.x, to.y, to.z), color.getRGB(), 2);
      }
   }

   private static final int[][] EDGES = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};

   public static void renderFilledBox(MatrixStack matrixStack, float x1, float y1, float z1, float x2, float y2, float z2, Color color) {
      if (ctx3D != null && projection3D != null && color.getAlpha() != 0) {
         Matrix4f view = matrixStack.peek().getPositionMatrix();
         Vector4f[] c = new Vector4f[]{toView(view, x1, y1, z1), toView(view, x2, y1, z1), toView(view, x2, y1, z2), toView(view, x1, y1, z2), toView(view, x1, y2, z1), toView(view, x2, y2, z1), toView(view, x2, y2, z2), toView(view, x1, y2, z2)};
         boolean anyIn = false;
         for (Vector4f v : c) {
            if (v.z < -NEAR) {
               anyIn = true;
               break;
            }
         }

         if (anyIn) {
            // Fill the projected silhouette, not its axis-aligned screen rectangle.
            // The old rectangle made every 3D ESP box look like a detached ghost/shadow.
            int fill = new Color(color.getRed(), color.getGreen(), color.getBlue(),
               Math.min(255, color.getAlpha() / 2)).getRGB();
            fillProjectedBoxHull(c, fill);

            int edge = (new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.min(255, color.getAlpha() + 100))).getRGB();
            for (int[] e : EDGES) {
               drawViewLine(c[e[0]], c[e[1]], edge, 2);
            }
         }
      }
   }

   private static void fillProjectedBoxHull(Vector4f[] corners, int argb) {
      List<double[]> points = new ArrayList<>();
      for (Vector4f v : corners) {
         if (v.z < -NEAR) {
            double[] p = toScreen(v);
            if (p != null) points.add(p);
         }
      }
      // Add intersections for edges crossing the near plane so boxes partly behind the camera clip cleanly.
      for (int[] edge : EDGES) {
         Vector4f a = corners[edge[0]], b = corners[edge[1]];
         boolean aIn = a.z < -NEAR, bIn = b.z < -NEAR;
         if (aIn != bIn) {
            float t = (-NEAR - a.z) / (b.z - a.z);
            Vector4f cut = new Vector4f(a.x + (b.x - a.x) * t,
               a.y + (b.y - a.y) * t, -NEAR, 1.0F);
            double[] p = toScreen(cut);
            if (p != null) points.add(p);
         }
      }
      if (points.size() < 3) return;

      points.sort(Comparator.comparingDouble((double[] p) -> p[0]).thenComparingDouble(p -> p[1]));
      List<double[]> hull = new ArrayList<>();
      for (double[] p : points) {
         while (hull.size() >= 2 && cross(hull.get(hull.size()-2), hull.get(hull.size()-1), p) <= 0) hull.remove(hull.size()-1);
         hull.add(p);
      }
      int lower = hull.size();
      for (int i = points.size() - 2; i >= 0; --i) {
         double[] p = points.get(i);
         while (hull.size() > lower && cross(hull.get(hull.size()-2), hull.get(hull.size()-1), p) <= 0) hull.remove(hull.size()-1);
         hull.add(p);
      }
      if (hull.size() < 4) return;
      hull.remove(hull.size()-1);

      int minY = Math.max(0, (int)Math.floor(hull.stream().mapToDouble(p -> p[1]).min().orElse(0)));
      int maxY = Math.min(fbHeight, (int)Math.ceil(hull.stream().mapToDouble(p -> p[1]).max().orElse(0)));
      for (int y = minY; y < maxY; ++y) {
         double scanY = y + 0.5;
         double minX = Double.POSITIVE_INFINITY, maxX = Double.NEGATIVE_INFINITY;
         for (int i = 0; i < hull.size(); ++i) {
            double[] a = hull.get(i), b = hull.get((i + 1) % hull.size());
            if ((a[1] <= scanY && b[1] > scanY) || (b[1] <= scanY && a[1] > scanY)) {
               double x = a[0] + (scanY - a[1]) * (b[0] - a[0]) / (b[1] - a[1]);
               minX = Math.min(minX, x); maxX = Math.max(maxX, x);
            }
         }
         if (Double.isFinite(minX) && Double.isFinite(maxX)) {
            int x1 = Math.max(0, (int)Math.floor(minX));
            int x2 = Math.min(fbWidth, (int)Math.ceil(maxX));
            if (x2 > x1) ctx3D.fill(x1, y, x2, y + 1, argb);
         }
      }
   }

   private static double cross(double[] o, double[] a, double[] b) {
      return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
   }

   /** Run-length rasteriser: number of fill() calls is bounded by the shorter axis of the segment. */
   private static void rasterLine(double x0, double y0, double x1, double y1, int argb, int th) {
      // clip to the framebuffer (Liang-Barsky) so huge off-screen segments cost nothing
      double dx = x1 - x0;
      double dy = y1 - y0;
      double t0 = 0.0;
      double t1 = 1.0;
      double[] p = new double[]{-dx, dx, -dy, dy};
      double[] q = new double[]{x0, (double)fbWidth - x0, y0, (double)fbHeight - y0};

      for(int i = 0; i < 4; ++i) {
         if (p[i] == 0.0) {
            if (q[i] < 0.0) {
               return;
            }
         } else {
            double t = q[i] / p[i];
            if (p[i] < 0.0) {
               if (t > t1) {
                  return;
               }

               if (t > t0) {
                  t0 = t;
               }
            } else {
               if (t < t0) {
                  return;
               }

               if (t < t1) {
                  t1 = t;
               }
            }
         }
      }

      double ax = x0 + t0 * dx;
      double ay = y0 + t0 * dy;
      double bx = x0 + t1 * dx;
      double by = y0 + t1 * dy;
      double ddx = bx - ax;
      double ddy = by - ay;
      if (Math.abs(ddx) >= Math.abs(ddy)) {
         double ymin = Math.min(ay, by);
         double ymax = Math.max(ay, by);
         int r0 = (int)Math.floor(ymin);
         int r1 = (int)Math.floor(ymax);

         for(int row = r0; row <= r1; ++row) {
            double ya = Math.max(ymin, (double)row);
            double yb = Math.min(ymax, (double)(row + 1));
            double xa;
            double xb;
            if (ddy == 0.0) {
               xa = ax;
               xb = bx;
            } else {
               xa = ax + (ya - ay) * ddx / ddy;
               xb = ax + (yb - ay) * ddx / ddy;
            }

            ctx3D.fill((int)Math.floor(Math.min(xa, xb)), row, (int)Math.floor(Math.max(xa, xb)) + th, row + th, argb);
         }
      } else {
         double xmin = Math.min(ax, bx);
         double xmax = Math.max(ax, bx);
         int c0 = (int)Math.floor(xmin);
         int c1 = (int)Math.floor(xmax);

         for(int col = c0; col <= c1; ++col) {
            double xa = Math.max(xmin, (double)col);
            double xb = Math.min(xmax, (double)(col + 1));
            double ya;
            double yb;
            if (ddx == 0.0) {
               ya = ay;
               yb = by;
            } else {
               ya = ay + (xa - ax) * ddy / ddx;
               yb = ay + (xb - ax) * ddy / ddx;
            }

            ctx3D.fill(col, (int)Math.floor(Math.min(ya, yb)), col + th, (int)Math.floor(Math.max(ya, yb)) + th, argb);
         }
      }

   }
}
