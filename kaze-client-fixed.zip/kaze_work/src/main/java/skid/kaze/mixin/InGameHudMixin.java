package skid.kaze.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import skid.kaze.Kaze;
import skid.kaze.event.events.Render2DEvent;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.manager.EventManager;
import skid.kaze.utils.RenderUtils;

@Mixin({InGameHud.class})
public class InGameHudMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void onRenderHud(DrawContext ctx, RenderTickCounter rtc, CallbackInfo ci) {
      float tickDelta = rtc.getTickProgress(true);
      if (Kaze.mc != null && Kaze.mc.world != null && Kaze.mc.player != null) {
         // 3D ESP/tracers are drawn as a projected overlay on the HUD DrawContext (see RenderUtils)
         try {
            RenderUtils.begin3D(ctx, RenderUtils.createProjection());
            EventManager.b(new Render3DEvent(new MatrixStack(), RenderUtils.createProjection(), tickDelta));
         } finally {
            RenderUtils.end3D();
         }
      }

      EventManager.b(new Render2DEvent(ctx, tickDelta));
   }
}
