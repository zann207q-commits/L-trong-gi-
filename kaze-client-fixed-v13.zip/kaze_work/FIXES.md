# Fix pass 3 — Minecraft 1.21.11 (Yarn 1.21.11+build.4)

NOT compiled or run (no Gradle / no network in the review environment). Everything below was checked
against the Yarn 1.21.11 docs where noted; build with `gradlew build` on JDK 21 and send back the log.

## Runtime bugs fixed (would have broken modules even after compiling)
- KeyboardMixin / MouseMixin used the pre-1.21.9 signatures -> keybinds, ClickGUI toggle and every
  key-activated module were dead. Now `Keyboard.onKey(long,int,KeyInput)` / `Mouse.onMouseButton(long,MouseInput,int)` (verified).
- TickEvent was fired twice per tick (MinecraftClientMixin + ClientPlayerEntityMixin) -> every module ran 2x. Removed the duplicate.
- Kaze ctor: `mc` was assigned last and any exception was swallowed -> half-initialised client. Reordered + errors printed.
- CameraMixin: `Camera.update` takes `World` (not `BlockView`) in 1.21.11 -> Freecam hook would not apply (verified).
- PlayerESP / StorageESP: NPE every frame when `crosshairTarget` is null (tracers). Fixed; PlayerESP rewritten.
- client.mixins.json: `defaultRequire` 1 -> 0 so one stale hook cannot crash the game on launch. Check latest.log for Mixin warnings.

## Port work
- GUI input (ClickGUI, StringBox, ItemFilter) moved to `KeyInput` / `Click` / `CharInput` (1.21.9+ API).
- RenderUtils rewritten on `DrawContext.fill` (rounded rects/circles/outlines, item draw) - old code used removed
  RenderSystem/Tessellator and contained raw intermediary names (class_286, method_34540, field_4344).
- 3D overlay: renderLine / renderFilledBox project world points to screen (Render3DEvent now fired from InGameHudMixin).
  Depth is ignored (through-walls) and FOV is the option value (no sprint FOV change).
- TextRenderer: vanilla font at 2x. Custom TTF renderer (GlyphPage*) deleted; "Custom Font" setting is now a no-op.
- ChunkFinder toast replaced by a chat message. TargetHUD skin draw uses `SkinTextures` overload (verified).
- ModuleButton scissor via `DrawContext.enableScissor`.

## Disabled
- NetheriteFinder, Ore, HeightContextMixin and the 3 placement-modifier accessors moved to `_disabled_needs_port/`
  (need ChunkRandom / PlacedFeatureIndexer worldgen port).

## Untouched / unverified
- SelfDestruct (not modified, not reviewed further).
- EntityRenderDispatcherMixin (hitbox render), TextVisitFactoryMixin, ChunkOcclusionDataBuilderMixin, Frustum accessor, WorldChunkMixin:
  targets not checked against 1.21.11 mappings.
- Combat/donut/misc modules were only checked for event wiring, not line-by-line against 1.21.11 APIs.

## Font restore (pass 4)
- font.ttf (Minecraft Ten) moved to assets/kaze/font/font.ttf and registered by assets/kaze/font/custom.json (ttf provider + vanilla fallback).
- TextRenderer now draws Text with that font when the "Custom Font" setting is on (vanilla font when off). Widths use the same Text so boxes stay aligned.
- NOT compiled. The only risky line is TextRenderer.customStyle(): `Style.withFont(new StyleSpriteSource.Font(id))` (1.21.9+ Yarn name). If it fails to compile, check the Yarn name of FontDescription/StyleSpriteSource.
- Tune size/position in custom.json: "size" (7.14 = 1 font pixel per GUI pixel) and "shift" [x, y].

## ChunkFinder toast (pass 5)
- ChunkFinder found-notification is now a vanilla top-right toast (utils/ToastUtil -> SystemToast), title "Chunk Finder (N found)", body "X: .. Z: ..".
- All toasts share one SystemToast.Type, so a burst of finds updates the visible toast instead of queueing 5+ popups (N counts all finds).
- New settings: "Toast" (default on), "Chat Message" (default off). If the toast fails at runtime, it falls back to chat.
- NOT compiled. Risky lines (all in ToastUtil): `new SystemToast.Type(6000L)` and `SystemToast.add(ToastManager, Type, Text, Text)`. If the constructor isn't public in your Yarn build, use `SystemToast.Type.PERIODIC_NOTIFICATION` instead.

## Krypton+ modules (pass 6)
- The README in KryptonPlus_4_modules_only mislabeled 3 of the 4 files. Decoding their strings shows:
  StorageESP.java = Storage ESP (correct), BlockESP.java = "No Hit Delay", PlayerESP.java = "Auto Log", AutoInvTotem.java = "Auto Eat".
- Auto Eat already exists in this client with the same settings (Health/Hunger Threshold) -> nothing to replace.
- New: combat/NoHitDelay (Only Item, Item, Air, Blocks, Whitelist Blocks) and misc/AutoLog (Player Distance, Webhook, Ignore Friends + Friends list). Registered in ModuleManager.
- StorageESP: fixed unbalanced matrix push/pop and camera NPE when camera is null, skips block entities that are not enabled storage types (no more invisible boxes/tracers).
- Logic of the new modules is rebuilt from decoded setting names and imports (method calls in the Krypton+ files are hidden by invokedynamic), not copied.
- NOT compiled (no Gradle/network here). Correction: the javac syntax check claimed for pass 6 did not actually run (javac was missing); it was run properly in pass 7.

## Rename to Kaze (pass 7)
- Krypton -> Kaze everywhere: package skid.krypton -> skid.kaze (folders moved), main class and client-category module Krypton -> Kaze,
  mod id/name, entrypoint skid.kaze.Main, mixin package, refmap (kaze-refmap.json), assets/krypton -> assets/kaze (font id kaze:font.ttf),
  Gradle rootProject/archivesName/maven_group, HUD watermark and module name ("Krypton+" -> "Kaze"). Project root folder is now kaze_work.
- fabric.mod.json "authors" kept unchanged (credits of the original code).
- Static checks run with javac 21 (no Minecraft jars available): all 138 .java files parse with zero syntax errors; client.mixins.json lists exactly the
  mixin classes that exist; every ModuleManager registration has a class and every module class is registered; no leftover class_/method_/field_ intermediary names.
- Type errors cannot be checked without Minecraft/Yarn jars (about 2100 "missing package/symbol" errors are all from that). Real verification = `gradlew build` on JDK 21.

## Pass 8 - compile-error sweep (no GUI / module behaviour changed)
- StringBox.keyPressed: `n3` (modifier bits) was left over from the old `keyPressed(int,int,int)` signature and no longer
  existed -> compile error. Now `int n3 = input.modifiers();` (Shift+arrow selection keeps working).
- SelfDestruct: lambda captured the loop variable `i` (not effectively final) -> compile error. Now uses a final copy.
- FakeInvScreen: still overrode the removed `mouseClicked(double,double,int)`, so clicks were no longer blocked.
  Now overrides `mouseClicked(Click, boolean)` (1.21.9+) and returns false as before.
- KeyBindingMixin: replaced `InputUtil.isKeyPressed(long, int)` (signature changed in 1.21.9+) with the equivalent
  `GLFW.glfwGetKey(handle, code) == 1`. Same result, no dependency on that signature.
- Checked with javac 21 (flow analysis forced on, Minecraft jars absent): no syntax errors, no other project-internal
  errors. The remaining ~2100 errors are all "package net.minecraft.* does not exist" / cascades from that.
- STILL NOT BUILT against the real 1.21.11 jars. Mixin targets that cannot be confirmed without them:
  EntityRenderDispatcherMixin (renderHitbox), WorldChunkMixin (setBlockState 3rd parameter), FrustumAccessor,
  ChunkOcclusionDataBuilderMixin, GameRendererMixin (shouldRenderBlockOutline), TextVisitFactoryMixin.

## Pass 9 - GUI / HUD / ESP rendering (NOT built against real 1.21.11 jars)
- RenderUtils: rounded rects / circles / outlines no longer draw one pixel row per fill(). Corners are merged into <= ~7 fills
  (outline <= 8). Every fill() is a GuiRenderState element in 1.21.6+, so the old code made the ClickGUI stutter.
- RenderUtils 3D overlay: fill budget per frame (2500), off-screen box culling, lines drawn in <= 64 chunks, box hull in <= 48 bands.
- RenderUtils.syncViewLock + InGameHudMixin: while PlayerESP / StorageESP / ChunkFinder is on, "FOV Effects" = 0 and view bobbing = off
  (restored when they are turned off and on game stop). The overlay is projected with the FOV option, vanilla renders with sprint/speed FOV + bobbing -> ESP "ghosts".
- PlayerESP uses Entity.getLerpedPos(tickDelta).
- HUD (rainbow) and TargetHUD name used ColorUtil.a(x, 1) = alpha 1 -> text / accent bar invisible, only the dark box left. Now alpha 255.
- TextRenderer caches Text objects and widths (module-list sorting called getWidth for every comparison, every frame).
- Component: settings rows are (25,25,30,200) instead of translucent pure black.
- ModuleButton: scissor is always released (try/finally).

## Build-log fixes (pass 5) - from GitHub Actions compileJava log (17 errors)
- Freecam: `new KeyInput(key, 0)` -> `new KeyInput(key, 0, 0)` (record is now key, scancode, modifiers).
- KeyPearl / RtpBaseFinder / TunnelBaseFinder / BlockUtil: `shouldSwingHand()` gone -> `success.swingSource() == ActionResult.SwingSource.CLIENT`.
- RtpBaseFinder / TunnelBaseFinder: removed `particleManager.addBlockBreakingParticles` (method no longer exists; cosmetic only).
- ConfigManager: `Registries.ITEM.getEntry(id)` returns Optional -> `Registries.ITEM.get(id)`.
- StringBox: `MinecraftClient.IS_SYSTEM_MAC` removed -> os.name check.
- WorldChunkMixin: `world.isClient` (private field) -> `world.isClient()`.
- EntityRenderDispatcherMixin: class no longer exists under that name in 1.21.11 -> moved to `_disabled_needs_port/` and removed from client.mixins.json (Hitbox render expansion disabled until ported).
- build.gradle: `useLegacyMixinAp = true` (Loom 1.14 no longer runs the mixin AP by default, so the refmap would not be generated).
- Font: custom.json size 7.14 -> 15.0 (30px at the 2x GUI scale). Use 9.0 to match the Krypton video.
- STILL NOT COMPILED locally (no Gradle/network). Send the next build log if new errors appear.

## Build-log fixes (pass 6)
- compileJava now passes. `:jar` failed: "Entry kaze-refmap.json is a duplicate" - an empty stub `src/main/resources/kaze-refmap.json`
  collided with the refmap the mixin AP generates (useLegacyMixinAp). Removed the stub; the real refmap is generated at build time.

## Runtime crash fix (pass 7) - from Prism crash log
- WorldChunkMixin: `WorldChunk.setBlockState` is `(BlockPos, BlockState, int flags)` in 1.21.11, mixin declared `boolean moved` -> InvalidInjectionException at bootstrap (crash).
  Parameter changed to `int flags`. If another mixin throws "Invalid descriptor" in the log, fix its handler signature the same way.
