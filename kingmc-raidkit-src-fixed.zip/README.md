# KingMC RaidKit — 1.21.11 Meteor addon

Module raid cho `kingmc.vn`, dựng từ 3 file log `itzluckyX9_2026-11-14_19-00-47`
(`bypass.log`, `bypass_config.txt`, `snapshot.json`).

## Có gì trong kit

| Module | Việc nó làm |
|---|---|
| `raid-base-finder` | Quét chunk đã load: block entity (chest/shulker/hopper/beacon/spawner), palette block người chơi đặt, skylight bị chặn ở `scan-y`. Ra box ESP theo cụm base + CSV. |
| `bypass-timing` | Chặn input mine/place/attack/use nhanh hơn ngưỡng AC đã đo trong log. Không đụng movement. |
| `raid-debug` | In telemetry: số chunk đã quét, số hit, hàng đợi, ping, gate đang bật hay tắt. |

## Build

```bash
cd kingmc-raidkit
./gradlew build
```

Jar: `build/libs/kingmc-raidkit-1.0.0.jar` → bỏ vào `.minecraft/mods` cùng Meteor Client.
Build đã chạy sạch trên bộ version dưới đây (JDK 21, Gradle 9.8.0 qua wrapper, Loom 1.17.21):

- `minecraft 1.21.11`, `yarn 1.21.11+build.6`
- `fabric-loader 0.20.1`, `fabric-api 0.141.6+1.21.11`
- `meteor-client 1.21.11-SNAPSHOT`

Loom 1.18+ đòi JVM 25; giữ 1.17.21 nếu máy chỉ có JDK 21. Đổi version thì sửa
`gradle.properties`, wrapper đã pin Gradle 9.8.0.

## Cách detection tính điểm

Mỗi chunk một lần quét, budget `chunks-per-tick`:

```
score = containers * 8.0
      + min(paletteScore, 30) * 0.3
      + skyRatio * 24.0
      + covered * 2.0
```

- `containers`: đếm block entity là container/beacon/spawner trong chunk. 1 chest = 8 điểm → hit ngay.
- `paletteScore`: sample grid 4×4×4 mỗi section, cộng trọng số block người chơi
  (obsidian 4, shulker 6, beacon 8, netherite block 9, tnt 7...). Trần đóng góp 9 điểm.
- `skyRatio`: tại `scan-y` (mặc định 63), đếm cột là air nhưng `LightType.SKY == 0`.
  Base có mái ở tầng đó cho tỉ lệ cao; cave tự nhiên cho tỉ lệ rải rác.
  Tỉ lệ 33% = ~8 điểm → hit. Đây là tín hiệu chính cho base chôn.
- `covered`: cột giữa chunk, 1 block trên heightmap vẫn tối → cộng 2.

Ngưỡng mặc định `min-score = 8.0`. Chunk trong bán kính `radius-chunks` quanh player,
đã load, chưa quét trong `rescan-seconds`. Hit được gộp cụm (merge 1 chunk) để ESP
vẽ footprint chứ không vẽ từng chunk rời.

Nether/End: skylight luôn 0 nên module tự tắt nhánh đó, chỉ còn container + palette.
Muốn quét base nether thì hạ `min-score` xuống 6 và đi theo trục đường lớn.

## Bypass lấy từ log

| Hành động | Flag thấp nhất trong log | Ngưỡng module |
|---|---|---|
| Block break | 4 ms | `mine-gap-ms = 10` + jitter 0–3 |
| Block place | 1 ms (safe 6) | `place-gap-ms = 7` + jitter |
| Entity attack | 1 ms (safe 6) | `attack-gap-ms = 7` + jitter |
| Item use | 1 ms (safe 6) | `use-gap-ms = 7` + jitter |
| Velocity | accept window ≤ 34 ms | không gửi velocity packet nào |
| Setback | 223 lần, aggressive < 100 ms | không đụng movement |

Điểm quan trọng: **finder không gửi packet nào**. Nó chỉ đọc chunk/light data server
đã gửi. Toàn bộ bề mặt AC của khâu tìm base là 0. Phần "bypass" nằm ở chỗ không
thêm module speed/timer — log cho thấy AC này flag cả di chuyển thường
(`SPEED hDist=0.10 bpt`, `FLY_MOVE airTicks=50`), nên thêm speed chỉ tăng flag.

`bypass-timing` mixin vào `ClientPlayerInteractionManager`: input nhanh hơn gap bị
cancel trước khi packet rời client. Jitter làm histogram khoảng cách không phải chu kỳ
cố định. Nó không sửa vị trí, không sửa rotation, không gửi packet lạ.

## Dùng

1. Bật `raid-base-finder`, đặt `radius-chunks` bằng render distance của client.
2. Bay/đi theo trục, quét tự chạy. Hit hiện trong chat + ESP + `hits.csv`.
3. Muốn quét tầng khác: đổi `scan-y` (ví dụ 100 cho base trên cao, 20 cho base sâu).
4. Bật `bypass-timing` trước khi raid thật.
5. `raid-debug` in mỗi 10s để biết scanner có bị nghẽn hay không
   (`queue` tụt về 0 liên tục = đã quét hết vùng load, cần di chuyển).

CSV: `.minecraft/kingmc-raidkit/hits.csv` — cột `time_ms,chunk_x,chunk_z,x,y,z,score,containers,palette,skylight_ratio`.
Đổ vào Excel/script để vẽ map.

## Giới hạn thật

- Chỉ thấy chunk client đã load. Render distance 12 → một vòng quét phủ ~450 chunk;
  muốn phủ map phải di chuyển. Không có module nào đọc được chunk chưa gửi.
- Tỉ lệ "70% ra base" phụ thuộc render distance, kiểu base và mật độ cave. Base có
  chest + mái ở tầng quét gần như chắc chắn ra; stash không container, không mái,
  nằm trong cave tự nhiên có thể trượt. Đây là scanner 3 tín hiệu, không phải X-ray.
- Yarn/Meteor đổi tên hàm giữa các bản 1.21.x là chuyện bình thường. Nếu build gãy,
  lỗi nằm ở tên method mixin hoặc `Render3DEvent.renderer` — sửa đúng chỗ đó, logic quét giữ nguyên.
