package vn.kingmc.raidkit.mixin;

import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import vn.kingmc.raidkit.modules.BypassTiming;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {

    @Inject(method = "attackBlock", at = @At("HEAD"), cancellable = true)
    private void kingmc$gateAttackBlock(BlockPos pos, Direction direction, CallbackInfoReturnable<Boolean> cir) {
        BypassTiming timing = Modules.get().get(BypassTiming.class);
        if (timing != null && timing.isActive() && !timing.allowMine()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void kingmc$gateInteractBlock(ClientPlayerEntity player, Hand hand, BlockHitResult hitResult,
                                          CallbackInfoReturnable<ActionResult> cir) {
        BypassTiming timing = Modules.get().get(BypassTiming.class);
        if (timing != null && timing.isActive() && !timing.allowPlace()) {
            cir.setReturnValue(ActionResult.FAIL);
        }
    }

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void kingmc$gateAttackEntity(PlayerEntity player, Entity target, CallbackInfo ci) {
        BypassTiming timing = Modules.get().get(BypassTiming.class);
        if (timing != null && timing.isActive() && !timing.allowAttack()) {
            ci.cancel();
        }
    }

    @Inject(method = "interactItem", at = @At("HEAD"), cancellable = true)
    private void kingmc$gateInteractItem(PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        BypassTiming timing = Modules.get().get(BypassTiming.class);
        if (timing != null && timing.isActive() && !timing.allowUse()) {
            cir.setReturnValue(ActionResult.FAIL);
        }
    }

    @Inject(method = "interactEntity", at = @At("HEAD"), cancellable = true)
    private void kingmc$gateInteractEntity(PlayerEntity player, Entity entity, Hand hand,
                                           CallbackInfoReturnable<ActionResult> cir) {
        BypassTiming timing = Modules.get().get(BypassTiming.class);
        if (timing != null && timing.isActive() && !timing.allowUse()) {
            cir.setReturnValue(ActionResult.FAIL);
        }
    }
}
