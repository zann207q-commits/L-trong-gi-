package vn.kingmc.raidkit;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import vn.kingmc.raidkit.modules.BypassTiming;
import vn.kingmc.raidkit.modules.RaidBaseFinder;
import vn.kingmc.raidkit.modules.RaidDebug;

public class RaidKitAddon extends MeteorAddon {
    public static final Category CATEGORY = new Category("KingMC Raid");

    @Override
    public void onInitialize() {
        Modules.get().add(new RaidBaseFinder());
        Modules.get().add(new BypassTiming());
        Modules.get().add(new RaidDebug());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "vn.kingmc.raidkit";
    }
}
