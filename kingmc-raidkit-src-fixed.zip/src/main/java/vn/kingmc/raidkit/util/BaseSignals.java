package vn.kingmc.raidkit.util;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.Map;
import java.util.Set;

import static java.util.Map.entry;

public final class BaseSignals {
    private BaseSignals() {}

    public static final Set<String> CONTAINERS = Set.of(
            "chest", "trapped_chest", "ender_chest", "barrel", "hopper",
            "dispenser", "dropper", "furnace", "blast_furnace", "smoker",
            "brewing_stand", "beacon", "shulker_box", "mob_spawner"
    );

    public static final Map<String, Integer> PALETTE_WEIGHTS = Map.ofEntries(
            entry("obsidian", 4),
            entry("crying_obsidian", 6),
            entry("netherrack", 2),
            entry("chest", 5),
            entry("trapped_chest", 5),
            entry("ender_chest", 7),
            entry("barrel", 4),
            entry("hopper", 4),
            entry("enchanting_table", 6),
            entry("anvil", 4),
            entry("chipped_anvil", 4),
            entry("damaged_anvil", 4),
            entry("beacon", 8),
            entry("glowstone", 3),
            entry("sea_lantern", 3),
            entry("lantern", 2),
            entry("crafting_table", 5),
            entry("furnace", 4),
            entry("blast_furnace", 4),
            entry("smoker", 4),
            entry("bookshelf", 3),
            entry("iron_block", 3),
            entry("gold_block", 3),
            entry("diamond_block", 5),
            entry("netherite_block", 9),
            entry("emerald_block", 5),
            entry("white_concrete", 2),
            entry("black_concrete", 2),
            entry("glass", 2),
            entry("iron_bars", 2),
            entry("spawner", 8),
            entry("tnt", 7),
            entry("respawn_anchor", 8),
            entry("lodestone", 6),
            entry("redstone_block", 3),
            entry("piston", 2),
            entry("sticky_piston", 2),
            entry("shulker_box", 6),
            entry("white_shulker_box", 6),
            entry("light_gray_shulker_box", 6),
            entry("gray_shulker_box", 6),
            entry("black_shulker_box", 6),
            entry("brown_shulker_box", 6),
            entry("red_shulker_box", 6),
            entry("orange_shulker_box", 6),
            entry("yellow_shulker_box", 6),
            entry("lime_shulker_box", 6),
            entry("green_shulker_box", 6),
            entry("cyan_shulker_box", 6),
            entry("light_blue_shulker_box", 6),
            entry("blue_shulker_box", 6),
            entry("purple_shulker_box", 6),
            entry("magenta_shulker_box", 6),
            entry("pink_shulker_box", 6)
    );

    public static boolean isContainer(BlockEntityType<?> type) {
        Identifier id = Registries.BLOCK_ENTITY_TYPE.getId(type);
        if (id == null) return false;
        String path = id.getPath();
        return CONTAINERS.contains(path) || path.endsWith("_shulker_box");
    }

    public static int paletteWeight(BlockState state) {
        Identifier id = Registries.BLOCK.getId(state.getBlock());
        if (id == null) return 0;
        Integer weight = PALETTE_WEIGHTS.get(id.getPath());
        return weight == null ? 0 : weight;
    }
}
