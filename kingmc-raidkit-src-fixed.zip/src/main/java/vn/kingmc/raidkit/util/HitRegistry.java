package vn.kingmc.raidkit.util;

import net.minecraft.util.math.ChunkPos;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public final class HitRegistry {
    private HitRegistry() {}

    private static final Map<Long, BaseHit> HITS = new ConcurrentHashMap<>();

    public static final AtomicInteger SCANNED = new AtomicInteger();
    public static final AtomicInteger FLAGGED = new AtomicInteger();

    public record Cluster(int minX, int minZ, int maxX, int maxZ, double score, int chunks) {}

    public static boolean put(BaseHit hit, int maxHits) {
        BaseHit previous = HITS.get(hit.chunk());

        if (previous != null) {
            if (hit.score() < previous.score() + 2.0 && hit.time() - previous.time() < 60_000L) {
                return false;
            }
        } else if (HITS.size() >= maxHits) {
            Long weakestKey = null;
            double weakestScore = Double.MAX_VALUE;

            for (Map.Entry<Long, BaseHit> entry : HITS.entrySet()) {
                if (entry.getValue().score() < weakestScore) {
                    weakestScore = entry.getValue().score();
                    weakestKey = entry.getKey();
                }
            }

            if (weakestKey != null) HITS.remove(weakestKey);
        }

        HITS.put(hit.chunk(), hit);
        return true;
    }

    public static Collection<BaseHit> all() {
        return HITS.values();
    }

    public static int size() {
        return HITS.size();
    }

    public static BaseHit get(long chunk) {
        return HITS.get(chunk);
    }

    public static void clear() {
        HITS.clear();
        SCANNED.set(0);
        FLAGGED.set(0);
    }

    /**
     * Flood-fills hit chunks within {@code merge} chunks of each other into one base footprint.
     */
    public static List<Cluster> clusters(int merge) {
        List<Cluster> clusters = new ArrayList<>();
        Set<Long> remaining = new HashSet<>(HITS.keySet());
        ArrayDeque<Long> stack = new ArrayDeque<>();

        while (!remaining.isEmpty()) {
            long seed = remaining.iterator().next();
            remaining.remove(seed);
            stack.clear();
            stack.push(seed);

            int minX = Integer.MAX_VALUE;
            int minZ = Integer.MAX_VALUE;
            int maxX = Integer.MIN_VALUE;
            int maxZ = Integer.MIN_VALUE;
            double best = 0.0;
            int count = 0;

            while (!stack.isEmpty()) {
                BaseHit hit = HITS.get(stack.pop());
                if (hit == null) continue;

                ChunkPos chunkPos = new ChunkPos(hit.chunk());
                minX = Math.min(minX, chunkPos.x);
                minZ = Math.min(minZ, chunkPos.z);
                maxX = Math.max(maxX, chunkPos.x);
                maxZ = Math.max(maxZ, chunkPos.z);
                best = Math.max(best, hit.score());
                count++;

                for (int dx = -merge; dx <= merge; dx++) {
                    for (int dz = -merge; dz <= merge; dz++) {
                        long neighbour = ChunkPos.toLong(chunkPos.x + dx, chunkPos.z + dz);
                        if (remaining.remove(neighbour)) stack.push(neighbour);
                    }
                }
            }

            if (count > 0) clusters.add(new Cluster(minX, minZ, maxX, maxZ, best, count));
        }

        return clusters;
    }
}
