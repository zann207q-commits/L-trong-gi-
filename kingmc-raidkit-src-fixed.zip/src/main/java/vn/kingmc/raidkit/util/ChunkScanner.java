package vn.kingmc.raidkit.util;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Client-side chunk scan. Reads only chunk data the server already sent; sends nothing.
 *
 * Signals, in order of weight:
 *  - block entities that only player builds carry in bulk (chests, shulkers, hoppers, beacons)
 *  - a weighted palette of player-placed blocks, sampled on a 4-block grid
 *  - skylight occlusion at the scan band: air surrounded by a roof reads skylight 0
 *  - a covered surface column (heightmap top still dark one block above)
 */
public final class ChunkScanner {
    private ChunkScanner() {}

    public record Config(boolean containers, boolean palette, boolean skylight, int scanY) {}

    public record Result(
            int containers,
            int paletteScore,
            int darkColumns,
            int samples,
            double skyRatio,
            double score,
            BlockPos strongest
    ) {}

    public static Result scan(ClientWorld world, WorldChunk chunk, Config cfg) {
        ChunkPos chunkPos = chunk.getPos();
        int containers = 0;
        BlockPos strongest = null;

        if (cfg.containers()) {
            for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
                if (BaseSignals.isContainer(blockEntity.getType())) {
                    containers++;
                    if (strongest == null) strongest = blockEntity.getPos().toImmutable();
                }
            }
        }

        int paletteScore = 0;
        if (cfg.palette()) {
            ChunkSection[] sections = chunk.getSectionArray();
            for (int index = 0; index < sections.length; index++) {
                ChunkSection section = sections[index];
                if (section == null || section.isEmpty()) continue;

                for (int y = 0; y < 16; y += 4) {
                    for (int x = 0; x < 16; x += 4) {
                        for (int z = 0; z < 16; z += 4) {
                            BlockState state = section.getBlockState(x, y, z);
                            if (state.isAir()) continue;
                            paletteScore += BaseSignals.paletteWeight(state);
                        }
                    }
                }
            }
        }

        int darkColumns = 0;
        int samples = 0;
        int covered = 0;

        if (cfg.skylight()) {
            int scanY = cfg.scanY();
            if (scanY >= chunk.getBottomY() && scanY < chunk.getBottomY() + chunk.getHeight()) {
                BlockPos.Mutable cursor = new BlockPos.Mutable();

                for (int x = 0; x < 16; x += 2) {
                    for (int z = 0; z < 16; z += 2) {
                        cursor.set(chunkPos.getStartX() + x, scanY, chunkPos.getStartZ() + z);
                        samples++;

                        if (world.isAir(cursor) && world.getLightLevel(LightType.SKY, cursor) == 0) {
                            darkColumns++;
                            if (strongest == null) strongest = cursor.toImmutable();
                        }
                    }
                }

                int surface = world.getTopY(Heightmap.Type.WORLD_SURFACE,
                        chunkPos.getStartX() + 8, chunkPos.getStartZ() + 8);

                if (surface + 1 < world.getBottomY() + world.getHeight()) {
                    cursor.set(chunkPos.getStartX() + 8, surface + 1, chunkPos.getStartZ() + 8);
                    if (world.getLightLevel(LightType.SKY, cursor) < 15) covered = 1;
                }
            }
        }

        double skyRatio = samples == 0 ? 0.0 : (double) darkColumns / samples;
        double score = containers * 8.0
                + Math.min(paletteScore, 30) * 0.3
                + skyRatio * 24.0
                + covered * 2.0;

        if (strongest == null) {
            strongest = new BlockPos(chunkPos.getStartX() + 8, cfg.scanY(), chunkPos.getStartZ() + 8);
        }

        return new Result(containers, paletteScore, darkColumns, samples, skyRatio, score, strongest);
    }
}
