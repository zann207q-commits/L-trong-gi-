package vn.kingmc.raidkit.util;

import net.minecraft.util.math.BlockPos;

public record BaseHit(
        long chunk,
        BlockPos pos,
        double score,
        int containers,
        int paletteScore,
        double skyRatio,
        int y,
        long time
) {}
