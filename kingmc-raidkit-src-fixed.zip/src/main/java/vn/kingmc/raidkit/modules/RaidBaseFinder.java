package vn.kingmc.raidkit.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.EmptyChunk;
import net.minecraft.world.chunk.WorldChunk;
import vn.kingmc.raidkit.RaidKitAddon;
import vn.kingmc.raidkit.util.BaseHit;
import vn.kingmc.raidkit.util.ChunkScanner;
import vn.kingmc.raidkit.util.HitRegistry;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class RaidBaseFinder extends Module {
    private final SettingGroup sgScan = settings.createGroup("Scan");
    private final SettingGroup sgRender = settings.createGroup("Render");
    private final SettingGroup sgOutput = settings.createGroup("Output");

    private final Setting<Integer> radiusChunks = sgScan.add(new IntSetting.Builder()
            .name("radius-chunks")
            .description("Scan radius in chunks around the player. Server render distance caps this.")
            .defaultValue(12)
            .min(1)
            .max(64)
            .sliderMax(32)
            .build());

    private final Setting<Integer> chunksPerTick = sgScan.add(new IntSetting.Builder()
            .name("chunks-per-tick")
            .description("Scan budget per tick. 2 keeps tick time under a millisecond on a 12-chunk radius.")
            .defaultValue(2)
            .min(1)
            .max(16)
            .sliderMax(8)
            .build());

    private final Setting<Integer> scanY = sgScan.add(new IntSetting.Builder()
            .name("scan-y")
            .description("Skylight slice. 63 catches most overworld buried bases; raise it for surface roofs.")
            .defaultValue(63)
            .min(-64)
            .max(320)
            .build());

    private final Setting<Boolean> scanContainers = sgScan.add(new BoolSetting.Builder()
            .name("containers")
            .description("Count chests, shulkers, barrels, hoppers, beacons and spawners from loaded chunk block entities.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> scanPalette = sgScan.add(new BoolSetting.Builder()
            .name("palette")
            .description("Weight player-placed blocks on a 4-block grid across every chunk section.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> scanSkylight = sgScan.add(new BoolSetting.Builder()
            .name("skylight")
            .description("Detect roofed air at scan-y (overworld only). Nether and end fall back to containers + palette.")
            .defaultValue(true)
            .build());

    private final Setting<Double> minScore = sgScan.add(new DoubleSetting.Builder()
            .name("min-score")
            .description("8.0 = one container, or roughly 33% dark columns at the scan slice.")
            .defaultValue(8.0)
            .min(1.0)
            .max(100.0)
            .sliderMax(40.0)
            .build());

    private final Setting<Integer> rescanSeconds = sgScan.add(new IntSetting.Builder()
            .name("rescan-seconds")
            .description("Do not re-scan the same chunk before this elapses.")
            .defaultValue(300)
            .min(10)
            .max(3600)
            .sliderMax(900)
            .build());

    private final Setting<Boolean> esp = sgRender.add(new BoolSetting.Builder()
            .name("esp")
            .description("Draw merged base footprints through walls.")
            .defaultValue(true)
            .build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
            .name("side-color")
            .defaultValue(new SettingColor(255, 60, 60, 40))
            .build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
            .name("line-color")
            .defaultValue(new SettingColor(255, 90, 90, 255))
            .build());

    private final Setting<Boolean> chatNotify = sgOutput.add(new BoolSetting.Builder()
            .name("chat-notify")
            .description("Print new hits with score and coordinates.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> exportCsv = sgOutput.add(new BoolSetting.Builder()
            .name("export-csv")
            .description("Append every hit to .minecraft/kingmc-raidkit/hits.csv.")
            .defaultValue(true)
            .build());

    private final Setting<Integer> maxHits = sgOutput.add(new IntSetting.Builder()
            .name("max-hits")
            .description("Registry cap. Lowest score is evicted first.")
            .defaultValue(512)
            .min(16)
            .max(8192)
            .sliderMax(2048)
            .build());

    private final ArrayDeque<ChunkPos> queue = new ArrayDeque<>();
    private final Map<Long, Long> lastScan = new HashMap<>();

    private int centerX = Integer.MIN_VALUE;
    private int centerZ = Integer.MIN_VALUE;

    public RaidBaseFinder() {
        super(RaidKitAddon.CATEGORY, "raid-base-finder",
                "Chunk scanner tuned from the kingmc.vn ACCollector session: containers, palette, skylight.");
    }

    @Override
    public void onActivate() {
        queue.clear();
        lastScan.clear();
        centerX = Integer.MIN_VALUE;
        centerZ = Integer.MIN_VALUE;
    }

    @Override
    public void onDeactivate() {
        queue.clear();
        lastScan.clear();
    }

    public int queueSize() {
        return queue.size();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.world == null || mc.player == null) return;

        int playerChunkX = mc.player.getBlockPos().getX() >> 4;
        int playerChunkZ = mc.player.getBlockPos().getZ() >> 4;

        if (playerChunkX != centerX || playerChunkZ != centerZ) {
            rebuildQueue(playerChunkX, playerChunkZ);
            centerX = playerChunkX;
            centerZ = playerChunkZ;
        }

        boolean overworld = mc.world.getRegistryKey() == World.OVERWORLD;
        ChunkScanner.Config config = new ChunkScanner.Config(
                scanContainers.get(),
                scanPalette.get(),
                scanSkylight.get() && overworld,
                scanY.get()
        );

        int budget = chunksPerTick.get();

        while (budget-- > 0 && !queue.isEmpty()) {
            ChunkPos chunkPos = queue.poll();

            if (!mc.world.getChunkManager().isChunkLoaded(chunkPos.x, chunkPos.z)) continue;

            long key = chunkPos.toLong();
            long now = System.currentTimeMillis();
            Long previous = lastScan.get(key);

            if (previous != null && now - previous < rescanSeconds.get() * 1000L) continue;
            lastScan.put(key, now);

            WorldChunk chunk = mc.world.getChunk(chunkPos.x, chunkPos.z);
            if (chunk instanceof EmptyChunk) continue;

            HitRegistry.SCANNED.incrementAndGet();
            ChunkScanner.Result result = ChunkScanner.scan(mc.world, chunk, config);
            if (result.score() < minScore.get()) continue;

            HitRegistry.FLAGGED.incrementAndGet();
            BaseHit hit = new BaseHit(
                    key,
                    result.strongest(),
                    result.score(),
                    result.containers(),
                    result.paletteScore(),
                    result.skyRatio(),
                    scanY.get(),
                    now
            );

            boolean fresh = HitRegistry.put(hit, maxHits.get());
            if (!fresh) continue;

            if (chatNotify.get()) {
                // Meteor's info() runs the message through String.format, so a literal '%'
                // (e.g. "sky=50% at") is parsed as a format specifier and crashes the client.
                // Pass the text as an argument instead of as the format string.
                info("%s", "base hit " + chunkPos.x + "," + chunkPos.z
                        + " score=" + String.format(Locale.ROOT, "%.1f", result.score())
                        + " chests=" + result.containers()
                        + " sky=" + String.format(Locale.ROOT, "%.0f%%", result.skyRatio() * 100.0)
                        + " at " + hit.pos().getX() + " " + hit.pos().getY() + " " + hit.pos().getZ());
            }

            if (exportCsv.get()) writeCsv(hit);
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!esp.get() || mc.player == null) return;

        double maxDistance = radiusChunks.get() * 16.0 + 48.0;
        double maxDistanceSq = maxDistance * maxDistance;
        double y = scanY.get();

        for (HitRegistry.Cluster cluster : HitRegistry.clusters(1)) {
            double x1 = cluster.minX() * 16.0;
            double z1 = cluster.minZ() * 16.0;
            double x2 = (cluster.maxX() + 1) * 16.0;
            double z2 = (cluster.maxZ() + 1) * 16.0;

            double centerX = (x1 + x2) * 0.5;
            double centerZ = (z1 + z2) * 0.5;

            if (mc.player.squaredDistanceTo(centerX, mc.player.getY(), centerZ) > maxDistanceSq) continue;

            event.renderer.box(x1, y - 10.0, z1, x2, y + 10.0, z2,
                    sideColor.get(), lineColor.get(), ShapeMode.Both, 0);
        }
    }

    private void rebuildQueue(int playerChunkX, int playerChunkZ) {
        queue.clear();

        int radius = radiusChunks.get();
        List<ChunkPos> candidates = new ArrayList<>();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius) continue;
                candidates.add(new ChunkPos(playerChunkX + dx, playerChunkZ + dz));
            }
        }

        candidates.sort(Comparator.comparingInt(chunkPos ->
                (chunkPos.x - playerChunkX) * (chunkPos.x - playerChunkX)
                        + (chunkPos.z - playerChunkZ) * (chunkPos.z - playerChunkZ)));

        queue.addAll(candidates);
    }

    private void writeCsv(BaseHit hit) {
        try {
            Path directory = FabricLoader.getInstance().getGameDir().resolve("kingmc-raidkit");
            Files.createDirectories(directory);

            Path file = directory.resolve("hits.csv");
            boolean writeHeader = Files.notExists(file) || Files.size(file) == 0L;

            ChunkPos chunkPos = new ChunkPos(hit.chunk());

            try (BufferedWriter writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                if (writeHeader) {
                    writer.write("time_ms,chunk_x,chunk_z,x,y,z,score,containers,palette,skylight_ratio\n");
                }

                writer.write(String.format(Locale.ROOT, "%d,%d,%d,%d,%d,%d,%.2f,%d,%d,%.3f%n",
                        hit.time(), chunkPos.x, chunkPos.z,
                        hit.pos().getX(), hit.pos().getY(), hit.pos().getZ(),
                        hit.score(), hit.containers(), hit.paletteScore(), hit.skyRatio()));
            }
        } catch (IOException exception) {
            error("%s", "CSV export failed: " + exception.getMessage());
        }
    }
}
