package vn.kingmc.raidkit.modules;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import vn.kingmc.raidkit.RaidKitAddon;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Outgoing interaction gate.
 *
 * Floors come from the ACCollector session:
 *   block break flagged under 9 ms  -> default 10 ms
 *   block place flagged under 6 ms  -> default 7 ms
 *   entity attack flagged under 6 ms -> default 7 ms
 *   item use flagged under 6 ms     -> default 7 ms
 * plus 0-3 ms of jitter so the gap histogram is not a flat period.
 *
 * Movement is deliberately untouched: vanilla walking already trips this AC's
 * 0.1 bpt speed cap in the log, so speed/timer modules are the leak, not the fix.
 */
public class BypassTiming extends Module {
    private final SettingGroup sgTiming = settings.getDefaultGroup();

    private final Setting<Integer> mineGap = sgTiming.add(new IntSetting.Builder()
            .name("mine-gap-ms")
            .description("Minimum interval between block break starts. AC floor: 9 ms.")
            .defaultValue(10)
            .min(6)
            .max(250)
            .sliderMax(60)
            .build());

    private final Setting<Integer> placeGap = sgTiming.add(new IntSetting.Builder()
            .name("place-gap-ms")
            .description("Minimum interval between block placements. AC floor: 6 ms.")
            .defaultValue(7)
            .min(4)
            .max(250)
            .sliderMax(60)
            .build());

    private final Setting<Integer> attackGap = sgTiming.add(new IntSetting.Builder()
            .name("attack-gap-ms")
            .description("Minimum interval between entity attacks. AC floor: 6 ms.")
            .defaultValue(7)
            .min(4)
            .max(250)
            .sliderMax(60)
            .build());

    private final Setting<Integer> useGap = sgTiming.add(new IntSetting.Builder()
            .name("use-gap-ms")
            .description("Minimum interval between item uses. AC floor: 6 ms.")
            .defaultValue(7)
            .min(4)
            .max(250)
            .sliderMax(60)
            .build());

    private final Setting<Integer> jitterMs = sgTiming.add(new IntSetting.Builder()
            .name("jitter-ms")
            .description("Random 0..n added to every gap. Keep it under the AC floor margin.")
            .defaultValue(3)
            .min(0)
            .max(50)
            .sliderMax(15)
            .build());

    private final Setting<Boolean> gateMine = sgTiming.add(new BoolSetting.Builder()
            .name("gate-mine")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> gatePlace = sgTiming.add(new BoolSetting.Builder()
            .name("gate-place")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> gateAttack = sgTiming.add(new BoolSetting.Builder()
            .name("gate-attack")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> gateUse = sgTiming.add(new BoolSetting.Builder()
            .name("gate-use")
            .defaultValue(true)
            .build());

    private long lastMine;
    private long lastPlace;
    private long lastAttack;
    private long lastUse;

    public BypassTiming() {
        super(RaidKitAddon.CATEGORY, "bypass-timing",
                "Caps mine/place/attack/use packet rate at the AC floor recovered from the session log.");
    }

    @Override
    public void onActivate() {
        long now = now();
        lastMine = now - 10_000L;
        lastPlace = now - 10_000L;
        lastAttack = now - 10_000L;
        lastUse = now - 10_000L;

        info("%s", "gate on — mine " + gap(mineGap) + "ms, place " + gap(placeGap)
                + "ms, attack " + gap(attackGap) + "ms, use " + gap(useGap) + "ms");
    }

    public boolean allowMine() {
        if (!gateMine.get()) return true;
        long now = now();
        if (now - lastMine < gap(mineGap)) return false;
        lastMine = now;
        return true;
    }

    public boolean allowPlace() {
        if (!gatePlace.get()) return true;
        long now = now();
        if (now - lastPlace < gap(placeGap)) return false;
        lastPlace = now;
        return true;
    }

    public boolean allowAttack() {
        if (!gateAttack.get()) return true;
        long now = now();
        if (now - lastAttack < gap(attackGap)) return false;
        lastAttack = now;
        return true;
    }

    public boolean allowUse() {
        if (!gateUse.get()) return true;
        long now = now();
        if (now - lastUse < gap(useGap)) return false;
        lastUse = now;
        return true;
    }

    private int gap(Setting<Integer> base) {
        int jitter = jitterMs.get();
        int value = base.get();
        return jitter == 0 ? value : value + ThreadLocalRandom.current().nextInt(jitter + 1);
    }

    private static long now() {
        return System.nanoTime() / 1_000_000L;
    }
}
