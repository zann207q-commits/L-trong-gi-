package vn.kingmc.raidkit.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.PlayerListEntry;
import vn.kingmc.raidkit.RaidKitAddon;
import vn.kingmc.raidkit.util.HitRegistry;

public class RaidDebug extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> intervalSeconds = sgGeneral.add(new IntSetting.Builder()
            .name("interval-seconds")
            .description("Telemetry print interval.")
            .defaultValue(10)
            .min(2)
            .max(120)
            .sliderMax(60)
            .build());

    private final Setting<Boolean> showTiming = sgGeneral.add(new BoolSetting.Builder()
            .name("show-timing")
            .description("Report whether the interaction gate is active.")
            .defaultValue(true)
            .build());

    private double timer;

    public RaidDebug() {
        super(RaidKitAddon.CATEGORY, "raid-debug",
                "Prints scanner and timing telemetry to chat every interval.");
    }

    @Override
    public void onActivate() {
        timer = 0.0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;

        timer += 1.0 / 20.0;
        if (timer < intervalSeconds.get()) return;
        timer = 0.0;

        RaidBaseFinder finder = Modules.get().get(RaidBaseFinder.class);
        BypassTiming timing = Modules.get().get(BypassTiming.class);

        int ping = -1;
        try {
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (entry != null) ping = entry.getLatency();
            }
        } catch (RuntimeException ignored) {
        }

        String line = "scanned=" + HitRegistry.SCANNED.get()
                + " flagged=" + HitRegistry.FLAGGED.get()
                + " hits=" + HitRegistry.size()
                + " queue=" + (finder == null ? -1 : finder.queueSize())
                + " ping=" + (ping < 0 ? "?" : ping + "ms");

        if (showTiming.get()) {
            line += " timing=" + (timing != null && timing.isActive() ? "on" : "off");
        }

        info("%s", line);
    }
}
