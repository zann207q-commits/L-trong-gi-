package dev.ollie.modules;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * V8 ClientSession — Meteor client-side.
 *
 * Fixes vs V7:
 *  #10  airTicks → AtomicInteger (remove volatile-int race)
 *  #15  tickRate() → LongAdder-based, atomic window swap
 *  #16  CopyOnWriteArrayList → BoundedDeque (lock-free, capped at MAX_SAMPLES)
 *  #22  transactionDeltas removed (packet gone since 1.17)
 *  #33  unknownPackets tracks actual byte sizes, not constant 0
 *  #25  EXPORT_ROOT null-safe on all platforms
 */
public class ClientSession {

    // ── Bounds ────────────────────────────────────────────────────────────────
    public static final int MAX_SAMPLES  = 8_000;
    public static final int MAX_FLAG_LOG = 15_000;

    // ── Identity ──────────────────────────────────────────────────────────────
    public final String playerName;
    public final Path   sessionDir;
    public final long   sessionStartMs;
    public final String sessionStartStr;

    private static final DateTimeFormatter FILE_FMT =
        DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
    private static final DateTimeFormatter TS_FMT =
        DateTimeFormatter.ofPattern("HH:mm:ss.SSS");

    // ── Counters ──────────────────────────────────────────────────────────────
    public final AtomicLong totalPackets        = new AtomicLong();
    public final AtomicLong digCount            = new AtomicLong();
    public final AtomicLong attackCount         = new AtomicLong();
    public final AtomicLong placeCount          = new AtomicLong();
    public final AtomicLong flagCount           = new AtomicLong();
    public final AtomicLong rawPktCount         = new AtomicLong();
    public final AtomicLong velocityBypassCount = new AtomicLong();
    public final AtomicLong moveCount           = new AtomicLong();  // fix #14
    public final AtomicLong swingCount          = new AtomicLong();  // new #18
    public final AtomicLong scaffoldCount       = new AtomicLong();  // new #29

    // Peak PPS — fix #15: atomic window swap
    private final AtomicLong peakPpsValue      = new AtomicLong();
    private final AtomicLong windowStart       = new AtomicLong(System.currentTimeMillis());
    private final LongAdder  windowCount       = new LongAdder();

    // ── Movement state ────────────────────────────────────────────────────────
    public volatile double lastX         = Double.MIN_VALUE;
    public volatile double lastY         = Double.MIN_VALUE;
    public volatile double lastZ         = Double.MIN_VALUE;
    public volatile float  lastYaw       = 0;
    public volatile float  lastPitch     = 0;
    public final    AtomicInteger airTicks = new AtomicInteger(); // fix #10
    public volatile double maxSpeedSeen  = 0;
    public volatile double maxDeltaYSeen = 0;
    // Rolling speed window for drift detection (fix #32)
    public final BoundedDeque<Double> recentSpeeds = new BoundedDeque<>(60);

    // ── Timing state ──────────────────────────────────────────────────────────
    public volatile long lastDigTime    = 0;
    public volatile long lastPlaceTime  = 0;
    public volatile long lastAttackTime = 0;
    public volatile long lastMoveTime   = 0;
    public volatile long lastSwingTime  = 0;    // fix #18
    public volatile long lastSlotTime   = 0;    // fix #19
    public volatile long lastItemUseTime= 0;    // fix #17

    // ── Rotation state ────────────────────────────────────────────────────────
    public volatile long  lastRotTime  = 0;
    public volatile float lastRotYaw   = 0;
    public volatile float lastRotPitch = 0;
    // Snap-aim counter for aimbot fingerprint
    public final AtomicInteger snapAimCount = new AtomicInteger();

    // ── Ping ──────────────────────────────────────────────────────────────────
    public volatile long lastKeepAliveSentMs = 0;
    public volatile long lastKeepAliveId     = 0;
    public final BoundedDeque<Long> pingSamples = new BoundedDeque<>(200);

    // ── Velocity bypass ───────────────────────────────────────────────────────
    // fix #11: store vel as record, cleared only after full check
    public volatile PendingVelocity pendingVelocity = null;

    // ── Teleport tracking (fix #20) ───────────────────────────────────────────
    public volatile int  pendingTeleportId   = -1;
    public volatile long pendingTeleportSentMs = 0;
    public final AtomicInteger teleportBypassCount = new AtomicInteger();

    // ── Scaffold state (fix #29) ──────────────────────────────────────────────
    public volatile long lastScaffoldMs = 0;

    // ── Sample buffers (bounded — fix #16) ───────────────────────────────────
    // Separate flagged-speed buffer from all-speed (fix #9 from V5 — still present in V7)
    public final BoundedDeque<Double> speedSamples    = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Double> flaggedSpeeds   = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Long>   digDeltas       = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Long>   placeDeltas     = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Long>   attackDeltas    = new BoundedDeque<>(MAX_SAMPLES);
    public final BoundedDeque<Long>   itemUseDeltas   = new BoundedDeque<>(MAX_SAMPLES); // fix #17
    public final BoundedDeque<String> flagLog         = new BoundedDeque<>(MAX_FLAG_LOG);

    // ── Unknown packet fingerprints (fix #33 — track actual sizes) ───────────
    // Key = "C→S/ClassName" or "S→C/ClassName"
    public final ConcurrentHashMap<String, PktStat> unknownPackets = new ConcurrentHashMap<>();

    // ── Writer ────────────────────────────────────────────────────────────────
    private volatile BufferedWriter writer;
    private volatile boolean        writerDead = false;
    private final Object            writeLock  = new Object();

    // ── Constructor ───────────────────────────────────────────────────────────
    public ClientSession(String playerName, Path exportRoot) {
        this.playerName      = playerName;
        this.sessionStartMs  = System.currentTimeMillis();
        this.sessionStartStr = FILE_FMT.format(LocalDateTime.now());
        this.sessionDir      = exportRoot.resolve(sanitize(playerName) + "_" + sessionStartStr);

        try {
            Files.createDirectories(sessionDir);
            Path logFile = sessionDir.resolve("bypass.log");
            this.writer  = Files.newBufferedWriter(logFile,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            writerDead = true;
            e.printStackTrace();
        }
        log("INIT", "ACCollector V8 session opened — player=" + playerName);
    }

    // ── Logging ───────────────────────────────────────────────────────────────
    public void log(String tag, String data) {
        if (writerDead) return;
        synchronized (writeLock) {
            if (writer == null) return;
            try {
                writer.write("[" + TS_FMT.format(LocalDateTime.now())
                    + "][" + tag + "] " + data);
                writer.newLine();
            } catch (IOException e) {
                writerDead = true;
            }
        }
    }

    public void flag(String type, String detail) {
        String line = "[" + TS_FMT.format(LocalDateTime.now())
            + "][FLAG:" + type + "] " + detail;
        flagLog.offer(line);
        flagCount.incrementAndGet();
        log("FLAG", type + " | " + detail);
        // Flush on flag so crashes don't lose data
        synchronized (writeLock) {
            try { if (writer != null) writer.flush(); } catch (IOException ignored) {}
        }
    }

    // ── PPS tracking (fix #15 — atomic window) ───────────────────────────────
    public long tickRate() {
        windowCount.increment();
        long now = System.currentTimeMillis();
        long ws  = windowStart.get();
        long elapsed = now - ws;
        if (elapsed >= 1000L && windowStart.compareAndSet(ws, now)) {
            long sum = windowCount.sumThenReset();
            long pps = sum * 1000L / Math.max(1L, elapsed);
            long cur;
            do { cur = peakPpsValue.get(); }
            while (pps > cur && !peakPpsValue.compareAndSet(cur, pps));
            return pps;
        }
        return 0L;
    }

    public long peakPps() { return peakPpsValue.get(); }

    // ── Flush / close ─────────────────────────────────────────────────────────
    public void flush() {
        if (writerDead) return;
        synchronized (writeLock) {
            try { if (writer != null) writer.flush(); } catch (IOException ignored) {}
        }
    }

    public void close() {
        synchronized (writeLock) {
            try {
                if (writer != null) { writer.flush(); writer.close(); }
            } catch (IOException ignored) {
            } finally { writer = null; }
        }
    }

    // ── Sanitize (safe for directory name) ───────────────────────────────────
    public static String sanitize(String s) {
        if (s == null) return "unknown";
        return s.replaceAll("[/\\\\:*?\"<>|]", "_")
                .replace("\n", "").replace("\r", "").replace("\t", "");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Inner types
    // ══════════════════════════════════════════════════════════════════════════

    /** Lock-free bounded FIFO — drops oldest when at cap. */
    public static final class BoundedDeque<T> {
        private final int cap;
        private final ConcurrentLinkedDeque<T> q = new ConcurrentLinkedDeque<>();
        private final AtomicInteger sz = new AtomicInteger();

        public BoundedDeque(int cap) { this.cap = cap; }

        public void offer(T val) {
            q.addLast(val);
            if (sz.incrementAndGet() > cap) {
                q.pollFirst();
                sz.decrementAndGet();
            }
        }

        public List<T> snapshot() { return new ArrayList<>(q); }
        public int     size()     { return sz.get(); }
        public boolean isEmpty()  { return sz.get() == 0; }
    }

    /** Pending velocity from server (fix #11 — immutable record). */
    public record PendingVelocity(double vx, double vy, double vz, long receivedMs) {
        public double hMag() { return Math.sqrt(vx * vx + vz * vz); }
    }

    /** Per-type unknown packet stats (fix #33). */
    public static final class PktStat {
        public final AtomicInteger count = new AtomicInteger();
        public final ConcurrentHashMap<Integer, AtomicInteger> sizeDist = new ConcurrentHashMap<>();

        public void record(int bytes) {
            count.incrementAndGet();
            sizeDist.computeIfAbsent(bytes, k -> new AtomicInteger()).incrementAndGet();
        }

        public int modalSize() {
            return sizeDist.entrySet().stream()
                .max(Comparator.comparingInt(e -> e.getValue().get()))
                .map(Map.Entry::getKey).orElse(0);
        }
    }
}
