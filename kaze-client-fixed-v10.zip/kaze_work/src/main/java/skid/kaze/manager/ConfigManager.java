package skid.kaze.manager;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.PrintStream;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import skid.kaze.Kaze;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BindSetting;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.ItemSetting;
import skid.kaze.module.setting.MinMaxSetting;
import skid.kaze.module.setting.ModeSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.module.setting.StringSetting;

public final class ConfigManager {
   private JsonObject jsonObject;

   public void loadProfile() {
      try {
         if (this.jsonObject == null) {
            this.jsonObject = new JsonObject();
            return;
         }

         for(Module next : Kaze.INSTANCE.getModuleManager().c()) {
            JsonElement value = this.jsonObject.get(next.getName().toString());
            if (value != null && value.isJsonObject()) {
               JsonObject asJsonObject = value.getAsJsonObject();
               JsonElement value2 = asJsonObject.get("enabled");
               if (value2 != null && value2.isJsonPrimitive() && value2.getAsBoolean()) {
                  next.toggle(true);
               }

               for(Object next2 : next.getSettings()) {
                  JsonElement value3 = asJsonObject.get(((Setting)next2).getName().toString());
                  if (value3 != null) {
                     this.setValueFromJson((Setting)next2, value3, next);
                  }
               }
            }
         }
      } catch (Exception ex) {
         System.err.println("Error loading profile: " + ex.getMessage());
      }

   }

   private void setValueFromJson(Setting setting, JsonElement jsonElement, Module module) {
      try {
         if (setting instanceof BooleanSetting booleanSetting) {
            if (jsonElement.isJsonPrimitive()) {
               booleanSetting.setValue(jsonElement.getAsBoolean());
            }
         } else if (setting instanceof ModeSetting enumSetting) {
            if (jsonElement.isJsonPrimitive()) {
               int asInt = jsonElement.getAsInt();
               if (asInt != -1) {
                  enumSetting.setModeIndex(asInt);
               } else {
                  enumSetting.setModeIndex(enumSetting.getOriginalValue());
               }
            }
         } else if (setting instanceof NumberSetting numberSetting) {
            if (jsonElement.isJsonPrimitive()) {
               numberSetting.getValue(jsonElement.getAsDouble());
            }
         } else if (setting instanceof BindSetting bindSetting) {
            if (jsonElement.isJsonPrimitive()) {
               int asInt2 = jsonElement.getAsInt();
               bindSetting.setValue(asInt2);
               if (bindSetting.isModuleKey()) {
                  module.setKeybind(asInt2);
               }
            }
         } else if (setting instanceof StringSetting stringSetting) {
            if (jsonElement.isJsonPrimitive()) {
               stringSetting.setValue(jsonElement.getAsString());
            }
         } else if (setting instanceof MinMaxSetting minMaxSetting) {
            if (jsonElement.isJsonObject()) {
               JsonObject asJsonObject = jsonElement.getAsJsonObject();
               if (asJsonObject.has("min") && asJsonObject.has("max")) {
                  double asDouble = asJsonObject.get("min").getAsDouble();
                  double asDouble2 = asJsonObject.get("max").getAsDouble();
                  minMaxSetting.setCurrentMin(asDouble);
                  minMaxSetting.setCurrentMax(asDouble2);
               }
            }
         } else if (setting instanceof ItemSetting && jsonElement.isJsonPrimitive()) {
            ((ItemSetting)setting).setItem((Item)Registries.ITEM.getEntry(Identifier.of(jsonElement.getAsString())));
         }
      } catch (Exception var15) {
      }

   }

   public void shutdown() {
      try {
         this.jsonObject = new JsonObject();

         for(Module module : Kaze.INSTANCE.getModuleManager().c()) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("enabled", module.isEnabled());

            for(Setting setting : module.getSettings()) {
               this.save(setting, jsonObject, module);
            }

            this.jsonObject.add(module.getName().toString(), jsonObject);
         }
      } catch (Exception _t) {
         _t.printStackTrace(System.err);
      }

   }

   private void save(Setting setting, JsonObject jsonObject, Module module) {
      try {
         if (setting instanceof BooleanSetting booleanSetting) {
            jsonObject.addProperty(setting.getName().toString(), booleanSetting.getValue());
         } else if (setting instanceof ModeSetting<?> enumSetting) {
            jsonObject.addProperty(setting.getName().toString(), enumSetting.getModeIndex());
         } else if (setting instanceof NumberSetting numberSetting) {
            jsonObject.addProperty(setting.getName().toString(), numberSetting.getValue());
         } else if (setting instanceof BindSetting bindSetting) {
            jsonObject.addProperty(setting.getName().toString(), bindSetting.getValue());
         } else if (setting instanceof StringSetting stringSetting) {
            jsonObject.addProperty(setting.getName().toString(), stringSetting.getValue());
         } else if (setting instanceof MinMaxSetting) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("min", ((MinMaxSetting)setting).getCurrentMin());
            jsonObject2.addProperty("max", ((MinMaxSetting)setting).getCurrentMax());
            jsonObject.add(setting.getName().toString(), jsonObject2);
         } else if (setting instanceof ItemSetting) {
            ItemSetting itemSetting = (ItemSetting)setting;
            jsonObject.addProperty(setting.getName().toString(), Registries.ITEM.getId(itemSetting.getItem()).toString());
         }
      } catch (Exception ex) {
         PrintStream var10000 = System.err;
         String var10001 = String.valueOf(setting.getName());
         var10000.println("Error saving setting " + var10001 + ": " + ex.getMessage());
      }

   }
}
