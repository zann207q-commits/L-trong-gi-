package skid.kaze.event.events;

import skid.kaze.event.CancellableEvent;

public class BlockBreakingEvent extends CancellableEvent {
}
