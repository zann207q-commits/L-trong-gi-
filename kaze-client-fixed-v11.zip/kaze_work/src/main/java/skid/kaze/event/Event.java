package skid.kaze.event;

public interface Event {
   default boolean isCancelled() {
      return false;
   }
}
