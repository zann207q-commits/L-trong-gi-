package skid.kaze.event.events;

import skid.kaze.event.CancellableEvent;

public class PreItemUseEvent extends CancellableEvent {
   public int cooldown;

   public PreItemUseEvent(int cooldown) {
      this.cooldown = cooldown;
   }
}
