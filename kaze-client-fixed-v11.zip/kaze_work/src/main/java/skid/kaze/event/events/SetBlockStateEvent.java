package skid.kaze.event.events;

import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import skid.kaze.event.CancellableEvent;

public class SetBlockStateEvent extends CancellableEvent {
   public BlockPos pos;
   public BlockState newState;
   public BlockState oldState;

   public SetBlockStateEvent(BlockPos pos, BlockState newState, BlockState oldState) {
      this.pos = pos;
      this.newState = oldState;
      this.oldState = newState;
   }
}
