package skid.kaze.event.events;

import net.minecraft.client.util.Window;
import skid.kaze.event.CancellableEvent;

public class ResolutionChangedEvent extends CancellableEvent {
   public Window window;

   public ResolutionChangedEvent(Window window) {
      this.window = window;
   }
}
