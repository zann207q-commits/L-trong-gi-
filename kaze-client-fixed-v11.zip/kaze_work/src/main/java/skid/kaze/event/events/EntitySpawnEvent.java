package skid.kaze.event.events;

import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import skid.kaze.event.CancellableEvent;

public class EntitySpawnEvent extends CancellableEvent {
   public EntitySpawnS2CPacket packet;

   public EntitySpawnEvent(EntitySpawnS2CPacket packet) {
      this.packet = packet;
   }
}
