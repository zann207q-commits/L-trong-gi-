package skid.kaze.event.events;

import net.minecraft.client.gui.DrawContext;
import skid.kaze.event.CancellableEvent;

public class Render2DEvent extends CancellableEvent {
   public DrawContext context;
   public float tickDelta;

   public Render2DEvent(DrawContext context, float tickDelta) {
      this.context = context;
      this.tickDelta = tickDelta;
   }
}
