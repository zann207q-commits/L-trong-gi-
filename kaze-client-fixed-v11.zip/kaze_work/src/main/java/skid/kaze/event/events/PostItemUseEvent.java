package skid.kaze.event.events;

import skid.kaze.event.CancellableEvent;

public class PostItemUseEvent extends CancellableEvent {
   public int cooldown;

   public PostItemUseEvent(int cooldown) {
      this.cooldown = cooldown;
   }
}
