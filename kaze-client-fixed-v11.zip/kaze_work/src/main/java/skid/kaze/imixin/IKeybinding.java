package skid.kaze.imixin;

public interface IKeybinding {
   boolean kaze$isActuallyPressed();

   void kaze$resetPressed();
}
