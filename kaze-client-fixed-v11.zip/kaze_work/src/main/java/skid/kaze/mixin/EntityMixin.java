package skid.kaze.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import skid.kaze.Kaze;
import skid.kaze.event.events.TargetMarginEvent;
import skid.kaze.event.events.TargetPoseEvent;
import skid.kaze.manager.EventManager;
import skid.kaze.module.modules.misc.Freecam;

@Mixin({Entity.class})
public class EntityMixin {
   @Inject(
      method = {"getTargetingMargin"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSendMovementPackets(CallbackInfoReturnable<Float> cir) {
      EventManager.b(new TargetMarginEvent((Entity)Entity.class.cast(this), cir));
   }

   @Inject(
      method = {"getPose"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetPose(CallbackInfoReturnable<EntityPose> cir) {
      EventManager.b(new TargetPoseEvent((Entity)Entity.class.cast(this), cir));
   }

   @Inject(
      method = {"changeLookDirection"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void updateChangeLookDirection(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
      if (Entity.class.cast(this) == Kaze.mc.player) {
         Freecam freecam = (Freecam)Kaze.INSTANCE.MODULE_MANAGER.getModuleByClass(Freecam.class);
         if (freecam.isEnabled()) {
            freecam.updateRotation(cursorDeltaX * 0.15, cursorDeltaY * 0.15);
            ci.cancel();
         }

      }
   }
}
