package skid.kaze.mixin;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import skid.kaze.Kaze;
import skid.kaze.imixin.IKeybinding;

@Mixin({KeyBinding.class})
public abstract class KeyBindingMixin implements IKeybinding {
   @Shadow
   private InputUtil.Key boundKey;

   @Shadow
   public abstract void setPressed(boolean var1);

   public boolean kaze$isActuallyPressed() {
      return GLFW.glfwGetKey(Kaze.mc.getWindow().getHandle(), this.boundKey.getCode()) == 1;
   }

   public void kaze$resetPressed() {
      this.setPressed(this.kaze$isActuallyPressed());
   }
}
