package skid.kaze.mixin;

import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import skid.kaze.Kaze;
import skid.kaze.module.modules.misc.Freecam;

@Mixin({GameRenderer.class})
public abstract class GameRendererMixin {
   // Render3DEvent is no longer fired here: the old injection point (Profiler.swap inside renderWorld) and the
   // projection helpers it used do not exist in 1.21.11. See InGameHudMixin.
   @Inject(
      method = {"shouldRenderBlockOutline"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void onShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> cir) {
      if (Kaze.INSTANCE != null && Kaze.INSTANCE.getModuleManager() != null
         && Kaze.INSTANCE.getModuleManager().getModuleByClass(Freecam.class) != null
         && Kaze.INSTANCE.getModuleManager().getModuleByClass(Freecam.class).isEnabled()) {
         cir.setReturnValue(false);
      }

   }
}
