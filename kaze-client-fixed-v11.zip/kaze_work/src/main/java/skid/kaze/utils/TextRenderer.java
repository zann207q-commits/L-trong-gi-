package skid.kaze.utils;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;
import skid.kaze.module.modules.client.Kaze;

/**
 * Text helpers. The GUI works in raw framebuffer pixels, so text is drawn at 2x.
 * With the "Custom Font" setting on, text uses assets/kaze/font/custom.json (Minecraft Ten TTF);
 * otherwise (or for glyphs the TTF lacks) it falls back to the vanilla font.
 */
public final class TextRenderer {
   private static final Identifier CUSTOM_FONT_ID = Identifier.of("kaze", "custom");
   private static Style customStyle;

   /** Only place that touches the 1.21.9+ font API (StyleSpriteSource.Font). Adjust here if the mapping differs. */
   private static Style customStyle() {
      if (customStyle == null) {
         customStyle = Style.EMPTY.withFont(new StyleSpriteSource.Font(CUSTOM_FONT_ID));
      }

      return customStyle;
   }

   private static boolean useCustom() {
      return Kaze.useCustomFont.getValue();
   }

   // Text objects and widths are cached: the HUD / ClickGUI ask for the same few hundred strings every frame
   // (module list sorting alone calls getWidth for every enabled module twice per comparison).
   private static final Map<String, Text> TEXT_CACHE = new HashMap<>();
   private static final Map<String, Integer> WIDTH_CACHE = new HashMap<>();
   private static boolean cachedCustom;

   private static void checkCaches(boolean custom) {
      if (custom != cachedCustom || TEXT_CACHE.size() > 2048) {
         TEXT_CACHE.clear();
         WIDTH_CACHE.clear();
         cachedCustom = custom;
      }
   }

   private static Text make(CharSequence text) {
      boolean custom = useCustom();
      checkCaches(custom);
      String key = text.toString();
      Text cached = TEXT_CACHE.get(key);
      if (cached == null) {
         MutableText t = Text.literal(key);
         cached = custom ? t.setStyle(customStyle()) : t;
         TEXT_CACHE.put(key, cached);
      }

      return cached;
   }

   public static void drawString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      Matrix3x2fStack m = ctx.getMatrices();
      m.pushMatrix();
      m.scale(2.0F, 2.0F);
      ctx.drawText(skid.kaze.Kaze.mc.textRenderer, make(text), x / 2, y / 2, color, false);
      m.popMatrix();
   }

   public static int getWidth(CharSequence text) {
      Text t = make(text);
      String key = text.toString();
      Integer w = WIDTH_CACHE.get(key);
      if (w == null) {
         w = skid.kaze.Kaze.mc.textRenderer.getWidth(t) * 2;
         WIDTH_CACHE.put(key, w);
      }

      return w;
   }

   public static void drawCenteredString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawString(text, ctx, x - getWidth(text) / 2, y, color);
   }

   public static void drawLargeString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawString(text, ctx, x, y, color);
   }

   public static void drawCenteredMinecraftText(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawCenteredString(text, ctx, x, y, color);
   }
}
