package skid.kaze.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

public class PingUtil {
   public static Integer getPingString() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.player != null && minecraftClient.getNetworkHandler() != null) {
         PlayerListEntry playerListEntry = minecraftClient.getNetworkHandler().getPlayerListEntry(minecraftClient.player.getUuid());
         return playerListEntry == null ? 0 : playerListEntry.getLatency();
      } else {
         return 0;
      }
   }
}
