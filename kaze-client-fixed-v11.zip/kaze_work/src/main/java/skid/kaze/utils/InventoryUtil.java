package skid.kaze.utils;

import java.util.function.Predicate;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import skid.kaze.Kaze;
import skid.kaze.mixin.ClientPlayerInteractionManagerAccessor;

public final class InventoryUtil {
   public static void swap(int selectedSlot) {
      if (selectedSlot >= 0 && selectedSlot <= 8) {
         Kaze.mc.player.getInventory().setSelectedSlot(selectedSlot);
         ((ClientPlayerInteractionManagerAccessor)Kaze.mc.interactionManager).syncSlot();
      }
   }

   public static boolean swapStack(Predicate<ItemStack> predicate) {
      PlayerInventory getInventory = Kaze.mc.player.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (predicate.test(getInventory.getStack(i))) {
            getInventory.setSelectedSlot(i);
            return true;
         }
      }

      return false;
   }

   public static boolean swapItem(Predicate<Item> predicate) {
      PlayerInventory getInventory = Kaze.mc.player.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (predicate.test(getInventory.getStack(i).getItem())) {
            getInventory.setSelectedSlot(i);
            return true;
         }
      }

      return false;
   }

   public static boolean swap(Item item) {
      return swapItem((item2) -> item2 == item);
   }

   public static int getSlot(Item obj) {
      ScreenHandler currentScreenHandler = Kaze.mc.player.currentScreenHandler;
      if (Kaze.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
         int n = 0;

         for(int i = 0; i < ((GenericContainerScreenHandler)Kaze.mc.player.currentScreenHandler).getRows() * 9; ++i) {
            if (currentScreenHandler.getSlot(i).getStack().getItem().equals(obj)) {
               ++n;
            }
         }

         return n;
      } else {
         return 0;
      }
   }
}
