package skid.kaze.utils;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import skid.kaze.Kaze;

/**
 * 1.21.11 render helpers.
 *
 * Mojang removed the old immediate-mode pipeline (RenderSystem.setShader, Tessellator + BufferRenderer,
 * setProjectionMatrix ...), so this class draws everything through DrawContext.fill():
 *  - 2D (GUI / HUD): rounded rects, circles and outlines are built from filled rows.
 *  - 3D (ESP / tracers): world positions are projected to the screen and drawn as a 2D overlay
 *    (ignores depth, i.e. "through walls" - which is what the ESP modules want anyway).
 */
public final class RenderUtils {
   public static boolean rendering3D = true;
   private static final float NEAR = 0.05F;
   private static DrawContext ctx3D;
   private static Matrix4f projection3D;
   private static int fbWidth;
   private static int fbHeight;
   /** Max GUI fill() calls the 3D overlay may emit per frame (protects the frame time on huge ESP lists). */
   private static final int FILL_BUDGET = 2500;
   private static final int MAX_LINE_CHUNKS = 64;
   private static final int MAX_HULL_BANDS = 48;
   private static int fills3D;
   private static Double savedFovEffect;
   private static Boolean savedBobView;

   // ------------------------------------------------------------------ camera / misc

   public static Camera getCamera() {
      return Kaze.mc.gameRenderer.getCamera();
   }

   public static Vec3d getCameraPos() {
      return getCamera().getCameraPos();
   }

   public static double deltaTime() {
      return Kaze.mc.getCurrentFps() > 0 ? 1.0 / (double)Kaze.mc.getCurrentFps() : 1.0;
   }

   public static float fast(float from, float to, float speed) {
      float t = MathHelper.clamp((float)(deltaTime() * (double)speed), 0.0F, 1.0F);
      return (1.0F - t) * from + t * to;
   }

   public static Vec3d getPlayerLookVec(PlayerEntity player) {
      float cos = MathHelper.cos(player.getYaw() * ((float)Math.PI / 180F) - (float)Math.PI);
      float sin = MathHelper.sin(player.getYaw() * ((float)Math.PI / 180F) - (float)Math.PI);
      float cos2 = MathHelper.cos(player.getPitch() * ((float)Math.PI / 180F));
      return (new Vec3d((double)(sin * cos2), (double)MathHelper.sin(player.getPitch() * ((float)Math.PI / 180F)), (double)(cos * cos2))).normalize();
   }

   // ------------------------------------------------------------------ "unscaled" GUI space
   // The GUI/HUD code works in raw framebuffer pixels. Instead of swapping the projection matrix
   // (no longer possible) we scale the DrawContext matrix by 1/guiScale while drawing.

   public static void unscaledProjection(DrawContext ctx) {
      float s = (float)(1.0 / Kaze.mc.getWindow().getScaleFactor());
      Matrix3x2fStack m = ctx.getMatrices();
      m.pushMatrix();
      m.scale(s, s);
      rendering3D = false;
   }

   public static void scaledProjection(DrawContext ctx) {
      ctx.getMatrices().popMatrix();
      rendering3D = true;
   }

   // ------------------------------------------------------------------ 2D shapes

   // ---- cheap rounded shapes ------------------------------------------------------------
   // Since 1.21.6 every DrawContext.fill() becomes a GuiRenderState element (allocation + layer
   // lookup). The old code drew rounded rects / circles one pixel row at a time, i.e. hundreds of
   // elements per button, which is what made the ClickGUI stutter. Corners are now built from at most
   // a handful of bands (rows with the same inset are merged into one fill).

   private static final int[] NO_ROWS = new int[0];
   private static final Map<Integer, int[]> CORNER_CACHE = new HashMap<>();

   /** Inset (in pixels) of each row of a corner, from the outer edge inwards. Trailing zero rows are dropped. */
   private static int[] cornerProfile(int radius) {
      if (radius <= 0) {
         return NO_ROWS;
      }

      int[] cached = CORNER_CACHE.get(radius);
      if (cached != null) {
         return cached;
      }

      int q = Math.max(1, radius / 4);
      int[] rows = new int[radius];
      int used = 0;
      for(int i = 0; i < radius; ++i) {
         double dy = (double)radius - ((double)i + 0.5);
         double dx = Math.sqrt(Math.max(0.0, (double)(radius * radius) - dy * dy));
         int inset = (int)Math.round(((double)radius - dx) / (double)q) * q;
         rows[i] = Math.min(radius, inset);
         if (rows[i] > 0) {
            used = i + 1;
         }
      }

      int[] out = new int[used];
      System.arraycopy(rows, 0, out, 0, used);
      CORNER_CACHE.put(radius, out);
      return out;
   }

   private static int rowInset(int[] profile, int row) {
      return row < profile.length ? profile[row] : 0;
   }

   private static void fillRounded(DrawContext ctx, int l, int t, int r, int b, int tl, int tr, int bl, int br, int argb) {
      int[] ptl = cornerProfile(tl);
      int[] ptr = cornerProfile(tr);
      int[] pbl = cornerProfile(bl);
      int[] pbr = cornerProfile(br);
      int topRows = Math.max(ptl.length, ptr.length);
      int botRows = Math.max(pbl.length, pbr.length);
      if (topRows + botRows > b - t) {
         // degenerate (tiny) rectangle: plain fill
         ctx.fill(l, t, r, b, argb);
         return;
      }

      int y = 0;
      while(y < topRows) {
         int inL = rowInset(ptl, y);
         int inR = rowInset(ptr, y);
         int y2 = y + 1;
         while(y2 < topRows && rowInset(ptl, y2) == inL && rowInset(ptr, y2) == inR) {
            ++y2;
         }

         if (l + inL < r - inR) {
            ctx.fill(l + inL, t + y, r - inR, t + y2, argb);
         }

         y = y2;
      }

      if (b - botRows > t + topRows) {
         ctx.fill(l, t + topRows, r, b - botRows, argb);
      }

      // bottom band: fromEdge = 0 is the bottom-most row
      int yy = b - botRows;
      while(yy < b) {
         int fromEdge = b - 1 - yy;
         int inL = rowInset(pbl, fromEdge);
         int inR = rowInset(pbr, fromEdge);
         int yy2 = yy + 1;
         while(yy2 < b && rowInset(pbl, b - 1 - yy2) == inL && rowInset(pbr, b - 1 - yy2) == inR) {
            ++yy2;
         }

         if (l + inL < r - inR) {
            ctx.fill(l + inL, yy, r - inR, yy2, argb);
         }

         yy = yy2;
      }
   }

   /** Radii order: top-left, top-right, bottom-left, bottom-right. */
   public static void renderRoundedQuad(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double rTL, double rTR, double rBL, double rBR, double segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) == 0) {
         return;
      }

      int l = (int)Math.round(Math.min(x1, x2));
      int r = (int)Math.round(Math.max(x1, x2));
      int t = (int)Math.round(Math.min(y1, y2));
      int b = (int)Math.round(Math.max(y1, y2));
      if (r <= l || b <= t) {
         return;
      }

      int maxR = Math.min(r - l, b - t) / 2;
      int tl = MathHelper.clamp((int)Math.round(rTL), 0, maxR);
      int tr = MathHelper.clamp((int)Math.round(rTR), 0, maxR);
      int bl = MathHelper.clamp((int)Math.round(rBL), 0, maxR);
      int br = MathHelper.clamp((int)Math.round(rBR), 0, maxR);
      fillRounded(ctx, l, t, r, b, tl, tr, bl, br, argb);
   }

   public static void renderRoundedQuad(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double radius, double segments) {
      renderRoundedQuad(ctx, color, x1, y1, x2, y2, radius, radius, radius, radius, segments);
   }

   /** Outline = 4 bars + 4 corner dots (<= 8 fills) instead of 2 fills per pixel row. */
   public static void renderRoundedOutline(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double rTL, double rTR, double rBL, double rBR, double thickness, double segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) == 0) {
         return;
      }

      int l = (int)Math.round(Math.min(x1, x2));
      int r = (int)Math.round(Math.max(x1, x2));
      int t = (int)Math.round(Math.min(y1, y2));
      int b = (int)Math.round(Math.max(y1, y2));
      int th = Math.max(1, (int)Math.round(thickness));
      if (r <= l || b <= t) {
         return;
      }

      if (r - l <= th * 2 || b - t <= th * 2) {
         ctx.fill(l, t, r, b, argb);
         return;
      }

      int maxR = Math.min(r - l, b - t) / 2;
      int tl = MathHelper.clamp((int)Math.round(rTL), 0, maxR);
      int tr = MathHelper.clamp((int)Math.round(rTR), 0, maxR);
      int bl = MathHelper.clamp((int)Math.round(rBL), 0, maxR);
      int br = MathHelper.clamp((int)Math.round(rBR), 0, maxR);
      int iTL = (int)Math.ceil((double)tl * 0.6);
      int iTR = (int)Math.ceil((double)tr * 0.6);
      int iBL = (int)Math.ceil((double)bl * 0.6);
      int iBR = (int)Math.ceil((double)br * 0.6);
      ctx.fill(l + iTL, t, r - iTR, t + th, argb);
      ctx.fill(l + iBL, b - th, r - iBR, b, argb);
      ctx.fill(l, t + iTL, l + th, b - iBL, argb);
      ctx.fill(r - th, t + iTR, r, b - iBR, argb);
      if (tl > 2) {
         int c = (int)Math.round((double)tl * 0.29);
         ctx.fill(l + c, t + c, l + c + th, t + c + th, argb);
      }

      if (tr > 2) {
         int c = (int)Math.round((double)tr * 0.29);
         ctx.fill(r - c - th, t + c, r - c, t + c + th, argb);
      }

      if (bl > 2) {
         int c = (int)Math.round((double)bl * 0.29);
         ctx.fill(l + c, b - c - th, l + c + th, b - c, argb);
      }

      if (br > 2) {
         int c = (int)Math.round((double)br * 0.29);
         ctx.fill(r - c - th, b - c - th, r - c, b - c, argb);
      }
   }

   public static void renderCircle(DrawContext ctx, Color color, double cx, double cy, double radius, int segments) {
      int argb = color.getRGB();
      if ((argb >>> 24) == 0 || radius <= 0.0) {
         return;
      }

      int l = (int)Math.round(cx - radius);
      int r = (int)Math.round(cx + radius);
      int t = (int)Math.round(cy - radius);
      int b = (int)Math.round(cy + radius);
      if (r <= l || b <= t) {
         return;
      }

      int rad = Math.min(r - l, b - t) / 2;
      fillRounded(ctx, l, t, r, b, rad, rad, rad, rad, argb);
   }

   public static void drawItem(DrawContext ctx, ItemStack stack, int x, int y, float size, int z) {
      if (!stack.isEmpty()) {
         float scale = size / 16.0F;
         Matrix3x2fStack m = ctx.getMatrices();
         m.pushMatrix();
         m.translate((float)x, (float)y);
         m.scale(scale, scale);
         ctx.drawItem(stack, 0, 0);
         m.popMatrix();
      }
   }

   // ------------------------------------------------------------------ 3D overlay

   public static Matrix4f createProjection() {
      double fov = (double)Kaze.mc.options.getFov().getValue();
      float aspect = (float)Kaze.mc.getWindow().getFramebufferWidth() / (float)Math.max(1, Kaze.mc.getWindow().getFramebufferHeight());
      return (new Matrix4f()).perspective((float)Math.toRadians(fov), aspect, NEAR, 1024.0F);
   }

   public static void begin3D(DrawContext ctx, Matrix4f projection) {
      ctx3D = ctx;
      projection3D = projection;
      fills3D = 0;
      fbWidth = Kaze.mc.getWindow().getFramebufferWidth();
      fbHeight = Kaze.mc.getWindow().getFramebufferHeight();
      float s = (float)(1.0 / Kaze.mc.getWindow().getScaleFactor());
      ctx.getMatrices().pushMatrix();
      ctx.getMatrices().scale(s, s);
   }

   public static void end3D() {
      if (ctx3D != null) {
         ctx3D.getMatrices().popMatrix();
      }

      ctx3D = null;
      projection3D = null;
   }

   private static void fill3D(int x1, int y1, int x2, int y2, int argb) {
      if (fills3D < FILL_BUDGET && x2 > x1 && y2 > y1) {
         ++fills3D;
         ctx3D.fill(x1, y1, x2, y2, argb);
      }
   }

   /**
    * The 3D overlay is projected with the FOV *option*, but vanilla renders the world with the FOV after
    * sprint/speed/bow effects and applies view bobbing. That mismatch is what makes ESP boxes slide off their
    * targets ("ghosts") while you move or turn. While an overlay module is on we therefore pin
    * "FOV Effects" to 0 and turn view bobbing off (same thing Freecam does), and restore both afterwards.
    */
   public static void syncViewLock(boolean lock) {
      try {
         if (lock) {
            if (savedFovEffect == null) {
               savedFovEffect = Kaze.mc.options.getFovEffectScale().getValue();
               Kaze.mc.options.getFovEffectScale().setValue(0.0);
            }

            if (savedBobView == null) {
               savedBobView = Kaze.mc.options.getBobView().getValue();
               Kaze.mc.options.getBobView().setValue(false);
            }
         } else {
            if (savedFovEffect != null) {
               Kaze.mc.options.getFovEffectScale().setValue(savedFovEffect);
               savedFovEffect = null;
            }

            if (savedBobView != null) {
               Kaze.mc.options.getBobView().setValue(savedBobView);
               savedBobView = null;
            }
         }
      } catch (Throwable ignored) {
      }
   }

   /** Kept for source compatibility with older modules: returns a MatrixStack positioned at the given world point. */
   public static MatrixStack matrixFrom(double x, double y, double z) {
      MatrixStack stack = new MatrixStack();
      Camera camera = getCamera();
      stack.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
      stack.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
      stack.translate(x - camera.getCameraPos().x, y - camera.getCameraPos().y, z - camera.getCameraPos().z);
      return stack;
   }

   private static Vector4f toView(Matrix4f view, double x, double y, double z) {
      return view.transform(new Vector4f((float)x, (float)y, (float)z, 1.0F));
   }

   private static double[] toScreen(Vector4f v) {
      Vector4f c = projection3D.transform(new Vector4f(v));
      if (c.w <= 0.0F) {
         return null;
      } else {
         double nx = (double)(c.x / c.w);
         double ny = (double)(c.y / c.w);
         return new double[]{(nx * 0.5 + 0.5) * (double)fbWidth, (0.5 - ny * 0.5) * (double)fbHeight};
      }
   }

   /** view-space segment -> screen segment (clips against the near plane). */
   private static void drawViewLine(Vector4f a, Vector4f b, int argb, int thickness) {
      float zn = -NEAR;
      boolean aIn = a.z < zn;
      boolean bIn = b.z < zn;
      if (aIn || bIn) {
         Vector4f pa = new Vector4f(a);
         Vector4f pb = new Vector4f(b);
         if (!aIn) {
            float t = (zn - a.z) / (b.z - a.z);
            pa.set(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, zn, 1.0F);
         } else if (!bIn) {
            float t = (zn - b.z) / (a.z - b.z);
            pb.set(b.x + (a.x - b.x) * t, b.y + (a.y - b.y) * t, zn, 1.0F);
         }

         double[] sa = toScreen(pa);
         double[] sb = toScreen(pb);
         if (sa != null && sb != null) {
            rasterLine(sa[0], sa[1], sb[0], sb[1], argb, thickness);
         }
      }
   }

   public static void renderLine(MatrixStack matrixStack, Color color, Vec3d from, Vec3d to) {
      if (ctx3D != null && projection3D != null && color.getAlpha() != 0) {
         Matrix4f view = matrixStack.peek().getPositionMatrix();
         drawViewLine(toView(view, from.x, from.y, from.z), toView(view, to.x, to.y, to.z), color.getRGB(), 2);
      }
   }

   private static final int[][] EDGES = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};

   public static void renderFilledBox(MatrixStack matrixStack, float x1, float y1, float z1, float x2, float y2, float z2, Color color) {
      if (ctx3D != null && projection3D != null && color.getAlpha() != 0) {
         Matrix4f view = matrixStack.peek().getPositionMatrix();
         Vector4f[] c = new Vector4f[]{toView(view, x1, y1, z1), toView(view, x2, y1, z1), toView(view, x2, y1, z2), toView(view, x1, y1, z2), toView(view, x1, y2, z1), toView(view, x2, y2, z1), toView(view, x2, y2, z2), toView(view, x1, y2, z2)};
         boolean anyIn = false;
         for (Vector4f v : c) {
            if (v.z < -NEAR) {
               anyIn = true;
               break;
            }
         }

         if (anyIn && isOffscreen(c)) {
            return;
         }

         if (anyIn) {
            // Fill the projected silhouette, not its axis-aligned screen rectangle.
            // The old rectangle made every 3D ESP box look like a detached ghost/shadow.
            int fill = new Color(color.getRed(), color.getGreen(), color.getBlue(),
               Math.min(255, color.getAlpha() / 2)).getRGB();
            fillProjectedBoxHull(c, fill);

            int edge = (new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.min(255, color.getAlpha() + 100))).getRGB();
            for (int[] e : EDGES) {
               drawViewLine(c[e[0]], c[e[1]], edge, 2);
            }
         }
      }
   }

   /** True when every corner is in front of the camera and the whole box projects outside the screen. */
   private static boolean isOffscreen(Vector4f[] corners) {
      double minX = Double.POSITIVE_INFINITY;
      double maxX = Double.NEGATIVE_INFINITY;
      double minY = Double.POSITIVE_INFINITY;
      double maxY = Double.NEGATIVE_INFINITY;
      for (Vector4f v : corners) {
         if (!(v.z < -NEAR)) {
            return false;
         }

         double[] p = toScreen(v);
         if (p == null) {
            return false;
         }

         minX = Math.min(minX, p[0]);
         maxX = Math.max(maxX, p[0]);
         minY = Math.min(minY, p[1]);
         maxY = Math.max(maxY, p[1]);
      }

      return maxX < 0.0 || minX > (double)fbWidth || maxY < 0.0 || minY > (double)fbHeight || maxX - minX < 1.0 && maxY - minY < 1.0;
   }

   private static void fillProjectedBoxHull(Vector4f[] corners, int argb) {
      List<double[]> points = new ArrayList<>();
      for (Vector4f v : corners) {
         if (v.z < -NEAR) {
            double[] p = toScreen(v);
            if (p != null) points.add(p);
         }
      }
      // Add intersections for edges crossing the near plane so boxes partly behind the camera clip cleanly.
      for (int[] edge : EDGES) {
         Vector4f a = corners[edge[0]], b = corners[edge[1]];
         boolean aIn = a.z < -NEAR, bIn = b.z < -NEAR;
         if (aIn != bIn) {
            float t = (-NEAR - a.z) / (b.z - a.z);
            Vector4f cut = new Vector4f(a.x + (b.x - a.x) * t,
               a.y + (b.y - a.y) * t, -NEAR, 1.0F);
            double[] p = toScreen(cut);
            if (p != null) points.add(p);
         }
      }
      if (points.size() < 3) return;

      points.sort(Comparator.comparingDouble((double[] p) -> p[0]).thenComparingDouble(p -> p[1]));
      List<double[]> hull = new ArrayList<>();
      for (double[] p : points) {
         while (hull.size() >= 2 && cross(hull.get(hull.size()-2), hull.get(hull.size()-1), p) <= 0) hull.remove(hull.size()-1);
         hull.add(p);
      }
      int lower = hull.size();
      for (int i = points.size() - 2; i >= 0; --i) {
         double[] p = points.get(i);
         while (hull.size() > lower && cross(hull.get(hull.size()-2), hull.get(hull.size()-1), p) <= 0) hull.remove(hull.size()-1);
         hull.add(p);
      }
      if (hull.size() < 4) return;
      hull.remove(hull.size()-1);

      int minY = Math.max(0, (int)Math.floor(hull.stream().mapToDouble(p -> p[1]).min().orElse(0)));
      int maxY = Math.min(fbHeight, (int)Math.ceil(hull.stream().mapToDouble(p -> p[1]).max().orElse(0)));
      int step = Math.max(1, (maxY - minY + MAX_HULL_BANDS - 1) / MAX_HULL_BANDS);
      for (int y = minY; y < maxY; y += step) {
         int y2 = Math.min(maxY, y + step);
         double scanY = (double)y + (double)(y2 - y) * 0.5;
         double minX = Double.POSITIVE_INFINITY, maxX = Double.NEGATIVE_INFINITY;
         for (int i = 0; i < hull.size(); ++i) {
            double[] a = hull.get(i), b = hull.get((i + 1) % hull.size());
            if ((a[1] <= scanY && b[1] > scanY) || (b[1] <= scanY && a[1] > scanY)) {
               double x = a[0] + (scanY - a[1]) * (b[0] - a[0]) / (b[1] - a[1]);
               minX = Math.min(minX, x); maxX = Math.max(maxX, x);
            }
         }
         if (Double.isFinite(minX) && Double.isFinite(maxX)) {
            int x1 = Math.max(0, (int)Math.floor(minX));
            int x2 = Math.min(fbWidth, (int)Math.ceil(maxX));
            if (x2 > x1) fill3D(x1, y, x2, y2, argb);
         }
      }
   }

   private static double cross(double[] o, double[] a, double[] b) {
      return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
   }

   /** Run-length rasteriser: number of fill() calls is bounded by the shorter axis of the segment. */
   private static void rasterLine(double x0, double y0, double x1, double y1, int argb, int th) {
      // clip to the framebuffer (Liang-Barsky) so huge off-screen segments cost nothing
      double dx = x1 - x0;
      double dy = y1 - y0;
      double t0 = 0.0;
      double t1 = 1.0;
      double[] p = new double[]{-dx, dx, -dy, dy};
      double[] q = new double[]{x0, (double)fbWidth - x0, y0, (double)fbHeight - y0};

      for(int i = 0; i < 4; ++i) {
         if (p[i] == 0.0) {
            if (q[i] < 0.0) {
               return;
            }
         } else {
            double t = q[i] / p[i];
            if (p[i] < 0.0) {
               if (t > t1) {
                  return;
               }

               if (t > t0) {
                  t0 = t;
               }
            } else {
               if (t < t0) {
                  return;
               }

               if (t < t1) {
                  t1 = t;
               }
            }
         }
      }

      double ax = x0 + t0 * dx;
      double ay = y0 + t0 * dy;
      double bx = x0 + t1 * dx;
      double by = y0 + t1 * dy;
      double ddx = bx - ax;
      double ddy = by - ay;
      if (Math.abs(ddx) >= Math.abs(ddy)) {
         double ymin = Math.min(ay, by);
         double ymax = Math.max(ay, by);
         int r0 = (int)Math.floor(ymin);
         int r1 = (int)Math.floor(ymax);
         int step = Math.max(1, (r1 - r0 + MAX_LINE_CHUNKS) / MAX_LINE_CHUNKS);

         for(int row = r0; row <= r1; row += step) {
            int rowEnd = Math.min(r1, row + step - 1);
            double ya = Math.max(ymin, (double)row);
            double yb = Math.min(ymax, (double)(rowEnd + 1));
            double xa;
            double xb;
            if (ddy == 0.0) {
               xa = ax;
               xb = bx;
            } else {
               xa = ax + (ya - ay) * ddx / ddy;
               xb = ax + (yb - ay) * ddx / ddy;
            }

            fill3D((int)Math.floor(Math.min(xa, xb)), row, (int)Math.floor(Math.max(xa, xb)) + th, rowEnd + th, argb);
         }
      } else {
         double xmin = Math.min(ax, bx);
         double xmax = Math.max(ax, bx);
         int c0 = (int)Math.floor(xmin);
         int c1 = (int)Math.floor(xmax);
         int step = Math.max(1, (c1 - c0 + MAX_LINE_CHUNKS) / MAX_LINE_CHUNKS);

         for(int col = c0; col <= c1; col += step) {
            int colEnd = Math.min(c1, col + step - 1);
            double xa = Math.max(xmin, (double)col);
            double xb = Math.min(xmax, (double)(colEnd + 1));
            double ya;
            double yb;
            if (ddx == 0.0) {
               ya = ay;
               yb = by;
            } else {
               ya = ay + (xa - ax) * ddy / ddx;
               yb = ay + (xb - ax) * ddy / ddx;
            }

            fill3D(col, (int)Math.floor(Math.min(ya, yb)), colEnd + th, (int)Math.floor(Math.max(ya, yb)) + th, argb);
         }
      }

   }
}
