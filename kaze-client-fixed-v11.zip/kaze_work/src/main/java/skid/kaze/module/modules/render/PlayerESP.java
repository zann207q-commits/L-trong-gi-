package skid.kaze.module.modules.render;

import java.awt.Color;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;
import skid.kaze.utils.Utils;

public final class PlayerESP extends Module {
   private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), (double)0.0F, (double)255.0F, (double)100.0F, (double)1.0F);
   private final NumberSetting lineWidth = new NumberSetting(EncryptedString.of("Line width"), (double)1.0F, (double)10.0F, (double)1.0F, (double)1.0F);
   private final BooleanSetting tracers = (new BooleanSetting(EncryptedString.of("Tracers"), false)).setDescription(EncryptedString.of("Draws a line from your player to the other"));

   public PlayerESP() {
      super(EncryptedString.of("Player ESP"), EncryptedString.of("Renders players through walls"), -1, Category.RENDER);
      this.addSettings(new Setting[]{this.alpha, this.lineWidth, this.tracers});
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (this.mc.world != null && this.mc.player != null) {
         Camera camera = RenderUtils.getCamera();
         if (camera != null) {
            MatrixStack ms = event.matrixStack;
            Vec3d cam = RenderUtils.getCameraPos();
            ms.push();
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
            ms.translate(-cam.x, -cam.y, -cam.z);
            Vec3d tracerStart = cam.add(Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(2.0));
            Color fill = Utils.getMainColor(this.alpha.getIntValue(), 1).brighter();

            for(PlayerEntity p : this.mc.world.getPlayers()) {
               if (p != this.mc.player) {
                  Vec3d lerped = p.getLerpedPos(event.tickDelta);
                  double x = lerped.x;
                  double y = lerped.y;
                  double z = lerped.z;
                  float hw = p.getWidth() / 2.0F;
                  RenderUtils.renderFilledBox(ms, (float)x - hw, (float)y, (float)z - hw, (float)x + hw, (float)y + p.getHeight(), (float)z + hw, fill);
                  if (this.tracers.getValue()) {
                     RenderUtils.renderLine(ms, Utils.getMainColor(255, 1), tracerStart, new Vec3d(x, y + (double)(p.getHeight() / 2.0F), z));
                  }
               }
            }

            ms.pop();
         }
      }
   }
}
