package skid.kaze.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.client.gui.screen.ChatScreen;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.KeyEvent;
import skid.kaze.module.modules.client.Kaze;
import skid.kaze.module.modules.client.SelfDestruct;
import skid.kaze.module.modules.combat.AnchorMacro;
import skid.kaze.module.modules.combat.AutoCrystal;
import skid.kaze.module.modules.combat.AutoInventoryTotem;
import skid.kaze.module.modules.combat.AutoTotem;
import skid.kaze.module.modules.combat.DoubleAnchor;
import skid.kaze.module.modules.combat.ElytraSwap;
import skid.kaze.module.modules.combat.Hitbox;
import skid.kaze.module.modules.combat.HoverTotem;
import skid.kaze.module.modules.combat.MaceSwap;
import skid.kaze.module.modules.combat.NoHitDelay;
import skid.kaze.module.modules.combat.StaticHitboxes;
import skid.kaze.module.modules.donut.AntiTrap;
import skid.kaze.module.modules.donut.AuctionSniper;
import skid.kaze.module.modules.donut.AutoSell;
import skid.kaze.module.modules.donut.AutoSpawnerSell;
import skid.kaze.module.modules.donut.BoneDropper;
import skid.kaze.module.modules.donut.RtpBaseFinder;
import skid.kaze.module.modules.donut.ShulkerDropper;
import skid.kaze.module.modules.donut.TunnelBaseFinder;
import skid.kaze.module.modules.misc.AutoEat;
import skid.kaze.module.modules.misc.AutoFirework;
import skid.kaze.module.modules.misc.AutoLog;
import skid.kaze.module.modules.misc.AutoMine;
import skid.kaze.module.modules.misc.AutoTPA;
import skid.kaze.module.modules.misc.AutoTool;
import skid.kaze.module.modules.misc.CordSnapper;
import skid.kaze.module.modules.misc.ElytraGlide;
import skid.kaze.module.modules.misc.FastPlace;
import skid.kaze.module.modules.misc.Freecam;
import skid.kaze.module.modules.misc.KeyPearl;
import skid.kaze.module.modules.misc.NameProtect;
import skid.kaze.module.modules.misc.PositionPacketFilter;
import skid.kaze.module.modules.render.ChunkFinder;
import skid.kaze.module.modules.render.HUD;
import skid.kaze.module.modules.render.PlayerESP;
import skid.kaze.module.modules.render.ScoreboardModule;
import skid.kaze.module.modules.render.StorageESP;
import skid.kaze.module.modules.render.TargetHUD;
import skid.kaze.module.setting.BindSetting;
import skid.kaze.utils.EncryptedString;

public final class ModuleManager {
   private final List<Module> modules = new ArrayList();

   public ModuleManager() {
      this.a();
      this.d();
   }

   public void a() {
      this.a((Module)(new ElytraSwap()));
      this.a((Module)(new MaceSwap()));
      this.a((Module)(new Hitbox()));
      this.a((Module)(new StaticHitboxes()));
      this.a((Module)(new AutoTotem()));
      this.a((Module)(new HoverTotem()));
      this.a((Module)(new AutoInventoryTotem()));
      this.a((Module)(new AnchorMacro()));
      this.a((Module)(new AutoCrystal()));
      this.a((Module)(new DoubleAnchor()));
      this.a((Module)(new FastPlace()));
      this.a((Module)(new Freecam()));
      this.a((Module)(new AutoFirework()));
      this.a((Module)(new ElytraGlide()));
      this.a((Module)(new AutoTool()));
      this.a((Module)(new AutoEat()));
      this.a((Module)(new AutoLog()));
      this.a((Module)(new NoHitDelay()));
      this.a((Module)(new AutoMine()));
      this.a((Module)(new CordSnapper()));
      this.a((Module)(new KeyPearl()));
      this.a((Module)(new NameProtect()));
      this.a((Module)(new AutoTPA()));
      this.a((Module)(new RtpBaseFinder()));
      this.a((Module)(new TunnelBaseFinder()));
      this.a((Module)(new BoneDropper()));
      this.a((Module)(new AutoSell()));
      this.a((Module)(new ShulkerDropper()));
      this.a((Module)(new AntiTrap()));
      this.a((Module)(new AuctionSniper()));
      this.a((Module)(new AutoSpawnerSell()));
      this.a((Module)(new HUD()));
      this.a((Module)(new ChunkFinder()));
      this.a((Module)(new PositionPacketFilter()));
      this.a((Module)(new ScoreboardModule()));
      this.a((Module)(new PlayerESP()));
      this.a((Module)(new StorageESP()));
      this.a((Module)(new TargetHUD()));
      this.a((Module)(new Kaze()));
      this.a((Module)(new SelfDestruct()));
   }

   public List<Module> b() {
      return this.modules.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> c() {
      return this.modules;
   }

   public void d() {
      skid.kaze.Kaze.INSTANCE.getEventBus().register(this);

      for(Module next : this.modules) {
         next.addSetting((new BindSetting(EncryptedString.of("Keybind"), next.getKeybind(), true)).setDescription(EncryptedString.of("Key to enabled the module")));
      }

   }

   public List<Module> a(Category category) {
      return this.modules.stream().filter((module) -> module.getCategory() == category).toList();
   }

   public Module getModuleByClass(Class<? extends Module> obj) {
      Objects.requireNonNull(obj);
      Stream var10000 = this.modules.stream();
      Objects.requireNonNull(obj);
      return (Module)var10000.filter(obj::isInstance).findFirst().orElse((Object)null);
   }

   public void a(Module module) {
      skid.kaze.Kaze.INSTANCE.getEventBus().register(module);
      this.modules.add(module);
   }

   @EventListener
   public void a(KeyEvent keyEvent) {
      if (skid.kaze.Kaze.mc.player != null && !(skid.kaze.Kaze.mc.currentScreen instanceof ChatScreen)) {
         if (!SelfDestruct.isActive) {
            this.modules.forEach((module) -> {
               if (module.getKeybind() == keyEvent.key && keyEvent.mode == 1) {
                  module.toggle();
               }

            });
         }

      }
   }
}
