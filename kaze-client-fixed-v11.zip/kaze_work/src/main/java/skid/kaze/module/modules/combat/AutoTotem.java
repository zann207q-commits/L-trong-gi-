package skid.kaze.module.modules.combat;

import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import skid.kaze.Kaze;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.modules.donut.RtpBaseFinder;
import skid.kaze.module.modules.donut.TunnelBaseFinder;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;

public final class AutoTotem extends Module {
   private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), (double)0.0F, (double)5.0F, (double)1.0F, (double)1.0F);
   private int delayCounter;

   public AutoTotem() {
      super(EncryptedString.of("Auto Totem"), EncryptedString.of("Automatically holds totem in your off hand"), -1, Category.COMBAT);
      this.addSettings(new Setting[]{this.delay});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.player != null) {
         Module rtpBaseFinder = Kaze.INSTANCE.MODULE_MANAGER.getModuleByClass(RtpBaseFinder.class);
         if (!rtpBaseFinder.isEnabled() || !((RtpBaseFinder)rtpBaseFinder).isRepairingActive()) {
            Module tunnelBaseFinder = Kaze.INSTANCE.MODULE_MANAGER.getModuleByClass(TunnelBaseFinder.class);
            if (!tunnelBaseFinder.isEnabled() || !((TunnelBaseFinder)tunnelBaseFinder).isDigging()) {
               if (this.mc.player.getInventory().getStack(40).getItem() == Items.TOTEM_OF_UNDYING) {
                  this.delayCounter = this.delay.getIntValue();
               } else if (this.delayCounter > 0) {
                  --this.delayCounter;
               } else {
                  int slot = this.findItemSlot(Items.TOTEM_OF_UNDYING);
                  if (slot != -1) {
                     this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, convertSlotIndex(slot), 40, SlotActionType.SWAP, this.mc.player);
                     this.delayCounter = this.delay.getIntValue();
                  }
               }
            }
         }
      }
   }

   public int findItemSlot(Item item) {
      if (this.mc.player == null) {
         return -1;
      } else {
         for(int i = 0; i < 36; ++i) {
            if (this.mc.player.getInventory().getStack(i).isOf(item)) {
               return i;
            }
         }

         return -1;
      }
   }

   private static int convertSlotIndex(int slotIndex) {
      return slotIndex < 9 ? 36 + slotIndex : slotIndex;
   }
}
