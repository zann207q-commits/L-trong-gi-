package skid.kaze.module.modules.client;

import java.util.Random;
import java.util.concurrent.CompletableFuture;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.PacketReceiveEvent;
import skid.kaze.gui.ClickGUI;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.ModeSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;

public final class Kaze extends Module {
   public static final NumberSetting redColor = new NumberSetting(EncryptedString.of("Red"), (double)0.0F, (double)255.0F, (double)120.0F, (double)1.0F);
   public static final NumberSetting greenColor = new NumberSetting(EncryptedString.of("Green"), (double)0.0F, (double)255.0F, (double)190.0F, (double)1.0F);
   public static final NumberSetting blueColor = new NumberSetting(EncryptedString.of("Blue"), (double)0.0F, (double)255.0F, (double)255.0F, (double)1.0F);
   public static final NumberSetting windowAlpha = new NumberSetting(EncryptedString.of("Window Alpha"), (double)0.0F, (double)255.0F, (double)170.0F, (double)1.0F);
   public static final BooleanSetting enableBreathingEffect = (new BooleanSetting(EncryptedString.of("Breathing"), false)).setDescription(EncryptedString.of("Color breathing effect (only with rainbow off)"));
   public static final BooleanSetting enableRainbowEffect = (new BooleanSetting(EncryptedString.of("Rainbow"), false)).setDescription(EncryptedString.of("Enables LGBTQ mode"));
   public static final BooleanSetting renderBackground = (new BooleanSetting(EncryptedString.of("Background"), true)).setDescription(EncryptedString.of("Renders the background of the Click Gui"));
   public static final BooleanSetting useCustomFont = new BooleanSetting(EncryptedString.of("Custom Font"), true);
   private final BooleanSetting preventClose = (new BooleanSetting(EncryptedString.of("Prevent Close"), true)).setDescription(EncryptedString.of("For servers with freeze plugins that don't let you open the GUI"));
   public static final NumberSetting cornerRoundness = new NumberSetting(EncryptedString.of("Roundness"), (double)1.0F, (double)10.0F, (double)5.0F, (double)1.0F);
   public static final ModeSetting<AnimationMode> animationMode;
   public static final BooleanSetting enableMSAA;
   public boolean shouldPreventClose;

   public Kaze() {
      super(EncryptedString.of("Kaze"), EncryptedString.of("Settings for the client"), 344, Category.CLIENT);
      this.addSettings(new Setting[]{redColor, greenColor, blueColor, windowAlpha, renderBackground, this.preventClose, cornerRoundness, animationMode, enableMSAA});
   }

   public void onEnable() {
      skid.kaze.Kaze.INSTANCE.screen = this.mc.currentScreen;
      if (skid.kaze.Kaze.INSTANCE.GUI != null) {
         this.mc.setScreen(skid.kaze.Kaze.INSTANCE.GUI);
      } else if (this.mc.currentScreen instanceof InventoryScreen) {
         this.shouldPreventClose = true;
      }

      if ((new Random()).nextInt(3) == 1) {
         CompletableFuture.runAsync(() -> {
         });
      }

      super.onEnable();
   }

   public void onDisable() {
      if (this.mc.currentScreen instanceof ClickGUI) {
         skid.kaze.Kaze.INSTANCE.GUI.close();
         this.mc.setScreen(skid.kaze.Kaze.INSTANCE.screen);
         skid.kaze.Kaze.INSTANCE.GUI.onGuiClose();
      } else if (this.mc.currentScreen instanceof InventoryScreen) {
         this.shouldPreventClose = false;
      }

      super.onDisable();
   }

   @EventListener
   public void onPacketReceive(PacketReceiveEvent packetReceiveEvent) {
      if (this.shouldPreventClose && packetReceiveEvent.packet instanceof OpenScreenS2CPacket && this.preventClose.getValue()) {
         packetReceiveEvent.cancel();
      }

   }

   static {
      animationMode = new ModeSetting<AnimationMode>(EncryptedString.of("Animations"), Kaze.AnimationMode.NORMAL, AnimationMode.class);
      enableMSAA = (new BooleanSetting(EncryptedString.of("MSAA"), true)).setDescription(EncryptedString.of("Anti Aliasing | This can impact performance if you're using tracers but gives them a smoother look |"));
   }

   public static enum AnimationMode {
      NORMAL("Normal", 0),
      POSITIVE("Positive", 1),
      OFF("Off", 2);

      private AnimationMode(final String name, final int ordinal) {
      }

      // $FF: synthetic method
      private static AnimationMode[] $values() {
         return new AnimationMode[]{NORMAL, POSITIVE, OFF};
      }
   }
}
