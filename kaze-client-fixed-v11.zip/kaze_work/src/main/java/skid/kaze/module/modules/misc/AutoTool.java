package skid.kaze.module.modules.misc;

import java.util.function.Predicate;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.block.BambooBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.BlockState;
import net.minecraft.registry.tag.BlockTags;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.AttackBlockEvent;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.InventoryUtil;

public final class AutoTool extends Module {
   private final BooleanSetting antiBreak = new BooleanSetting(EncryptedString.of("Anti Break"), true);
   private final NumberSetting antiBreakPercentage = new NumberSetting(EncryptedString.of("Anti Break Percentage"), (double)1.0F, (double)100.0F, (double)5.0F, (double)1.0F);
   private boolean isToolSwapping;
   private int keybindCounter;
   private int selectedToolSlot;

   public AutoTool() {
      super(EncryptedString.of("Auto Tool"), EncryptedString.of("Module that automatically switches to best tool"), -1, Category.MISC);
      this.addSettings(new Setting[]{this.antiBreak, this.antiBreakPercentage});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.keybindCounter <= 0 && this.isToolSwapping && this.selectedToolSlot != -1) {
         InventoryUtil.swap(this.selectedToolSlot);
         this.isToolSwapping = false;
      } else {
         --this.keybindCounter;
      }

   }

   @EventListener
   public void handleAttackBlockEvent(AttackBlockEvent attackBlockEvent) {
      BlockState getBlockState = this.mc.world.getBlockState(attackBlockEvent.pos);
      ItemStack getBlockEntity = this.mc.player.getMainHandStack();
      double n = (double)-1.0F;
      this.selectedToolSlot = -1;

      for(int i = 0; i < 9; ++i) {
         double a = calculateToolEfficiency(this.mc.player.getInventory().getStack(i), getBlockState, (itemStack) -> !this.isToolBreakingSoon(itemStack));
         if (a >= (double)0.0F && a > n) {
            this.selectedToolSlot = i;
            n = a;
         }
      }

      if (this.selectedToolSlot != -1 && n > calculateToolEfficiency(getBlockEntity, getBlockState, (itemStack2) -> !this.isToolBreakingSoon(itemStack2)) || this.isToolBreakingSoon(getBlockEntity) || !isToolItemStack(getBlockEntity)) {
         InventoryUtil.swap(this.selectedToolSlot);
      }

      ItemStack heldStack = this.mc.player.getMainHandStack();
      if (this.isToolBreakingSoon(heldStack) && isToolItemStack(heldStack)) {
         this.mc.options.attackKey.setPressed(false);
         attackBlockEvent.cancel();
      }

   }

   public static double calculateToolEfficiency(ItemStack itemStack, BlockState blockState, Predicate<ItemStack> predicate) {
      if (predicate.test(itemStack) && isToolItemStack(itemStack)) {
         return !itemStack.isSuitableFor(blockState) && (!itemStack.isIn(ItemTags.SWORDS) || !(blockState.getBlock() instanceof BambooBlock)) && (!itemStack.isOf(Items.SHEARS) || !(blockState.getBlock() instanceof LeavesBlock)) && !blockState.isIn(BlockTags.WOOL) ? (double)-1.0F : (double)0.0F + (double)(itemStack.getMiningSpeedMultiplier(blockState) * 1000.0F);
      } else {
         return (double)-1.0F;
      }
   }

   public static boolean isToolItemStack(ItemStack itemStack) {
      return itemStack.contains(DataComponentTypes.TOOL);
   }

   public static boolean isToolItem(Item item) {
      return isToolItemStack(item.getDefaultStack());
   }

   private boolean isToolBreakingSoon(ItemStack itemStack) {
      return this.antiBreak.getValue() && itemStack.getMaxDamage() - itemStack.getDamage() < itemStack.getMaxDamage() * this.antiBreakPercentage.getIntValue() / 100;
   }
}
