package skid.kaze.module.modules.misc;

import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.Setting;
import skid.kaze.module.setting.StringSetting;
import skid.kaze.utils.EncryptedString;

public class NameProtect extends Module {
   private final StringSetting fakeName = new StringSetting("Fake Name", "Player");

   public NameProtect() {
      super(EncryptedString.of("Name Protect"), EncryptedString.of("Replaces your name with given one."), -1, Category.MISC);
      this.addSettings(new Setting[]{this.fakeName});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   public String getFakeName() {
      return this.fakeName.getValue();
   }
}
