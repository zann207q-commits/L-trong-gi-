// Language: Java 21
// File: ACCollectorModule.java (V9 — drop-in thay V8)
// Runtime: Fabric 1.21.11 / Meteor 0.5.9-SNAPSHOT
//
// V9 THÊM SO VỚI V8:
//  KB_TIMING       — đo thời gian từ EntityVelocityUpdate đến PlayerMove tiếp theo
//                    → tìm velocity accept window của server
//  SETBACK_TRACK   — phát hiện PlayerPositionLook S→C sau movement (rubber-band)
//                    → đo tần suất + pattern setback
//  GCD_ROTATION    — đo GCD của yaw delta để fingerprint rotation check algorithm
//                    → output: gcd_yaw, gcd_pitch, samples → bypass advice
//  Snapshot thêm:  kb_timing{}, setback{}, rotation_gcd{}
//  ClientSession:  thêm 3 state block tương ứng

package dev.ollie.modules;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.ServerConnectBeginEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.s2c.common.CustomPayloadS2CPacket;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket;
import net.minecraft.util.math.Vec3d;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class ACCollectorModule extends Module {

    // ── Settings ──────────────────────────────────────────────────────────────
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> autoStart = sg.add(
        new BoolSetting.Builder()
            .name("auto-start")
            .description("Tự bắt đầu thu thập khi vào world")
            .defaultValue(true).build()
    );
    private final Setting<Double> speedThreshold = sg.add(
        new DoubleSetting.Builder()
            .name("speed-threshold")
            .description("Ngưỡng block/tick để flag SPEED (vanilla sprint = ~0.28 bpt)")
            .defaultValue(0.55).min(0.1).sliderMax(2.0).build()
    );
    private final Setting<Integer> attackMsThreshold = sg.add(
        new IntSetting.Builder()
            .name("attack-ms-threshold")
            .description("Dưới X ms giữa 2 attack = flag KILL_AURA")
            .defaultValue(100).min(50).sliderMax(500).build()
    );
    private final Setting<Boolean> logAllPackets = sg.add(
        new BoolSetting.Builder()
            .name("log-all-packets")
            .description("Log mọi packet vào file")
            .defaultValue(false).build()
    );

    // ── State ─────────────────────────────────────────────────────────────────
    private volatile ClientSession session = null;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private final long[] surroundTs  = new long[8];
    private final int[]  surroundX   = new int[8];
    private final int[]  surroundZ   = new int[8];
    private int          surroundHead = 0;

    private static final Path EXPORT_ROOT;
    static {
        Path root;
        String os = System.getProperty("os.name","").toLowerCase();
        if (os.contains("win")) {
            String appdata = System.getenv("APPDATA");
            if (appdata == null) appdata = System.getProperty("user.home",".");
            root = Path.of(appdata,".minecraft","acv9_export");
        } else if (os.contains("mac")) {
            root = Path.of(System.getProperty("user.home","."),
                "Library","Application Support","minecraft","acv9_export");
        } else {
            root = Path.of(System.getProperty("user.home",".")
                ,".minecraft","acv9_export");
        }
        EXPORT_ROOT = root;
    }

    public ACCollectorModule() {
        super(dev.ollie.ACAddon.CATEGORY, "ACCollector",
            "Thu thập dữ liệu AC từ server. /pen để export.");
    }

    private static double rawVel(double bpt) {
        return (short) Math.max(-32768, Math.min(32767, Math.round(bpt * 8000.0)));
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override public void onActivate() { startSession(); }
    @Override public void onDeactivate() {
        ClientSession s = session; session = null;
        if (s != null) dumpReportAsync(s);
    }

    @EventHandler
    private void onConnect(ServerConnectBeginEvent event) {
        if (autoStart.get() && isActive()) startSession();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKET C→S
    // ══════════════════════════════════════════════════════════════════════════
    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        ClientSession s = session;
        if (s == null) return;
        s.totalPackets.incrementAndGet();
        s.tickRate();

        var pkt = event.packet;

        if (pkt instanceof PlayerMoveC2SPacket move) {
            if (move.changesPosition()) {
                s.moveCount.incrementAndGet();
                handleMovement(s,
                    move.getX(s.lastX), move.getY(s.lastY), move.getZ(s.lastZ),
                    move.getYaw(s.lastYaw), move.getPitch(s.lastPitch),
                    move.isOnGround());
            }
            if (move.changesLook())
                handleRotation(s, move.getYaw(s.lastYaw), move.getPitch(s.lastPitch));
        }

        else if (pkt instanceof TeleportConfirmC2SPacket tp) {
            long now = System.currentTimeMillis();
            if (s.pendingTeleportId != -1 && tp.getTeleportId() != s.pendingTeleportId) {
                s.teleportBypassCount.incrementAndGet();
                s.flag("TELEPORT_MISMATCH",
                    "expected=" + s.pendingTeleportId + " got=" + tp.getTeleportId());
            }
            long latency = s.pendingTeleportSentMs > 0 ? now - s.pendingTeleportSentMs : 0;
            s.pendingTeleportId = -1;
            s.log("TP_CONFIRM", "id=" + tp.getTeleportId() + " latencyMs=" + latency);
        }

        else if (pkt instanceof PlayerActionC2SPacket dig) {
            s.digCount.incrementAndGet();
            long now = System.currentTimeMillis();
            long delta = s.lastDigTime == 0 ? 0 : now - s.lastDigTime;
            if (dig.getAction() == PlayerActionC2SPacket.Action.START_DESTROY_BLOCK) {
                if (delta > 0) {
                    s.digDeltas.offer(delta);
                    if (delta < 50) s.flag("INSTANT_MINE","delta="+delta+"ms pos="+dig.getPos());
                }
                s.lastDigTime = now;
            }
        }

        else if (pkt instanceof PlayerInteractBlockC2SPacket place) {
            s.placeCount.incrementAndGet();
            long now = System.currentTimeMillis();
            long delta = s.lastPlaceTime == 0 ? 0 : now - s.lastPlaceTime;
            int bx=place.getBlockHitResult().getBlockPos().getX();
            int by=place.getBlockHitResult().getBlockPos().getY();
            int bz=place.getBlockHitResult().getBlockPos().getZ();
            if (delta > 0) {
                s.placeDeltas.offer(delta);
                if (delta < 50) s.flag("RAPID_PLACE","gap="+delta+"ms pos=("+bx+","+by+","+bz+")");
            }
            s.lastPlaceTime = now;
            var mc = MinecraftClient.getInstance();
            if (mc.player != null) {
                double py = mc.player.getY();
                if (by == (int)(py - 1) && s.moveCount.get() > 0
                        && now - lastMoveTimeForScaffold < 100) {
                    s.scaffoldCount.incrementAndGet();
                    if (s.scaffoldCount.get() % 5 == 1)
                        s.flag("SCAFFOLD","count="+s.scaffoldCount.get()+" pos=("+bx+","+by+","+bz+")");
                }
            }
            surroundTs[surroundHead]=now; surroundX[surroundHead]=bx;
            surroundZ[surroundHead]=bz; surroundHead=(surroundHead+1)%8;
            checkSurround(s, now, bx, bz);
        }

        else if (pkt instanceof PlayerInteractEntityC2SPacket attack) {
            int[] ia = PktUtil.readInteract(attack);
            int attackEntityId = ia == null ? -1 : ia[0];
            if (ia != null && ia[1] == 1) {
                s.attackCount.incrementAndGet();
                long now = System.currentTimeMillis();
                long delta = s.lastAttackTime == 0 ? 0 : now - s.lastAttackTime;
                if (delta > 0) {
                    s.attackDeltas.offer(delta);
                    if (delta < attackMsThreshold.get())
                        s.flag("KILL_AURA","delta="+delta+"ms entityId="+attackEntityId);
                }
                s.lastAttackTime = now;
                long sinceSwing = now - s.lastSwingTime;
                if (sinceSwing > 300 && s.swingCount.get() > 5)
                    s.flag("NO_SWING","sinceSwing="+sinceSwing+"ms entityId="+attackEntityId);
            }
        }

        else if (pkt instanceof HandSwingC2SPacket swing) {
            s.swingCount.incrementAndGet();
            s.lastSwingTime = System.currentTimeMillis();
        }

        else if (pkt instanceof PlayerInteractItemC2SPacket itemUse) {
            long now = System.currentTimeMillis();
            long delta = s.lastItemUseTime == 0 ? 0 : now - s.lastItemUseTime;
            if (delta > 0 && delta < 20) {
                s.itemUseDeltas.offer(delta);
                s.flag("FAST_USE","delta="+delta+"ms hand="+itemUse.getHand());
            }
            s.lastItemUseTime = now;
        }

        else if (pkt instanceof UpdateSelectedSlotC2SPacket slot) {
            long now = System.currentTimeMillis();
            long delta = s.lastSlotTime == 0 ? 0 : now - s.lastSlotTime;
            if (delta > 0 && delta < 20)
                s.flag("AUTO_TOOL","slotChange delta="+delta+"ms slot="+slot.getSelectedSlot());
            s.lastSlotTime = now;
        }

        else if (pkt instanceof ClickSlotC2SPacket click) {
            int slot = click.slot();
            if (slot >= 5 && slot <= 8) {
                long now = System.currentTimeMillis();
                long delta = s.lastSlotTime == 0 ? 0 : now - s.lastSlotTime;
                if (delta > 0 && delta < 50)
                    s.flag("AUTO_ARMOR","armorSlot="+slot+" delta="+delta+"ms");
                s.lastSlotTime = now;
            }
        }

        else if (pkt instanceof KeepAliveC2SPacket ka) {
            long now = System.currentTimeMillis();
            if (s.lastKeepAliveSentMs > 0 && PktUtil.firstLong(ka,-1) == s.lastKeepAliveId) {
                long ping = now - s.lastKeepAliveSentMs;
                s.pingSamples.offer(ping);
            }
        }

        else if (pkt instanceof ChatMessageC2SPacket chat) {
            s.log("CHAT", ClientSession.sanitize(chat.chatMessage()));
        }

        else if (pkt instanceof CommandExecutionC2SPacket cmd) {
            s.log("CMD", "/" + ClientSession.sanitize(cmd.command()));
        }

        else if (pkt instanceof CustomPayloadC2SPacket custom) {
            String channel = custom.payload().getId().id().toString();
            String key = "C→S/CUSTOM/" + channel;
            s.unknownPackets.computeIfAbsent(key, k -> new ClientSession.PktStat()).record(0);
        }

        else {
            String name = pkt.getClass().getSimpleName();
            s.unknownPackets.computeIfAbsent("C→S/"+name,
                k -> new ClientSession.PktStat()).record(0);
            s.rawPktCount.incrementAndGet();
            if (logAllPackets.get()) s.log("RAW_C→S","type="+name);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKET S→C
    // ══════════════════════════════════════════════════════════════════════════
    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        ClientSession s = session;
        if (s == null) return;
        var pkt = event.packet;

        if (pkt instanceof KeepAliveS2CPacket ka) {
            s.lastKeepAliveSentMs = System.currentTimeMillis();
            s.lastKeepAliveId = PktUtil.firstLong(ka, -1);
        }

        else if (pkt instanceof EntityVelocityUpdateS2CPacket vel) {
            var mc = MinecraftClient.getInstance();
            if (mc.player != null && PktUtil.firstInt(vel, -1) == mc.player.getId()) {
                Vec3d v = PktUtil.vec(vel);
                double vx = v == null ? 0 : rawVel(v.x) / 8000.0;
                double vy = v == null ? 0 : rawVel(v.y) / 8000.0;
                double vz = v == null ? 0 : rawVel(v.z) / 8000.0;
                s.pendingVelocity = new ClientSession.PendingVelocity(vx, vy, vz,
                    System.currentTimeMillis());

                // V9: KB_TIMING — record timestamp of velocity packet
                // The next movement packet will compute acceptWindowMs
                s.pendingKbReceivedMs = System.currentTimeMillis();
                s.pendingKbMag = Math.sqrt(vx*vx + vz*vz);
                s.log("S→C_VEL", String.format("vx=%.4f vy=%.4f vz=%.4f hMag=%.4f",
                    vx, vy, vz, s.pendingKbMag));
            }
        }

        // V9: SETBACK_TRACK — PlayerPositionLookS2CPacket là server setback/rubber-band
        else if (pkt instanceof PlayerPositionLookS2CPacket pos) {
            int tpId = PktUtil.firstInt(pos, 0);
            Vec3d tpPos = PktUtil.vec(pos);
            long now = System.currentTimeMillis();

            // Track teleport confirm window
            s.pendingTeleportId = tpId;
            s.pendingTeleportSentMs = now;
            s.log("S→C_TP", "id=" + tpId
                + " pos=" + (tpPos == null ? "?" : tpPos.x+","+tpPos.y+","+tpPos.z));

            // V9 SETBACK: nếu player đang di chuyển (moveCount đủ) → đây là rubber-band
            if (s.moveCount.get() > 10) {
                long sinceLastMove = now - s.lastMoveTime;
                // Setback thật xảy ra trong vòng 500ms sau move → không phải spawn TP
                if (sinceLastMove < 500) {
                    s.setbackCount.incrementAndGet();
                    // Đo khoảng cách giữa 2 setback liên tiếp
                    long sinceLastSetback = now - s.lastSetbackMs;
                    if (s.lastSetbackMs > 0) {
                        s.setbackIntervals.offer(sinceLastSetback);
                    }
                    s.lastSetbackMs = now;
                    s.flag("SETBACK", String.format(
                        "count=%d sinceMove=%dms sinceLastSetback=%dms",
                        s.setbackCount.get(), sinceLastMove,
                        s.lastSetbackMs > 0 ? sinceLastSetback : -1));
                }
            }
        }

        else if (pkt instanceof DisconnectS2CPacket dc) {
            String reason = "unknown";
            try { reason = PktUtil.text(dc); } catch (Exception ignored) {}
            s.flag("AC_KICK", "server kicked: " + reason);
        }

        else if (pkt instanceof EntityStatusS2CPacket status) {
            if (status.getStatus() >= 32) {
                s.unknownPackets.computeIfAbsent("S→C/EntityStatus_"+status.getStatus(),
                    k -> new ClientSession.PktStat()).record(0);
                s.log("S→C_AC_STATUS","status="+status.getStatus()
                    +" entityId="+PktUtil.firstInt(status,-1));
            }
        }

        else if (pkt instanceof CustomPayloadS2CPacket custom) {
            String channel = custom.payload().getId().id().toString();
            s.unknownPackets.computeIfAbsent("S→C/CUSTOM/"+channel,
                k -> new ClientSession.PktStat()).record(0);
            s.log("S→C_CUSTOM","channel="+channel);
        }

        else if (logAllPackets.get()) {
            String name = pkt.getClass().getSimpleName();
            if (!name.startsWith("Block") && !name.startsWith("Chunk")
                && !name.startsWith("Light") && !name.startsWith("Particle")
                && !name.startsWith("GameJoin") && !name.startsWith("PlayerList"))
                s.log("S→C","type="+name);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // MOVEMENT HANDLER
    // ══════════════════════════════════════════════════════════════════════════
    private volatile long lastMoveTimeForScaffold = 0;

    private void handleMovement(ClientSession s,
                                double x, double y, double z,
                                float yaw, float pitch, boolean onGround) {
        long now    = System.currentTimeMillis();
        long tDelta = s.lastMoveTime == 0 ? 50 : now - s.lastMoveTime;
        s.lastMoveTime = now;
        lastMoveTimeForScaffold = now;

        if (s.lastX == Double.MIN_VALUE) {
            s.lastX=x; s.lastY=y; s.lastZ=z;
            s.lastYaw=yaw; s.lastPitch=pitch; return;
        }

        double dx = x - s.lastX, dy = y - s.lastY, dz = z - s.lastZ;
        double hDist = Math.sqrt(dx*dx + dz*dz);
        double vDist = dy;

        s.lastX=x; s.lastY=y; s.lastZ=z;
        s.lastYaw=yaw; s.lastPitch=pitch;

        if (hDist > 0.005) { s.speedSamples.offer(hDist); s.recentSpeeds.offer(hDist); }
        if (hDist > s.maxSpeedSeen) s.maxSpeedSeen = hDist;
        if (Math.abs(vDist) > s.maxDeltaYSeen) s.maxDeltaYSeen = Math.abs(vDist);

        if (tDelta > 2000 && hDist > 3.0 && s.moveCount.get() > 20)
            s.flag("BLINK","tDelta="+tDelta+"ms hDist="+String.format("%.4f",hDist));

        if (!onGround) s.airTicks.incrementAndGet();
        else s.airTicks.set(0);

        // V9: KB_TIMING — đo accept window từ velocity packet đến move này
        if (s.pendingKbReceivedMs > 0) {
            long acceptWindowMs = now - s.pendingKbReceivedMs;
            // Chỉ record nếu player thực sự phản ứng (hDist > threshold nhỏ)
            // và trong window hợp lý (< 2000ms)
            if (acceptWindowMs < 2000 && s.pendingKbMag > 0.05) {
                s.kbAcceptWindows.offer(acceptWindowMs);
                // Flag nếu accept window quá nhanh (< 20ms) → có thể bypass
                if (acceptWindowMs < 20 && hDist < s.pendingKbMag * 0.3) {
                    s.velocityBypassCount.incrementAndGet();
                    s.flag("VELOCITY_BYPASS", String.format(
                        "acceptWindow=%dms expected_hMag=%.4f actual=%.4f",
                        acceptWindowMs, s.pendingKbMag, hDist));
                } else {
                    s.log("KB_ACCEPT", "window="+acceptWindowMs+"ms hMag="+
                        String.format("%.4f",s.pendingKbMag)+" actual="+String.format("%.4f",hDist));
                }
            }
            s.pendingKbReceivedMs = 0;
            s.pendingKbMag = 0;
            s.pendingVelocity = null;
        }

        // Existing velocity bypass (V8 logic retained as fallback)
        ClientSession.PendingVelocity pv = s.pendingVelocity;
        if (pv != null && s.pendingKbReceivedMs == 0) { // avoid double-check
            long sinceVel = now - pv.receivedMs();
            if (sinceVel < 500) {
                double expectedH = pv.hMag();
                long avgPing = getAvgPing(s);
                if (expectedH > 0.15 && avgPing < 300) {
                    double ratio = hDist / Math.max(expectedH, 0.001);
                    if (ratio < 0.30) {
                        s.velocityBypassCount.incrementAndGet();
                        s.flag("VELOCITY_BYPASS", String.format(
                            "expected=%.4f actual=%.4f ratio=%.2f ping=%dms",
                            expectedH, hDist, ratio, avgPing));
                    }
                }
            }
            s.pendingVelocity = null;
        }

        if (hDist > speedThreshold.get()) {
            s.flaggedSpeeds.offer(hDist);
            s.flag("SPEED", String.format("hDist=%.4f bpt tDelta=%dms", hDist, tDelta));
        }

        int air = s.airTicks.get();
        if (air > 20 && vDist > 0.03 && hDist < 2.5)
            s.flag("FLY_MOVE","airTicks="+air+" vDist="+String.format("%.4f",vDist));

        if (hDist > 5.0 && tDelta < 500)
            s.flag("CLIP","hDist="+String.format("%.4f",hDist)+" phase/clip");

        if (tDelta > 0 && tDelta < 30 && s.moveCount.get() > 40)
            s.flag("TIMER","tDelta="+tDelta+"ms (>"+(1000/tDelta)+" pps)");

        if (logAllPackets.get())
            s.log("MOVE", String.format("x=%.3f y=%.3f z=%.3f hDist=%.4f vDist=%.4f air=%d tDelta=%dms",
                x, y, z, hDist, vDist, air, tDelta));
    }

    // ══════════════════════════════════════════════════════════════════════════
    // V9: GCD ROTATION HANDLER
    // Grim và nhiều AC khác check GCD (Greatest Common Divisor) của yaw/pitch deltas.
    // Vanilla mouse input có GCD dương ~0.15° do sensitivity rounding.
    // Aimbot/smooth-aim thường có GCD = 0 hoặc rất nhỏ (<0.01°).
    // Đo GCD → biết server đang check pattern nào → advice cho rotation module.
    // ══════════════════════════════════════════════════════════════════════════
    private void handleRotation(ClientSession s, float yaw, float pitch) {
        long now = System.currentTimeMillis();

        // Snap-aim check (unchanged from V8)
        if (s.lastRotTime > 0) {
            long dt = now - s.lastRotTime;
            if (dt > 0 && dt < 100) {
                float dyaw   = Math.abs(yaw   - s.lastRotYaw);
                float dpitch = Math.abs(pitch - s.lastRotPitch);
                if (dyaw > 180) dyaw = 360 - dyaw;
                if (dyaw > 90 || dpitch > 90) {
                    s.snapAimCount.incrementAndGet();
                    s.flag("SNAP_AIM", String.format(
                        "dyaw=%.1f dpitch=%.1f dt=%dms count=%d",
                        dyaw, dpitch, dt, s.snapAimCount.get()));
                }

                // V9: GCD collection — only collect small-delta rotations
                // Large snaps are aimbot artifacts, not useful for GCD measurement
                if (dyaw > 0.001f && dyaw < 10f) {
                    // Store as integer millidegrees to avoid float precision issues
                    int dyawMd  = Math.round(dyaw  * 1000f);
                    int dpitchMd = Math.round(dpitch * 1000f);
                    if (dyawMd > 0)   s.gcdYawSamples.offer(dyawMd);
                    if (dpitchMd > 0) s.gcdPitchSamples.offer(dpitchMd);
                }
            }
        }
        s.lastRotTime  = now;
        s.lastRotYaw   = yaw;
        s.lastRotPitch = pitch;
    }

    /** Compute GCD of two integers (Euclidean). */
    private static int gcd(int a, int b) {
        while (b != 0) { int t=b; b=a%b; a=t; }
        return a;
    }

    /** Compute GCD of a list of integers — returns the GCD of all values. */
    private static int listGcd(List<Integer> vals) {
        if (vals.isEmpty()) return 0;
        int g = vals.get(0);
        for (int i = 1; i < vals.size(); i++) g = gcd(g, vals.get(i));
        return g;
    }

    // ── Surround ──────────────────────────────────────────────────────────────
    private void checkSurround(ClientSession s, long now, int bx, int bz) {
        int nearby = 0;
        for (int i = 0; i < 8; i++)
            if (now - surroundTs[i] < 100
                && Math.abs(surroundX[i]-bx) <= 1
                && Math.abs(surroundZ[i]-bz) <= 1) nearby++;
        if (nearby >= 4)
            s.flag("SURROUND","4+ blocks near ("+bx+","+bz+") within 100ms");
    }

    private long getAvgPing(ClientSession s) {
        List<Long> samples = s.pingSamples.snapshot();
        if (samples.isEmpty()) return 50L;
        return (long) samples.stream().mapToLong(l->l).average().orElse(50L);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SESSION MANAGEMENT
    // ══════════════════════════════════════════════════════════════════════════
    private void startSession() {
        ClientSession old = session;
        if (old != null) old.close();
        var mc = MinecraftClient.getInstance();
        String name = mc.player != null ? mc.player.getName().getString() : "unknown";
        try { Files.createDirectories(EXPORT_ROOT); } catch (IOException e) { e.printStackTrace(); }
        session = new ClientSession(name, EXPORT_ROOT);
        chatInfo("§aSession V9 bắt đầu — §f" + name);
    }

    private static void chatInfo(String msg) {
        MinecraftClient.getInstance().execute(
            () -> ChatUtils.infoPrefix("ACCollector", "%s", msg));
    }
    private static void chatError(String msg) {
        MinecraftClient.getInstance().execute(
            () -> ChatUtils.errorPrefix("ACCollector", "%s", msg));
    }

    public void onPenCommand() {
        ClientSession s = session;
        if (s == null) { chatError("Chưa có session nào đang chạy!"); return; }
        dumpReportAsync(s);
    }

    private void dumpReportAsync(ClientSession s) {
        Thread.ofVirtual().name("acv9-export").start(() -> {
            try { doExport(s); }
            catch (Exception e) { e.printStackTrace(); chatError("Export lỗi: "+e.getMessage()); }
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    // EXPORT
    // ══════════════════════════════════════════════════════════════════════════
    private void doExport(ClientSession s) throws IOException {
        Files.createDirectories(s.sessionDir);
        JsonObject report = buildReport(s);

        Path jsonOut = s.sessionDir.resolve("snapshot.json");
        Files.writeString(jsonOut, gson.toJson(report), StandardCharsets.UTF_8,
            StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

        JsonObject summary = report.getAsJsonObject("raid_bypass_summary");
        String txt = buildTxt(s, summary);
        Path txtOut = s.sessionDir.resolve("bypass_config.txt");
        Files.writeString(txtOut, txt, StandardCharsets.UTF_8,
            StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

        s.flush();
        chatInfo("§a✔ §fFlags=" + s.flagCount.get()
            + " Pkts=" + s.totalPackets.get()
            + " UnknownAC=" + s.unknownPackets.size()
            + " VelBypass=" + s.velocityBypassCount.get()
            + " Setbacks=" + s.setbackCount.get());
        chatInfo("§7Saved → " + txtOut.toAbsolutePath());
    }

    // ══════════════════════════════════════════════════════════════════════════
    // REPORT BUILDER
    // ══════════════════════════════════════════════════════════════════════════
    private JsonObject buildReport(ClientSession s) {
        JsonObject r = new JsonObject();
        r.addProperty("player",          s.playerName);
        r.addProperty("session_ms",      System.currentTimeMillis() - s.sessionStartMs);
        r.addProperty("total_packets",   s.totalPackets.get());
        r.addProperty("move_packets",    s.moveCount.get());
        r.addProperty("flag_count",      s.flagCount.get());
        r.addProperty("peak_pps",        s.peakPps());
        r.addProperty("velocity_bypass", s.velocityBypassCount.get());
        r.addProperty("teleport_bypass", s.teleportBypassCount.get());
        r.addProperty("snap_aim_count",  s.snapAimCount.get());
        r.addProperty("scaffold_count",  s.scaffoldCount.get());
        r.addProperty("setback_count",   s.setbackCount.get()); // V9

        r.add("ping",         buildPing(s));
        r.add("speed",        buildSpeed(s));
        r.add("dig_timing",   buildTiming(s.digDeltas,    "block break delay"));
        r.add("place_timing", buildTiming(s.placeDeltas,  "placement delay"));
        r.add("attack_timing",buildTiming(s.attackDeltas, "attack gap"));
        r.add("item_use",     buildTiming(s.itemUseDeltas,"item use gap"));

        // V9: KB timing block
        r.add("kb_timing", buildKbTiming(s));

        // V9: Setback block
        r.add("setback", buildSetback(s));

        // V9: GCD rotation block
        r.add("rotation_gcd", buildGcd(s));

        JsonObject unknowns = new JsonObject();
        s.unknownPackets.forEach((name, stat) -> {
            JsonObject p = new JsonObject();
            p.addProperty("occurrences", stat.count.get());
            p.addProperty("modal_size",  stat.modalSize());
            p.addProperty("advice",      "Track/spoof type=" + name);
            unknowns.add(name, p);
        });
        r.add("unknown_packets", unknowns);

        JsonArray flags = new JsonArray();
        s.flagLog.snapshot().forEach(flags::add);
        r.add("flags", flags);

        r.add("raid_bypass_summary", buildSummary(r, s));
        return r;
    }

    // ── V9: KB timing block ───────────────────────────────────────────────────
    // Đo thời gian từ server gửi EntityVelocityUpdate đến client gửi PlayerMove tiếp theo.
    // Đây là "KB accept window" thật — dùng để set velocity accept delay trong bypass module.
    private JsonObject buildKbTiming(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Long> arr = s.kbAcceptWindows.snapshot();
        if (arr.isEmpty()) {
            o.addProperty("note","Chưa đủ KB samples — cần bị đánh KB ít nhất 5 lần");
            return o;
        }
        long min  = arr.stream().mapToLong(l->l).min().orElse(0);
        long max  = arr.stream().mapToLong(l->l).max().orElse(0);
        long avg  = (long) arr.stream().mapToLong(l->l).average().orElse(0);
        long med  = arr.stream().sorted().collect(java.util.stream.Collectors.toList())
                       .get(arr.size()/2);
        o.addProperty("min_accept_window_ms", min);
        o.addProperty("max_accept_window_ms", max);
        o.addProperty("avg_accept_window_ms", avg);
        o.addProperty("median_accept_window_ms", med);
        o.addProperty("samples", arr.size());
        // Advice: safe accept window = median + 20ms buffer
        long safeWindow = med + 20;
        o.addProperty("safe_accept_window_ms", safeWindow);
        o.addProperty("confidence", arr.size() >= 10 ? "high" : arr.size() >= 3 ? "medium" : "low");
        o.addProperty("bypass_advice",
            "Set velocity accept window <= " + safeWindow + "ms after receiving KB packet");
        return o;
    }

    // ── V9: Setback block ─────────────────────────────────────────────────────
    // PlayerPositionLookS2CPacket sau movement = rubber-band/setback.
    // Đo tần suất → biết server có setback hay chỉ flag.
    // Nếu setback_count = 0 sau nhiều flags → server chỉ flag, không setback → an toàn hơn.
    private JsonObject buildSetback(ClientSession s) {
        JsonObject o = new JsonObject();
        o.addProperty("setback_count", s.setbackCount.get());
        List<Long> intervals = s.setbackIntervals.snapshot();
        if (!intervals.isEmpty()) {
            long minInterval = intervals.stream().mapToLong(l->l).min().orElse(0);
            long avgInterval = (long) intervals.stream().mapToLong(l->l).average().orElse(0);
            o.addProperty("min_interval_ms", minInterval);
            o.addProperty("avg_interval_ms", avgInterval);
            o.addProperty("samples", intervals.size());
            // Advice
            if (s.setbackCount.get() == 0) {
                o.addProperty("ac_behavior","NO_SETBACK — server flags only, no rubber-band");
                o.addProperty("bypass_advice","Safe: server does not setback on flags");
            } else if (minInterval < 100) {
                o.addProperty("ac_behavior","AGGRESSIVE_SETBACK — setbacks < 100ms apart");
                o.addProperty("bypass_advice","Setback every ~"+avgInterval+"ms — keep movements below threshold");
            } else {
                o.addProperty("ac_behavior","NORMAL_SETBACK — standard rubber-band");
                o.addProperty("bypass_advice","Setback every ~"+avgInterval+"ms — normal AC behavior");
            }
        } else if (s.setbackCount.get() == 0) {
            o.addProperty("ac_behavior","NO_SETBACK — no PlayerPositionLook during movement");
            o.addProperty("bypass_advice","Server does not setback — flag-only AC or lenient");
        } else {
            o.addProperty("ac_behavior","SETBACK_DETECTED");
        }
        return o;
    }

    // ── V9: GCD rotation block ────────────────────────────────────────────────
    // GCD của yaw delta (millidegrees) → fingerprint rotation algorithm.
    // Vanilla: GCD ~150-500 mdeg (sensitivity rounding artifact).
    // Aimbot: GCD = 1 hoặc 0 (perfect precision).
    // Grim GCD check: flags when gcd < ~100 mdeg consistently.
    private JsonObject buildGcd(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Integer> yawSamples   = s.gcdYawSamples.snapshot();
        List<Integer> pitchSamples = s.gcdPitchSamples.snapshot();

        if (yawSamples.isEmpty()) {
            o.addProperty("note","Chưa đủ rotation samples — cần nhìn xung quanh nhiều hơn");
            return o;
        }

        int gcdYaw   = listGcd(yawSamples);
        int gcdPitch = pitchSamples.isEmpty() ? 0 : listGcd(pitchSamples);

        // Convert back to degrees
        double gcdYawDeg   = gcdYaw   / 1000.0;
        double gcdPitchDeg = gcdPitch / 1000.0;

        o.addProperty("gcd_yaw_mdeg",   gcdYaw);
        o.addProperty("gcd_pitch_mdeg", gcdPitch);
        o.addProperty("gcd_yaw_deg",    gcdYawDeg);
        o.addProperty("gcd_pitch_deg",  gcdPitchDeg);
        o.addProperty("yaw_samples",    yawSamples.size());
        o.addProperty("pitch_samples",  pitchSamples.size());

        // Fingerprint
        String fingerprint;
        if (gcdYaw <= 1) {
            fingerprint = "PERFECT_PRECISION — aimbot/macro detected, GCD=0/1 mdeg";
            o.addProperty("bypass_advice",
                "Rotation too precise — add GCD noise >= 150 mdeg to bypass Grim GCD check");
        } else if (gcdYaw < 100) {
            fingerprint = "LOW_GCD — suspicious, may flag Grim GCD check";
            o.addProperty("bypass_advice",
                "GCD low (" + gcdYaw + " mdeg) — increase rotation step size or add sensitivity simulation");
        } else if (gcdYaw < 500) {
            fingerprint = "NORMAL_VANILLA — GCD in vanilla range, likely safe";
            o.addProperty("bypass_advice",
                "GCD normal (" + gcdYaw + " mdeg) — rotation should pass Grim GCD check");
        } else {
            fingerprint = "HIGH_GCD — large steps, could flag angular check on strict servers";
            o.addProperty("bypass_advice",
                "GCD high (" + gcdYaw + " mdeg) — lower rotation speed or sensitivity");
        }
        o.addProperty("fingerprint", fingerprint);
        return o;
    }

    // ── Existing report helpers (unchanged from V8) ───────────────────────────
    private JsonObject buildPing(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Long> arr = s.pingSamples.snapshot();
        if (arr.isEmpty()) return o;
        o.addProperty("min_ms",  arr.stream().mapToLong(l->l).min().orElse(0));
        o.addProperty("max_ms",  arr.stream().mapToLong(l->l).max().orElse(0));
        o.addProperty("avg_ms",  (long) arr.stream().mapToLong(l->l).average().orElse(0));
        o.addProperty("samples", arr.size());
        return o;
    }

    private JsonObject buildSpeed(ClientSession s) {
        JsonObject o = new JsonObject();
        List<Double> all     = s.speedSamples.snapshot();
        List<Double> flagged = s.flaggedSpeeds.snapshot();
        if (!all.isEmpty()) {
            o.addProperty("max_seen",    all.stream().mapToDouble(d->d).max().orElse(0));
            o.addProperty("avg_all",     all.stream().mapToDouble(d->d).average().orElse(0));
            o.addProperty("avg_recent_60",
                s.recentSpeeds.snapshot().stream().mapToDouble(d->d).average().orElse(0));
        }
        if (!flagged.isEmpty()) {
            double minFlagged = flagged.stream().mapToDouble(d->d).min().orElse(0);
            double safeCap    = Math.max(0.1, minFlagged - 0.03);
            o.addProperty("min_flagged",   minFlagged);
            o.addProperty("safe_cap",      safeCap);
            o.addProperty("bypass_advice", "Set speed < " +
                String.format("%.4f", safeCap) + " bpt");
        } else {
            o.addProperty("safe_cap", 0.5);
            o.addProperty("bypass_advice",
                "No SPEED flags — lower speed-threshold setting and retry");
        }
        o.addProperty("flag_threshold", speedThreshold.get());
        return o;
    }

    private JsonObject buildTiming(ClientSession.BoundedDeque<Long> deque, String label) {
        JsonObject o = new JsonObject();
        List<Long> arr = deque.snapshot();
        if (arr.isEmpty()) return o;
        long min  = arr.stream().mapToLong(l->l).min().orElse(0);
        long avg  = (long) arr.stream().mapToLong(l->l).average().orElse(0);
        long safe = min + 5;
        o.addProperty("min_flagged_ms", min);
        o.addProperty("avg_ms",         avg);
        o.addProperty("safe_delay_ms",  safe);
        o.addProperty("samples",        arr.size());
        o.addProperty("confidence",     arr.size()>=10?"high":arr.size()>=3?"medium":"low");
        o.addProperty("bypass_advice",  "Set " + label + " >= " + safe + "ms");
        return o;
    }

    private JsonObject buildSummary(JsonObject r, ClientSession s) {
        JsonObject sum = new JsonObject();
        StringBuilder advice = new StringBuilder();
        JsonObject spd = r.getAsJsonObject("speed");
        if (spd.has("safe_cap"))
            advice.append("SPEED: cap=")
                  .append(String.format("%.4f", spd.get("safe_cap").getAsDouble()))
                  .append(" bpt | ");
        appendTiming(advice, r.getAsJsonObject("dig_timing"),    "MINE");
        appendTiming(advice, r.getAsJsonObject("place_timing"),  "PLACE");
        appendTiming(advice, r.getAsJsonObject("attack_timing"), "ATTACK");
        JsonObject ping = r.getAsJsonObject("ping");
        if (ping.has("avg_ms"))
            advice.append("PING avg=").append(ping.get("avg_ms").getAsLong()).append("ms");
        // V9: thêm KB + setback + GCD vào summary
        JsonObject kb = r.getAsJsonObject("kb_timing");
        if (kb.has("safe_accept_window_ms"))
            advice.append(" | KB_WINDOW: ").append(kb.get("safe_accept_window_ms").getAsLong()).append("ms");
        JsonObject setback = r.getAsJsonObject("setback");
        if (setback.has("ac_behavior"))
            advice.append(" | SETBACK: ").append(setback.get("ac_behavior").getAsString());
        JsonObject gcd = r.getAsJsonObject("rotation_gcd");
        if (gcd.has("gcd_yaw_mdeg"))
            advice.append(" | GCD_YAW: ").append(gcd.get("gcd_yaw_mdeg").getAsInt()).append("mdeg");

        sum.addProperty("module_config",             advice.toString());
        sum.addProperty("unknown_ac_packets",        s.unknownPackets.size());
        sum.addProperty("velocity_bypass_possible",  s.velocityBypassCount.get() > 0);
        sum.addProperty("teleport_bypass_seen",      s.teleportBypassCount.get() > 0);
        sum.addProperty("aimbot_snap_count",         s.snapAimCount.get());
        sum.addProperty("scaffold_detected",         s.scaffoldCount.get() > 10);
        sum.addProperty("setback_behavior",          s.setbackCount.get() == 0
            ? "NO_SETBACK" : "SETBACKS=" + s.setbackCount.get());
        sum.addProperty("gcd_yaw_mdeg",              s.gcdYawSamples.isEmpty() ? -1
            : listGcd(s.gcdYawSamples.snapshot()));
        sum.addProperty("ready",
            (System.currentTimeMillis() - s.sessionStartMs) > 30_000
            && s.totalPackets.get() > 200
            && s.flagCount.get() > 0);
        return sum;
    }

    private void appendTiming(StringBuilder sb, JsonObject block, String label) {
        if (block != null && block.has("safe_delay_ms"))
            sb.append(label).append(": delay=")
              .append(block.get("safe_delay_ms").getAsLong()).append("ms | ");
    }

    private String buildTxt(ClientSession s, JsonObject sum) {
        return "=== ACCollector V9 Meteor ===\n"
            + "Player:               " + s.playerName + "\n"
            + "Session:              " + s.sessionStartStr + "\n"
            + "Total Packets:        " + s.totalPackets.get() + "\n"
            + "Total Flags:          " + s.flagCount.get() + "\n"
            + "Peak PPS:             " + s.peakPps() + "\n"
            + "Velocity Bypass:      " + s.velocityBypassCount.get() + "\n"
            + "Teleport Bypass:      " + s.teleportBypassCount.get() + "\n"
            + "Snap-Aim Count:       " + s.snapAimCount.get() + "\n"
            + "Scaffold Count:       " + s.scaffoldCount.get() + "\n"
            + "Setback Count:        " + s.setbackCount.get() + "\n"
            + "Unknown AC Packets:   " + s.unknownPackets.size() + "\n"
            + "\nModule Config:\n  " + sum.get("module_config").getAsString() + "\n"
            + "\nReady for module build: " + sum.get("ready").getAsBoolean() + "\n";
    }
}